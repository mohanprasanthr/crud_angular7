INFO - 2019-07-20 07:01:14 --> Config Class Initialized
INFO - 2019-07-20 07:01:14 --> Hooks Class Initialized
DEBUG - 2019-07-20 07:01:14 --> UTF-8 Support Enabled
INFO - 2019-07-20 07:01:14 --> Utf8 Class Initialized
INFO - 2019-07-20 07:01:14 --> URI Class Initialized
DEBUG - 2019-07-20 07:01:14 --> No URI present. Default controller set.
INFO - 2019-07-20 07:01:14 --> Router Class Initialized
INFO - 2019-07-20 07:01:14 --> Output Class Initialized
INFO - 2019-07-20 07:01:14 --> Security Class Initialized
DEBUG - 2019-07-20 07:01:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 07:01:14 --> Input Class Initialized
INFO - 2019-07-20 07:01:14 --> Language Class Initialized
INFO - 2019-07-20 07:01:14 --> Loader Class Initialized
INFO - 2019-07-20 07:01:14 --> Database Driver Class Initialized
INFO - 2019-07-20 07:01:14 --> Controller Class Initialized
INFO - 2019-07-20 07:01:14 --> Model "Product" initialized
INFO - 2019-07-20 07:01:14 --> File loaded: /opt/lampp/htdocs/mautic_ci_product/application/views/welcome_message.php
INFO - 2019-07-20 07:01:14 --> Final output sent to browser
DEBUG - 2019-07-20 07:01:14 --> Total execution time: 0.1374
INFO - 2019-07-20 09:16:35 --> Config Class Initialized
INFO - 2019-07-20 09:16:35 --> Hooks Class Initialized
DEBUG - 2019-07-20 09:16:35 --> UTF-8 Support Enabled
INFO - 2019-07-20 09:16:35 --> Utf8 Class Initialized
INFO - 2019-07-20 09:16:35 --> URI Class Initialized
DEBUG - 2019-07-20 09:16:35 --> No URI present. Default controller set.
INFO - 2019-07-20 09:16:35 --> Router Class Initialized
INFO - 2019-07-20 09:16:35 --> Output Class Initialized
INFO - 2019-07-20 09:16:36 --> Security Class Initialized
DEBUG - 2019-07-20 09:16:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 09:16:36 --> Input Class Initialized
INFO - 2019-07-20 09:16:36 --> Language Class Initialized
INFO - 2019-07-20 09:16:36 --> Loader Class Initialized
INFO - 2019-07-20 09:16:36 --> Database Driver Class Initialized
ERROR - 2019-07-20 09:16:36 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /opt/lampp/htdocs/mautic_ci_product/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2019-07-20 09:16:36 --> Unable to connect to the database
INFO - 2019-07-20 09:16:37 --> Language file loaded: language/english/db_lang.php
INFO - 2019-07-20 09:16:42 --> Config Class Initialized
INFO - 2019-07-20 09:16:42 --> Hooks Class Initialized
DEBUG - 2019-07-20 09:16:42 --> UTF-8 Support Enabled
INFO - 2019-07-20 09:16:42 --> Utf8 Class Initialized
INFO - 2019-07-20 09:16:42 --> URI Class Initialized
DEBUG - 2019-07-20 09:16:42 --> No URI present. Default controller set.
INFO - 2019-07-20 09:16:42 --> Router Class Initialized
INFO - 2019-07-20 09:16:42 --> Output Class Initialized
INFO - 2019-07-20 09:16:42 --> Security Class Initialized
DEBUG - 2019-07-20 09:16:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 09:16:42 --> Input Class Initialized
INFO - 2019-07-20 09:16:42 --> Language Class Initialized
INFO - 2019-07-20 09:16:42 --> Loader Class Initialized
INFO - 2019-07-20 09:16:42 --> Database Driver Class Initialized
INFO - 2019-07-20 09:16:42 --> Controller Class Initialized
INFO - 2019-07-20 09:16:42 --> Model "Product" initialized
INFO - 2019-07-20 09:16:42 --> File loaded: /opt/lampp/htdocs/mautic_ci_product/application/views/welcome_message.php
INFO - 2019-07-20 09:16:42 --> Final output sent to browser
DEBUG - 2019-07-20 09:16:42 --> Total execution time: 0.0959
INFO - 2019-07-20 09:16:46 --> Config Class Initialized
INFO - 2019-07-20 09:16:46 --> Hooks Class Initialized
DEBUG - 2019-07-20 09:16:46 --> UTF-8 Support Enabled
INFO - 2019-07-20 09:16:46 --> Utf8 Class Initialized
INFO - 2019-07-20 09:16:46 --> URI Class Initialized
DEBUG - 2019-07-20 09:16:46 --> No URI present. Default controller set.
INFO - 2019-07-20 09:16:46 --> Router Class Initialized
INFO - 2019-07-20 09:16:46 --> Output Class Initialized
INFO - 2019-07-20 09:16:46 --> Security Class Initialized
DEBUG - 2019-07-20 09:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 09:16:46 --> Input Class Initialized
INFO - 2019-07-20 09:16:46 --> Language Class Initialized
INFO - 2019-07-20 09:16:46 --> Loader Class Initialized
INFO - 2019-07-20 09:16:46 --> Database Driver Class Initialized
INFO - 2019-07-20 09:16:46 --> Controller Class Initialized
INFO - 2019-07-20 09:16:46 --> Model "Product" initialized
INFO - 2019-07-20 09:16:46 --> File loaded: /opt/lampp/htdocs/mautic_ci_product/application/views/welcome_message.php
INFO - 2019-07-20 09:16:46 --> Final output sent to browser
DEBUG - 2019-07-20 09:16:46 --> Total execution time: 0.0186
INFO - 2019-07-20 09:24:30 --> Config Class Initialized
INFO - 2019-07-20 09:24:30 --> Hooks Class Initialized
DEBUG - 2019-07-20 09:24:30 --> UTF-8 Support Enabled
INFO - 2019-07-20 09:24:30 --> Utf8 Class Initialized
INFO - 2019-07-20 09:24:30 --> URI Class Initialized
INFO - 2019-07-20 09:24:30 --> Router Class Initialized
INFO - 2019-07-20 09:24:30 --> Output Class Initialized
INFO - 2019-07-20 09:24:30 --> Security Class Initialized
DEBUG - 2019-07-20 09:24:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 09:24:30 --> Input Class Initialized
INFO - 2019-07-20 09:24:30 --> Language Class Initialized
INFO - 2019-07-20 09:24:30 --> Loader Class Initialized
INFO - 2019-07-20 09:24:30 --> Database Driver Class Initialized
INFO - 2019-07-20 09:24:30 --> Controller Class Initialized
INFO - 2019-07-20 09:24:30 --> Model "Product" initialized
INFO - 2019-07-20 09:24:30 --> Final output sent to browser
DEBUG - 2019-07-20 09:24:30 --> Total execution time: 0.6039
INFO - 2019-07-20 09:24:30 --> Config Class Initialized
INFO - 2019-07-20 09:24:30 --> Hooks Class Initialized
DEBUG - 2019-07-20 09:24:30 --> UTF-8 Support Enabled
INFO - 2019-07-20 09:24:30 --> Utf8 Class Initialized
INFO - 2019-07-20 09:24:30 --> URI Class Initialized
INFO - 2019-07-20 09:24:30 --> Router Class Initialized
INFO - 2019-07-20 09:24:30 --> Output Class Initialized
INFO - 2019-07-20 09:24:30 --> Security Class Initialized
DEBUG - 2019-07-20 09:24:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 09:24:30 --> Input Class Initialized
INFO - 2019-07-20 09:24:30 --> Language Class Initialized
INFO - 2019-07-20 09:24:30 --> Loader Class Initialized
INFO - 2019-07-20 09:24:30 --> Database Driver Class Initialized
INFO - 2019-07-20 09:24:30 --> Controller Class Initialized
INFO - 2019-07-20 09:24:30 --> Model "Product" initialized
INFO - 2019-07-20 09:24:31 --> Final output sent to browser
DEBUG - 2019-07-20 09:24:31 --> Total execution time: 0.3495
INFO - 2019-07-20 09:26:49 --> Config Class Initialized
INFO - 2019-07-20 09:26:49 --> Hooks Class Initialized
DEBUG - 2019-07-20 09:26:49 --> UTF-8 Support Enabled
INFO - 2019-07-20 09:26:49 --> Utf8 Class Initialized
INFO - 2019-07-20 09:26:49 --> URI Class Initialized
INFO - 2019-07-20 09:26:49 --> Router Class Initialized
INFO - 2019-07-20 09:26:49 --> Output Class Initialized
INFO - 2019-07-20 09:26:49 --> Security Class Initialized
DEBUG - 2019-07-20 09:26:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 09:26:49 --> Input Class Initialized
INFO - 2019-07-20 09:26:49 --> Language Class Initialized
INFO - 2019-07-20 09:26:49 --> Loader Class Initialized
INFO - 2019-07-20 09:26:49 --> Database Driver Class Initialized
INFO - 2019-07-20 09:26:49 --> Controller Class Initialized
INFO - 2019-07-20 09:26:49 --> Model "Product" initialized
INFO - 2019-07-20 09:26:49 --> Final output sent to browser
DEBUG - 2019-07-20 09:26:49 --> Total execution time: 0.0179
INFO - 2019-07-20 09:26:49 --> Config Class Initialized
INFO - 2019-07-20 09:26:49 --> Hooks Class Initialized
DEBUG - 2019-07-20 09:26:49 --> UTF-8 Support Enabled
INFO - 2019-07-20 09:26:49 --> Utf8 Class Initialized
INFO - 2019-07-20 09:26:49 --> URI Class Initialized
INFO - 2019-07-20 09:26:49 --> Router Class Initialized
INFO - 2019-07-20 09:26:49 --> Output Class Initialized
INFO - 2019-07-20 09:26:49 --> Security Class Initialized
DEBUG - 2019-07-20 09:26:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 09:26:49 --> Input Class Initialized
INFO - 2019-07-20 09:26:49 --> Language Class Initialized
INFO - 2019-07-20 09:26:49 --> Loader Class Initialized
INFO - 2019-07-20 09:26:49 --> Database Driver Class Initialized
INFO - 2019-07-20 09:26:49 --> Controller Class Initialized
INFO - 2019-07-20 09:26:49 --> Model "Product" initialized
INFO - 2019-07-20 09:26:49 --> Final output sent to browser
DEBUG - 2019-07-20 09:26:49 --> Total execution time: 0.1930
INFO - 2019-07-20 09:27:18 --> Config Class Initialized
INFO - 2019-07-20 09:27:18 --> Hooks Class Initialized
DEBUG - 2019-07-20 09:27:18 --> UTF-8 Support Enabled
INFO - 2019-07-20 09:27:18 --> Utf8 Class Initialized
INFO - 2019-07-20 09:27:18 --> URI Class Initialized
INFO - 2019-07-20 09:27:18 --> Router Class Initialized
INFO - 2019-07-20 09:27:18 --> Output Class Initialized
INFO - 2019-07-20 09:27:18 --> Security Class Initialized
DEBUG - 2019-07-20 09:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 09:27:18 --> Input Class Initialized
INFO - 2019-07-20 09:27:18 --> Language Class Initialized
INFO - 2019-07-20 09:27:18 --> Loader Class Initialized
INFO - 2019-07-20 09:27:18 --> Database Driver Class Initialized
INFO - 2019-07-20 09:27:18 --> Controller Class Initialized
INFO - 2019-07-20 09:27:18 --> Model "Product" initialized
INFO - 2019-07-20 09:27:18 --> Final output sent to browser
DEBUG - 2019-07-20 09:27:18 --> Total execution time: 0.0235
INFO - 2019-07-20 09:27:18 --> Config Class Initialized
INFO - 2019-07-20 09:27:18 --> Hooks Class Initialized
DEBUG - 2019-07-20 09:27:18 --> UTF-8 Support Enabled
INFO - 2019-07-20 09:27:18 --> Utf8 Class Initialized
INFO - 2019-07-20 09:27:18 --> URI Class Initialized
INFO - 2019-07-20 09:27:18 --> Router Class Initialized
INFO - 2019-07-20 09:27:18 --> Output Class Initialized
INFO - 2019-07-20 09:27:18 --> Security Class Initialized
DEBUG - 2019-07-20 09:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 09:27:18 --> Input Class Initialized
INFO - 2019-07-20 09:27:18 --> Language Class Initialized
INFO - 2019-07-20 09:27:18 --> Loader Class Initialized
INFO - 2019-07-20 09:27:18 --> Database Driver Class Initialized
INFO - 2019-07-20 09:27:18 --> Controller Class Initialized
INFO - 2019-07-20 09:27:18 --> Model "Product" initialized
INFO - 2019-07-20 09:27:18 --> Final output sent to browser
DEBUG - 2019-07-20 09:27:18 --> Total execution time: 0.1169
INFO - 2019-07-20 09:28:33 --> Config Class Initialized
INFO - 2019-07-20 09:28:33 --> Hooks Class Initialized
DEBUG - 2019-07-20 09:28:33 --> UTF-8 Support Enabled
INFO - 2019-07-20 09:28:33 --> Utf8 Class Initialized
INFO - 2019-07-20 09:28:33 --> URI Class Initialized
INFO - 2019-07-20 09:28:33 --> Router Class Initialized
INFO - 2019-07-20 09:28:33 --> Output Class Initialized
INFO - 2019-07-20 09:28:33 --> Security Class Initialized
DEBUG - 2019-07-20 09:28:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 09:28:33 --> Input Class Initialized
INFO - 2019-07-20 09:28:33 --> Language Class Initialized
INFO - 2019-07-20 09:28:33 --> Loader Class Initialized
INFO - 2019-07-20 09:28:33 --> Database Driver Class Initialized
INFO - 2019-07-20 09:28:33 --> Controller Class Initialized
INFO - 2019-07-20 09:28:33 --> Model "Product" initialized
INFO - 2019-07-20 09:28:33 --> Final output sent to browser
DEBUG - 2019-07-20 09:28:33 --> Total execution time: 0.0253
INFO - 2019-07-20 09:28:33 --> Config Class Initialized
INFO - 2019-07-20 09:28:33 --> Hooks Class Initialized
DEBUG - 2019-07-20 09:28:33 --> UTF-8 Support Enabled
INFO - 2019-07-20 09:28:33 --> Utf8 Class Initialized
INFO - 2019-07-20 09:28:33 --> URI Class Initialized
INFO - 2019-07-20 09:28:33 --> Router Class Initialized
INFO - 2019-07-20 09:28:33 --> Output Class Initialized
INFO - 2019-07-20 09:28:33 --> Security Class Initialized
DEBUG - 2019-07-20 09:28:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 09:28:33 --> Input Class Initialized
INFO - 2019-07-20 09:28:33 --> Language Class Initialized
INFO - 2019-07-20 09:28:33 --> Loader Class Initialized
INFO - 2019-07-20 09:28:33 --> Database Driver Class Initialized
INFO - 2019-07-20 09:28:33 --> Controller Class Initialized
INFO - 2019-07-20 09:28:33 --> Model "Product" initialized
INFO - 2019-07-20 09:28:33 --> Final output sent to browser
DEBUG - 2019-07-20 09:28:33 --> Total execution time: 0.1249
INFO - 2019-07-20 09:29:40 --> Config Class Initialized
INFO - 2019-07-20 09:29:40 --> Hooks Class Initialized
DEBUG - 2019-07-20 09:29:40 --> UTF-8 Support Enabled
INFO - 2019-07-20 09:29:40 --> Utf8 Class Initialized
INFO - 2019-07-20 09:29:40 --> URI Class Initialized
INFO - 2019-07-20 09:29:40 --> Router Class Initialized
INFO - 2019-07-20 09:29:40 --> Output Class Initialized
INFO - 2019-07-20 09:29:40 --> Security Class Initialized
DEBUG - 2019-07-20 09:29:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 09:29:40 --> Input Class Initialized
INFO - 2019-07-20 09:29:40 --> Language Class Initialized
INFO - 2019-07-20 09:29:40 --> Loader Class Initialized
INFO - 2019-07-20 09:29:40 --> Database Driver Class Initialized
INFO - 2019-07-20 09:29:40 --> Controller Class Initialized
INFO - 2019-07-20 09:29:40 --> Model "Product" initialized
INFO - 2019-07-20 09:29:40 --> Final output sent to browser
DEBUG - 2019-07-20 09:29:40 --> Total execution time: 0.0187
INFO - 2019-07-20 09:29:40 --> Config Class Initialized
INFO - 2019-07-20 09:29:40 --> Hooks Class Initialized
DEBUG - 2019-07-20 09:29:40 --> UTF-8 Support Enabled
INFO - 2019-07-20 09:29:40 --> Utf8 Class Initialized
INFO - 2019-07-20 09:29:40 --> URI Class Initialized
INFO - 2019-07-20 09:29:40 --> Router Class Initialized
INFO - 2019-07-20 09:29:40 --> Output Class Initialized
INFO - 2019-07-20 09:29:40 --> Security Class Initialized
DEBUG - 2019-07-20 09:29:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 09:29:40 --> Input Class Initialized
INFO - 2019-07-20 09:29:40 --> Language Class Initialized
INFO - 2019-07-20 09:29:40 --> Loader Class Initialized
INFO - 2019-07-20 09:29:40 --> Database Driver Class Initialized
INFO - 2019-07-20 09:29:40 --> Controller Class Initialized
INFO - 2019-07-20 09:29:40 --> Model "Product" initialized
INFO - 2019-07-20 09:29:40 --> Final output sent to browser
DEBUG - 2019-07-20 09:29:40 --> Total execution time: 0.1054
INFO - 2019-07-20 09:30:04 --> Config Class Initialized
INFO - 2019-07-20 09:30:04 --> Hooks Class Initialized
DEBUG - 2019-07-20 09:30:04 --> UTF-8 Support Enabled
INFO - 2019-07-20 09:30:04 --> Utf8 Class Initialized
INFO - 2019-07-20 09:30:04 --> URI Class Initialized
INFO - 2019-07-20 09:30:04 --> Router Class Initialized
INFO - 2019-07-20 09:30:04 --> Output Class Initialized
INFO - 2019-07-20 09:30:04 --> Security Class Initialized
DEBUG - 2019-07-20 09:30:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 09:30:04 --> Input Class Initialized
INFO - 2019-07-20 09:30:04 --> Language Class Initialized
INFO - 2019-07-20 09:30:04 --> Loader Class Initialized
INFO - 2019-07-20 09:30:04 --> Database Driver Class Initialized
INFO - 2019-07-20 09:30:04 --> Controller Class Initialized
INFO - 2019-07-20 09:30:04 --> Model "Product" initialized
INFO - 2019-07-20 09:30:04 --> Final output sent to browser
DEBUG - 2019-07-20 09:30:04 --> Total execution time: 0.0187
INFO - 2019-07-20 09:30:04 --> Config Class Initialized
INFO - 2019-07-20 09:30:04 --> Hooks Class Initialized
DEBUG - 2019-07-20 09:30:04 --> UTF-8 Support Enabled
INFO - 2019-07-20 09:30:04 --> Utf8 Class Initialized
INFO - 2019-07-20 09:30:04 --> URI Class Initialized
INFO - 2019-07-20 09:30:04 --> Router Class Initialized
INFO - 2019-07-20 09:30:04 --> Output Class Initialized
INFO - 2019-07-20 09:30:04 --> Security Class Initialized
DEBUG - 2019-07-20 09:30:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 09:30:04 --> Input Class Initialized
INFO - 2019-07-20 09:30:04 --> Language Class Initialized
INFO - 2019-07-20 09:30:04 --> Loader Class Initialized
INFO - 2019-07-20 09:30:04 --> Database Driver Class Initialized
INFO - 2019-07-20 09:30:04 --> Controller Class Initialized
INFO - 2019-07-20 09:30:04 --> Model "Product" initialized
INFO - 2019-07-20 09:30:04 --> Final output sent to browser
DEBUG - 2019-07-20 09:30:04 --> Total execution time: 0.1131
INFO - 2019-07-20 09:44:22 --> Config Class Initialized
INFO - 2019-07-20 09:44:22 --> Hooks Class Initialized
DEBUG - 2019-07-20 09:44:22 --> UTF-8 Support Enabled
INFO - 2019-07-20 09:44:22 --> Utf8 Class Initialized
INFO - 2019-07-20 09:44:22 --> URI Class Initialized
INFO - 2019-07-20 09:44:22 --> Router Class Initialized
INFO - 2019-07-20 09:44:22 --> Output Class Initialized
INFO - 2019-07-20 09:44:22 --> Security Class Initialized
DEBUG - 2019-07-20 09:44:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 09:44:22 --> Input Class Initialized
INFO - 2019-07-20 09:44:22 --> Language Class Initialized
INFO - 2019-07-20 09:44:22 --> Loader Class Initialized
INFO - 2019-07-20 09:44:22 --> Database Driver Class Initialized
INFO - 2019-07-20 09:44:22 --> Controller Class Initialized
INFO - 2019-07-20 09:44:22 --> Model "Product" initialized
INFO - 2019-07-20 09:44:22 --> Final output sent to browser
DEBUG - 2019-07-20 09:44:22 --> Total execution time: 0.6252
INFO - 2019-07-20 09:44:22 --> Config Class Initialized
INFO - 2019-07-20 09:44:22 --> Hooks Class Initialized
DEBUG - 2019-07-20 09:44:22 --> UTF-8 Support Enabled
INFO - 2019-07-20 09:44:22 --> Utf8 Class Initialized
INFO - 2019-07-20 09:44:22 --> URI Class Initialized
INFO - 2019-07-20 09:44:22 --> Router Class Initialized
INFO - 2019-07-20 09:44:22 --> Output Class Initialized
INFO - 2019-07-20 09:44:22 --> Security Class Initialized
DEBUG - 2019-07-20 09:44:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 09:44:22 --> Input Class Initialized
INFO - 2019-07-20 09:44:22 --> Language Class Initialized
INFO - 2019-07-20 09:44:22 --> Loader Class Initialized
INFO - 2019-07-20 09:44:22 --> Database Driver Class Initialized
INFO - 2019-07-20 09:44:22 --> Controller Class Initialized
INFO - 2019-07-20 09:44:22 --> Model "Product" initialized
INFO - 2019-07-20 09:44:23 --> Final output sent to browser
DEBUG - 2019-07-20 09:44:23 --> Total execution time: 0.7096
INFO - 2019-07-20 09:45:05 --> Config Class Initialized
INFO - 2019-07-20 09:45:05 --> Hooks Class Initialized
DEBUG - 2019-07-20 09:45:05 --> UTF-8 Support Enabled
INFO - 2019-07-20 09:45:05 --> Utf8 Class Initialized
INFO - 2019-07-20 09:45:05 --> URI Class Initialized
INFO - 2019-07-20 09:45:05 --> Router Class Initialized
INFO - 2019-07-20 09:45:05 --> Output Class Initialized
INFO - 2019-07-20 09:45:05 --> Security Class Initialized
DEBUG - 2019-07-20 09:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 09:45:05 --> Input Class Initialized
INFO - 2019-07-20 09:45:05 --> Language Class Initialized
INFO - 2019-07-20 09:45:05 --> Loader Class Initialized
INFO - 2019-07-20 09:45:05 --> Database Driver Class Initialized
INFO - 2019-07-20 09:45:05 --> Controller Class Initialized
INFO - 2019-07-20 09:45:05 --> Model "Product" initialized
INFO - 2019-07-20 09:45:05 --> Final output sent to browser
DEBUG - 2019-07-20 09:45:05 --> Total execution time: 0.0195
INFO - 2019-07-20 09:45:05 --> Config Class Initialized
INFO - 2019-07-20 09:45:05 --> Hooks Class Initialized
DEBUG - 2019-07-20 09:45:05 --> UTF-8 Support Enabled
INFO - 2019-07-20 09:45:05 --> Utf8 Class Initialized
INFO - 2019-07-20 09:45:05 --> URI Class Initialized
INFO - 2019-07-20 09:45:05 --> Router Class Initialized
INFO - 2019-07-20 09:45:05 --> Output Class Initialized
INFO - 2019-07-20 09:45:05 --> Security Class Initialized
DEBUG - 2019-07-20 09:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 09:45:05 --> Input Class Initialized
INFO - 2019-07-20 09:45:05 --> Language Class Initialized
INFO - 2019-07-20 09:45:05 --> Loader Class Initialized
INFO - 2019-07-20 09:45:05 --> Database Driver Class Initialized
INFO - 2019-07-20 09:45:05 --> Controller Class Initialized
INFO - 2019-07-20 09:45:05 --> Model "Product" initialized
INFO - 2019-07-20 09:45:05 --> Final output sent to browser
DEBUG - 2019-07-20 09:45:05 --> Total execution time: 0.0200
INFO - 2019-07-20 09:45:27 --> Config Class Initialized
INFO - 2019-07-20 09:45:27 --> Hooks Class Initialized
DEBUG - 2019-07-20 09:45:27 --> UTF-8 Support Enabled
INFO - 2019-07-20 09:45:27 --> Utf8 Class Initialized
INFO - 2019-07-20 09:45:27 --> URI Class Initialized
INFO - 2019-07-20 09:45:27 --> Router Class Initialized
INFO - 2019-07-20 09:45:27 --> Output Class Initialized
INFO - 2019-07-20 09:45:27 --> Security Class Initialized
DEBUG - 2019-07-20 09:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 09:45:27 --> Input Class Initialized
INFO - 2019-07-20 09:45:27 --> Language Class Initialized
INFO - 2019-07-20 09:45:27 --> Loader Class Initialized
INFO - 2019-07-20 09:45:27 --> Database Driver Class Initialized
INFO - 2019-07-20 09:45:27 --> Controller Class Initialized
INFO - 2019-07-20 09:45:27 --> Model "Product" initialized
INFO - 2019-07-20 09:45:27 --> Final output sent to browser
DEBUG - 2019-07-20 09:45:27 --> Total execution time: 0.0225
INFO - 2019-07-20 09:45:27 --> Config Class Initialized
INFO - 2019-07-20 09:45:27 --> Hooks Class Initialized
DEBUG - 2019-07-20 09:45:27 --> UTF-8 Support Enabled
INFO - 2019-07-20 09:45:27 --> Utf8 Class Initialized
INFO - 2019-07-20 09:45:27 --> URI Class Initialized
INFO - 2019-07-20 09:45:27 --> Router Class Initialized
INFO - 2019-07-20 09:45:27 --> Output Class Initialized
INFO - 2019-07-20 09:45:27 --> Security Class Initialized
DEBUG - 2019-07-20 09:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 09:45:27 --> Input Class Initialized
INFO - 2019-07-20 09:45:27 --> Language Class Initialized
INFO - 2019-07-20 09:45:27 --> Loader Class Initialized
INFO - 2019-07-20 09:45:27 --> Database Driver Class Initialized
INFO - 2019-07-20 09:45:27 --> Controller Class Initialized
INFO - 2019-07-20 09:45:27 --> Model "Product" initialized
INFO - 2019-07-20 09:45:27 --> Final output sent to browser
DEBUG - 2019-07-20 09:45:27 --> Total execution time: 0.0210
INFO - 2019-07-20 10:24:59 --> Config Class Initialized
INFO - 2019-07-20 10:24:59 --> Hooks Class Initialized
DEBUG - 2019-07-20 10:24:59 --> UTF-8 Support Enabled
INFO - 2019-07-20 10:24:59 --> Utf8 Class Initialized
INFO - 2019-07-20 10:24:59 --> URI Class Initialized
INFO - 2019-07-20 10:24:59 --> Router Class Initialized
INFO - 2019-07-20 10:24:59 --> Output Class Initialized
INFO - 2019-07-20 10:24:59 --> Security Class Initialized
DEBUG - 2019-07-20 10:24:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 10:24:59 --> Input Class Initialized
INFO - 2019-07-20 10:24:59 --> Language Class Initialized
INFO - 2019-07-20 10:24:59 --> Loader Class Initialized
INFO - 2019-07-20 10:25:00 --> Database Driver Class Initialized
INFO - 2019-07-20 10:25:00 --> Controller Class Initialized
INFO - 2019-07-20 10:25:00 --> Model "Product" initialized
INFO - 2019-07-20 10:25:00 --> Final output sent to browser
DEBUG - 2019-07-20 10:25:00 --> Total execution time: 0.1507
INFO - 2019-07-20 10:25:00 --> Config Class Initialized
INFO - 2019-07-20 10:25:00 --> Hooks Class Initialized
DEBUG - 2019-07-20 10:25:00 --> UTF-8 Support Enabled
INFO - 2019-07-20 10:25:00 --> Utf8 Class Initialized
INFO - 2019-07-20 10:25:00 --> URI Class Initialized
INFO - 2019-07-20 10:25:00 --> Router Class Initialized
INFO - 2019-07-20 10:25:00 --> Output Class Initialized
INFO - 2019-07-20 10:25:00 --> Security Class Initialized
DEBUG - 2019-07-20 10:25:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 10:25:00 --> Input Class Initialized
INFO - 2019-07-20 10:25:00 --> Language Class Initialized
INFO - 2019-07-20 10:25:00 --> Loader Class Initialized
INFO - 2019-07-20 10:25:00 --> Database Driver Class Initialized
INFO - 2019-07-20 10:25:00 --> Controller Class Initialized
INFO - 2019-07-20 10:25:00 --> Model "Product" initialized
INFO - 2019-07-20 10:25:00 --> Final output sent to browser
DEBUG - 2019-07-20 10:25:00 --> Total execution time: 0.0194
INFO - 2019-07-20 10:25:06 --> Config Class Initialized
INFO - 2019-07-20 10:25:06 --> Hooks Class Initialized
DEBUG - 2019-07-20 10:25:06 --> UTF-8 Support Enabled
INFO - 2019-07-20 10:25:06 --> Utf8 Class Initialized
INFO - 2019-07-20 10:25:06 --> URI Class Initialized
INFO - 2019-07-20 10:25:06 --> Router Class Initialized
INFO - 2019-07-20 10:25:06 --> Output Class Initialized
INFO - 2019-07-20 10:25:06 --> Security Class Initialized
DEBUG - 2019-07-20 10:25:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 10:25:06 --> Input Class Initialized
INFO - 2019-07-20 10:25:06 --> Language Class Initialized
INFO - 2019-07-20 10:25:06 --> Loader Class Initialized
INFO - 2019-07-20 10:25:06 --> Database Driver Class Initialized
INFO - 2019-07-20 10:25:06 --> Controller Class Initialized
INFO - 2019-07-20 10:25:06 --> Model "Product" initialized
INFO - 2019-07-20 10:25:06 --> Final output sent to browser
DEBUG - 2019-07-20 10:25:06 --> Total execution time: 0.0204
INFO - 2019-07-20 10:25:06 --> Config Class Initialized
INFO - 2019-07-20 10:25:06 --> Hooks Class Initialized
DEBUG - 2019-07-20 10:25:06 --> UTF-8 Support Enabled
INFO - 2019-07-20 10:25:06 --> Utf8 Class Initialized
INFO - 2019-07-20 10:25:06 --> URI Class Initialized
INFO - 2019-07-20 10:25:06 --> Router Class Initialized
INFO - 2019-07-20 10:25:06 --> Output Class Initialized
INFO - 2019-07-20 10:25:06 --> Security Class Initialized
DEBUG - 2019-07-20 10:25:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 10:25:06 --> Input Class Initialized
INFO - 2019-07-20 10:25:06 --> Language Class Initialized
INFO - 2019-07-20 10:25:06 --> Loader Class Initialized
INFO - 2019-07-20 10:25:06 --> Database Driver Class Initialized
INFO - 2019-07-20 10:25:06 --> Controller Class Initialized
INFO - 2019-07-20 10:25:06 --> Model "Product" initialized
INFO - 2019-07-20 10:25:06 --> Final output sent to browser
DEBUG - 2019-07-20 10:25:06 --> Total execution time: 0.0243
INFO - 2019-07-20 10:27:31 --> Config Class Initialized
INFO - 2019-07-20 10:27:31 --> Hooks Class Initialized
DEBUG - 2019-07-20 10:27:31 --> UTF-8 Support Enabled
INFO - 2019-07-20 10:27:31 --> Utf8 Class Initialized
INFO - 2019-07-20 10:27:31 --> URI Class Initialized
INFO - 2019-07-20 10:27:31 --> Router Class Initialized
INFO - 2019-07-20 10:27:31 --> Output Class Initialized
INFO - 2019-07-20 10:27:31 --> Security Class Initialized
DEBUG - 2019-07-20 10:27:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 10:27:31 --> Input Class Initialized
INFO - 2019-07-20 10:27:31 --> Language Class Initialized
INFO - 2019-07-20 10:27:31 --> Loader Class Initialized
INFO - 2019-07-20 10:27:31 --> Database Driver Class Initialized
INFO - 2019-07-20 10:27:31 --> Controller Class Initialized
INFO - 2019-07-20 10:27:31 --> Model "Product" initialized
INFO - 2019-07-20 10:27:31 --> Final output sent to browser
DEBUG - 2019-07-20 10:27:31 --> Total execution time: 0.3553
INFO - 2019-07-20 10:27:31 --> Config Class Initialized
INFO - 2019-07-20 10:27:31 --> Hooks Class Initialized
DEBUG - 2019-07-20 10:27:31 --> UTF-8 Support Enabled
INFO - 2019-07-20 10:27:31 --> Utf8 Class Initialized
INFO - 2019-07-20 10:27:31 --> URI Class Initialized
INFO - 2019-07-20 10:27:31 --> Router Class Initialized
INFO - 2019-07-20 10:27:31 --> Output Class Initialized
INFO - 2019-07-20 10:27:31 --> Security Class Initialized
DEBUG - 2019-07-20 10:27:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 10:27:31 --> Input Class Initialized
INFO - 2019-07-20 10:27:31 --> Language Class Initialized
INFO - 2019-07-20 10:27:31 --> Loader Class Initialized
INFO - 2019-07-20 10:27:31 --> Database Driver Class Initialized
INFO - 2019-07-20 10:27:31 --> Controller Class Initialized
INFO - 2019-07-20 10:27:31 --> Model "Product" initialized
INFO - 2019-07-20 10:27:31 --> Final output sent to browser
DEBUG - 2019-07-20 10:27:31 --> Total execution time: 0.0928
INFO - 2019-07-20 10:27:37 --> Config Class Initialized
INFO - 2019-07-20 10:27:37 --> Hooks Class Initialized
DEBUG - 2019-07-20 10:27:37 --> UTF-8 Support Enabled
INFO - 2019-07-20 10:27:37 --> Utf8 Class Initialized
INFO - 2019-07-20 10:27:37 --> URI Class Initialized
INFO - 2019-07-20 10:27:37 --> Router Class Initialized
INFO - 2019-07-20 10:27:37 --> Output Class Initialized
INFO - 2019-07-20 10:27:37 --> Security Class Initialized
DEBUG - 2019-07-20 10:27:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 10:27:37 --> Input Class Initialized
INFO - 2019-07-20 10:27:37 --> Language Class Initialized
INFO - 2019-07-20 10:27:37 --> Loader Class Initialized
INFO - 2019-07-20 10:27:37 --> Database Driver Class Initialized
INFO - 2019-07-20 10:27:37 --> Controller Class Initialized
INFO - 2019-07-20 10:27:37 --> Model "Product" initialized
INFO - 2019-07-20 10:27:37 --> Final output sent to browser
DEBUG - 2019-07-20 10:27:37 --> Total execution time: 0.0186
INFO - 2019-07-20 10:27:37 --> Config Class Initialized
INFO - 2019-07-20 10:27:37 --> Hooks Class Initialized
DEBUG - 2019-07-20 10:27:37 --> UTF-8 Support Enabled
INFO - 2019-07-20 10:27:37 --> Utf8 Class Initialized
INFO - 2019-07-20 10:27:37 --> URI Class Initialized
INFO - 2019-07-20 10:27:37 --> Router Class Initialized
INFO - 2019-07-20 10:27:37 --> Output Class Initialized
INFO - 2019-07-20 10:27:37 --> Security Class Initialized
DEBUG - 2019-07-20 10:27:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 10:27:37 --> Input Class Initialized
INFO - 2019-07-20 10:27:37 --> Language Class Initialized
INFO - 2019-07-20 10:27:37 --> Loader Class Initialized
INFO - 2019-07-20 10:27:37 --> Database Driver Class Initialized
INFO - 2019-07-20 10:27:37 --> Controller Class Initialized
INFO - 2019-07-20 10:27:37 --> Model "Product" initialized
INFO - 2019-07-20 10:27:37 --> Final output sent to browser
DEBUG - 2019-07-20 10:27:37 --> Total execution time: 0.0219
INFO - 2019-07-20 10:30:19 --> Config Class Initialized
INFO - 2019-07-20 10:30:19 --> Hooks Class Initialized
DEBUG - 2019-07-20 10:30:19 --> UTF-8 Support Enabled
INFO - 2019-07-20 10:30:19 --> Utf8 Class Initialized
INFO - 2019-07-20 10:30:19 --> URI Class Initialized
INFO - 2019-07-20 10:30:19 --> Router Class Initialized
INFO - 2019-07-20 10:30:19 --> Output Class Initialized
INFO - 2019-07-20 10:30:19 --> Security Class Initialized
DEBUG - 2019-07-20 10:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 10:30:19 --> Input Class Initialized
INFO - 2019-07-20 10:30:19 --> Language Class Initialized
INFO - 2019-07-20 10:30:19 --> Loader Class Initialized
INFO - 2019-07-20 10:30:19 --> Database Driver Class Initialized
INFO - 2019-07-20 10:30:19 --> Controller Class Initialized
INFO - 2019-07-20 10:30:19 --> Model "Product" initialized
INFO - 2019-07-20 10:30:19 --> Final output sent to browser
DEBUG - 2019-07-20 10:30:19 --> Total execution time: 0.0139
INFO - 2019-07-20 10:30:19 --> Config Class Initialized
INFO - 2019-07-20 10:30:19 --> Hooks Class Initialized
DEBUG - 2019-07-20 10:30:19 --> UTF-8 Support Enabled
INFO - 2019-07-20 10:30:19 --> Utf8 Class Initialized
INFO - 2019-07-20 10:30:19 --> URI Class Initialized
INFO - 2019-07-20 10:30:19 --> Router Class Initialized
INFO - 2019-07-20 10:30:19 --> Output Class Initialized
INFO - 2019-07-20 10:30:19 --> Security Class Initialized
DEBUG - 2019-07-20 10:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 10:30:19 --> Input Class Initialized
INFO - 2019-07-20 10:30:19 --> Language Class Initialized
INFO - 2019-07-20 10:30:19 --> Loader Class Initialized
INFO - 2019-07-20 10:30:19 --> Database Driver Class Initialized
INFO - 2019-07-20 10:30:19 --> Controller Class Initialized
INFO - 2019-07-20 10:30:19 --> Model "Product" initialized
INFO - 2019-07-20 10:30:19 --> Final output sent to browser
DEBUG - 2019-07-20 10:30:19 --> Total execution time: 0.0174
INFO - 2019-07-20 10:30:56 --> Config Class Initialized
INFO - 2019-07-20 10:30:56 --> Hooks Class Initialized
DEBUG - 2019-07-20 10:30:56 --> UTF-8 Support Enabled
INFO - 2019-07-20 10:30:56 --> Utf8 Class Initialized
INFO - 2019-07-20 10:30:56 --> URI Class Initialized
INFO - 2019-07-20 10:30:56 --> Router Class Initialized
INFO - 2019-07-20 10:30:56 --> Output Class Initialized
INFO - 2019-07-20 10:30:56 --> Security Class Initialized
DEBUG - 2019-07-20 10:30:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 10:30:56 --> Input Class Initialized
INFO - 2019-07-20 10:30:56 --> Language Class Initialized
INFO - 2019-07-20 10:30:56 --> Loader Class Initialized
INFO - 2019-07-20 10:30:56 --> Database Driver Class Initialized
INFO - 2019-07-20 10:30:56 --> Controller Class Initialized
INFO - 2019-07-20 10:30:56 --> Model "Product" initialized
INFO - 2019-07-20 10:30:56 --> Final output sent to browser
DEBUG - 2019-07-20 10:30:56 --> Total execution time: 0.0154
INFO - 2019-07-20 10:30:56 --> Config Class Initialized
INFO - 2019-07-20 10:30:56 --> Hooks Class Initialized
DEBUG - 2019-07-20 10:30:56 --> UTF-8 Support Enabled
INFO - 2019-07-20 10:30:56 --> Utf8 Class Initialized
INFO - 2019-07-20 10:30:56 --> URI Class Initialized
INFO - 2019-07-20 10:30:56 --> Router Class Initialized
INFO - 2019-07-20 10:30:56 --> Output Class Initialized
INFO - 2019-07-20 10:30:56 --> Security Class Initialized
DEBUG - 2019-07-20 10:30:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 10:30:56 --> Input Class Initialized
INFO - 2019-07-20 10:30:56 --> Language Class Initialized
INFO - 2019-07-20 10:30:56 --> Loader Class Initialized
INFO - 2019-07-20 10:30:56 --> Database Driver Class Initialized
INFO - 2019-07-20 10:30:56 --> Controller Class Initialized
INFO - 2019-07-20 10:30:56 --> Model "Product" initialized
INFO - 2019-07-20 10:30:56 --> Final output sent to browser
DEBUG - 2019-07-20 10:30:56 --> Total execution time: 0.0214
INFO - 2019-07-20 10:40:32 --> Config Class Initialized
INFO - 2019-07-20 10:40:32 --> Hooks Class Initialized
DEBUG - 2019-07-20 10:40:32 --> UTF-8 Support Enabled
INFO - 2019-07-20 10:40:32 --> Utf8 Class Initialized
INFO - 2019-07-20 10:40:32 --> URI Class Initialized
INFO - 2019-07-20 10:40:32 --> Router Class Initialized
INFO - 2019-07-20 10:40:32 --> Output Class Initialized
INFO - 2019-07-20 10:40:32 --> Security Class Initialized
DEBUG - 2019-07-20 10:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 10:40:32 --> Input Class Initialized
INFO - 2019-07-20 10:40:32 --> Language Class Initialized
INFO - 2019-07-20 10:40:32 --> Loader Class Initialized
INFO - 2019-07-20 10:40:32 --> Database Driver Class Initialized
INFO - 2019-07-20 10:40:33 --> Controller Class Initialized
INFO - 2019-07-20 10:40:33 --> Model "Product" initialized
INFO - 2019-07-20 10:40:33 --> Final output sent to browser
DEBUG - 2019-07-20 10:40:33 --> Total execution time: 1.2257
INFO - 2019-07-20 10:40:33 --> Config Class Initialized
INFO - 2019-07-20 10:40:33 --> Hooks Class Initialized
DEBUG - 2019-07-20 10:40:33 --> UTF-8 Support Enabled
INFO - 2019-07-20 10:40:33 --> Utf8 Class Initialized
INFO - 2019-07-20 10:40:33 --> URI Class Initialized
INFO - 2019-07-20 10:40:33 --> Router Class Initialized
INFO - 2019-07-20 10:40:33 --> Output Class Initialized
INFO - 2019-07-20 10:40:33 --> Security Class Initialized
DEBUG - 2019-07-20 10:40:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 10:40:33 --> Input Class Initialized
INFO - 2019-07-20 10:40:33 --> Language Class Initialized
INFO - 2019-07-20 10:40:33 --> Loader Class Initialized
INFO - 2019-07-20 10:40:33 --> Database Driver Class Initialized
INFO - 2019-07-20 10:40:33 --> Controller Class Initialized
INFO - 2019-07-20 10:40:33 --> Model "Product" initialized
INFO - 2019-07-20 10:40:33 --> Final output sent to browser
DEBUG - 2019-07-20 10:40:33 --> Total execution time: 0.2096
INFO - 2019-07-20 10:41:30 --> Config Class Initialized
INFO - 2019-07-20 10:41:30 --> Hooks Class Initialized
DEBUG - 2019-07-20 10:41:30 --> UTF-8 Support Enabled
INFO - 2019-07-20 10:41:30 --> Utf8 Class Initialized
INFO - 2019-07-20 10:41:30 --> URI Class Initialized
INFO - 2019-07-20 10:41:30 --> Router Class Initialized
INFO - 2019-07-20 10:41:30 --> Output Class Initialized
INFO - 2019-07-20 10:41:30 --> Security Class Initialized
DEBUG - 2019-07-20 10:41:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 10:41:30 --> Input Class Initialized
INFO - 2019-07-20 10:41:30 --> Language Class Initialized
INFO - 2019-07-20 10:41:30 --> Loader Class Initialized
INFO - 2019-07-20 10:41:30 --> Database Driver Class Initialized
INFO - 2019-07-20 10:41:30 --> Controller Class Initialized
INFO - 2019-07-20 10:41:30 --> Model "Product" initialized
INFO - 2019-07-20 10:41:30 --> Final output sent to browser
DEBUG - 2019-07-20 10:41:30 --> Total execution time: 0.0820
INFO - 2019-07-20 10:41:30 --> Config Class Initialized
INFO - 2019-07-20 10:41:30 --> Hooks Class Initialized
DEBUG - 2019-07-20 10:41:30 --> UTF-8 Support Enabled
INFO - 2019-07-20 10:41:30 --> Utf8 Class Initialized
INFO - 2019-07-20 10:41:30 --> URI Class Initialized
INFO - 2019-07-20 10:41:30 --> Router Class Initialized
INFO - 2019-07-20 10:41:30 --> Output Class Initialized
INFO - 2019-07-20 10:41:30 --> Security Class Initialized
DEBUG - 2019-07-20 10:41:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 10:41:30 --> Input Class Initialized
INFO - 2019-07-20 10:41:30 --> Language Class Initialized
INFO - 2019-07-20 10:41:30 --> Loader Class Initialized
INFO - 2019-07-20 10:41:30 --> Database Driver Class Initialized
INFO - 2019-07-20 10:41:30 --> Controller Class Initialized
INFO - 2019-07-20 10:41:30 --> Model "Product" initialized
INFO - 2019-07-20 10:41:30 --> Final output sent to browser
DEBUG - 2019-07-20 10:41:30 --> Total execution time: 0.1116
INFO - 2019-07-20 10:41:37 --> Config Class Initialized
INFO - 2019-07-20 10:41:37 --> Hooks Class Initialized
DEBUG - 2019-07-20 10:41:37 --> UTF-8 Support Enabled
INFO - 2019-07-20 10:41:37 --> Utf8 Class Initialized
INFO - 2019-07-20 10:41:37 --> URI Class Initialized
INFO - 2019-07-20 10:41:37 --> Router Class Initialized
INFO - 2019-07-20 10:41:37 --> Output Class Initialized
INFO - 2019-07-20 10:41:37 --> Security Class Initialized
DEBUG - 2019-07-20 10:41:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 10:41:37 --> Input Class Initialized
INFO - 2019-07-20 10:41:37 --> Language Class Initialized
INFO - 2019-07-20 10:41:37 --> Loader Class Initialized
INFO - 2019-07-20 10:41:37 --> Database Driver Class Initialized
INFO - 2019-07-20 10:41:37 --> Controller Class Initialized
INFO - 2019-07-20 10:41:37 --> Model "Product" initialized
INFO - 2019-07-20 10:41:37 --> Final output sent to browser
DEBUG - 2019-07-20 10:41:37 --> Total execution time: 0.1324
INFO - 2019-07-20 10:41:37 --> Config Class Initialized
INFO - 2019-07-20 10:41:37 --> Hooks Class Initialized
DEBUG - 2019-07-20 10:41:37 --> UTF-8 Support Enabled
INFO - 2019-07-20 10:41:37 --> Utf8 Class Initialized
INFO - 2019-07-20 10:41:37 --> URI Class Initialized
INFO - 2019-07-20 10:41:37 --> Router Class Initialized
INFO - 2019-07-20 10:41:37 --> Output Class Initialized
INFO - 2019-07-20 10:41:37 --> Security Class Initialized
DEBUG - 2019-07-20 10:41:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 10:41:37 --> Input Class Initialized
INFO - 2019-07-20 10:41:37 --> Language Class Initialized
INFO - 2019-07-20 10:41:37 --> Loader Class Initialized
INFO - 2019-07-20 10:41:37 --> Database Driver Class Initialized
INFO - 2019-07-20 10:41:37 --> Controller Class Initialized
INFO - 2019-07-20 10:41:37 --> Model "Product" initialized
INFO - 2019-07-20 10:41:37 --> Final output sent to browser
DEBUG - 2019-07-20 10:41:37 --> Total execution time: 0.0253
INFO - 2019-07-20 10:47:53 --> Config Class Initialized
INFO - 2019-07-20 10:47:53 --> Hooks Class Initialized
DEBUG - 2019-07-20 10:47:53 --> UTF-8 Support Enabled
INFO - 2019-07-20 10:47:53 --> Utf8 Class Initialized
INFO - 2019-07-20 10:47:53 --> URI Class Initialized
INFO - 2019-07-20 10:47:53 --> Router Class Initialized
INFO - 2019-07-20 10:47:53 --> Output Class Initialized
INFO - 2019-07-20 10:47:53 --> Security Class Initialized
DEBUG - 2019-07-20 10:47:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 10:47:53 --> Input Class Initialized
INFO - 2019-07-20 10:47:53 --> Language Class Initialized
INFO - 2019-07-20 10:47:53 --> Loader Class Initialized
INFO - 2019-07-20 10:47:53 --> Database Driver Class Initialized
INFO - 2019-07-20 10:47:53 --> Controller Class Initialized
INFO - 2019-07-20 10:47:53 --> Model "Product" initialized
INFO - 2019-07-20 10:47:53 --> Final output sent to browser
DEBUG - 2019-07-20 10:47:53 --> Total execution time: 0.0199
INFO - 2019-07-20 10:47:53 --> Config Class Initialized
INFO - 2019-07-20 10:47:53 --> Hooks Class Initialized
DEBUG - 2019-07-20 10:47:53 --> UTF-8 Support Enabled
INFO - 2019-07-20 10:47:53 --> Utf8 Class Initialized
INFO - 2019-07-20 10:47:53 --> URI Class Initialized
INFO - 2019-07-20 10:47:53 --> Router Class Initialized
INFO - 2019-07-20 10:47:53 --> Output Class Initialized
INFO - 2019-07-20 10:47:53 --> Security Class Initialized
DEBUG - 2019-07-20 10:47:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 10:47:53 --> Input Class Initialized
INFO - 2019-07-20 10:47:53 --> Language Class Initialized
INFO - 2019-07-20 10:47:53 --> Loader Class Initialized
INFO - 2019-07-20 10:47:53 --> Database Driver Class Initialized
INFO - 2019-07-20 10:47:53 --> Controller Class Initialized
INFO - 2019-07-20 10:47:53 --> Model "Product" initialized
INFO - 2019-07-20 10:47:53 --> Final output sent to browser
DEBUG - 2019-07-20 10:47:53 --> Total execution time: 0.0319
INFO - 2019-07-20 10:48:00 --> Config Class Initialized
INFO - 2019-07-20 10:48:00 --> Hooks Class Initialized
DEBUG - 2019-07-20 10:48:00 --> UTF-8 Support Enabled
INFO - 2019-07-20 10:48:00 --> Utf8 Class Initialized
INFO - 2019-07-20 10:48:00 --> URI Class Initialized
INFO - 2019-07-20 10:48:00 --> Router Class Initialized
INFO - 2019-07-20 10:48:00 --> Output Class Initialized
INFO - 2019-07-20 10:48:00 --> Security Class Initialized
DEBUG - 2019-07-20 10:48:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 10:48:00 --> Input Class Initialized
INFO - 2019-07-20 10:48:00 --> Language Class Initialized
INFO - 2019-07-20 10:48:00 --> Loader Class Initialized
INFO - 2019-07-20 10:48:00 --> Database Driver Class Initialized
INFO - 2019-07-20 10:48:00 --> Controller Class Initialized
INFO - 2019-07-20 10:48:00 --> Model "Product" initialized
INFO - 2019-07-20 10:48:00 --> Final output sent to browser
DEBUG - 2019-07-20 10:48:00 --> Total execution time: 0.0361
INFO - 2019-07-20 10:48:00 --> Config Class Initialized
INFO - 2019-07-20 10:48:00 --> Hooks Class Initialized
DEBUG - 2019-07-20 10:48:00 --> UTF-8 Support Enabled
INFO - 2019-07-20 10:48:00 --> Utf8 Class Initialized
INFO - 2019-07-20 10:48:00 --> URI Class Initialized
INFO - 2019-07-20 10:48:00 --> Router Class Initialized
INFO - 2019-07-20 10:48:00 --> Output Class Initialized
INFO - 2019-07-20 10:48:00 --> Security Class Initialized
DEBUG - 2019-07-20 10:48:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 10:48:00 --> Input Class Initialized
INFO - 2019-07-20 10:48:00 --> Language Class Initialized
INFO - 2019-07-20 10:48:00 --> Loader Class Initialized
INFO - 2019-07-20 10:48:00 --> Database Driver Class Initialized
INFO - 2019-07-20 10:48:00 --> Controller Class Initialized
INFO - 2019-07-20 10:48:00 --> Model "Product" initialized
INFO - 2019-07-20 10:48:00 --> Final output sent to browser
DEBUG - 2019-07-20 10:48:00 --> Total execution time: 0.0211
INFO - 2019-07-20 10:48:42 --> Config Class Initialized
INFO - 2019-07-20 10:48:42 --> Hooks Class Initialized
DEBUG - 2019-07-20 10:48:42 --> UTF-8 Support Enabled
INFO - 2019-07-20 10:48:42 --> Utf8 Class Initialized
INFO - 2019-07-20 10:48:42 --> URI Class Initialized
INFO - 2019-07-20 10:48:42 --> Router Class Initialized
INFO - 2019-07-20 10:48:42 --> Output Class Initialized
INFO - 2019-07-20 10:48:42 --> Security Class Initialized
DEBUG - 2019-07-20 10:48:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 10:48:42 --> Input Class Initialized
INFO - 2019-07-20 10:48:42 --> Language Class Initialized
INFO - 2019-07-20 10:48:42 --> Loader Class Initialized
INFO - 2019-07-20 10:48:42 --> Database Driver Class Initialized
INFO - 2019-07-20 10:48:42 --> Controller Class Initialized
INFO - 2019-07-20 10:48:42 --> Model "Product" initialized
INFO - 2019-07-20 10:48:42 --> Final output sent to browser
DEBUG - 2019-07-20 10:48:42 --> Total execution time: 0.3296
INFO - 2019-07-20 10:48:42 --> Config Class Initialized
INFO - 2019-07-20 10:48:42 --> Hooks Class Initialized
DEBUG - 2019-07-20 10:48:42 --> UTF-8 Support Enabled
INFO - 2019-07-20 10:48:42 --> Utf8 Class Initialized
INFO - 2019-07-20 10:48:42 --> URI Class Initialized
INFO - 2019-07-20 10:48:42 --> Router Class Initialized
INFO - 2019-07-20 10:48:42 --> Output Class Initialized
INFO - 2019-07-20 10:48:42 --> Security Class Initialized
DEBUG - 2019-07-20 10:48:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 10:48:42 --> Input Class Initialized
INFO - 2019-07-20 10:48:42 --> Language Class Initialized
INFO - 2019-07-20 10:48:42 --> Loader Class Initialized
INFO - 2019-07-20 10:48:42 --> Database Driver Class Initialized
INFO - 2019-07-20 10:48:42 --> Controller Class Initialized
INFO - 2019-07-20 10:48:42 --> Model "Product" initialized
INFO - 2019-07-20 10:48:42 --> Final output sent to browser
DEBUG - 2019-07-20 10:48:42 --> Total execution time: 0.0164
INFO - 2019-07-20 10:49:15 --> Config Class Initialized
INFO - 2019-07-20 10:49:15 --> Hooks Class Initialized
DEBUG - 2019-07-20 10:49:15 --> UTF-8 Support Enabled
INFO - 2019-07-20 10:49:15 --> Utf8 Class Initialized
INFO - 2019-07-20 10:49:15 --> URI Class Initialized
INFO - 2019-07-20 10:49:15 --> Router Class Initialized
INFO - 2019-07-20 10:49:15 --> Output Class Initialized
INFO - 2019-07-20 10:49:15 --> Security Class Initialized
DEBUG - 2019-07-20 10:49:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 10:49:15 --> Input Class Initialized
INFO - 2019-07-20 10:49:15 --> Language Class Initialized
INFO - 2019-07-20 10:49:15 --> Loader Class Initialized
INFO - 2019-07-20 10:49:15 --> Database Driver Class Initialized
INFO - 2019-07-20 10:49:15 --> Controller Class Initialized
INFO - 2019-07-20 10:49:15 --> Model "Product" initialized
INFO - 2019-07-20 10:49:15 --> Final output sent to browser
DEBUG - 2019-07-20 10:49:15 --> Total execution time: 0.0359
INFO - 2019-07-20 10:49:15 --> Config Class Initialized
INFO - 2019-07-20 10:49:15 --> Hooks Class Initialized
DEBUG - 2019-07-20 10:49:15 --> UTF-8 Support Enabled
INFO - 2019-07-20 10:49:15 --> Utf8 Class Initialized
INFO - 2019-07-20 10:49:15 --> URI Class Initialized
INFO - 2019-07-20 10:49:15 --> Router Class Initialized
INFO - 2019-07-20 10:49:15 --> Output Class Initialized
INFO - 2019-07-20 10:49:15 --> Security Class Initialized
DEBUG - 2019-07-20 10:49:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 10:49:15 --> Input Class Initialized
INFO - 2019-07-20 10:49:15 --> Language Class Initialized
INFO - 2019-07-20 10:49:15 --> Loader Class Initialized
INFO - 2019-07-20 10:49:15 --> Database Driver Class Initialized
INFO - 2019-07-20 10:49:15 --> Controller Class Initialized
INFO - 2019-07-20 10:49:15 --> Model "Product" initialized
INFO - 2019-07-20 10:49:15 --> Final output sent to browser
DEBUG - 2019-07-20 10:49:15 --> Total execution time: 0.0161
INFO - 2019-07-20 10:49:21 --> Config Class Initialized
INFO - 2019-07-20 10:49:21 --> Hooks Class Initialized
DEBUG - 2019-07-20 10:49:21 --> UTF-8 Support Enabled
INFO - 2019-07-20 10:49:21 --> Utf8 Class Initialized
INFO - 2019-07-20 10:49:21 --> URI Class Initialized
INFO - 2019-07-20 10:49:21 --> Router Class Initialized
INFO - 2019-07-20 10:49:21 --> Output Class Initialized
INFO - 2019-07-20 10:49:21 --> Security Class Initialized
DEBUG - 2019-07-20 10:49:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 10:49:21 --> Input Class Initialized
INFO - 2019-07-20 10:49:21 --> Language Class Initialized
INFO - 2019-07-20 10:49:21 --> Loader Class Initialized
INFO - 2019-07-20 10:49:21 --> Database Driver Class Initialized
INFO - 2019-07-20 10:49:21 --> Controller Class Initialized
INFO - 2019-07-20 10:49:21 --> Model "Product" initialized
INFO - 2019-07-20 10:49:21 --> Final output sent to browser
DEBUG - 2019-07-20 10:49:21 --> Total execution time: 0.0262
INFO - 2019-07-20 10:49:21 --> Config Class Initialized
INFO - 2019-07-20 10:49:21 --> Hooks Class Initialized
DEBUG - 2019-07-20 10:49:21 --> UTF-8 Support Enabled
INFO - 2019-07-20 10:49:21 --> Utf8 Class Initialized
INFO - 2019-07-20 10:49:21 --> URI Class Initialized
INFO - 2019-07-20 10:49:21 --> Router Class Initialized
INFO - 2019-07-20 10:49:21 --> Output Class Initialized
INFO - 2019-07-20 10:49:21 --> Security Class Initialized
DEBUG - 2019-07-20 10:49:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 10:49:21 --> Input Class Initialized
INFO - 2019-07-20 10:49:21 --> Language Class Initialized
INFO - 2019-07-20 10:49:21 --> Loader Class Initialized
INFO - 2019-07-20 10:49:21 --> Database Driver Class Initialized
INFO - 2019-07-20 10:49:21 --> Controller Class Initialized
INFO - 2019-07-20 10:49:21 --> Model "Product" initialized
INFO - 2019-07-20 10:49:21 --> Final output sent to browser
DEBUG - 2019-07-20 10:49:21 --> Total execution time: 0.0323
INFO - 2019-07-20 10:49:54 --> Config Class Initialized
INFO - 2019-07-20 10:49:54 --> Hooks Class Initialized
DEBUG - 2019-07-20 10:49:54 --> UTF-8 Support Enabled
INFO - 2019-07-20 10:49:54 --> Utf8 Class Initialized
INFO - 2019-07-20 10:49:54 --> URI Class Initialized
INFO - 2019-07-20 10:49:54 --> Router Class Initialized
INFO - 2019-07-20 10:49:54 --> Output Class Initialized
INFO - 2019-07-20 10:49:54 --> Security Class Initialized
DEBUG - 2019-07-20 10:49:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 10:49:54 --> Input Class Initialized
INFO - 2019-07-20 10:49:54 --> Language Class Initialized
INFO - 2019-07-20 10:49:54 --> Loader Class Initialized
INFO - 2019-07-20 10:49:54 --> Database Driver Class Initialized
INFO - 2019-07-20 10:49:54 --> Controller Class Initialized
INFO - 2019-07-20 10:49:54 --> Model "Product" initialized
INFO - 2019-07-20 10:49:54 --> Final output sent to browser
DEBUG - 2019-07-20 10:49:54 --> Total execution time: 0.0184
INFO - 2019-07-20 10:49:54 --> Config Class Initialized
INFO - 2019-07-20 10:49:54 --> Hooks Class Initialized
DEBUG - 2019-07-20 10:49:54 --> UTF-8 Support Enabled
INFO - 2019-07-20 10:49:54 --> Utf8 Class Initialized
INFO - 2019-07-20 10:49:54 --> URI Class Initialized
INFO - 2019-07-20 10:49:54 --> Router Class Initialized
INFO - 2019-07-20 10:49:54 --> Output Class Initialized
INFO - 2019-07-20 10:49:54 --> Security Class Initialized
DEBUG - 2019-07-20 10:49:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 10:49:54 --> Input Class Initialized
INFO - 2019-07-20 10:49:54 --> Language Class Initialized
INFO - 2019-07-20 10:49:54 --> Loader Class Initialized
INFO - 2019-07-20 10:49:54 --> Database Driver Class Initialized
INFO - 2019-07-20 10:49:54 --> Controller Class Initialized
INFO - 2019-07-20 10:49:54 --> Model "Product" initialized
INFO - 2019-07-20 10:49:54 --> Final output sent to browser
DEBUG - 2019-07-20 10:49:54 --> Total execution time: 0.0200
INFO - 2019-07-20 10:50:07 --> Config Class Initialized
INFO - 2019-07-20 10:50:07 --> Hooks Class Initialized
DEBUG - 2019-07-20 10:50:07 --> UTF-8 Support Enabled
INFO - 2019-07-20 10:50:07 --> Utf8 Class Initialized
INFO - 2019-07-20 10:50:07 --> URI Class Initialized
INFO - 2019-07-20 10:50:07 --> Router Class Initialized
INFO - 2019-07-20 10:50:07 --> Output Class Initialized
INFO - 2019-07-20 10:50:07 --> Security Class Initialized
DEBUG - 2019-07-20 10:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 10:50:07 --> Input Class Initialized
INFO - 2019-07-20 10:50:07 --> Language Class Initialized
INFO - 2019-07-20 10:50:07 --> Loader Class Initialized
INFO - 2019-07-20 10:50:07 --> Database Driver Class Initialized
INFO - 2019-07-20 10:50:07 --> Controller Class Initialized
INFO - 2019-07-20 10:50:07 --> Model "Product" initialized
INFO - 2019-07-20 10:50:07 --> Final output sent to browser
DEBUG - 2019-07-20 10:50:07 --> Total execution time: 0.0345
INFO - 2019-07-20 10:50:07 --> Config Class Initialized
INFO - 2019-07-20 10:50:07 --> Hooks Class Initialized
DEBUG - 2019-07-20 10:50:07 --> UTF-8 Support Enabled
INFO - 2019-07-20 10:50:07 --> Utf8 Class Initialized
INFO - 2019-07-20 10:50:07 --> URI Class Initialized
INFO - 2019-07-20 10:50:07 --> Router Class Initialized
INFO - 2019-07-20 10:50:07 --> Output Class Initialized
INFO - 2019-07-20 10:50:07 --> Security Class Initialized
DEBUG - 2019-07-20 10:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 10:50:07 --> Input Class Initialized
INFO - 2019-07-20 10:50:07 --> Language Class Initialized
INFO - 2019-07-20 10:50:07 --> Loader Class Initialized
INFO - 2019-07-20 10:50:07 --> Database Driver Class Initialized
INFO - 2019-07-20 10:50:07 --> Controller Class Initialized
INFO - 2019-07-20 10:50:07 --> Model "Product" initialized
INFO - 2019-07-20 10:50:07 --> Final output sent to browser
DEBUG - 2019-07-20 10:50:07 --> Total execution time: 0.0177
INFO - 2019-07-20 10:50:10 --> Config Class Initialized
INFO - 2019-07-20 10:50:10 --> Hooks Class Initialized
DEBUG - 2019-07-20 10:50:11 --> UTF-8 Support Enabled
INFO - 2019-07-20 10:50:11 --> Utf8 Class Initialized
INFO - 2019-07-20 10:50:11 --> URI Class Initialized
INFO - 2019-07-20 10:50:11 --> Router Class Initialized
INFO - 2019-07-20 10:50:11 --> Output Class Initialized
INFO - 2019-07-20 10:50:11 --> Security Class Initialized
DEBUG - 2019-07-20 10:50:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 10:50:11 --> Input Class Initialized
INFO - 2019-07-20 10:50:11 --> Language Class Initialized
INFO - 2019-07-20 10:50:11 --> Loader Class Initialized
INFO - 2019-07-20 10:50:11 --> Database Driver Class Initialized
INFO - 2019-07-20 10:50:11 --> Controller Class Initialized
INFO - 2019-07-20 10:50:11 --> Model "Product" initialized
INFO - 2019-07-20 10:50:11 --> Final output sent to browser
DEBUG - 2019-07-20 10:50:11 --> Total execution time: 0.0179
INFO - 2019-07-20 10:50:21 --> Config Class Initialized
INFO - 2019-07-20 10:50:21 --> Hooks Class Initialized
DEBUG - 2019-07-20 10:50:21 --> UTF-8 Support Enabled
INFO - 2019-07-20 10:50:21 --> Utf8 Class Initialized
INFO - 2019-07-20 10:50:21 --> URI Class Initialized
INFO - 2019-07-20 10:50:21 --> Router Class Initialized
INFO - 2019-07-20 10:50:21 --> Output Class Initialized
INFO - 2019-07-20 10:50:21 --> Security Class Initialized
DEBUG - 2019-07-20 10:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 10:50:21 --> Input Class Initialized
INFO - 2019-07-20 10:50:21 --> Language Class Initialized
INFO - 2019-07-20 10:50:21 --> Loader Class Initialized
INFO - 2019-07-20 10:50:21 --> Database Driver Class Initialized
INFO - 2019-07-20 10:50:21 --> Controller Class Initialized
INFO - 2019-07-20 10:50:21 --> Model "Product" initialized
INFO - 2019-07-20 10:50:21 --> Final output sent to browser
DEBUG - 2019-07-20 10:50:21 --> Total execution time: 0.0296
INFO - 2019-07-20 10:50:21 --> Config Class Initialized
INFO - 2019-07-20 10:50:21 --> Hooks Class Initialized
DEBUG - 2019-07-20 10:50:21 --> UTF-8 Support Enabled
INFO - 2019-07-20 10:50:21 --> Utf8 Class Initialized
INFO - 2019-07-20 10:50:21 --> URI Class Initialized
INFO - 2019-07-20 10:50:21 --> Router Class Initialized
INFO - 2019-07-20 10:50:21 --> Output Class Initialized
INFO - 2019-07-20 10:50:21 --> Security Class Initialized
DEBUG - 2019-07-20 10:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 10:50:21 --> Input Class Initialized
INFO - 2019-07-20 10:50:21 --> Language Class Initialized
INFO - 2019-07-20 10:50:21 --> Loader Class Initialized
INFO - 2019-07-20 10:50:21 --> Database Driver Class Initialized
INFO - 2019-07-20 10:50:21 --> Controller Class Initialized
INFO - 2019-07-20 10:50:21 --> Model "Product" initialized
INFO - 2019-07-20 10:50:21 --> Final output sent to browser
DEBUG - 2019-07-20 10:50:21 --> Total execution time: 0.0205
INFO - 2019-07-20 10:50:33 --> Config Class Initialized
INFO - 2019-07-20 10:50:33 --> Hooks Class Initialized
DEBUG - 2019-07-20 10:50:33 --> UTF-8 Support Enabled
INFO - 2019-07-20 10:50:33 --> Utf8 Class Initialized
INFO - 2019-07-20 10:50:33 --> URI Class Initialized
INFO - 2019-07-20 10:50:33 --> Router Class Initialized
INFO - 2019-07-20 10:50:33 --> Output Class Initialized
INFO - 2019-07-20 10:50:33 --> Security Class Initialized
DEBUG - 2019-07-20 10:50:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 10:50:33 --> Input Class Initialized
INFO - 2019-07-20 10:50:33 --> Language Class Initialized
INFO - 2019-07-20 10:50:33 --> Loader Class Initialized
INFO - 2019-07-20 10:50:33 --> Database Driver Class Initialized
INFO - 2019-07-20 10:50:33 --> Controller Class Initialized
INFO - 2019-07-20 10:50:33 --> Model "Product" initialized
INFO - 2019-07-20 10:50:33 --> Final output sent to browser
DEBUG - 2019-07-20 10:50:33 --> Total execution time: 0.0160
INFO - 2019-07-20 10:50:33 --> Config Class Initialized
INFO - 2019-07-20 10:50:33 --> Hooks Class Initialized
DEBUG - 2019-07-20 10:50:33 --> UTF-8 Support Enabled
INFO - 2019-07-20 10:50:33 --> Utf8 Class Initialized
INFO - 2019-07-20 10:50:33 --> URI Class Initialized
INFO - 2019-07-20 10:50:33 --> Router Class Initialized
INFO - 2019-07-20 10:50:33 --> Output Class Initialized
INFO - 2019-07-20 10:50:33 --> Security Class Initialized
DEBUG - 2019-07-20 10:50:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 10:50:33 --> Input Class Initialized
INFO - 2019-07-20 10:50:33 --> Language Class Initialized
INFO - 2019-07-20 10:50:33 --> Loader Class Initialized
INFO - 2019-07-20 10:50:33 --> Database Driver Class Initialized
INFO - 2019-07-20 10:50:33 --> Controller Class Initialized
INFO - 2019-07-20 10:50:33 --> Model "Product" initialized
INFO - 2019-07-20 10:50:33 --> Final output sent to browser
DEBUG - 2019-07-20 10:50:33 --> Total execution time: 0.0161
INFO - 2019-07-20 10:55:47 --> Config Class Initialized
INFO - 2019-07-20 10:55:47 --> Hooks Class Initialized
DEBUG - 2019-07-20 10:55:47 --> UTF-8 Support Enabled
INFO - 2019-07-20 10:55:47 --> Utf8 Class Initialized
INFO - 2019-07-20 10:55:47 --> URI Class Initialized
INFO - 2019-07-20 10:55:47 --> Router Class Initialized
INFO - 2019-07-20 10:55:47 --> Output Class Initialized
INFO - 2019-07-20 10:55:47 --> Security Class Initialized
DEBUG - 2019-07-20 10:55:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 10:55:47 --> Input Class Initialized
INFO - 2019-07-20 10:55:47 --> Language Class Initialized
INFO - 2019-07-20 10:55:47 --> Loader Class Initialized
INFO - 2019-07-20 10:55:47 --> Database Driver Class Initialized
INFO - 2019-07-20 10:55:47 --> Controller Class Initialized
INFO - 2019-07-20 10:55:47 --> Model "Product" initialized
INFO - 2019-07-20 10:55:47 --> Final output sent to browser
DEBUG - 2019-07-20 10:55:47 --> Total execution time: 0.7984
INFO - 2019-07-20 10:55:47 --> Config Class Initialized
INFO - 2019-07-20 10:55:47 --> Hooks Class Initialized
DEBUG - 2019-07-20 10:55:47 --> UTF-8 Support Enabled
INFO - 2019-07-20 10:55:47 --> Utf8 Class Initialized
INFO - 2019-07-20 10:55:47 --> URI Class Initialized
INFO - 2019-07-20 10:55:47 --> Router Class Initialized
INFO - 2019-07-20 10:55:47 --> Output Class Initialized
INFO - 2019-07-20 10:55:47 --> Security Class Initialized
DEBUG - 2019-07-20 10:55:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 10:55:47 --> Input Class Initialized
INFO - 2019-07-20 10:55:47 --> Language Class Initialized
INFO - 2019-07-20 10:55:47 --> Loader Class Initialized
INFO - 2019-07-20 10:55:47 --> Database Driver Class Initialized
INFO - 2019-07-20 10:55:47 --> Controller Class Initialized
INFO - 2019-07-20 10:55:47 --> Model "Product" initialized
INFO - 2019-07-20 10:55:48 --> Final output sent to browser
DEBUG - 2019-07-20 10:55:48 --> Total execution time: 0.1720
INFO - 2019-07-20 10:58:48 --> Config Class Initialized
INFO - 2019-07-20 10:58:48 --> Hooks Class Initialized
DEBUG - 2019-07-20 10:58:48 --> UTF-8 Support Enabled
INFO - 2019-07-20 10:58:48 --> Utf8 Class Initialized
INFO - 2019-07-20 10:58:48 --> URI Class Initialized
INFO - 2019-07-20 10:58:48 --> Router Class Initialized
INFO - 2019-07-20 10:58:48 --> Output Class Initialized
INFO - 2019-07-20 10:58:48 --> Security Class Initialized
DEBUG - 2019-07-20 10:58:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 10:58:48 --> Input Class Initialized
INFO - 2019-07-20 10:58:48 --> Language Class Initialized
INFO - 2019-07-20 10:58:48 --> Loader Class Initialized
INFO - 2019-07-20 10:58:48 --> Database Driver Class Initialized
INFO - 2019-07-20 10:58:48 --> Controller Class Initialized
INFO - 2019-07-20 10:58:48 --> Model "Product" initialized
INFO - 2019-07-20 10:58:48 --> Final output sent to browser
DEBUG - 2019-07-20 10:58:48 --> Total execution time: 0.0135
INFO - 2019-07-20 10:58:48 --> Config Class Initialized
INFO - 2019-07-20 10:58:48 --> Hooks Class Initialized
DEBUG - 2019-07-20 10:58:48 --> UTF-8 Support Enabled
INFO - 2019-07-20 10:58:48 --> Utf8 Class Initialized
INFO - 2019-07-20 10:58:48 --> URI Class Initialized
INFO - 2019-07-20 10:58:48 --> Router Class Initialized
INFO - 2019-07-20 10:58:48 --> Output Class Initialized
INFO - 2019-07-20 10:58:48 --> Security Class Initialized
DEBUG - 2019-07-20 10:58:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 10:58:48 --> Input Class Initialized
INFO - 2019-07-20 10:58:48 --> Language Class Initialized
INFO - 2019-07-20 10:58:48 --> Loader Class Initialized
INFO - 2019-07-20 10:58:48 --> Database Driver Class Initialized
INFO - 2019-07-20 10:58:48 --> Controller Class Initialized
INFO - 2019-07-20 10:58:48 --> Model "Product" initialized
INFO - 2019-07-20 10:58:48 --> Final output sent to browser
DEBUG - 2019-07-20 10:58:48 --> Total execution time: 0.0202
INFO - 2019-07-20 10:59:52 --> Config Class Initialized
INFO - 2019-07-20 10:59:52 --> Hooks Class Initialized
DEBUG - 2019-07-20 10:59:52 --> UTF-8 Support Enabled
INFO - 2019-07-20 10:59:52 --> Utf8 Class Initialized
INFO - 2019-07-20 10:59:52 --> URI Class Initialized
INFO - 2019-07-20 10:59:52 --> Router Class Initialized
INFO - 2019-07-20 10:59:52 --> Output Class Initialized
INFO - 2019-07-20 10:59:52 --> Security Class Initialized
DEBUG - 2019-07-20 10:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 10:59:52 --> Input Class Initialized
INFO - 2019-07-20 10:59:52 --> Language Class Initialized
INFO - 2019-07-20 10:59:52 --> Loader Class Initialized
INFO - 2019-07-20 10:59:52 --> Database Driver Class Initialized
INFO - 2019-07-20 10:59:52 --> Controller Class Initialized
INFO - 2019-07-20 10:59:52 --> Model "Product" initialized
INFO - 2019-07-20 10:59:52 --> Final output sent to browser
DEBUG - 2019-07-20 10:59:52 --> Total execution time: 0.0176
INFO - 2019-07-20 10:59:52 --> Config Class Initialized
INFO - 2019-07-20 10:59:52 --> Hooks Class Initialized
DEBUG - 2019-07-20 10:59:52 --> UTF-8 Support Enabled
INFO - 2019-07-20 10:59:52 --> Utf8 Class Initialized
INFO - 2019-07-20 10:59:52 --> URI Class Initialized
INFO - 2019-07-20 10:59:52 --> Router Class Initialized
INFO - 2019-07-20 10:59:52 --> Output Class Initialized
INFO - 2019-07-20 10:59:52 --> Security Class Initialized
DEBUG - 2019-07-20 10:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 10:59:52 --> Input Class Initialized
INFO - 2019-07-20 10:59:52 --> Language Class Initialized
INFO - 2019-07-20 10:59:52 --> Loader Class Initialized
INFO - 2019-07-20 10:59:52 --> Database Driver Class Initialized
INFO - 2019-07-20 10:59:52 --> Controller Class Initialized
INFO - 2019-07-20 10:59:52 --> Model "Product" initialized
INFO - 2019-07-20 10:59:52 --> Final output sent to browser
DEBUG - 2019-07-20 10:59:52 --> Total execution time: 0.0435
INFO - 2019-07-20 10:59:57 --> Config Class Initialized
INFO - 2019-07-20 10:59:57 --> Hooks Class Initialized
DEBUG - 2019-07-20 10:59:57 --> UTF-8 Support Enabled
INFO - 2019-07-20 10:59:57 --> Utf8 Class Initialized
INFO - 2019-07-20 10:59:57 --> URI Class Initialized
INFO - 2019-07-20 10:59:57 --> Router Class Initialized
INFO - 2019-07-20 10:59:57 --> Output Class Initialized
INFO - 2019-07-20 10:59:57 --> Security Class Initialized
DEBUG - 2019-07-20 10:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 10:59:57 --> Input Class Initialized
INFO - 2019-07-20 10:59:57 --> Language Class Initialized
INFO - 2019-07-20 10:59:57 --> Loader Class Initialized
INFO - 2019-07-20 10:59:57 --> Database Driver Class Initialized
INFO - 2019-07-20 10:59:57 --> Controller Class Initialized
INFO - 2019-07-20 10:59:57 --> Model "Product" initialized
INFO - 2019-07-20 10:59:57 --> Final output sent to browser
DEBUG - 2019-07-20 10:59:57 --> Total execution time: 0.0180
INFO - 2019-07-20 10:59:57 --> Config Class Initialized
INFO - 2019-07-20 10:59:57 --> Hooks Class Initialized
DEBUG - 2019-07-20 10:59:57 --> UTF-8 Support Enabled
INFO - 2019-07-20 10:59:57 --> Utf8 Class Initialized
INFO - 2019-07-20 10:59:57 --> URI Class Initialized
INFO - 2019-07-20 10:59:57 --> Router Class Initialized
INFO - 2019-07-20 10:59:57 --> Output Class Initialized
INFO - 2019-07-20 10:59:57 --> Security Class Initialized
DEBUG - 2019-07-20 10:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 10:59:57 --> Input Class Initialized
INFO - 2019-07-20 10:59:57 --> Language Class Initialized
INFO - 2019-07-20 10:59:57 --> Loader Class Initialized
INFO - 2019-07-20 10:59:57 --> Database Driver Class Initialized
INFO - 2019-07-20 10:59:57 --> Controller Class Initialized
INFO - 2019-07-20 10:59:57 --> Model "Product" initialized
INFO - 2019-07-20 10:59:57 --> Final output sent to browser
DEBUG - 2019-07-20 10:59:57 --> Total execution time: 0.0192
INFO - 2019-07-20 11:02:42 --> Config Class Initialized
INFO - 2019-07-20 11:02:42 --> Hooks Class Initialized
DEBUG - 2019-07-20 11:02:42 --> UTF-8 Support Enabled
INFO - 2019-07-20 11:02:42 --> Utf8 Class Initialized
INFO - 2019-07-20 11:02:42 --> URI Class Initialized
INFO - 2019-07-20 11:02:42 --> Router Class Initialized
INFO - 2019-07-20 11:02:42 --> Output Class Initialized
INFO - 2019-07-20 11:02:42 --> Security Class Initialized
DEBUG - 2019-07-20 11:02:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 11:02:42 --> Input Class Initialized
INFO - 2019-07-20 11:02:42 --> Language Class Initialized
INFO - 2019-07-20 11:02:42 --> Loader Class Initialized
INFO - 2019-07-20 11:02:42 --> Database Driver Class Initialized
INFO - 2019-07-20 11:02:42 --> Controller Class Initialized
INFO - 2019-07-20 11:02:42 --> Model "Product" initialized
INFO - 2019-07-20 11:02:42 --> Final output sent to browser
DEBUG - 2019-07-20 11:02:42 --> Total execution time: 0.0219
INFO - 2019-07-20 11:02:42 --> Config Class Initialized
INFO - 2019-07-20 11:02:42 --> Hooks Class Initialized
DEBUG - 2019-07-20 11:02:42 --> UTF-8 Support Enabled
INFO - 2019-07-20 11:02:42 --> Utf8 Class Initialized
INFO - 2019-07-20 11:02:42 --> URI Class Initialized
INFO - 2019-07-20 11:02:42 --> Router Class Initialized
INFO - 2019-07-20 11:02:42 --> Output Class Initialized
INFO - 2019-07-20 11:02:42 --> Security Class Initialized
DEBUG - 2019-07-20 11:02:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 11:02:42 --> Input Class Initialized
INFO - 2019-07-20 11:02:42 --> Language Class Initialized
INFO - 2019-07-20 11:02:42 --> Loader Class Initialized
INFO - 2019-07-20 11:02:42 --> Database Driver Class Initialized
INFO - 2019-07-20 11:02:42 --> Controller Class Initialized
INFO - 2019-07-20 11:02:42 --> Model "Product" initialized
INFO - 2019-07-20 11:02:42 --> Final output sent to browser
DEBUG - 2019-07-20 11:02:42 --> Total execution time: 0.0219
INFO - 2019-07-20 11:04:38 --> Config Class Initialized
INFO - 2019-07-20 11:04:38 --> Hooks Class Initialized
DEBUG - 2019-07-20 11:04:38 --> UTF-8 Support Enabled
INFO - 2019-07-20 11:04:38 --> Utf8 Class Initialized
INFO - 2019-07-20 11:04:38 --> URI Class Initialized
INFO - 2019-07-20 11:04:38 --> Router Class Initialized
INFO - 2019-07-20 11:04:38 --> Output Class Initialized
INFO - 2019-07-20 11:04:38 --> Security Class Initialized
DEBUG - 2019-07-20 11:04:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 11:04:38 --> Input Class Initialized
INFO - 2019-07-20 11:04:38 --> Language Class Initialized
INFO - 2019-07-20 11:04:38 --> Loader Class Initialized
INFO - 2019-07-20 11:04:38 --> Database Driver Class Initialized
INFO - 2019-07-20 11:04:38 --> Controller Class Initialized
INFO - 2019-07-20 11:04:38 --> Model "Product" initialized
INFO - 2019-07-20 11:04:38 --> Final output sent to browser
DEBUG - 2019-07-20 11:04:38 --> Total execution time: 0.6436
INFO - 2019-07-20 11:04:38 --> Config Class Initialized
INFO - 2019-07-20 11:04:38 --> Hooks Class Initialized
DEBUG - 2019-07-20 11:04:38 --> UTF-8 Support Enabled
INFO - 2019-07-20 11:04:38 --> Utf8 Class Initialized
INFO - 2019-07-20 11:04:38 --> URI Class Initialized
INFO - 2019-07-20 11:04:38 --> Router Class Initialized
INFO - 2019-07-20 11:04:38 --> Output Class Initialized
INFO - 2019-07-20 11:04:38 --> Security Class Initialized
DEBUG - 2019-07-20 11:04:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 11:04:38 --> Input Class Initialized
INFO - 2019-07-20 11:04:38 --> Language Class Initialized
INFO - 2019-07-20 11:04:38 --> Loader Class Initialized
INFO - 2019-07-20 11:04:38 --> Database Driver Class Initialized
INFO - 2019-07-20 11:04:38 --> Controller Class Initialized
INFO - 2019-07-20 11:04:38 --> Model "Product" initialized
INFO - 2019-07-20 11:04:38 --> Final output sent to browser
DEBUG - 2019-07-20 11:04:38 --> Total execution time: 0.1830
INFO - 2019-07-20 11:04:54 --> Config Class Initialized
INFO - 2019-07-20 11:04:54 --> Hooks Class Initialized
DEBUG - 2019-07-20 11:04:54 --> UTF-8 Support Enabled
INFO - 2019-07-20 11:04:54 --> Utf8 Class Initialized
INFO - 2019-07-20 11:04:54 --> URI Class Initialized
INFO - 2019-07-20 11:04:54 --> Router Class Initialized
INFO - 2019-07-20 11:04:54 --> Output Class Initialized
INFO - 2019-07-20 11:04:54 --> Security Class Initialized
DEBUG - 2019-07-20 11:04:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 11:04:54 --> Input Class Initialized
INFO - 2019-07-20 11:04:54 --> Language Class Initialized
INFO - 2019-07-20 11:04:54 --> Loader Class Initialized
INFO - 2019-07-20 11:04:54 --> Database Driver Class Initialized
INFO - 2019-07-20 11:04:54 --> Controller Class Initialized
INFO - 2019-07-20 11:04:54 --> Model "Product" initialized
INFO - 2019-07-20 11:04:54 --> Final output sent to browser
DEBUG - 2019-07-20 11:04:54 --> Total execution time: 0.0172
INFO - 2019-07-20 11:04:54 --> Config Class Initialized
INFO - 2019-07-20 11:04:54 --> Hooks Class Initialized
DEBUG - 2019-07-20 11:04:54 --> UTF-8 Support Enabled
INFO - 2019-07-20 11:04:54 --> Utf8 Class Initialized
INFO - 2019-07-20 11:04:54 --> URI Class Initialized
INFO - 2019-07-20 11:04:54 --> Router Class Initialized
INFO - 2019-07-20 11:04:54 --> Output Class Initialized
INFO - 2019-07-20 11:04:54 --> Security Class Initialized
DEBUG - 2019-07-20 11:04:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 11:04:54 --> Input Class Initialized
INFO - 2019-07-20 11:04:54 --> Language Class Initialized
INFO - 2019-07-20 11:04:54 --> Loader Class Initialized
INFO - 2019-07-20 11:04:54 --> Database Driver Class Initialized
INFO - 2019-07-20 11:04:54 --> Controller Class Initialized
INFO - 2019-07-20 11:04:54 --> Model "Product" initialized
INFO - 2019-07-20 11:04:54 --> Final output sent to browser
DEBUG - 2019-07-20 11:04:54 --> Total execution time: 0.0207
INFO - 2019-07-20 11:05:04 --> Config Class Initialized
INFO - 2019-07-20 11:05:04 --> Hooks Class Initialized
DEBUG - 2019-07-20 11:05:04 --> UTF-8 Support Enabled
INFO - 2019-07-20 11:05:04 --> Utf8 Class Initialized
INFO - 2019-07-20 11:05:04 --> URI Class Initialized
INFO - 2019-07-20 11:05:04 --> Router Class Initialized
INFO - 2019-07-20 11:05:04 --> Output Class Initialized
INFO - 2019-07-20 11:05:04 --> Security Class Initialized
DEBUG - 2019-07-20 11:05:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 11:05:04 --> Input Class Initialized
INFO - 2019-07-20 11:05:04 --> Language Class Initialized
INFO - 2019-07-20 11:05:04 --> Loader Class Initialized
INFO - 2019-07-20 11:05:04 --> Database Driver Class Initialized
INFO - 2019-07-20 11:05:04 --> Controller Class Initialized
INFO - 2019-07-20 11:05:04 --> Model "Product" initialized
INFO - 2019-07-20 11:05:04 --> Final output sent to browser
DEBUG - 2019-07-20 11:05:04 --> Total execution time: 0.0156
INFO - 2019-07-20 11:05:04 --> Config Class Initialized
INFO - 2019-07-20 11:05:04 --> Hooks Class Initialized
DEBUG - 2019-07-20 11:05:04 --> UTF-8 Support Enabled
INFO - 2019-07-20 11:05:04 --> Utf8 Class Initialized
INFO - 2019-07-20 11:05:04 --> URI Class Initialized
INFO - 2019-07-20 11:05:04 --> Router Class Initialized
INFO - 2019-07-20 11:05:04 --> Output Class Initialized
INFO - 2019-07-20 11:05:04 --> Security Class Initialized
DEBUG - 2019-07-20 11:05:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 11:05:04 --> Input Class Initialized
INFO - 2019-07-20 11:05:04 --> Language Class Initialized
INFO - 2019-07-20 11:05:04 --> Loader Class Initialized
INFO - 2019-07-20 11:05:04 --> Database Driver Class Initialized
INFO - 2019-07-20 11:05:04 --> Controller Class Initialized
INFO - 2019-07-20 11:05:04 --> Model "Product" initialized
INFO - 2019-07-20 11:05:04 --> Final output sent to browser
DEBUG - 2019-07-20 11:05:04 --> Total execution time: 0.0215
INFO - 2019-07-20 11:07:16 --> Config Class Initialized
INFO - 2019-07-20 11:07:16 --> Hooks Class Initialized
DEBUG - 2019-07-20 11:07:16 --> UTF-8 Support Enabled
INFO - 2019-07-20 11:07:16 --> Utf8 Class Initialized
INFO - 2019-07-20 11:07:16 --> URI Class Initialized
INFO - 2019-07-20 11:07:16 --> Router Class Initialized
INFO - 2019-07-20 11:07:16 --> Output Class Initialized
INFO - 2019-07-20 11:07:16 --> Security Class Initialized
DEBUG - 2019-07-20 11:07:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 11:07:16 --> Input Class Initialized
INFO - 2019-07-20 11:07:16 --> Language Class Initialized
INFO - 2019-07-20 11:07:16 --> Loader Class Initialized
INFO - 2019-07-20 11:07:16 --> Database Driver Class Initialized
INFO - 2019-07-20 11:07:16 --> Controller Class Initialized
INFO - 2019-07-20 11:07:16 --> Model "Product" initialized
INFO - 2019-07-20 11:07:16 --> Final output sent to browser
DEBUG - 2019-07-20 11:07:16 --> Total execution time: 0.0543
INFO - 2019-07-20 11:07:16 --> Config Class Initialized
INFO - 2019-07-20 11:07:16 --> Hooks Class Initialized
DEBUG - 2019-07-20 11:07:16 --> UTF-8 Support Enabled
INFO - 2019-07-20 11:07:16 --> Utf8 Class Initialized
INFO - 2019-07-20 11:07:16 --> URI Class Initialized
INFO - 2019-07-20 11:07:16 --> Router Class Initialized
INFO - 2019-07-20 11:07:16 --> Output Class Initialized
INFO - 2019-07-20 11:07:16 --> Security Class Initialized
DEBUG - 2019-07-20 11:07:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 11:07:16 --> Input Class Initialized
INFO - 2019-07-20 11:07:16 --> Language Class Initialized
INFO - 2019-07-20 11:07:16 --> Loader Class Initialized
INFO - 2019-07-20 11:07:16 --> Database Driver Class Initialized
INFO - 2019-07-20 11:07:16 --> Controller Class Initialized
INFO - 2019-07-20 11:07:16 --> Model "Product" initialized
INFO - 2019-07-20 11:07:16 --> Final output sent to browser
DEBUG - 2019-07-20 11:07:16 --> Total execution time: 0.2300
INFO - 2019-07-20 11:07:35 --> Config Class Initialized
INFO - 2019-07-20 11:07:35 --> Hooks Class Initialized
DEBUG - 2019-07-20 11:07:35 --> UTF-8 Support Enabled
INFO - 2019-07-20 11:07:35 --> Utf8 Class Initialized
INFO - 2019-07-20 11:07:35 --> URI Class Initialized
INFO - 2019-07-20 11:07:35 --> Router Class Initialized
INFO - 2019-07-20 11:07:35 --> Output Class Initialized
INFO - 2019-07-20 11:07:35 --> Security Class Initialized
DEBUG - 2019-07-20 11:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 11:07:35 --> Input Class Initialized
INFO - 2019-07-20 11:07:35 --> Language Class Initialized
INFO - 2019-07-20 11:07:35 --> Loader Class Initialized
INFO - 2019-07-20 11:07:35 --> Database Driver Class Initialized
INFO - 2019-07-20 11:07:35 --> Controller Class Initialized
INFO - 2019-07-20 11:07:35 --> Model "Product" initialized
INFO - 2019-07-20 11:07:35 --> Final output sent to browser
DEBUG - 2019-07-20 11:07:35 --> Total execution time: 0.0169
INFO - 2019-07-20 11:07:35 --> Config Class Initialized
INFO - 2019-07-20 11:07:35 --> Hooks Class Initialized
DEBUG - 2019-07-20 11:07:35 --> UTF-8 Support Enabled
INFO - 2019-07-20 11:07:35 --> Utf8 Class Initialized
INFO - 2019-07-20 11:07:35 --> URI Class Initialized
INFO - 2019-07-20 11:07:35 --> Router Class Initialized
INFO - 2019-07-20 11:07:35 --> Output Class Initialized
INFO - 2019-07-20 11:07:35 --> Security Class Initialized
DEBUG - 2019-07-20 11:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 11:07:35 --> Input Class Initialized
INFO - 2019-07-20 11:07:35 --> Language Class Initialized
INFO - 2019-07-20 11:07:35 --> Loader Class Initialized
INFO - 2019-07-20 11:07:35 --> Database Driver Class Initialized
INFO - 2019-07-20 11:07:35 --> Controller Class Initialized
INFO - 2019-07-20 11:07:35 --> Model "Product" initialized
INFO - 2019-07-20 11:07:35 --> Final output sent to browser
DEBUG - 2019-07-20 11:07:35 --> Total execution time: 0.0189
INFO - 2019-07-20 11:08:02 --> Config Class Initialized
INFO - 2019-07-20 11:08:02 --> Hooks Class Initialized
DEBUG - 2019-07-20 11:08:02 --> UTF-8 Support Enabled
INFO - 2019-07-20 11:08:02 --> Utf8 Class Initialized
INFO - 2019-07-20 11:08:02 --> URI Class Initialized
INFO - 2019-07-20 11:08:02 --> Router Class Initialized
INFO - 2019-07-20 11:08:02 --> Output Class Initialized
INFO - 2019-07-20 11:08:02 --> Security Class Initialized
DEBUG - 2019-07-20 11:08:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 11:08:02 --> Input Class Initialized
INFO - 2019-07-20 11:08:02 --> Language Class Initialized
INFO - 2019-07-20 11:08:02 --> Loader Class Initialized
INFO - 2019-07-20 11:08:02 --> Database Driver Class Initialized
INFO - 2019-07-20 11:08:02 --> Controller Class Initialized
INFO - 2019-07-20 11:08:02 --> Model "Product" initialized
INFO - 2019-07-20 11:08:02 --> Final output sent to browser
DEBUG - 2019-07-20 11:08:02 --> Total execution time: 0.0198
INFO - 2019-07-20 11:08:02 --> Config Class Initialized
INFO - 2019-07-20 11:08:02 --> Hooks Class Initialized
DEBUG - 2019-07-20 11:08:02 --> UTF-8 Support Enabled
INFO - 2019-07-20 11:08:02 --> Utf8 Class Initialized
INFO - 2019-07-20 11:08:02 --> URI Class Initialized
INFO - 2019-07-20 11:08:02 --> Router Class Initialized
INFO - 2019-07-20 11:08:02 --> Output Class Initialized
INFO - 2019-07-20 11:08:02 --> Security Class Initialized
DEBUG - 2019-07-20 11:08:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 11:08:02 --> Input Class Initialized
INFO - 2019-07-20 11:08:02 --> Language Class Initialized
INFO - 2019-07-20 11:08:02 --> Loader Class Initialized
INFO - 2019-07-20 11:08:02 --> Database Driver Class Initialized
INFO - 2019-07-20 11:08:02 --> Controller Class Initialized
INFO - 2019-07-20 11:08:02 --> Model "Product" initialized
INFO - 2019-07-20 11:08:02 --> Final output sent to browser
DEBUG - 2019-07-20 11:08:02 --> Total execution time: 0.0241
INFO - 2019-07-20 11:08:22 --> Config Class Initialized
INFO - 2019-07-20 11:08:22 --> Hooks Class Initialized
DEBUG - 2019-07-20 11:08:22 --> UTF-8 Support Enabled
INFO - 2019-07-20 11:08:22 --> Utf8 Class Initialized
INFO - 2019-07-20 11:08:22 --> URI Class Initialized
INFO - 2019-07-20 11:08:22 --> Router Class Initialized
INFO - 2019-07-20 11:08:22 --> Output Class Initialized
INFO - 2019-07-20 11:08:22 --> Security Class Initialized
DEBUG - 2019-07-20 11:08:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 11:08:22 --> Input Class Initialized
INFO - 2019-07-20 11:08:22 --> Language Class Initialized
INFO - 2019-07-20 11:08:22 --> Loader Class Initialized
INFO - 2019-07-20 11:08:22 --> Database Driver Class Initialized
INFO - 2019-07-20 11:08:22 --> Controller Class Initialized
INFO - 2019-07-20 11:08:22 --> Model "Product" initialized
INFO - 2019-07-20 11:08:22 --> Final output sent to browser
DEBUG - 2019-07-20 11:08:22 --> Total execution time: 0.0233
INFO - 2019-07-20 11:08:22 --> Config Class Initialized
INFO - 2019-07-20 11:08:22 --> Hooks Class Initialized
DEBUG - 2019-07-20 11:08:22 --> UTF-8 Support Enabled
INFO - 2019-07-20 11:08:22 --> Utf8 Class Initialized
INFO - 2019-07-20 11:08:22 --> URI Class Initialized
INFO - 2019-07-20 11:08:22 --> Router Class Initialized
INFO - 2019-07-20 11:08:22 --> Output Class Initialized
INFO - 2019-07-20 11:08:22 --> Security Class Initialized
DEBUG - 2019-07-20 11:08:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 11:08:22 --> Input Class Initialized
INFO - 2019-07-20 11:08:22 --> Language Class Initialized
INFO - 2019-07-20 11:08:22 --> Loader Class Initialized
INFO - 2019-07-20 11:08:22 --> Database Driver Class Initialized
INFO - 2019-07-20 11:08:22 --> Controller Class Initialized
INFO - 2019-07-20 11:08:22 --> Model "Product" initialized
INFO - 2019-07-20 11:08:22 --> Final output sent to browser
DEBUG - 2019-07-20 11:08:22 --> Total execution time: 0.0181
INFO - 2019-07-20 11:12:08 --> Config Class Initialized
INFO - 2019-07-20 11:12:08 --> Hooks Class Initialized
DEBUG - 2019-07-20 11:12:08 --> UTF-8 Support Enabled
INFO - 2019-07-20 11:12:08 --> Utf8 Class Initialized
INFO - 2019-07-20 11:12:08 --> URI Class Initialized
INFO - 2019-07-20 11:12:08 --> Router Class Initialized
INFO - 2019-07-20 11:12:08 --> Output Class Initialized
INFO - 2019-07-20 11:12:08 --> Security Class Initialized
DEBUG - 2019-07-20 11:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 11:12:08 --> Input Class Initialized
INFO - 2019-07-20 11:12:08 --> Language Class Initialized
INFO - 2019-07-20 11:12:08 --> Loader Class Initialized
INFO - 2019-07-20 11:12:08 --> Database Driver Class Initialized
INFO - 2019-07-20 11:12:08 --> Controller Class Initialized
INFO - 2019-07-20 11:12:08 --> Model "Product" initialized
INFO - 2019-07-20 11:12:08 --> Final output sent to browser
DEBUG - 2019-07-20 11:12:08 --> Total execution time: 0.0198
INFO - 2019-07-20 11:12:08 --> Config Class Initialized
INFO - 2019-07-20 11:12:08 --> Hooks Class Initialized
DEBUG - 2019-07-20 11:12:08 --> UTF-8 Support Enabled
INFO - 2019-07-20 11:12:08 --> Utf8 Class Initialized
INFO - 2019-07-20 11:12:08 --> URI Class Initialized
INFO - 2019-07-20 11:12:08 --> Router Class Initialized
INFO - 2019-07-20 11:12:08 --> Output Class Initialized
INFO - 2019-07-20 11:12:08 --> Security Class Initialized
DEBUG - 2019-07-20 11:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 11:12:08 --> Input Class Initialized
INFO - 2019-07-20 11:12:08 --> Language Class Initialized
INFO - 2019-07-20 11:12:08 --> Loader Class Initialized
INFO - 2019-07-20 11:12:08 --> Database Driver Class Initialized
INFO - 2019-07-20 11:12:08 --> Controller Class Initialized
INFO - 2019-07-20 11:12:08 --> Model "Product" initialized
INFO - 2019-07-20 11:12:08 --> Final output sent to browser
DEBUG - 2019-07-20 11:12:08 --> Total execution time: 0.0203
INFO - 2019-07-20 11:31:56 --> Config Class Initialized
INFO - 2019-07-20 11:31:56 --> Hooks Class Initialized
DEBUG - 2019-07-20 11:31:56 --> UTF-8 Support Enabled
INFO - 2019-07-20 11:31:56 --> Utf8 Class Initialized
INFO - 2019-07-20 11:31:56 --> URI Class Initialized
INFO - 2019-07-20 11:31:56 --> Router Class Initialized
INFO - 2019-07-20 11:31:56 --> Output Class Initialized
INFO - 2019-07-20 11:31:56 --> Security Class Initialized
DEBUG - 2019-07-20 11:31:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 11:31:56 --> Input Class Initialized
INFO - 2019-07-20 11:31:56 --> Language Class Initialized
INFO - 2019-07-20 11:31:56 --> Loader Class Initialized
INFO - 2019-07-20 11:31:56 --> Database Driver Class Initialized
INFO - 2019-07-20 11:31:56 --> Controller Class Initialized
INFO - 2019-07-20 11:31:56 --> Model "Product" initialized
INFO - 2019-07-20 11:31:56 --> Final output sent to browser
DEBUG - 2019-07-20 11:31:56 --> Total execution time: 0.0200
INFO - 2019-07-20 11:31:56 --> Config Class Initialized
INFO - 2019-07-20 11:31:56 --> Hooks Class Initialized
DEBUG - 2019-07-20 11:31:56 --> UTF-8 Support Enabled
INFO - 2019-07-20 11:31:56 --> Utf8 Class Initialized
INFO - 2019-07-20 11:31:56 --> URI Class Initialized
INFO - 2019-07-20 11:31:56 --> Router Class Initialized
INFO - 2019-07-20 11:31:56 --> Output Class Initialized
INFO - 2019-07-20 11:31:56 --> Security Class Initialized
DEBUG - 2019-07-20 11:31:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 11:31:56 --> Input Class Initialized
INFO - 2019-07-20 11:31:56 --> Language Class Initialized
INFO - 2019-07-20 11:31:56 --> Loader Class Initialized
INFO - 2019-07-20 11:31:56 --> Database Driver Class Initialized
INFO - 2019-07-20 11:31:56 --> Controller Class Initialized
INFO - 2019-07-20 11:31:56 --> Model "Product" initialized
INFO - 2019-07-20 11:31:56 --> Final output sent to browser
DEBUG - 2019-07-20 11:31:56 --> Total execution time: 0.0193
INFO - 2019-07-20 11:32:01 --> Config Class Initialized
INFO - 2019-07-20 11:32:01 --> Hooks Class Initialized
DEBUG - 2019-07-20 11:32:01 --> UTF-8 Support Enabled
INFO - 2019-07-20 11:32:01 --> Utf8 Class Initialized
INFO - 2019-07-20 11:32:01 --> URI Class Initialized
INFO - 2019-07-20 11:32:01 --> Router Class Initialized
INFO - 2019-07-20 11:32:01 --> Output Class Initialized
INFO - 2019-07-20 11:32:01 --> Security Class Initialized
DEBUG - 2019-07-20 11:32:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 11:32:01 --> Input Class Initialized
INFO - 2019-07-20 11:32:01 --> Language Class Initialized
ERROR - 2019-07-20 11:32:01 --> 404 Page Not Found: Welcome/loadusers
INFO - 2019-07-20 11:32:13 --> Config Class Initialized
INFO - 2019-07-20 11:32:13 --> Hooks Class Initialized
DEBUG - 2019-07-20 11:32:13 --> UTF-8 Support Enabled
INFO - 2019-07-20 11:32:13 --> Utf8 Class Initialized
INFO - 2019-07-20 11:32:13 --> URI Class Initialized
INFO - 2019-07-20 11:32:13 --> Router Class Initialized
INFO - 2019-07-20 11:32:13 --> Output Class Initialized
INFO - 2019-07-20 11:32:13 --> Security Class Initialized
DEBUG - 2019-07-20 11:32:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 11:32:13 --> Input Class Initialized
INFO - 2019-07-20 11:32:13 --> Language Class Initialized
ERROR - 2019-07-20 11:32:13 --> 404 Page Not Found: Welcome/loadusers
INFO - 2019-07-20 11:33:04 --> Config Class Initialized
INFO - 2019-07-20 11:33:04 --> Hooks Class Initialized
DEBUG - 2019-07-20 11:33:04 --> UTF-8 Support Enabled
INFO - 2019-07-20 11:33:04 --> Utf8 Class Initialized
INFO - 2019-07-20 11:33:04 --> URI Class Initialized
INFO - 2019-07-20 11:33:04 --> Router Class Initialized
INFO - 2019-07-20 11:33:04 --> Output Class Initialized
INFO - 2019-07-20 11:33:04 --> Security Class Initialized
DEBUG - 2019-07-20 11:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 11:33:04 --> Input Class Initialized
INFO - 2019-07-20 11:33:04 --> Language Class Initialized
ERROR - 2019-07-20 11:33:04 --> 404 Page Not Found: Welcome/loadusers
INFO - 2019-07-20 11:33:05 --> Config Class Initialized
INFO - 2019-07-20 11:33:05 --> Hooks Class Initialized
DEBUG - 2019-07-20 11:33:05 --> UTF-8 Support Enabled
INFO - 2019-07-20 11:33:05 --> Utf8 Class Initialized
INFO - 2019-07-20 11:33:05 --> URI Class Initialized
INFO - 2019-07-20 11:33:05 --> Router Class Initialized
INFO - 2019-07-20 11:33:05 --> Output Class Initialized
INFO - 2019-07-20 11:33:05 --> Security Class Initialized
DEBUG - 2019-07-20 11:33:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 11:33:05 --> Input Class Initialized
INFO - 2019-07-20 11:33:05 --> Language Class Initialized
ERROR - 2019-07-20 11:33:05 --> 404 Page Not Found: Welcome/loadusers
INFO - 2019-07-20 11:33:06 --> Config Class Initialized
INFO - 2019-07-20 11:33:06 --> Hooks Class Initialized
DEBUG - 2019-07-20 11:33:06 --> UTF-8 Support Enabled
INFO - 2019-07-20 11:33:06 --> Utf8 Class Initialized
INFO - 2019-07-20 11:33:06 --> URI Class Initialized
INFO - 2019-07-20 11:33:06 --> Router Class Initialized
INFO - 2019-07-20 11:33:06 --> Output Class Initialized
INFO - 2019-07-20 11:33:06 --> Security Class Initialized
DEBUG - 2019-07-20 11:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 11:33:06 --> Input Class Initialized
INFO - 2019-07-20 11:33:06 --> Language Class Initialized
ERROR - 2019-07-20 11:33:06 --> 404 Page Not Found: Welcome/loadusers
INFO - 2019-07-20 11:33:07 --> Config Class Initialized
INFO - 2019-07-20 11:33:07 --> Hooks Class Initialized
DEBUG - 2019-07-20 11:33:07 --> UTF-8 Support Enabled
INFO - 2019-07-20 11:33:07 --> Utf8 Class Initialized
INFO - 2019-07-20 11:33:07 --> URI Class Initialized
INFO - 2019-07-20 11:33:07 --> Router Class Initialized
INFO - 2019-07-20 11:33:07 --> Output Class Initialized
INFO - 2019-07-20 11:33:07 --> Security Class Initialized
DEBUG - 2019-07-20 11:33:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 11:33:07 --> Input Class Initialized
INFO - 2019-07-20 11:33:07 --> Language Class Initialized
ERROR - 2019-07-20 11:33:07 --> 404 Page Not Found: Welcome/loadusers
INFO - 2019-07-20 11:33:12 --> Config Class Initialized
INFO - 2019-07-20 11:33:12 --> Hooks Class Initialized
DEBUG - 2019-07-20 11:33:12 --> UTF-8 Support Enabled
INFO - 2019-07-20 11:33:12 --> Utf8 Class Initialized
INFO - 2019-07-20 11:33:12 --> URI Class Initialized
INFO - 2019-07-20 11:33:12 --> Router Class Initialized
INFO - 2019-07-20 11:33:12 --> Output Class Initialized
INFO - 2019-07-20 11:33:12 --> Security Class Initialized
DEBUG - 2019-07-20 11:33:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 11:33:12 --> Input Class Initialized
INFO - 2019-07-20 11:33:12 --> Language Class Initialized
ERROR - 2019-07-20 11:33:12 --> 404 Page Not Found: Welcome/loadusers
INFO - 2019-07-20 11:33:14 --> Config Class Initialized
INFO - 2019-07-20 11:33:14 --> Hooks Class Initialized
DEBUG - 2019-07-20 11:33:14 --> UTF-8 Support Enabled
INFO - 2019-07-20 11:33:14 --> Utf8 Class Initialized
INFO - 2019-07-20 11:33:14 --> URI Class Initialized
INFO - 2019-07-20 11:33:14 --> Router Class Initialized
INFO - 2019-07-20 11:33:14 --> Output Class Initialized
INFO - 2019-07-20 11:33:14 --> Security Class Initialized
DEBUG - 2019-07-20 11:33:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 11:33:14 --> Input Class Initialized
INFO - 2019-07-20 11:33:14 --> Language Class Initialized
ERROR - 2019-07-20 11:33:14 --> 404 Page Not Found: Welcome/loadusers
INFO - 2019-07-20 11:33:50 --> Config Class Initialized
INFO - 2019-07-20 11:33:50 --> Hooks Class Initialized
DEBUG - 2019-07-20 11:33:50 --> UTF-8 Support Enabled
INFO - 2019-07-20 11:33:50 --> Utf8 Class Initialized
INFO - 2019-07-20 11:33:50 --> URI Class Initialized
INFO - 2019-07-20 11:33:50 --> Router Class Initialized
INFO - 2019-07-20 11:33:50 --> Output Class Initialized
INFO - 2019-07-20 11:33:50 --> Security Class Initialized
DEBUG - 2019-07-20 11:33:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 11:33:50 --> Input Class Initialized
INFO - 2019-07-20 11:33:50 --> Language Class Initialized
INFO - 2019-07-20 11:33:50 --> Loader Class Initialized
INFO - 2019-07-20 11:33:50 --> Database Driver Class Initialized
INFO - 2019-07-20 11:33:50 --> Controller Class Initialized
INFO - 2019-07-20 11:33:50 --> Model "Product" initialized
INFO - 2019-07-20 11:33:50 --> Final output sent to browser
DEBUG - 2019-07-20 11:33:50 --> Total execution time: 0.0180
INFO - 2019-07-20 11:34:02 --> Config Class Initialized
INFO - 2019-07-20 11:34:02 --> Hooks Class Initialized
DEBUG - 2019-07-20 11:34:02 --> UTF-8 Support Enabled
INFO - 2019-07-20 11:34:02 --> Utf8 Class Initialized
INFO - 2019-07-20 11:34:02 --> URI Class Initialized
INFO - 2019-07-20 11:34:02 --> Router Class Initialized
INFO - 2019-07-20 11:34:02 --> Output Class Initialized
INFO - 2019-07-20 11:34:02 --> Security Class Initialized
DEBUG - 2019-07-20 11:34:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 11:34:02 --> Input Class Initialized
INFO - 2019-07-20 11:34:02 --> Language Class Initialized
ERROR - 2019-07-20 11:34:02 --> 404 Page Not Found: Welcome/loadusers
INFO - 2019-07-20 11:34:40 --> Config Class Initialized
INFO - 2019-07-20 11:34:40 --> Hooks Class Initialized
DEBUG - 2019-07-20 11:34:40 --> UTF-8 Support Enabled
INFO - 2019-07-20 11:34:40 --> Utf8 Class Initialized
INFO - 2019-07-20 11:34:40 --> URI Class Initialized
INFO - 2019-07-20 11:34:40 --> Router Class Initialized
INFO - 2019-07-20 11:34:40 --> Output Class Initialized
INFO - 2019-07-20 11:34:40 --> Security Class Initialized
DEBUG - 2019-07-20 11:34:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 11:34:40 --> Input Class Initialized
INFO - 2019-07-20 11:34:40 --> Language Class Initialized
ERROR - 2019-07-20 11:34:40 --> 404 Page Not Found: Welcome/loadusers
INFO - 2019-07-20 11:34:45 --> Config Class Initialized
INFO - 2019-07-20 11:34:45 --> Hooks Class Initialized
DEBUG - 2019-07-20 11:34:45 --> UTF-8 Support Enabled
INFO - 2019-07-20 11:34:45 --> Utf8 Class Initialized
INFO - 2019-07-20 11:34:45 --> URI Class Initialized
INFO - 2019-07-20 11:34:45 --> Router Class Initialized
INFO - 2019-07-20 11:34:45 --> Output Class Initialized
INFO - 2019-07-20 11:34:45 --> Security Class Initialized
DEBUG - 2019-07-20 11:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 11:34:45 --> Input Class Initialized
INFO - 2019-07-20 11:34:45 --> Language Class Initialized
ERROR - 2019-07-20 11:34:45 --> 404 Page Not Found: Welcome/loadusers
INFO - 2019-07-20 11:37:41 --> Config Class Initialized
INFO - 2019-07-20 11:37:41 --> Hooks Class Initialized
DEBUG - 2019-07-20 11:37:41 --> UTF-8 Support Enabled
INFO - 2019-07-20 11:37:41 --> Utf8 Class Initialized
INFO - 2019-07-20 11:37:41 --> URI Class Initialized
INFO - 2019-07-20 11:37:41 --> Router Class Initialized
INFO - 2019-07-20 11:37:41 --> Output Class Initialized
INFO - 2019-07-20 11:37:41 --> Security Class Initialized
DEBUG - 2019-07-20 11:37:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 11:37:41 --> Input Class Initialized
INFO - 2019-07-20 11:37:41 --> Language Class Initialized
INFO - 2019-07-20 11:37:41 --> Loader Class Initialized
INFO - 2019-07-20 11:37:41 --> Database Driver Class Initialized
INFO - 2019-07-20 11:37:41 --> Controller Class Initialized
INFO - 2019-07-20 11:37:41 --> Model "Product" initialized
INFO - 2019-07-20 11:37:41 --> Final output sent to browser
DEBUG - 2019-07-20 11:37:41 --> Total execution time: 0.0188
INFO - 2019-07-20 11:37:50 --> Config Class Initialized
INFO - 2019-07-20 11:37:50 --> Hooks Class Initialized
DEBUG - 2019-07-20 11:37:50 --> UTF-8 Support Enabled
INFO - 2019-07-20 11:37:50 --> Utf8 Class Initialized
INFO - 2019-07-20 11:37:50 --> URI Class Initialized
INFO - 2019-07-20 11:37:50 --> Router Class Initialized
INFO - 2019-07-20 11:37:50 --> Output Class Initialized
INFO - 2019-07-20 11:37:50 --> Security Class Initialized
DEBUG - 2019-07-20 11:37:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 11:37:50 --> Input Class Initialized
INFO - 2019-07-20 11:37:50 --> Language Class Initialized
INFO - 2019-07-20 11:37:50 --> Loader Class Initialized
INFO - 2019-07-20 11:37:50 --> Database Driver Class Initialized
INFO - 2019-07-20 11:37:50 --> Controller Class Initialized
INFO - 2019-07-20 11:37:50 --> Model "Product" initialized
INFO - 2019-07-20 11:37:50 --> Final output sent to browser
DEBUG - 2019-07-20 11:37:50 --> Total execution time: 0.0194
INFO - 2019-07-20 11:43:42 --> Config Class Initialized
INFO - 2019-07-20 11:43:42 --> Hooks Class Initialized
DEBUG - 2019-07-20 11:43:42 --> UTF-8 Support Enabled
INFO - 2019-07-20 11:43:42 --> Utf8 Class Initialized
INFO - 2019-07-20 11:43:42 --> URI Class Initialized
INFO - 2019-07-20 11:43:42 --> Router Class Initialized
INFO - 2019-07-20 11:43:42 --> Output Class Initialized
INFO - 2019-07-20 11:43:42 --> Security Class Initialized
DEBUG - 2019-07-20 11:43:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 11:43:42 --> Input Class Initialized
INFO - 2019-07-20 11:43:42 --> Language Class Initialized
INFO - 2019-07-20 11:43:42 --> Loader Class Initialized
INFO - 2019-07-20 11:43:42 --> Database Driver Class Initialized
INFO - 2019-07-20 11:43:42 --> Controller Class Initialized
INFO - 2019-07-20 11:43:42 --> Model "Product" initialized
INFO - 2019-07-20 11:43:42 --> Final output sent to browser
DEBUG - 2019-07-20 11:43:42 --> Total execution time: 0.0223
INFO - 2019-07-20 11:43:42 --> Config Class Initialized
INFO - 2019-07-20 11:43:42 --> Hooks Class Initialized
DEBUG - 2019-07-20 11:43:42 --> UTF-8 Support Enabled
INFO - 2019-07-20 11:43:42 --> Utf8 Class Initialized
INFO - 2019-07-20 11:43:42 --> URI Class Initialized
INFO - 2019-07-20 11:43:42 --> Router Class Initialized
INFO - 2019-07-20 11:43:42 --> Output Class Initialized
INFO - 2019-07-20 11:43:42 --> Security Class Initialized
DEBUG - 2019-07-20 11:43:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 11:43:42 --> Input Class Initialized
INFO - 2019-07-20 11:43:42 --> Language Class Initialized
INFO - 2019-07-20 11:43:42 --> Loader Class Initialized
INFO - 2019-07-20 11:43:42 --> Database Driver Class Initialized
INFO - 2019-07-20 11:43:42 --> Controller Class Initialized
INFO - 2019-07-20 11:43:42 --> Model "Product" initialized
INFO - 2019-07-20 11:43:42 --> Final output sent to browser
DEBUG - 2019-07-20 11:43:42 --> Total execution time: 0.0195
INFO - 2019-07-20 11:43:53 --> Config Class Initialized
INFO - 2019-07-20 11:43:53 --> Hooks Class Initialized
DEBUG - 2019-07-20 11:43:53 --> UTF-8 Support Enabled
INFO - 2019-07-20 11:43:53 --> Utf8 Class Initialized
INFO - 2019-07-20 11:43:53 --> URI Class Initialized
INFO - 2019-07-20 11:43:53 --> Router Class Initialized
INFO - 2019-07-20 11:43:53 --> Output Class Initialized
INFO - 2019-07-20 11:43:53 --> Security Class Initialized
DEBUG - 2019-07-20 11:43:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 11:43:53 --> Input Class Initialized
INFO - 2019-07-20 11:43:53 --> Language Class Initialized
INFO - 2019-07-20 11:43:53 --> Loader Class Initialized
INFO - 2019-07-20 11:43:53 --> Database Driver Class Initialized
INFO - 2019-07-20 11:43:53 --> Controller Class Initialized
INFO - 2019-07-20 11:43:53 --> Model "Product" initialized
INFO - 2019-07-20 11:43:53 --> Final output sent to browser
DEBUG - 2019-07-20 11:43:53 --> Total execution time: 0.0550
INFO - 2019-07-20 11:44:41 --> Config Class Initialized
INFO - 2019-07-20 11:44:41 --> Hooks Class Initialized
DEBUG - 2019-07-20 11:44:41 --> UTF-8 Support Enabled
INFO - 2019-07-20 11:44:41 --> Utf8 Class Initialized
INFO - 2019-07-20 11:44:41 --> URI Class Initialized
INFO - 2019-07-20 11:44:41 --> Router Class Initialized
INFO - 2019-07-20 11:44:41 --> Output Class Initialized
INFO - 2019-07-20 11:44:41 --> Security Class Initialized
DEBUG - 2019-07-20 11:44:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 11:44:41 --> Input Class Initialized
INFO - 2019-07-20 11:44:41 --> Language Class Initialized
INFO - 2019-07-20 11:44:41 --> Loader Class Initialized
INFO - 2019-07-20 11:44:41 --> Database Driver Class Initialized
INFO - 2019-07-20 11:44:41 --> Controller Class Initialized
INFO - 2019-07-20 11:44:41 --> Model "Product" initialized
INFO - 2019-07-20 11:44:41 --> Final output sent to browser
DEBUG - 2019-07-20 11:44:41 --> Total execution time: 0.0206
INFO - 2019-07-20 11:44:41 --> Config Class Initialized
INFO - 2019-07-20 11:44:41 --> Hooks Class Initialized
DEBUG - 2019-07-20 11:44:41 --> UTF-8 Support Enabled
INFO - 2019-07-20 11:44:41 --> Utf8 Class Initialized
INFO - 2019-07-20 11:44:41 --> URI Class Initialized
INFO - 2019-07-20 11:44:41 --> Router Class Initialized
INFO - 2019-07-20 11:44:41 --> Output Class Initialized
INFO - 2019-07-20 11:44:41 --> Security Class Initialized
DEBUG - 2019-07-20 11:44:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 11:44:41 --> Input Class Initialized
INFO - 2019-07-20 11:44:41 --> Language Class Initialized
INFO - 2019-07-20 11:44:41 --> Loader Class Initialized
INFO - 2019-07-20 11:44:41 --> Database Driver Class Initialized
INFO - 2019-07-20 11:44:41 --> Controller Class Initialized
INFO - 2019-07-20 11:44:41 --> Model "Product" initialized
INFO - 2019-07-20 11:44:41 --> Final output sent to browser
DEBUG - 2019-07-20 11:44:41 --> Total execution time: 0.0450
INFO - 2019-07-20 11:44:45 --> Config Class Initialized
INFO - 2019-07-20 11:44:45 --> Hooks Class Initialized
DEBUG - 2019-07-20 11:44:45 --> UTF-8 Support Enabled
INFO - 2019-07-20 11:44:45 --> Utf8 Class Initialized
INFO - 2019-07-20 11:44:45 --> URI Class Initialized
INFO - 2019-07-20 11:44:45 --> Router Class Initialized
INFO - 2019-07-20 11:44:45 --> Output Class Initialized
INFO - 2019-07-20 11:44:45 --> Security Class Initialized
DEBUG - 2019-07-20 11:44:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 11:44:45 --> Input Class Initialized
INFO - 2019-07-20 11:44:45 --> Language Class Initialized
INFO - 2019-07-20 11:44:45 --> Loader Class Initialized
INFO - 2019-07-20 11:44:45 --> Database Driver Class Initialized
INFO - 2019-07-20 11:44:45 --> Controller Class Initialized
INFO - 2019-07-20 11:44:45 --> Model "Product" initialized
INFO - 2019-07-20 11:44:45 --> Final output sent to browser
DEBUG - 2019-07-20 11:44:45 --> Total execution time: 0.0497
INFO - 2019-07-20 11:46:29 --> Config Class Initialized
INFO - 2019-07-20 11:46:29 --> Hooks Class Initialized
DEBUG - 2019-07-20 11:46:29 --> UTF-8 Support Enabled
INFO - 2019-07-20 11:46:29 --> Utf8 Class Initialized
INFO - 2019-07-20 11:46:29 --> URI Class Initialized
INFO - 2019-07-20 11:46:29 --> Router Class Initialized
INFO - 2019-07-20 11:46:29 --> Output Class Initialized
INFO - 2019-07-20 11:46:29 --> Security Class Initialized
DEBUG - 2019-07-20 11:46:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 11:46:29 --> Input Class Initialized
INFO - 2019-07-20 11:46:29 --> Language Class Initialized
INFO - 2019-07-20 11:46:29 --> Loader Class Initialized
INFO - 2019-07-20 11:46:29 --> Database Driver Class Initialized
INFO - 2019-07-20 11:46:29 --> Controller Class Initialized
INFO - 2019-07-20 11:46:29 --> Model "Product" initialized
INFO - 2019-07-20 11:46:29 --> Final output sent to browser
DEBUG - 2019-07-20 11:46:29 --> Total execution time: 0.0203
INFO - 2019-07-20 11:46:29 --> Config Class Initialized
INFO - 2019-07-20 11:46:29 --> Hooks Class Initialized
DEBUG - 2019-07-20 11:46:29 --> UTF-8 Support Enabled
INFO - 2019-07-20 11:46:29 --> Utf8 Class Initialized
INFO - 2019-07-20 11:46:29 --> URI Class Initialized
INFO - 2019-07-20 11:46:29 --> Router Class Initialized
INFO - 2019-07-20 11:46:29 --> Output Class Initialized
INFO - 2019-07-20 11:46:29 --> Security Class Initialized
DEBUG - 2019-07-20 11:46:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 11:46:29 --> Input Class Initialized
INFO - 2019-07-20 11:46:29 --> Language Class Initialized
INFO - 2019-07-20 11:46:29 --> Loader Class Initialized
INFO - 2019-07-20 11:46:29 --> Database Driver Class Initialized
INFO - 2019-07-20 11:46:29 --> Controller Class Initialized
INFO - 2019-07-20 11:46:29 --> Model "Product" initialized
INFO - 2019-07-20 11:46:29 --> Final output sent to browser
DEBUG - 2019-07-20 11:46:29 --> Total execution time: 0.0252
INFO - 2019-07-20 11:46:33 --> Config Class Initialized
INFO - 2019-07-20 11:46:33 --> Hooks Class Initialized
DEBUG - 2019-07-20 11:46:33 --> UTF-8 Support Enabled
INFO - 2019-07-20 11:46:33 --> Utf8 Class Initialized
INFO - 2019-07-20 11:46:33 --> URI Class Initialized
INFO - 2019-07-20 11:46:33 --> Router Class Initialized
INFO - 2019-07-20 11:46:33 --> Output Class Initialized
INFO - 2019-07-20 11:46:33 --> Security Class Initialized
DEBUG - 2019-07-20 11:46:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 11:46:33 --> Input Class Initialized
INFO - 2019-07-20 11:46:33 --> Language Class Initialized
INFO - 2019-07-20 11:46:33 --> Loader Class Initialized
INFO - 2019-07-20 11:46:33 --> Database Driver Class Initialized
INFO - 2019-07-20 11:46:33 --> Controller Class Initialized
INFO - 2019-07-20 11:46:33 --> Model "Product" initialized
INFO - 2019-07-20 11:46:33 --> Final output sent to browser
DEBUG - 2019-07-20 11:46:33 --> Total execution time: 0.0193
INFO - 2019-07-20 11:47:18 --> Config Class Initialized
INFO - 2019-07-20 11:47:18 --> Hooks Class Initialized
DEBUG - 2019-07-20 11:47:18 --> UTF-8 Support Enabled
INFO - 2019-07-20 11:47:18 --> Utf8 Class Initialized
INFO - 2019-07-20 11:47:18 --> URI Class Initialized
INFO - 2019-07-20 11:47:18 --> Router Class Initialized
INFO - 2019-07-20 11:47:18 --> Output Class Initialized
INFO - 2019-07-20 11:47:18 --> Security Class Initialized
DEBUG - 2019-07-20 11:47:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 11:47:18 --> Input Class Initialized
INFO - 2019-07-20 11:47:18 --> Language Class Initialized
INFO - 2019-07-20 11:47:18 --> Loader Class Initialized
INFO - 2019-07-20 11:47:18 --> Database Driver Class Initialized
INFO - 2019-07-20 11:47:18 --> Controller Class Initialized
INFO - 2019-07-20 11:47:18 --> Model "Product" initialized
INFO - 2019-07-20 11:47:18 --> Final output sent to browser
DEBUG - 2019-07-20 11:47:18 --> Total execution time: 0.0235
INFO - 2019-07-20 11:47:18 --> Config Class Initialized
INFO - 2019-07-20 11:47:18 --> Hooks Class Initialized
DEBUG - 2019-07-20 11:47:18 --> UTF-8 Support Enabled
INFO - 2019-07-20 11:47:18 --> Utf8 Class Initialized
INFO - 2019-07-20 11:47:18 --> URI Class Initialized
INFO - 2019-07-20 11:47:18 --> Router Class Initialized
INFO - 2019-07-20 11:47:18 --> Output Class Initialized
INFO - 2019-07-20 11:47:18 --> Security Class Initialized
DEBUG - 2019-07-20 11:47:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 11:47:18 --> Input Class Initialized
INFO - 2019-07-20 11:47:18 --> Language Class Initialized
INFO - 2019-07-20 11:47:18 --> Loader Class Initialized
INFO - 2019-07-20 11:47:18 --> Database Driver Class Initialized
INFO - 2019-07-20 11:47:18 --> Controller Class Initialized
INFO - 2019-07-20 11:47:18 --> Model "Product" initialized
INFO - 2019-07-20 11:47:18 --> Final output sent to browser
DEBUG - 2019-07-20 11:47:18 --> Total execution time: 0.0253
INFO - 2019-07-20 11:47:22 --> Config Class Initialized
INFO - 2019-07-20 11:47:22 --> Hooks Class Initialized
DEBUG - 2019-07-20 11:47:22 --> UTF-8 Support Enabled
INFO - 2019-07-20 11:47:22 --> Utf8 Class Initialized
INFO - 2019-07-20 11:47:22 --> URI Class Initialized
INFO - 2019-07-20 11:47:22 --> Router Class Initialized
INFO - 2019-07-20 11:47:22 --> Output Class Initialized
INFO - 2019-07-20 11:47:22 --> Security Class Initialized
DEBUG - 2019-07-20 11:47:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 11:47:22 --> Input Class Initialized
INFO - 2019-07-20 11:47:22 --> Language Class Initialized
INFO - 2019-07-20 11:47:22 --> Loader Class Initialized
INFO - 2019-07-20 11:47:22 --> Database Driver Class Initialized
INFO - 2019-07-20 11:47:22 --> Controller Class Initialized
INFO - 2019-07-20 11:47:22 --> Model "Product" initialized
INFO - 2019-07-20 11:47:22 --> Final output sent to browser
DEBUG - 2019-07-20 11:47:22 --> Total execution time: 0.0242
INFO - 2019-07-20 11:47:24 --> Config Class Initialized
INFO - 2019-07-20 11:47:24 --> Hooks Class Initialized
DEBUG - 2019-07-20 11:47:24 --> UTF-8 Support Enabled
INFO - 2019-07-20 11:47:24 --> Utf8 Class Initialized
INFO - 2019-07-20 11:47:24 --> URI Class Initialized
INFO - 2019-07-20 11:47:24 --> Router Class Initialized
INFO - 2019-07-20 11:47:24 --> Output Class Initialized
INFO - 2019-07-20 11:47:24 --> Security Class Initialized
DEBUG - 2019-07-20 11:47:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 11:47:24 --> Input Class Initialized
INFO - 2019-07-20 11:47:24 --> Language Class Initialized
INFO - 2019-07-20 11:47:24 --> Loader Class Initialized
INFO - 2019-07-20 11:47:24 --> Database Driver Class Initialized
INFO - 2019-07-20 11:47:24 --> Controller Class Initialized
INFO - 2019-07-20 11:47:24 --> Model "Product" initialized
INFO - 2019-07-20 11:47:24 --> Final output sent to browser
DEBUG - 2019-07-20 11:47:24 --> Total execution time: 0.0178
INFO - 2019-07-20 11:48:08 --> Config Class Initialized
INFO - 2019-07-20 11:48:08 --> Hooks Class Initialized
DEBUG - 2019-07-20 11:48:08 --> UTF-8 Support Enabled
INFO - 2019-07-20 11:48:08 --> Utf8 Class Initialized
INFO - 2019-07-20 11:48:08 --> URI Class Initialized
INFO - 2019-07-20 11:48:08 --> Router Class Initialized
INFO - 2019-07-20 11:48:08 --> Output Class Initialized
INFO - 2019-07-20 11:48:08 --> Security Class Initialized
DEBUG - 2019-07-20 11:48:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 11:48:08 --> Input Class Initialized
INFO - 2019-07-20 11:48:08 --> Language Class Initialized
INFO - 2019-07-20 11:48:08 --> Loader Class Initialized
INFO - 2019-07-20 11:48:08 --> Database Driver Class Initialized
INFO - 2019-07-20 11:48:08 --> Controller Class Initialized
INFO - 2019-07-20 11:48:08 --> Model "Product" initialized
INFO - 2019-07-20 11:48:08 --> Final output sent to browser
DEBUG - 2019-07-20 11:48:08 --> Total execution time: 0.0223
INFO - 2019-07-20 11:48:08 --> Config Class Initialized
INFO - 2019-07-20 11:48:08 --> Hooks Class Initialized
DEBUG - 2019-07-20 11:48:08 --> UTF-8 Support Enabled
INFO - 2019-07-20 11:48:08 --> Utf8 Class Initialized
INFO - 2019-07-20 11:48:08 --> URI Class Initialized
INFO - 2019-07-20 11:48:08 --> Router Class Initialized
INFO - 2019-07-20 11:48:08 --> Output Class Initialized
INFO - 2019-07-20 11:48:08 --> Security Class Initialized
DEBUG - 2019-07-20 11:48:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 11:48:08 --> Input Class Initialized
INFO - 2019-07-20 11:48:08 --> Language Class Initialized
INFO - 2019-07-20 11:48:08 --> Loader Class Initialized
INFO - 2019-07-20 11:48:08 --> Database Driver Class Initialized
INFO - 2019-07-20 11:48:08 --> Controller Class Initialized
INFO - 2019-07-20 11:48:08 --> Model "Product" initialized
INFO - 2019-07-20 11:48:08 --> Final output sent to browser
DEBUG - 2019-07-20 11:48:08 --> Total execution time: 0.1792
INFO - 2019-07-20 11:48:18 --> Config Class Initialized
INFO - 2019-07-20 11:48:18 --> Hooks Class Initialized
DEBUG - 2019-07-20 11:48:18 --> UTF-8 Support Enabled
INFO - 2019-07-20 11:48:18 --> Utf8 Class Initialized
INFO - 2019-07-20 11:48:18 --> URI Class Initialized
INFO - 2019-07-20 11:48:18 --> Router Class Initialized
INFO - 2019-07-20 11:48:18 --> Output Class Initialized
INFO - 2019-07-20 11:48:18 --> Security Class Initialized
DEBUG - 2019-07-20 11:48:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 11:48:18 --> Input Class Initialized
INFO - 2019-07-20 11:48:18 --> Language Class Initialized
INFO - 2019-07-20 11:48:18 --> Loader Class Initialized
INFO - 2019-07-20 11:48:18 --> Database Driver Class Initialized
INFO - 2019-07-20 11:48:18 --> Controller Class Initialized
INFO - 2019-07-20 11:48:18 --> Model "Product" initialized
INFO - 2019-07-20 11:48:18 --> Final output sent to browser
DEBUG - 2019-07-20 11:48:18 --> Total execution time: 0.0215
INFO - 2019-07-20 11:48:18 --> Config Class Initialized
INFO - 2019-07-20 11:48:18 --> Hooks Class Initialized
DEBUG - 2019-07-20 11:48:18 --> UTF-8 Support Enabled
INFO - 2019-07-20 11:48:18 --> Utf8 Class Initialized
INFO - 2019-07-20 11:48:18 --> URI Class Initialized
INFO - 2019-07-20 11:48:18 --> Router Class Initialized
INFO - 2019-07-20 11:48:18 --> Output Class Initialized
INFO - 2019-07-20 11:48:18 --> Security Class Initialized
DEBUG - 2019-07-20 11:48:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 11:48:18 --> Input Class Initialized
INFO - 2019-07-20 11:48:18 --> Language Class Initialized
INFO - 2019-07-20 11:48:18 --> Loader Class Initialized
INFO - 2019-07-20 11:48:18 --> Database Driver Class Initialized
INFO - 2019-07-20 11:48:18 --> Controller Class Initialized
INFO - 2019-07-20 11:48:18 --> Model "Product" initialized
INFO - 2019-07-20 11:48:18 --> Final output sent to browser
DEBUG - 2019-07-20 11:48:18 --> Total execution time: 0.1022
INFO - 2019-07-20 11:48:28 --> Config Class Initialized
INFO - 2019-07-20 11:48:28 --> Hooks Class Initialized
DEBUG - 2019-07-20 11:48:28 --> UTF-8 Support Enabled
INFO - 2019-07-20 11:48:28 --> Utf8 Class Initialized
INFO - 2019-07-20 11:48:28 --> URI Class Initialized
INFO - 2019-07-20 11:48:28 --> Router Class Initialized
INFO - 2019-07-20 11:48:28 --> Output Class Initialized
INFO - 2019-07-20 11:48:28 --> Security Class Initialized
DEBUG - 2019-07-20 11:48:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 11:48:28 --> Input Class Initialized
INFO - 2019-07-20 11:48:28 --> Language Class Initialized
INFO - 2019-07-20 11:48:28 --> Loader Class Initialized
INFO - 2019-07-20 11:48:28 --> Database Driver Class Initialized
INFO - 2019-07-20 11:48:28 --> Controller Class Initialized
INFO - 2019-07-20 11:48:28 --> Model "Product" initialized
INFO - 2019-07-20 11:48:28 --> Final output sent to browser
DEBUG - 2019-07-20 11:48:28 --> Total execution time: 0.0213
INFO - 2019-07-20 11:48:28 --> Config Class Initialized
INFO - 2019-07-20 11:48:28 --> Hooks Class Initialized
DEBUG - 2019-07-20 11:48:28 --> UTF-8 Support Enabled
INFO - 2019-07-20 11:48:28 --> Utf8 Class Initialized
INFO - 2019-07-20 11:48:28 --> URI Class Initialized
INFO - 2019-07-20 11:48:28 --> Router Class Initialized
INFO - 2019-07-20 11:48:28 --> Output Class Initialized
INFO - 2019-07-20 11:48:28 --> Security Class Initialized
DEBUG - 2019-07-20 11:48:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 11:48:28 --> Input Class Initialized
INFO - 2019-07-20 11:48:28 --> Language Class Initialized
INFO - 2019-07-20 11:48:28 --> Loader Class Initialized
INFO - 2019-07-20 11:48:28 --> Database Driver Class Initialized
INFO - 2019-07-20 11:48:28 --> Controller Class Initialized
INFO - 2019-07-20 11:48:28 --> Model "Product" initialized
INFO - 2019-07-20 11:48:28 --> Final output sent to browser
DEBUG - 2019-07-20 11:48:28 --> Total execution time: 0.0575
INFO - 2019-07-20 11:48:31 --> Config Class Initialized
INFO - 2019-07-20 11:48:31 --> Hooks Class Initialized
DEBUG - 2019-07-20 11:48:31 --> UTF-8 Support Enabled
INFO - 2019-07-20 11:48:31 --> Utf8 Class Initialized
INFO - 2019-07-20 11:48:31 --> URI Class Initialized
INFO - 2019-07-20 11:48:31 --> Router Class Initialized
INFO - 2019-07-20 11:48:31 --> Output Class Initialized
INFO - 2019-07-20 11:48:31 --> Security Class Initialized
DEBUG - 2019-07-20 11:48:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 11:48:31 --> Input Class Initialized
INFO - 2019-07-20 11:48:31 --> Language Class Initialized
INFO - 2019-07-20 11:48:31 --> Loader Class Initialized
INFO - 2019-07-20 11:48:31 --> Database Driver Class Initialized
INFO - 2019-07-20 11:48:31 --> Controller Class Initialized
INFO - 2019-07-20 11:48:31 --> Model "Product" initialized
INFO - 2019-07-20 11:48:31 --> Final output sent to browser
DEBUG - 2019-07-20 11:48:31 --> Total execution time: 0.0197
INFO - 2019-07-20 11:49:32 --> Config Class Initialized
INFO - 2019-07-20 11:49:32 --> Hooks Class Initialized
DEBUG - 2019-07-20 11:49:32 --> UTF-8 Support Enabled
INFO - 2019-07-20 11:49:32 --> Utf8 Class Initialized
INFO - 2019-07-20 11:49:32 --> URI Class Initialized
INFO - 2019-07-20 11:49:32 --> Router Class Initialized
INFO - 2019-07-20 11:49:32 --> Output Class Initialized
INFO - 2019-07-20 11:49:32 --> Security Class Initialized
DEBUG - 2019-07-20 11:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 11:49:32 --> Input Class Initialized
INFO - 2019-07-20 11:49:32 --> Language Class Initialized
INFO - 2019-07-20 11:49:32 --> Loader Class Initialized
INFO - 2019-07-20 11:49:32 --> Database Driver Class Initialized
INFO - 2019-07-20 11:49:32 --> Controller Class Initialized
INFO - 2019-07-20 11:49:32 --> Model "Product" initialized
INFO - 2019-07-20 11:49:32 --> Final output sent to browser
DEBUG - 2019-07-20 11:49:32 --> Total execution time: 0.0240
INFO - 2019-07-20 11:49:32 --> Config Class Initialized
INFO - 2019-07-20 11:49:32 --> Hooks Class Initialized
DEBUG - 2019-07-20 11:49:32 --> UTF-8 Support Enabled
INFO - 2019-07-20 11:49:32 --> Utf8 Class Initialized
INFO - 2019-07-20 11:49:32 --> URI Class Initialized
INFO - 2019-07-20 11:49:32 --> Router Class Initialized
INFO - 2019-07-20 11:49:32 --> Output Class Initialized
INFO - 2019-07-20 11:49:32 --> Security Class Initialized
DEBUG - 2019-07-20 11:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 11:49:32 --> Input Class Initialized
INFO - 2019-07-20 11:49:32 --> Language Class Initialized
INFO - 2019-07-20 11:49:32 --> Loader Class Initialized
INFO - 2019-07-20 11:49:32 --> Database Driver Class Initialized
INFO - 2019-07-20 11:49:32 --> Controller Class Initialized
INFO - 2019-07-20 11:49:32 --> Model "Product" initialized
INFO - 2019-07-20 11:49:32 --> Final output sent to browser
DEBUG - 2019-07-20 11:49:32 --> Total execution time: 0.0283
INFO - 2019-07-20 11:49:45 --> Config Class Initialized
INFO - 2019-07-20 11:49:45 --> Hooks Class Initialized
DEBUG - 2019-07-20 11:49:45 --> UTF-8 Support Enabled
INFO - 2019-07-20 11:49:45 --> Utf8 Class Initialized
INFO - 2019-07-20 11:49:45 --> URI Class Initialized
INFO - 2019-07-20 11:49:45 --> Router Class Initialized
INFO - 2019-07-20 11:49:45 --> Output Class Initialized
INFO - 2019-07-20 11:49:45 --> Security Class Initialized
DEBUG - 2019-07-20 11:49:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 11:49:45 --> Input Class Initialized
INFO - 2019-07-20 11:49:45 --> Language Class Initialized
INFO - 2019-07-20 11:49:45 --> Loader Class Initialized
INFO - 2019-07-20 11:49:45 --> Database Driver Class Initialized
INFO - 2019-07-20 11:49:45 --> Controller Class Initialized
INFO - 2019-07-20 11:49:45 --> Model "Product" initialized
INFO - 2019-07-20 11:49:45 --> Final output sent to browser
DEBUG - 2019-07-20 11:49:45 --> Total execution time: 0.0244
INFO - 2019-07-20 11:49:45 --> Config Class Initialized
INFO - 2019-07-20 11:49:45 --> Hooks Class Initialized
DEBUG - 2019-07-20 11:49:45 --> UTF-8 Support Enabled
INFO - 2019-07-20 11:49:45 --> Utf8 Class Initialized
INFO - 2019-07-20 11:49:45 --> URI Class Initialized
INFO - 2019-07-20 11:49:45 --> Router Class Initialized
INFO - 2019-07-20 11:49:45 --> Output Class Initialized
INFO - 2019-07-20 11:49:45 --> Security Class Initialized
DEBUG - 2019-07-20 11:49:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 11:49:45 --> Input Class Initialized
INFO - 2019-07-20 11:49:45 --> Language Class Initialized
INFO - 2019-07-20 11:49:45 --> Loader Class Initialized
INFO - 2019-07-20 11:49:45 --> Database Driver Class Initialized
INFO - 2019-07-20 11:49:45 --> Controller Class Initialized
INFO - 2019-07-20 11:49:45 --> Model "Product" initialized
INFO - 2019-07-20 11:49:45 --> Final output sent to browser
DEBUG - 2019-07-20 11:49:45 --> Total execution time: 0.0193
INFO - 2019-07-20 11:49:49 --> Config Class Initialized
INFO - 2019-07-20 11:49:49 --> Hooks Class Initialized
DEBUG - 2019-07-20 11:49:49 --> UTF-8 Support Enabled
INFO - 2019-07-20 11:49:49 --> Utf8 Class Initialized
INFO - 2019-07-20 11:49:49 --> URI Class Initialized
INFO - 2019-07-20 11:49:49 --> Router Class Initialized
INFO - 2019-07-20 11:49:49 --> Output Class Initialized
INFO - 2019-07-20 11:49:49 --> Security Class Initialized
DEBUG - 2019-07-20 11:49:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 11:49:49 --> Input Class Initialized
INFO - 2019-07-20 11:49:49 --> Language Class Initialized
INFO - 2019-07-20 11:49:49 --> Loader Class Initialized
INFO - 2019-07-20 11:49:49 --> Database Driver Class Initialized
INFO - 2019-07-20 11:49:49 --> Controller Class Initialized
INFO - 2019-07-20 11:49:49 --> Model "Product" initialized
INFO - 2019-07-20 11:49:49 --> Final output sent to browser
DEBUG - 2019-07-20 11:49:49 --> Total execution time: 0.0237
INFO - 2019-07-20 11:51:55 --> Config Class Initialized
INFO - 2019-07-20 11:51:55 --> Hooks Class Initialized
DEBUG - 2019-07-20 11:51:55 --> UTF-8 Support Enabled
INFO - 2019-07-20 11:51:55 --> Utf8 Class Initialized
INFO - 2019-07-20 11:51:55 --> URI Class Initialized
INFO - 2019-07-20 11:51:55 --> Router Class Initialized
INFO - 2019-07-20 11:51:55 --> Output Class Initialized
INFO - 2019-07-20 11:51:55 --> Security Class Initialized
DEBUG - 2019-07-20 11:51:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 11:51:55 --> Input Class Initialized
INFO - 2019-07-20 11:51:55 --> Language Class Initialized
INFO - 2019-07-20 11:51:55 --> Loader Class Initialized
INFO - 2019-07-20 11:51:55 --> Database Driver Class Initialized
INFO - 2019-07-20 11:51:55 --> Controller Class Initialized
INFO - 2019-07-20 11:51:55 --> Model "Product" initialized
INFO - 2019-07-20 11:51:55 --> Final output sent to browser
DEBUG - 2019-07-20 11:51:55 --> Total execution time: 0.0218
INFO - 2019-07-20 11:51:55 --> Config Class Initialized
INFO - 2019-07-20 11:51:55 --> Hooks Class Initialized
DEBUG - 2019-07-20 11:51:55 --> UTF-8 Support Enabled
INFO - 2019-07-20 11:51:55 --> Utf8 Class Initialized
INFO - 2019-07-20 11:51:55 --> URI Class Initialized
INFO - 2019-07-20 11:51:55 --> Router Class Initialized
INFO - 2019-07-20 11:51:55 --> Output Class Initialized
INFO - 2019-07-20 11:51:55 --> Security Class Initialized
DEBUG - 2019-07-20 11:51:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 11:51:55 --> Input Class Initialized
INFO - 2019-07-20 11:51:55 --> Language Class Initialized
INFO - 2019-07-20 11:51:55 --> Loader Class Initialized
INFO - 2019-07-20 11:51:55 --> Database Driver Class Initialized
INFO - 2019-07-20 11:51:55 --> Controller Class Initialized
INFO - 2019-07-20 11:51:55 --> Model "Product" initialized
INFO - 2019-07-20 11:51:55 --> Final output sent to browser
DEBUG - 2019-07-20 11:51:55 --> Total execution time: 0.0257
INFO - 2019-07-20 11:52:03 --> Config Class Initialized
INFO - 2019-07-20 11:52:03 --> Hooks Class Initialized
DEBUG - 2019-07-20 11:52:03 --> UTF-8 Support Enabled
INFO - 2019-07-20 11:52:03 --> Utf8 Class Initialized
INFO - 2019-07-20 11:52:03 --> URI Class Initialized
INFO - 2019-07-20 11:52:03 --> Router Class Initialized
INFO - 2019-07-20 11:52:03 --> Output Class Initialized
INFO - 2019-07-20 11:52:03 --> Security Class Initialized
DEBUG - 2019-07-20 11:52:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 11:52:03 --> Input Class Initialized
INFO - 2019-07-20 11:52:03 --> Language Class Initialized
INFO - 2019-07-20 11:52:03 --> Loader Class Initialized
INFO - 2019-07-20 11:52:03 --> Database Driver Class Initialized
INFO - 2019-07-20 11:52:03 --> Controller Class Initialized
INFO - 2019-07-20 11:52:03 --> Model "Product" initialized
INFO - 2019-07-20 11:52:03 --> Final output sent to browser
DEBUG - 2019-07-20 11:52:03 --> Total execution time: 0.0269
INFO - 2019-07-20 11:56:47 --> Config Class Initialized
INFO - 2019-07-20 11:56:47 --> Hooks Class Initialized
DEBUG - 2019-07-20 11:56:47 --> UTF-8 Support Enabled
INFO - 2019-07-20 11:56:47 --> Utf8 Class Initialized
INFO - 2019-07-20 11:56:47 --> URI Class Initialized
INFO - 2019-07-20 11:56:47 --> Router Class Initialized
INFO - 2019-07-20 11:56:47 --> Output Class Initialized
INFO - 2019-07-20 11:56:47 --> Security Class Initialized
DEBUG - 2019-07-20 11:56:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 11:56:47 --> Input Class Initialized
INFO - 2019-07-20 11:56:47 --> Language Class Initialized
INFO - 2019-07-20 11:56:47 --> Loader Class Initialized
INFO - 2019-07-20 11:56:47 --> Database Driver Class Initialized
INFO - 2019-07-20 11:56:47 --> Controller Class Initialized
INFO - 2019-07-20 11:56:47 --> Model "Product" initialized
INFO - 2019-07-20 11:56:47 --> Final output sent to browser
DEBUG - 2019-07-20 11:56:47 --> Total execution time: 0.0185
INFO - 2019-07-20 18:13:48 --> Config Class Initialized
INFO - 2019-07-20 18:13:49 --> Hooks Class Initialized
DEBUG - 2019-07-20 18:13:49 --> UTF-8 Support Enabled
INFO - 2019-07-20 18:13:49 --> Utf8 Class Initialized
INFO - 2019-07-20 18:13:49 --> URI Class Initialized
INFO - 2019-07-20 18:13:49 --> Router Class Initialized
INFO - 2019-07-20 18:13:49 --> Output Class Initialized
INFO - 2019-07-20 18:13:49 --> Security Class Initialized
DEBUG - 2019-07-20 18:13:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 18:13:49 --> Input Class Initialized
INFO - 2019-07-20 18:13:49 --> Language Class Initialized
INFO - 2019-07-20 18:13:49 --> Loader Class Initialized
INFO - 2019-07-20 18:13:49 --> Database Driver Class Initialized
INFO - 2019-07-20 18:13:49 --> Controller Class Initialized
INFO - 2019-07-20 18:13:49 --> Model "Product" initialized
INFO - 2019-07-20 18:13:49 --> Final output sent to browser
DEBUG - 2019-07-20 18:13:49 --> Total execution time: 0.1829
INFO - 2019-07-20 18:13:49 --> Config Class Initialized
INFO - 2019-07-20 18:13:49 --> Hooks Class Initialized
DEBUG - 2019-07-20 18:13:49 --> UTF-8 Support Enabled
INFO - 2019-07-20 18:13:49 --> Utf8 Class Initialized
INFO - 2019-07-20 18:13:49 --> URI Class Initialized
INFO - 2019-07-20 18:13:49 --> Router Class Initialized
INFO - 2019-07-20 18:13:49 --> Output Class Initialized
INFO - 2019-07-20 18:13:49 --> Security Class Initialized
DEBUG - 2019-07-20 18:13:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 18:13:49 --> Input Class Initialized
INFO - 2019-07-20 18:13:49 --> Language Class Initialized
INFO - 2019-07-20 18:13:49 --> Loader Class Initialized
INFO - 2019-07-20 18:13:49 --> Database Driver Class Initialized
INFO - 2019-07-20 18:13:49 --> Controller Class Initialized
INFO - 2019-07-20 18:13:49 --> Model "Product" initialized
INFO - 2019-07-20 18:13:49 --> Final output sent to browser
DEBUG - 2019-07-20 18:13:49 --> Total execution time: 0.0224
INFO - 2019-07-20 18:13:53 --> Config Class Initialized
INFO - 2019-07-20 18:13:53 --> Hooks Class Initialized
DEBUG - 2019-07-20 18:13:53 --> UTF-8 Support Enabled
INFO - 2019-07-20 18:13:53 --> Utf8 Class Initialized
INFO - 2019-07-20 18:13:53 --> URI Class Initialized
INFO - 2019-07-20 18:13:53 --> Router Class Initialized
INFO - 2019-07-20 18:13:53 --> Output Class Initialized
INFO - 2019-07-20 18:13:53 --> Security Class Initialized
DEBUG - 2019-07-20 18:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 18:13:53 --> Input Class Initialized
INFO - 2019-07-20 18:13:53 --> Language Class Initialized
INFO - 2019-07-20 18:13:53 --> Loader Class Initialized
INFO - 2019-07-20 18:13:53 --> Database Driver Class Initialized
INFO - 2019-07-20 18:13:53 --> Controller Class Initialized
INFO - 2019-07-20 18:13:53 --> Model "Product" initialized
INFO - 2019-07-20 18:13:53 --> Final output sent to browser
DEBUG - 2019-07-20 18:13:53 --> Total execution time: 0.0250
INFO - 2019-07-20 18:21:04 --> Config Class Initialized
INFO - 2019-07-20 18:21:04 --> Hooks Class Initialized
DEBUG - 2019-07-20 18:21:04 --> UTF-8 Support Enabled
INFO - 2019-07-20 18:21:04 --> Utf8 Class Initialized
INFO - 2019-07-20 18:21:04 --> URI Class Initialized
INFO - 2019-07-20 18:21:04 --> Router Class Initialized
INFO - 2019-07-20 18:21:04 --> Output Class Initialized
INFO - 2019-07-20 18:21:04 --> Security Class Initialized
DEBUG - 2019-07-20 18:21:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 18:21:04 --> Input Class Initialized
INFO - 2019-07-20 18:21:04 --> Language Class Initialized
INFO - 2019-07-20 18:21:04 --> Loader Class Initialized
INFO - 2019-07-20 18:21:04 --> Database Driver Class Initialized
INFO - 2019-07-20 18:21:05 --> Controller Class Initialized
INFO - 2019-07-20 18:21:05 --> Model "Product" initialized
INFO - 2019-07-20 18:21:05 --> Final output sent to browser
DEBUG - 2019-07-20 18:21:05 --> Total execution time: 0.8146
INFO - 2019-07-20 18:21:05 --> Config Class Initialized
INFO - 2019-07-20 18:21:05 --> Hooks Class Initialized
DEBUG - 2019-07-20 18:21:05 --> UTF-8 Support Enabled
INFO - 2019-07-20 18:21:05 --> Utf8 Class Initialized
INFO - 2019-07-20 18:21:05 --> URI Class Initialized
INFO - 2019-07-20 18:21:05 --> Router Class Initialized
INFO - 2019-07-20 18:21:05 --> Output Class Initialized
INFO - 2019-07-20 18:21:05 --> Security Class Initialized
DEBUG - 2019-07-20 18:21:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 18:21:05 --> Input Class Initialized
INFO - 2019-07-20 18:21:05 --> Language Class Initialized
INFO - 2019-07-20 18:21:05 --> Loader Class Initialized
INFO - 2019-07-20 18:21:05 --> Database Driver Class Initialized
INFO - 2019-07-20 18:21:05 --> Controller Class Initialized
INFO - 2019-07-20 18:21:05 --> Model "Product" initialized
INFO - 2019-07-20 18:21:05 --> Final output sent to browser
DEBUG - 2019-07-20 18:21:05 --> Total execution time: 0.1554
INFO - 2019-07-20 18:43:24 --> Config Class Initialized
INFO - 2019-07-20 18:43:24 --> Hooks Class Initialized
DEBUG - 2019-07-20 18:43:24 --> UTF-8 Support Enabled
INFO - 2019-07-20 18:43:24 --> Utf8 Class Initialized
INFO - 2019-07-20 18:43:24 --> URI Class Initialized
INFO - 2019-07-20 18:43:24 --> Router Class Initialized
INFO - 2019-07-20 18:43:24 --> Output Class Initialized
INFO - 2019-07-20 18:43:24 --> Security Class Initialized
DEBUG - 2019-07-20 18:43:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 18:43:24 --> Input Class Initialized
INFO - 2019-07-20 18:43:24 --> Language Class Initialized
INFO - 2019-07-20 18:43:24 --> Loader Class Initialized
INFO - 2019-07-20 18:43:24 --> Database Driver Class Initialized
INFO - 2019-07-20 18:43:24 --> Controller Class Initialized
INFO - 2019-07-20 18:43:24 --> Model "Product" initialized
INFO - 2019-07-20 18:43:24 --> Final output sent to browser
DEBUG - 2019-07-20 18:43:24 --> Total execution time: 0.2870
INFO - 2019-07-20 18:45:28 --> Config Class Initialized
INFO - 2019-07-20 18:45:28 --> Hooks Class Initialized
DEBUG - 2019-07-20 18:45:28 --> UTF-8 Support Enabled
INFO - 2019-07-20 18:45:28 --> Utf8 Class Initialized
INFO - 2019-07-20 18:45:28 --> URI Class Initialized
INFO - 2019-07-20 18:45:28 --> Router Class Initialized
INFO - 2019-07-20 18:45:28 --> Output Class Initialized
INFO - 2019-07-20 18:45:28 --> Security Class Initialized
DEBUG - 2019-07-20 18:45:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 18:45:28 --> Input Class Initialized
INFO - 2019-07-20 18:45:28 --> Language Class Initialized
INFO - 2019-07-20 18:45:28 --> Loader Class Initialized
INFO - 2019-07-20 18:45:28 --> Database Driver Class Initialized
INFO - 2019-07-20 18:45:28 --> Controller Class Initialized
INFO - 2019-07-20 18:45:28 --> Model "Product" initialized
INFO - 2019-07-20 18:45:28 --> Final output sent to browser
DEBUG - 2019-07-20 18:45:28 --> Total execution time: 0.0400
INFO - 2019-07-20 18:46:18 --> Config Class Initialized
INFO - 2019-07-20 18:46:18 --> Hooks Class Initialized
DEBUG - 2019-07-20 18:46:18 --> UTF-8 Support Enabled
INFO - 2019-07-20 18:46:18 --> Utf8 Class Initialized
INFO - 2019-07-20 18:46:18 --> URI Class Initialized
INFO - 2019-07-20 18:46:18 --> Router Class Initialized
INFO - 2019-07-20 18:46:18 --> Output Class Initialized
INFO - 2019-07-20 18:46:18 --> Security Class Initialized
DEBUG - 2019-07-20 18:46:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 18:46:18 --> Input Class Initialized
INFO - 2019-07-20 18:46:18 --> Language Class Initialized
INFO - 2019-07-20 18:46:18 --> Loader Class Initialized
INFO - 2019-07-20 18:46:18 --> Database Driver Class Initialized
INFO - 2019-07-20 18:46:18 --> Controller Class Initialized
INFO - 2019-07-20 18:46:18 --> Model "Product" initialized
INFO - 2019-07-20 18:46:18 --> Final output sent to browser
DEBUG - 2019-07-20 18:46:18 --> Total execution time: 0.0265
INFO - 2019-07-20 18:46:38 --> Config Class Initialized
INFO - 2019-07-20 18:46:38 --> Hooks Class Initialized
DEBUG - 2019-07-20 18:46:38 --> UTF-8 Support Enabled
INFO - 2019-07-20 18:46:38 --> Utf8 Class Initialized
INFO - 2019-07-20 18:46:38 --> URI Class Initialized
INFO - 2019-07-20 18:46:38 --> Router Class Initialized
INFO - 2019-07-20 18:46:38 --> Output Class Initialized
INFO - 2019-07-20 18:46:38 --> Security Class Initialized
DEBUG - 2019-07-20 18:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 18:46:38 --> Input Class Initialized
INFO - 2019-07-20 18:46:38 --> Language Class Initialized
INFO - 2019-07-20 18:46:38 --> Loader Class Initialized
INFO - 2019-07-20 18:46:38 --> Database Driver Class Initialized
INFO - 2019-07-20 18:46:38 --> Controller Class Initialized
INFO - 2019-07-20 18:46:38 --> Model "Product" initialized
INFO - 2019-07-20 18:46:38 --> Final output sent to browser
DEBUG - 2019-07-20 18:46:38 --> Total execution time: 0.0287
INFO - 2019-07-20 18:46:57 --> Config Class Initialized
INFO - 2019-07-20 18:46:57 --> Hooks Class Initialized
DEBUG - 2019-07-20 18:46:57 --> UTF-8 Support Enabled
INFO - 2019-07-20 18:46:57 --> Utf8 Class Initialized
INFO - 2019-07-20 18:46:57 --> URI Class Initialized
INFO - 2019-07-20 18:46:57 --> Router Class Initialized
INFO - 2019-07-20 18:46:57 --> Output Class Initialized
INFO - 2019-07-20 18:46:57 --> Security Class Initialized
DEBUG - 2019-07-20 18:46:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 18:46:57 --> Input Class Initialized
INFO - 2019-07-20 18:46:57 --> Language Class Initialized
INFO - 2019-07-20 18:46:57 --> Loader Class Initialized
INFO - 2019-07-20 18:46:57 --> Database Driver Class Initialized
INFO - 2019-07-20 18:46:57 --> Controller Class Initialized
INFO - 2019-07-20 18:46:57 --> Model "Product" initialized
INFO - 2019-07-20 18:46:57 --> Final output sent to browser
DEBUG - 2019-07-20 18:46:57 --> Total execution time: 0.0240
INFO - 2019-07-20 18:47:28 --> Config Class Initialized
INFO - 2019-07-20 18:47:28 --> Hooks Class Initialized
DEBUG - 2019-07-20 18:47:28 --> UTF-8 Support Enabled
INFO - 2019-07-20 18:47:28 --> Utf8 Class Initialized
INFO - 2019-07-20 18:47:28 --> URI Class Initialized
INFO - 2019-07-20 18:47:28 --> Router Class Initialized
INFO - 2019-07-20 18:47:28 --> Output Class Initialized
INFO - 2019-07-20 18:47:28 --> Security Class Initialized
DEBUG - 2019-07-20 18:47:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 18:47:28 --> Input Class Initialized
INFO - 2019-07-20 18:47:28 --> Language Class Initialized
INFO - 2019-07-20 18:47:28 --> Loader Class Initialized
INFO - 2019-07-20 18:47:28 --> Database Driver Class Initialized
INFO - 2019-07-20 18:47:28 --> Controller Class Initialized
INFO - 2019-07-20 18:47:28 --> Model "Product" initialized
INFO - 2019-07-20 18:47:28 --> Final output sent to browser
DEBUG - 2019-07-20 18:47:28 --> Total execution time: 0.0256
INFO - 2019-07-20 18:48:24 --> Config Class Initialized
INFO - 2019-07-20 18:48:24 --> Hooks Class Initialized
DEBUG - 2019-07-20 18:48:24 --> UTF-8 Support Enabled
INFO - 2019-07-20 18:48:24 --> Utf8 Class Initialized
INFO - 2019-07-20 18:48:24 --> URI Class Initialized
INFO - 2019-07-20 18:48:24 --> Router Class Initialized
INFO - 2019-07-20 18:48:24 --> Output Class Initialized
INFO - 2019-07-20 18:48:24 --> Security Class Initialized
DEBUG - 2019-07-20 18:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 18:48:24 --> Input Class Initialized
INFO - 2019-07-20 18:48:24 --> Language Class Initialized
INFO - 2019-07-20 18:48:24 --> Loader Class Initialized
INFO - 2019-07-20 18:48:24 --> Database Driver Class Initialized
INFO - 2019-07-20 18:48:24 --> Controller Class Initialized
INFO - 2019-07-20 18:48:24 --> Model "Product" initialized
INFO - 2019-07-20 18:48:24 --> Final output sent to browser
DEBUG - 2019-07-20 18:48:24 --> Total execution time: 0.0252
INFO - 2019-07-20 18:48:30 --> Config Class Initialized
INFO - 2019-07-20 18:48:30 --> Hooks Class Initialized
DEBUG - 2019-07-20 18:48:30 --> UTF-8 Support Enabled
INFO - 2019-07-20 18:48:30 --> Utf8 Class Initialized
INFO - 2019-07-20 18:48:30 --> URI Class Initialized
INFO - 2019-07-20 18:48:30 --> Router Class Initialized
INFO - 2019-07-20 18:48:30 --> Output Class Initialized
INFO - 2019-07-20 18:48:30 --> Security Class Initialized
DEBUG - 2019-07-20 18:48:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 18:48:30 --> Input Class Initialized
INFO - 2019-07-20 18:48:30 --> Language Class Initialized
INFO - 2019-07-20 18:48:30 --> Loader Class Initialized
INFO - 2019-07-20 18:48:30 --> Database Driver Class Initialized
INFO - 2019-07-20 18:48:30 --> Controller Class Initialized
INFO - 2019-07-20 18:48:30 --> Model "Product" initialized
INFO - 2019-07-20 18:48:30 --> Final output sent to browser
DEBUG - 2019-07-20 18:48:30 --> Total execution time: 0.0251
INFO - 2019-07-20 18:55:50 --> Config Class Initialized
INFO - 2019-07-20 18:55:50 --> Hooks Class Initialized
DEBUG - 2019-07-20 18:55:50 --> UTF-8 Support Enabled
INFO - 2019-07-20 18:55:50 --> Utf8 Class Initialized
INFO - 2019-07-20 18:55:50 --> URI Class Initialized
INFO - 2019-07-20 18:55:50 --> Router Class Initialized
INFO - 2019-07-20 18:55:50 --> Output Class Initialized
INFO - 2019-07-20 18:55:50 --> Security Class Initialized
DEBUG - 2019-07-20 18:55:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 18:55:50 --> Input Class Initialized
INFO - 2019-07-20 18:55:50 --> Language Class Initialized
INFO - 2019-07-20 18:55:50 --> Loader Class Initialized
INFO - 2019-07-20 18:55:50 --> Database Driver Class Initialized
INFO - 2019-07-20 18:55:50 --> Controller Class Initialized
INFO - 2019-07-20 18:55:50 --> Model "Product" initialized
INFO - 2019-07-20 18:55:50 --> Final output sent to browser
DEBUG - 2019-07-20 18:55:50 --> Total execution time: 0.1271
INFO - 2019-07-20 18:55:54 --> Config Class Initialized
INFO - 2019-07-20 18:55:54 --> Hooks Class Initialized
DEBUG - 2019-07-20 18:55:54 --> UTF-8 Support Enabled
INFO - 2019-07-20 18:55:54 --> Utf8 Class Initialized
INFO - 2019-07-20 18:55:54 --> URI Class Initialized
INFO - 2019-07-20 18:55:54 --> Router Class Initialized
INFO - 2019-07-20 18:55:54 --> Output Class Initialized
INFO - 2019-07-20 18:55:54 --> Security Class Initialized
DEBUG - 2019-07-20 18:55:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 18:55:54 --> Input Class Initialized
INFO - 2019-07-20 18:55:54 --> Language Class Initialized
INFO - 2019-07-20 18:55:54 --> Loader Class Initialized
INFO - 2019-07-20 18:55:54 --> Database Driver Class Initialized
INFO - 2019-07-20 18:55:54 --> Controller Class Initialized
INFO - 2019-07-20 18:55:54 --> Model "Product" initialized
INFO - 2019-07-20 18:55:54 --> Final output sent to browser
DEBUG - 2019-07-20 18:55:54 --> Total execution time: 0.0262
INFO - 2019-07-20 18:56:38 --> Config Class Initialized
INFO - 2019-07-20 18:56:38 --> Hooks Class Initialized
DEBUG - 2019-07-20 18:56:38 --> UTF-8 Support Enabled
INFO - 2019-07-20 18:56:38 --> Utf8 Class Initialized
INFO - 2019-07-20 18:56:38 --> URI Class Initialized
INFO - 2019-07-20 18:56:38 --> Router Class Initialized
INFO - 2019-07-20 18:56:38 --> Output Class Initialized
INFO - 2019-07-20 18:56:38 --> Security Class Initialized
DEBUG - 2019-07-20 18:56:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 18:56:38 --> Input Class Initialized
INFO - 2019-07-20 18:56:38 --> Language Class Initialized
INFO - 2019-07-20 18:56:38 --> Loader Class Initialized
INFO - 2019-07-20 18:56:38 --> Database Driver Class Initialized
INFO - 2019-07-20 18:56:38 --> Controller Class Initialized
INFO - 2019-07-20 18:56:38 --> Model "Product" initialized
INFO - 2019-07-20 18:56:38 --> Final output sent to browser
DEBUG - 2019-07-20 18:56:38 --> Total execution time: 0.0237
INFO - 2019-07-20 18:56:47 --> Config Class Initialized
INFO - 2019-07-20 18:56:47 --> Hooks Class Initialized
DEBUG - 2019-07-20 18:56:47 --> UTF-8 Support Enabled
INFO - 2019-07-20 18:56:47 --> Utf8 Class Initialized
INFO - 2019-07-20 18:56:47 --> URI Class Initialized
INFO - 2019-07-20 18:56:47 --> Router Class Initialized
INFO - 2019-07-20 18:56:47 --> Output Class Initialized
INFO - 2019-07-20 18:56:47 --> Security Class Initialized
DEBUG - 2019-07-20 18:56:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 18:56:47 --> Input Class Initialized
INFO - 2019-07-20 18:56:47 --> Language Class Initialized
INFO - 2019-07-20 18:56:47 --> Loader Class Initialized
INFO - 2019-07-20 18:56:47 --> Database Driver Class Initialized
INFO - 2019-07-20 18:56:47 --> Controller Class Initialized
INFO - 2019-07-20 18:56:47 --> Model "Product" initialized
INFO - 2019-07-20 18:56:47 --> Final output sent to browser
DEBUG - 2019-07-20 18:56:47 --> Total execution time: 0.0203
INFO - 2019-07-20 19:03:39 --> Config Class Initialized
INFO - 2019-07-20 19:03:39 --> Hooks Class Initialized
DEBUG - 2019-07-20 19:03:39 --> UTF-8 Support Enabled
INFO - 2019-07-20 19:03:39 --> Utf8 Class Initialized
INFO - 2019-07-20 19:03:39 --> URI Class Initialized
INFO - 2019-07-20 19:03:39 --> Router Class Initialized
INFO - 2019-07-20 19:03:39 --> Output Class Initialized
INFO - 2019-07-20 19:03:39 --> Security Class Initialized
DEBUG - 2019-07-20 19:03:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 19:03:39 --> Input Class Initialized
INFO - 2019-07-20 19:03:39 --> Language Class Initialized
INFO - 2019-07-20 19:03:39 --> Loader Class Initialized
INFO - 2019-07-20 19:03:39 --> Database Driver Class Initialized
INFO - 2019-07-20 19:03:39 --> Controller Class Initialized
INFO - 2019-07-20 19:03:39 --> Model "Product" initialized
INFO - 2019-07-20 19:03:39 --> Final output sent to browser
DEBUG - 2019-07-20 19:03:39 --> Total execution time: 0.0198
INFO - 2019-07-20 19:03:52 --> Config Class Initialized
INFO - 2019-07-20 19:03:52 --> Hooks Class Initialized
DEBUG - 2019-07-20 19:03:52 --> UTF-8 Support Enabled
INFO - 2019-07-20 19:03:52 --> Utf8 Class Initialized
INFO - 2019-07-20 19:03:52 --> URI Class Initialized
INFO - 2019-07-20 19:03:52 --> Router Class Initialized
INFO - 2019-07-20 19:03:52 --> Output Class Initialized
INFO - 2019-07-20 19:03:52 --> Security Class Initialized
DEBUG - 2019-07-20 19:03:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 19:03:52 --> Input Class Initialized
INFO - 2019-07-20 19:03:52 --> Language Class Initialized
INFO - 2019-07-20 19:03:52 --> Loader Class Initialized
INFO - 2019-07-20 19:03:52 --> Database Driver Class Initialized
INFO - 2019-07-20 19:03:52 --> Controller Class Initialized
INFO - 2019-07-20 19:03:52 --> Model "Product" initialized
INFO - 2019-07-20 19:03:52 --> Final output sent to browser
DEBUG - 2019-07-20 19:03:52 --> Total execution time: 0.0265
INFO - 2019-07-20 19:04:04 --> Config Class Initialized
INFO - 2019-07-20 19:04:04 --> Hooks Class Initialized
DEBUG - 2019-07-20 19:04:04 --> UTF-8 Support Enabled
INFO - 2019-07-20 19:04:04 --> Utf8 Class Initialized
INFO - 2019-07-20 19:04:04 --> URI Class Initialized
INFO - 2019-07-20 19:04:04 --> Router Class Initialized
INFO - 2019-07-20 19:04:04 --> Output Class Initialized
INFO - 2019-07-20 19:04:04 --> Security Class Initialized
DEBUG - 2019-07-20 19:04:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 19:04:04 --> Input Class Initialized
INFO - 2019-07-20 19:04:04 --> Language Class Initialized
INFO - 2019-07-20 19:04:04 --> Loader Class Initialized
INFO - 2019-07-20 19:04:04 --> Database Driver Class Initialized
INFO - 2019-07-20 19:04:04 --> Controller Class Initialized
INFO - 2019-07-20 19:04:04 --> Model "Product" initialized
INFO - 2019-07-20 19:04:04 --> Final output sent to browser
DEBUG - 2019-07-20 19:04:04 --> Total execution time: 0.0249
INFO - 2019-07-20 19:04:16 --> Config Class Initialized
INFO - 2019-07-20 19:04:16 --> Hooks Class Initialized
DEBUG - 2019-07-20 19:04:16 --> UTF-8 Support Enabled
INFO - 2019-07-20 19:04:16 --> Utf8 Class Initialized
INFO - 2019-07-20 19:04:16 --> URI Class Initialized
INFO - 2019-07-20 19:04:16 --> Router Class Initialized
INFO - 2019-07-20 19:04:16 --> Output Class Initialized
INFO - 2019-07-20 19:04:16 --> Security Class Initialized
DEBUG - 2019-07-20 19:04:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 19:04:16 --> Input Class Initialized
INFO - 2019-07-20 19:04:16 --> Language Class Initialized
INFO - 2019-07-20 19:04:16 --> Loader Class Initialized
INFO - 2019-07-20 19:04:16 --> Database Driver Class Initialized
INFO - 2019-07-20 19:04:16 --> Controller Class Initialized
INFO - 2019-07-20 19:04:16 --> Model "Product" initialized
INFO - 2019-07-20 19:04:16 --> Final output sent to browser
DEBUG - 2019-07-20 19:04:16 --> Total execution time: 0.0256
INFO - 2019-07-20 19:04:23 --> Config Class Initialized
INFO - 2019-07-20 19:04:23 --> Hooks Class Initialized
DEBUG - 2019-07-20 19:04:23 --> UTF-8 Support Enabled
INFO - 2019-07-20 19:04:23 --> Utf8 Class Initialized
INFO - 2019-07-20 19:04:23 --> URI Class Initialized
INFO - 2019-07-20 19:04:23 --> Router Class Initialized
INFO - 2019-07-20 19:04:23 --> Output Class Initialized
INFO - 2019-07-20 19:04:23 --> Security Class Initialized
DEBUG - 2019-07-20 19:04:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 19:04:23 --> Input Class Initialized
INFO - 2019-07-20 19:04:23 --> Language Class Initialized
INFO - 2019-07-20 19:04:23 --> Loader Class Initialized
INFO - 2019-07-20 19:04:23 --> Database Driver Class Initialized
INFO - 2019-07-20 19:04:23 --> Controller Class Initialized
INFO - 2019-07-20 19:04:23 --> Model "Product" initialized
INFO - 2019-07-20 19:04:23 --> Final output sent to browser
DEBUG - 2019-07-20 19:04:23 --> Total execution time: 0.0224
INFO - 2019-07-20 19:16:39 --> Config Class Initialized
INFO - 2019-07-20 19:16:39 --> Hooks Class Initialized
DEBUG - 2019-07-20 19:16:39 --> UTF-8 Support Enabled
INFO - 2019-07-20 19:16:39 --> Utf8 Class Initialized
INFO - 2019-07-20 19:16:39 --> URI Class Initialized
INFO - 2019-07-20 19:16:39 --> Router Class Initialized
INFO - 2019-07-20 19:16:39 --> Output Class Initialized
INFO - 2019-07-20 19:16:39 --> Security Class Initialized
DEBUG - 2019-07-20 19:16:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 19:16:39 --> Input Class Initialized
INFO - 2019-07-20 19:16:39 --> Language Class Initialized
INFO - 2019-07-20 19:16:39 --> Loader Class Initialized
INFO - 2019-07-20 19:16:39 --> Database Driver Class Initialized
INFO - 2019-07-20 19:16:39 --> Controller Class Initialized
INFO - 2019-07-20 19:16:39 --> Model "Product" initialized
INFO - 2019-07-20 19:16:39 --> Final output sent to browser
DEBUG - 2019-07-20 19:16:39 --> Total execution time: 0.2440
INFO - 2019-07-20 19:17:02 --> Config Class Initialized
INFO - 2019-07-20 19:17:02 --> Hooks Class Initialized
DEBUG - 2019-07-20 19:17:02 --> UTF-8 Support Enabled
INFO - 2019-07-20 19:17:02 --> Utf8 Class Initialized
INFO - 2019-07-20 19:17:02 --> URI Class Initialized
INFO - 2019-07-20 19:17:02 --> Router Class Initialized
INFO - 2019-07-20 19:17:02 --> Output Class Initialized
INFO - 2019-07-20 19:17:02 --> Security Class Initialized
DEBUG - 2019-07-20 19:17:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 19:17:02 --> Input Class Initialized
INFO - 2019-07-20 19:17:02 --> Language Class Initialized
INFO - 2019-07-20 19:17:02 --> Loader Class Initialized
INFO - 2019-07-20 19:17:03 --> Database Driver Class Initialized
INFO - 2019-07-20 19:17:03 --> Controller Class Initialized
INFO - 2019-07-20 19:17:03 --> Model "Product" initialized
INFO - 2019-07-20 19:17:03 --> Final output sent to browser
DEBUG - 2019-07-20 19:17:03 --> Total execution time: 0.0326
INFO - 2019-07-20 19:18:41 --> Config Class Initialized
INFO - 2019-07-20 19:18:41 --> Hooks Class Initialized
DEBUG - 2019-07-20 19:18:41 --> UTF-8 Support Enabled
INFO - 2019-07-20 19:18:41 --> Utf8 Class Initialized
INFO - 2019-07-20 19:18:41 --> URI Class Initialized
INFO - 2019-07-20 19:18:41 --> Router Class Initialized
INFO - 2019-07-20 19:18:41 --> Output Class Initialized
INFO - 2019-07-20 19:18:41 --> Security Class Initialized
DEBUG - 2019-07-20 19:18:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 19:18:41 --> Input Class Initialized
INFO - 2019-07-20 19:18:41 --> Language Class Initialized
INFO - 2019-07-20 19:18:41 --> Loader Class Initialized
INFO - 2019-07-20 19:18:41 --> Database Driver Class Initialized
INFO - 2019-07-20 19:18:41 --> Controller Class Initialized
INFO - 2019-07-20 19:18:41 --> Model "Product" initialized
INFO - 2019-07-20 19:18:41 --> Final output sent to browser
DEBUG - 2019-07-20 19:18:41 --> Total execution time: 0.0285
INFO - 2019-07-20 19:20:48 --> Config Class Initialized
INFO - 2019-07-20 19:20:48 --> Hooks Class Initialized
DEBUG - 2019-07-20 19:20:48 --> UTF-8 Support Enabled
INFO - 2019-07-20 19:20:48 --> Utf8 Class Initialized
INFO - 2019-07-20 19:20:48 --> URI Class Initialized
INFO - 2019-07-20 19:20:48 --> Router Class Initialized
INFO - 2019-07-20 19:20:48 --> Output Class Initialized
INFO - 2019-07-20 19:20:48 --> Security Class Initialized
DEBUG - 2019-07-20 19:20:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 19:20:48 --> Input Class Initialized
INFO - 2019-07-20 19:20:48 --> Language Class Initialized
INFO - 2019-07-20 19:20:48 --> Loader Class Initialized
INFO - 2019-07-20 19:20:48 --> Database Driver Class Initialized
INFO - 2019-07-20 19:20:48 --> Controller Class Initialized
INFO - 2019-07-20 19:20:48 --> Model "Product" initialized
INFO - 2019-07-20 19:20:48 --> Final output sent to browser
DEBUG - 2019-07-20 19:20:48 --> Total execution time: 0.0519
INFO - 2019-07-20 19:23:24 --> Config Class Initialized
INFO - 2019-07-20 19:23:24 --> Hooks Class Initialized
DEBUG - 2019-07-20 19:23:24 --> UTF-8 Support Enabled
INFO - 2019-07-20 19:23:24 --> Utf8 Class Initialized
INFO - 2019-07-20 19:23:24 --> URI Class Initialized
INFO - 2019-07-20 19:23:24 --> Router Class Initialized
INFO - 2019-07-20 19:23:24 --> Output Class Initialized
INFO - 2019-07-20 19:23:24 --> Security Class Initialized
DEBUG - 2019-07-20 19:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 19:23:24 --> Input Class Initialized
INFO - 2019-07-20 19:23:24 --> Language Class Initialized
INFO - 2019-07-20 19:23:24 --> Loader Class Initialized
INFO - 2019-07-20 19:23:24 --> Database Driver Class Initialized
INFO - 2019-07-20 19:23:24 --> Controller Class Initialized
INFO - 2019-07-20 19:23:24 --> Model "Product" initialized
INFO - 2019-07-20 19:23:24 --> Final output sent to browser
DEBUG - 2019-07-20 19:23:24 --> Total execution time: 0.0498
INFO - 2019-07-20 19:24:00 --> Config Class Initialized
INFO - 2019-07-20 19:24:00 --> Hooks Class Initialized
DEBUG - 2019-07-20 19:24:00 --> UTF-8 Support Enabled
INFO - 2019-07-20 19:24:00 --> Utf8 Class Initialized
INFO - 2019-07-20 19:24:00 --> URI Class Initialized
INFO - 2019-07-20 19:24:00 --> Router Class Initialized
INFO - 2019-07-20 19:24:00 --> Output Class Initialized
INFO - 2019-07-20 19:24:00 --> Security Class Initialized
DEBUG - 2019-07-20 19:24:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 19:24:00 --> Input Class Initialized
INFO - 2019-07-20 19:24:00 --> Language Class Initialized
INFO - 2019-07-20 19:24:00 --> Loader Class Initialized
INFO - 2019-07-20 19:24:00 --> Database Driver Class Initialized
INFO - 2019-07-20 19:24:00 --> Controller Class Initialized
INFO - 2019-07-20 19:24:00 --> Model "Product" initialized
INFO - 2019-07-20 19:24:00 --> Final output sent to browser
DEBUG - 2019-07-20 19:24:00 --> Total execution time: 0.0228
INFO - 2019-07-20 19:24:00 --> Config Class Initialized
INFO - 2019-07-20 19:24:00 --> Hooks Class Initialized
DEBUG - 2019-07-20 19:24:00 --> UTF-8 Support Enabled
INFO - 2019-07-20 19:24:00 --> Utf8 Class Initialized
INFO - 2019-07-20 19:24:00 --> URI Class Initialized
INFO - 2019-07-20 19:24:00 --> Router Class Initialized
INFO - 2019-07-20 19:24:00 --> Output Class Initialized
INFO - 2019-07-20 19:24:00 --> Security Class Initialized
DEBUG - 2019-07-20 19:24:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 19:24:00 --> Input Class Initialized
INFO - 2019-07-20 19:24:00 --> Language Class Initialized
ERROR - 2019-07-20 19:24:00 --> 404 Page Not Found: Welcome/getuser
INFO - 2019-07-20 19:29:56 --> Config Class Initialized
INFO - 2019-07-20 19:29:56 --> Hooks Class Initialized
DEBUG - 2019-07-20 19:29:56 --> UTF-8 Support Enabled
INFO - 2019-07-20 19:29:56 --> Utf8 Class Initialized
INFO - 2019-07-20 19:29:56 --> URI Class Initialized
INFO - 2019-07-20 19:29:56 --> Router Class Initialized
INFO - 2019-07-20 19:29:56 --> Output Class Initialized
INFO - 2019-07-20 19:29:56 --> Security Class Initialized
DEBUG - 2019-07-20 19:29:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 19:29:56 --> Input Class Initialized
INFO - 2019-07-20 19:29:56 --> Language Class Initialized
INFO - 2019-07-20 19:29:56 --> Loader Class Initialized
INFO - 2019-07-20 19:29:57 --> Database Driver Class Initialized
INFO - 2019-07-20 19:29:57 --> Controller Class Initialized
INFO - 2019-07-20 19:29:57 --> Model "Product" initialized
INFO - 2019-07-20 19:29:57 --> Final output sent to browser
DEBUG - 2019-07-20 19:29:57 --> Total execution time: 0.0386
INFO - 2019-07-20 19:29:57 --> Config Class Initialized
INFO - 2019-07-20 19:29:57 --> Hooks Class Initialized
DEBUG - 2019-07-20 19:29:57 --> UTF-8 Support Enabled
INFO - 2019-07-20 19:29:57 --> Utf8 Class Initialized
INFO - 2019-07-20 19:29:57 --> URI Class Initialized
INFO - 2019-07-20 19:29:57 --> Router Class Initialized
INFO - 2019-07-20 19:29:57 --> Output Class Initialized
INFO - 2019-07-20 19:29:57 --> Security Class Initialized
DEBUG - 2019-07-20 19:29:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 19:29:57 --> Input Class Initialized
INFO - 2019-07-20 19:29:57 --> Language Class Initialized
INFO - 2019-07-20 19:29:57 --> Loader Class Initialized
INFO - 2019-07-20 19:29:57 --> Database Driver Class Initialized
INFO - 2019-07-20 19:29:57 --> Controller Class Initialized
INFO - 2019-07-20 19:29:57 --> Model "Product" initialized
INFO - 2019-07-20 19:30:23 --> Config Class Initialized
INFO - 2019-07-20 19:30:23 --> Hooks Class Initialized
DEBUG - 2019-07-20 19:30:23 --> UTF-8 Support Enabled
INFO - 2019-07-20 19:30:23 --> Utf8 Class Initialized
INFO - 2019-07-20 19:30:23 --> URI Class Initialized
INFO - 2019-07-20 19:30:23 --> Router Class Initialized
INFO - 2019-07-20 19:30:23 --> Output Class Initialized
INFO - 2019-07-20 19:30:23 --> Security Class Initialized
DEBUG - 2019-07-20 19:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 19:30:23 --> Input Class Initialized
INFO - 2019-07-20 19:30:23 --> Language Class Initialized
INFO - 2019-07-20 19:30:23 --> Loader Class Initialized
INFO - 2019-07-20 19:30:23 --> Database Driver Class Initialized
INFO - 2019-07-20 19:30:23 --> Controller Class Initialized
INFO - 2019-07-20 19:30:23 --> Model "Product" initialized
INFO - 2019-07-20 19:30:23 --> Final output sent to browser
DEBUG - 2019-07-20 19:30:23 --> Total execution time: 0.0167
INFO - 2019-07-20 19:30:23 --> Config Class Initialized
INFO - 2019-07-20 19:30:23 --> Hooks Class Initialized
DEBUG - 2019-07-20 19:30:23 --> UTF-8 Support Enabled
INFO - 2019-07-20 19:30:23 --> Utf8 Class Initialized
INFO - 2019-07-20 19:30:23 --> URI Class Initialized
INFO - 2019-07-20 19:30:23 --> Router Class Initialized
INFO - 2019-07-20 19:30:23 --> Output Class Initialized
INFO - 2019-07-20 19:30:23 --> Security Class Initialized
DEBUG - 2019-07-20 19:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-20 19:30:23 --> Input Class Initialized
INFO - 2019-07-20 19:30:23 --> Language Class Initialized
INFO - 2019-07-20 19:30:23 --> Loader Class Initialized
INFO - 2019-07-20 19:30:23 --> Database Driver Class Initialized
INFO - 2019-07-20 19:30:23 --> Controller Class Initialized
INFO - 2019-07-20 19:30:23 --> Model "Product" initialized
