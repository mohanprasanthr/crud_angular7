<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2019-07-21 06:27:35 --> Config Class Initialized
INFO - 2019-07-21 06:27:35 --> Hooks Class Initialized
DEBUG - 2019-07-21 06:27:36 --> UTF-8 Support Enabled
INFO - 2019-07-21 06:27:36 --> Utf8 Class Initialized
INFO - 2019-07-21 06:27:36 --> URI Class Initialized
INFO - 2019-07-21 06:27:36 --> Router Class Initialized
INFO - 2019-07-21 06:27:36 --> Output Class Initialized
INFO - 2019-07-21 06:27:36 --> Security Class Initialized
DEBUG - 2019-07-21 06:27:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 06:27:36 --> Input Class Initialized
INFO - 2019-07-21 06:27:36 --> Language Class Initialized
INFO - 2019-07-21 06:27:36 --> Loader Class Initialized
INFO - 2019-07-21 06:27:36 --> Database Driver Class Initialized
INFO - 2019-07-21 06:27:37 --> Controller Class Initialized
INFO - 2019-07-21 06:27:37 --> Model "Product" initialized
INFO - 2019-07-21 06:27:38 --> Final output sent to browser
DEBUG - 2019-07-21 06:27:38 --> Total execution time: 2.3782
INFO - 2019-07-21 06:28:24 --> Config Class Initialized
INFO - 2019-07-21 06:28:24 --> Hooks Class Initialized
DEBUG - 2019-07-21 06:28:24 --> UTF-8 Support Enabled
INFO - 2019-07-21 06:28:24 --> Utf8 Class Initialized
INFO - 2019-07-21 06:28:24 --> URI Class Initialized
INFO - 2019-07-21 06:28:24 --> Router Class Initialized
INFO - 2019-07-21 06:28:24 --> Output Class Initialized
INFO - 2019-07-21 06:28:24 --> Security Class Initialized
DEBUG - 2019-07-21 06:28:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 06:28:24 --> Input Class Initialized
INFO - 2019-07-21 06:28:24 --> Language Class Initialized
INFO - 2019-07-21 06:28:24 --> Loader Class Initialized
INFO - 2019-07-21 06:28:24 --> Database Driver Class Initialized
INFO - 2019-07-21 06:28:24 --> Controller Class Initialized
INFO - 2019-07-21 06:28:24 --> Model "Product" initialized
INFO - 2019-07-21 06:28:26 --> Final output sent to browser
DEBUG - 2019-07-21 06:28:26 --> Total execution time: 2.0835
INFO - 2019-07-21 06:28:37 --> Config Class Initialized
INFO - 2019-07-21 06:28:37 --> Hooks Class Initialized
DEBUG - 2019-07-21 06:28:37 --> UTF-8 Support Enabled
INFO - 2019-07-21 06:28:37 --> Utf8 Class Initialized
INFO - 2019-07-21 06:28:37 --> URI Class Initialized
INFO - 2019-07-21 06:28:37 --> Router Class Initialized
INFO - 2019-07-21 06:28:37 --> Output Class Initialized
INFO - 2019-07-21 06:28:37 --> Security Class Initialized
DEBUG - 2019-07-21 06:28:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 06:28:37 --> Input Class Initialized
INFO - 2019-07-21 06:28:37 --> Language Class Initialized
INFO - 2019-07-21 06:28:37 --> Loader Class Initialized
INFO - 2019-07-21 06:28:37 --> Database Driver Class Initialized
INFO - 2019-07-21 06:28:37 --> Controller Class Initialized
INFO - 2019-07-21 06:28:37 --> Model "Product" initialized
INFO - 2019-07-21 06:28:37 --> Final output sent to browser
DEBUG - 2019-07-21 06:28:37 --> Total execution time: 0.0378
INFO - 2019-07-21 06:29:12 --> Config Class Initialized
INFO - 2019-07-21 06:29:12 --> Hooks Class Initialized
DEBUG - 2019-07-21 06:29:12 --> UTF-8 Support Enabled
INFO - 2019-07-21 06:29:12 --> Utf8 Class Initialized
INFO - 2019-07-21 06:29:12 --> URI Class Initialized
INFO - 2019-07-21 06:29:12 --> Router Class Initialized
INFO - 2019-07-21 06:29:12 --> Output Class Initialized
INFO - 2019-07-21 06:29:12 --> Security Class Initialized
DEBUG - 2019-07-21 06:29:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 06:29:12 --> Input Class Initialized
INFO - 2019-07-21 06:29:12 --> Language Class Initialized
INFO - 2019-07-21 06:29:12 --> Loader Class Initialized
INFO - 2019-07-21 06:29:12 --> Database Driver Class Initialized
INFO - 2019-07-21 06:29:12 --> Controller Class Initialized
INFO - 2019-07-21 06:29:12 --> Model "Product" initialized
INFO - 2019-07-21 06:29:12 --> Final output sent to browser
DEBUG - 2019-07-21 06:29:12 --> Total execution time: 0.0245
INFO - 2019-07-21 08:39:29 --> Config Class Initialized
INFO - 2019-07-21 08:39:29 --> Hooks Class Initialized
DEBUG - 2019-07-21 08:39:29 --> UTF-8 Support Enabled
INFO - 2019-07-21 08:39:29 --> Utf8 Class Initialized
INFO - 2019-07-21 08:39:29 --> URI Class Initialized
INFO - 2019-07-21 08:39:29 --> Router Class Initialized
INFO - 2019-07-21 08:39:29 --> Output Class Initialized
INFO - 2019-07-21 08:39:29 --> Security Class Initialized
DEBUG - 2019-07-21 08:39:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 08:39:29 --> Input Class Initialized
INFO - 2019-07-21 08:39:29 --> Language Class Initialized
INFO - 2019-07-21 08:39:29 --> Loader Class Initialized
INFO - 2019-07-21 08:39:29 --> Database Driver Class Initialized
INFO - 2019-07-21 08:39:29 --> Controller Class Initialized
INFO - 2019-07-21 08:39:29 --> Model "Product" initialized
INFO - 2019-07-21 08:39:30 --> Final output sent to browser
DEBUG - 2019-07-21 08:39:30 --> Total execution time: 0.9244
INFO - 2019-07-21 08:41:58 --> Config Class Initialized
INFO - 2019-07-21 08:41:58 --> Hooks Class Initialized
DEBUG - 2019-07-21 08:41:58 --> UTF-8 Support Enabled
INFO - 2019-07-21 08:41:58 --> Utf8 Class Initialized
INFO - 2019-07-21 08:41:58 --> URI Class Initialized
INFO - 2019-07-21 08:41:58 --> Router Class Initialized
INFO - 2019-07-21 08:41:58 --> Output Class Initialized
INFO - 2019-07-21 08:41:58 --> Security Class Initialized
DEBUG - 2019-07-21 08:41:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 08:41:58 --> Input Class Initialized
INFO - 2019-07-21 08:41:58 --> Language Class Initialized
INFO - 2019-07-21 08:41:58 --> Loader Class Initialized
INFO - 2019-07-21 08:41:58 --> Database Driver Class Initialized
INFO - 2019-07-21 08:41:58 --> Controller Class Initialized
INFO - 2019-07-21 08:41:58 --> Model "Product" initialized
INFO - 2019-07-21 08:41:58 --> Final output sent to browser
DEBUG - 2019-07-21 08:41:58 --> Total execution time: 0.0332
INFO - 2019-07-21 08:43:28 --> Config Class Initialized
INFO - 2019-07-21 08:43:28 --> Hooks Class Initialized
DEBUG - 2019-07-21 08:43:28 --> UTF-8 Support Enabled
INFO - 2019-07-21 08:43:28 --> Utf8 Class Initialized
INFO - 2019-07-21 08:43:28 --> URI Class Initialized
INFO - 2019-07-21 08:43:28 --> Router Class Initialized
INFO - 2019-07-21 08:43:28 --> Output Class Initialized
INFO - 2019-07-21 08:43:28 --> Security Class Initialized
DEBUG - 2019-07-21 08:43:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 08:43:28 --> Input Class Initialized
INFO - 2019-07-21 08:43:28 --> Language Class Initialized
INFO - 2019-07-21 08:43:28 --> Loader Class Initialized
INFO - 2019-07-21 08:43:28 --> Database Driver Class Initialized
INFO - 2019-07-21 08:43:28 --> Controller Class Initialized
INFO - 2019-07-21 08:43:28 --> Model "Product" initialized
INFO - 2019-07-21 08:43:28 --> Final output sent to browser
DEBUG - 2019-07-21 08:43:28 --> Total execution time: 0.0537
INFO - 2019-07-21 08:43:37 --> Config Class Initialized
INFO - 2019-07-21 08:43:37 --> Hooks Class Initialized
DEBUG - 2019-07-21 08:43:37 --> UTF-8 Support Enabled
INFO - 2019-07-21 08:43:37 --> Utf8 Class Initialized
INFO - 2019-07-21 08:43:37 --> URI Class Initialized
INFO - 2019-07-21 08:43:37 --> Router Class Initialized
INFO - 2019-07-21 08:43:37 --> Output Class Initialized
INFO - 2019-07-21 08:43:37 --> Security Class Initialized
DEBUG - 2019-07-21 08:43:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 08:43:37 --> Input Class Initialized
INFO - 2019-07-21 08:43:37 --> Language Class Initialized
INFO - 2019-07-21 08:43:37 --> Loader Class Initialized
INFO - 2019-07-21 08:43:37 --> Database Driver Class Initialized
INFO - 2019-07-21 08:43:37 --> Controller Class Initialized
INFO - 2019-07-21 08:43:37 --> Model "Product" initialized
INFO - 2019-07-21 08:43:37 --> Final output sent to browser
DEBUG - 2019-07-21 08:43:37 --> Total execution time: 0.0326
INFO - 2019-07-21 08:43:46 --> Config Class Initialized
INFO - 2019-07-21 08:43:46 --> Hooks Class Initialized
DEBUG - 2019-07-21 08:43:46 --> UTF-8 Support Enabled
INFO - 2019-07-21 08:43:46 --> Utf8 Class Initialized
INFO - 2019-07-21 08:43:46 --> URI Class Initialized
INFO - 2019-07-21 08:43:46 --> Router Class Initialized
INFO - 2019-07-21 08:43:46 --> Output Class Initialized
INFO - 2019-07-21 08:43:46 --> Security Class Initialized
DEBUG - 2019-07-21 08:43:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 08:43:46 --> Input Class Initialized
INFO - 2019-07-21 08:43:46 --> Language Class Initialized
INFO - 2019-07-21 08:43:46 --> Loader Class Initialized
INFO - 2019-07-21 08:43:46 --> Database Driver Class Initialized
INFO - 2019-07-21 08:43:46 --> Controller Class Initialized
INFO - 2019-07-21 08:43:46 --> Model "Product" initialized
INFO - 2019-07-21 08:43:46 --> Final output sent to browser
DEBUG - 2019-07-21 08:43:46 --> Total execution time: 0.0613
INFO - 2019-07-21 08:45:55 --> Config Class Initialized
INFO - 2019-07-21 08:45:55 --> Hooks Class Initialized
DEBUG - 2019-07-21 08:45:55 --> UTF-8 Support Enabled
INFO - 2019-07-21 08:45:55 --> Utf8 Class Initialized
INFO - 2019-07-21 08:45:55 --> URI Class Initialized
INFO - 2019-07-21 08:45:55 --> Router Class Initialized
INFO - 2019-07-21 08:45:55 --> Output Class Initialized
INFO - 2019-07-21 08:45:55 --> Security Class Initialized
DEBUG - 2019-07-21 08:45:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 08:45:55 --> Input Class Initialized
INFO - 2019-07-21 08:45:55 --> Language Class Initialized
INFO - 2019-07-21 08:45:55 --> Loader Class Initialized
INFO - 2019-07-21 08:45:55 --> Database Driver Class Initialized
INFO - 2019-07-21 08:45:55 --> Controller Class Initialized
INFO - 2019-07-21 08:45:55 --> Model "Product" initialized
INFO - 2019-07-21 08:45:55 --> Final output sent to browser
DEBUG - 2019-07-21 08:45:55 --> Total execution time: 0.0231
INFO - 2019-07-21 08:46:29 --> Config Class Initialized
INFO - 2019-07-21 08:46:29 --> Hooks Class Initialized
DEBUG - 2019-07-21 08:46:29 --> UTF-8 Support Enabled
INFO - 2019-07-21 08:46:29 --> Utf8 Class Initialized
INFO - 2019-07-21 08:46:29 --> URI Class Initialized
INFO - 2019-07-21 08:46:29 --> Router Class Initialized
INFO - 2019-07-21 08:46:29 --> Output Class Initialized
INFO - 2019-07-21 08:46:29 --> Security Class Initialized
DEBUG - 2019-07-21 08:46:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 08:46:29 --> Input Class Initialized
INFO - 2019-07-21 08:46:29 --> Language Class Initialized
INFO - 2019-07-21 08:46:29 --> Loader Class Initialized
INFO - 2019-07-21 08:46:29 --> Database Driver Class Initialized
INFO - 2019-07-21 08:46:29 --> Controller Class Initialized
INFO - 2019-07-21 08:46:29 --> Model "Product" initialized
INFO - 2019-07-21 08:46:29 --> Final output sent to browser
DEBUG - 2019-07-21 08:46:29 --> Total execution time: 0.0431
INFO - 2019-07-21 08:46:42 --> Config Class Initialized
INFO - 2019-07-21 08:46:42 --> Hooks Class Initialized
DEBUG - 2019-07-21 08:46:42 --> UTF-8 Support Enabled
INFO - 2019-07-21 08:46:42 --> Utf8 Class Initialized
INFO - 2019-07-21 08:46:42 --> URI Class Initialized
INFO - 2019-07-21 08:46:42 --> Router Class Initialized
INFO - 2019-07-21 08:46:42 --> Output Class Initialized
INFO - 2019-07-21 08:46:42 --> Security Class Initialized
DEBUG - 2019-07-21 08:46:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 08:46:42 --> Input Class Initialized
INFO - 2019-07-21 08:46:42 --> Language Class Initialized
INFO - 2019-07-21 08:46:42 --> Loader Class Initialized
INFO - 2019-07-21 08:46:42 --> Database Driver Class Initialized
INFO - 2019-07-21 08:46:42 --> Controller Class Initialized
INFO - 2019-07-21 08:46:42 --> Model "Product" initialized
INFO - 2019-07-21 08:46:42 --> Final output sent to browser
DEBUG - 2019-07-21 08:46:42 --> Total execution time: 0.0372
INFO - 2019-07-21 08:47:04 --> Config Class Initialized
INFO - 2019-07-21 08:47:04 --> Hooks Class Initialized
DEBUG - 2019-07-21 08:47:04 --> UTF-8 Support Enabled
INFO - 2019-07-21 08:47:04 --> Utf8 Class Initialized
INFO - 2019-07-21 08:47:04 --> URI Class Initialized
INFO - 2019-07-21 08:47:04 --> Router Class Initialized
INFO - 2019-07-21 08:47:04 --> Output Class Initialized
INFO - 2019-07-21 08:47:04 --> Security Class Initialized
DEBUG - 2019-07-21 08:47:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 08:47:04 --> Input Class Initialized
INFO - 2019-07-21 08:47:04 --> Language Class Initialized
INFO - 2019-07-21 08:47:04 --> Loader Class Initialized
INFO - 2019-07-21 08:47:04 --> Database Driver Class Initialized
INFO - 2019-07-21 08:47:04 --> Controller Class Initialized
INFO - 2019-07-21 08:47:04 --> Model "Product" initialized
INFO - 2019-07-21 08:47:04 --> Final output sent to browser
DEBUG - 2019-07-21 08:47:04 --> Total execution time: 0.0343
INFO - 2019-07-21 08:47:13 --> Config Class Initialized
INFO - 2019-07-21 08:47:13 --> Hooks Class Initialized
DEBUG - 2019-07-21 08:47:13 --> UTF-8 Support Enabled
INFO - 2019-07-21 08:47:13 --> Utf8 Class Initialized
INFO - 2019-07-21 08:47:13 --> URI Class Initialized
INFO - 2019-07-21 08:47:13 --> Router Class Initialized
INFO - 2019-07-21 08:47:13 --> Output Class Initialized
INFO - 2019-07-21 08:47:13 --> Security Class Initialized
DEBUG - 2019-07-21 08:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 08:47:13 --> Input Class Initialized
INFO - 2019-07-21 08:47:13 --> Language Class Initialized
INFO - 2019-07-21 08:47:13 --> Loader Class Initialized
INFO - 2019-07-21 08:47:13 --> Database Driver Class Initialized
INFO - 2019-07-21 08:47:13 --> Controller Class Initialized
INFO - 2019-07-21 08:47:13 --> Model "Product" initialized
INFO - 2019-07-21 08:47:13 --> Final output sent to browser
DEBUG - 2019-07-21 08:47:13 --> Total execution time: 0.0401
INFO - 2019-07-21 08:47:23 --> Config Class Initialized
INFO - 2019-07-21 08:47:23 --> Hooks Class Initialized
DEBUG - 2019-07-21 08:47:23 --> UTF-8 Support Enabled
INFO - 2019-07-21 08:47:23 --> Utf8 Class Initialized
INFO - 2019-07-21 08:47:23 --> URI Class Initialized
INFO - 2019-07-21 08:47:23 --> Router Class Initialized
INFO - 2019-07-21 08:47:23 --> Output Class Initialized
INFO - 2019-07-21 08:47:23 --> Security Class Initialized
DEBUG - 2019-07-21 08:47:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 08:47:23 --> Input Class Initialized
INFO - 2019-07-21 08:47:23 --> Language Class Initialized
INFO - 2019-07-21 08:47:23 --> Loader Class Initialized
INFO - 2019-07-21 08:47:23 --> Database Driver Class Initialized
INFO - 2019-07-21 08:47:23 --> Controller Class Initialized
INFO - 2019-07-21 08:47:23 --> Model "Product" initialized
INFO - 2019-07-21 08:47:23 --> Final output sent to browser
DEBUG - 2019-07-21 08:47:23 --> Total execution time: 0.0336
INFO - 2019-07-21 08:47:34 --> Config Class Initialized
INFO - 2019-07-21 08:47:34 --> Hooks Class Initialized
DEBUG - 2019-07-21 08:47:34 --> UTF-8 Support Enabled
INFO - 2019-07-21 08:47:34 --> Utf8 Class Initialized
INFO - 2019-07-21 08:47:34 --> URI Class Initialized
INFO - 2019-07-21 08:47:34 --> Router Class Initialized
INFO - 2019-07-21 08:47:34 --> Output Class Initialized
INFO - 2019-07-21 08:47:34 --> Security Class Initialized
DEBUG - 2019-07-21 08:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 08:47:34 --> Input Class Initialized
INFO - 2019-07-21 08:47:34 --> Language Class Initialized
INFO - 2019-07-21 08:47:34 --> Loader Class Initialized
INFO - 2019-07-21 08:47:34 --> Database Driver Class Initialized
INFO - 2019-07-21 08:47:34 --> Controller Class Initialized
INFO - 2019-07-21 08:47:34 --> Model "Product" initialized
INFO - 2019-07-21 08:47:34 --> Final output sent to browser
DEBUG - 2019-07-21 08:47:34 --> Total execution time: 0.0303
INFO - 2019-07-21 08:47:43 --> Config Class Initialized
INFO - 2019-07-21 08:47:43 --> Hooks Class Initialized
DEBUG - 2019-07-21 08:47:43 --> UTF-8 Support Enabled
INFO - 2019-07-21 08:47:43 --> Utf8 Class Initialized
INFO - 2019-07-21 08:47:43 --> URI Class Initialized
INFO - 2019-07-21 08:47:43 --> Router Class Initialized
INFO - 2019-07-21 08:47:43 --> Output Class Initialized
INFO - 2019-07-21 08:47:43 --> Security Class Initialized
DEBUG - 2019-07-21 08:47:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 08:47:43 --> Input Class Initialized
INFO - 2019-07-21 08:47:43 --> Language Class Initialized
INFO - 2019-07-21 08:47:43 --> Loader Class Initialized
INFO - 2019-07-21 08:47:43 --> Database Driver Class Initialized
INFO - 2019-07-21 08:47:43 --> Controller Class Initialized
INFO - 2019-07-21 08:47:43 --> Model "Product" initialized
INFO - 2019-07-21 08:47:43 --> Final output sent to browser
DEBUG - 2019-07-21 08:47:43 --> Total execution time: 0.0394
INFO - 2019-07-21 08:47:52 --> Config Class Initialized
INFO - 2019-07-21 08:47:52 --> Hooks Class Initialized
DEBUG - 2019-07-21 08:47:52 --> UTF-8 Support Enabled
INFO - 2019-07-21 08:47:52 --> Utf8 Class Initialized
INFO - 2019-07-21 08:47:52 --> URI Class Initialized
INFO - 2019-07-21 08:47:52 --> Router Class Initialized
INFO - 2019-07-21 08:47:52 --> Output Class Initialized
INFO - 2019-07-21 08:47:52 --> Security Class Initialized
DEBUG - 2019-07-21 08:47:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 08:47:52 --> Input Class Initialized
INFO - 2019-07-21 08:47:52 --> Language Class Initialized
INFO - 2019-07-21 08:47:52 --> Loader Class Initialized
INFO - 2019-07-21 08:47:52 --> Database Driver Class Initialized
INFO - 2019-07-21 08:47:52 --> Controller Class Initialized
INFO - 2019-07-21 08:47:52 --> Model "Product" initialized
INFO - 2019-07-21 08:47:52 --> Final output sent to browser
DEBUG - 2019-07-21 08:47:52 --> Total execution time: 0.0519
INFO - 2019-07-21 08:49:46 --> Config Class Initialized
INFO - 2019-07-21 08:49:46 --> Hooks Class Initialized
DEBUG - 2019-07-21 08:49:46 --> UTF-8 Support Enabled
INFO - 2019-07-21 08:49:46 --> Utf8 Class Initialized
INFO - 2019-07-21 08:49:46 --> URI Class Initialized
INFO - 2019-07-21 08:49:46 --> Router Class Initialized
INFO - 2019-07-21 08:49:46 --> Output Class Initialized
INFO - 2019-07-21 08:49:46 --> Security Class Initialized
DEBUG - 2019-07-21 08:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 08:49:46 --> Input Class Initialized
INFO - 2019-07-21 08:49:46 --> Language Class Initialized
INFO - 2019-07-21 08:49:46 --> Loader Class Initialized
INFO - 2019-07-21 08:49:46 --> Database Driver Class Initialized
INFO - 2019-07-21 08:49:46 --> Controller Class Initialized
INFO - 2019-07-21 08:49:46 --> Model "Product" initialized
INFO - 2019-07-21 08:49:46 --> Final output sent to browser
DEBUG - 2019-07-21 08:49:46 --> Total execution time: 0.0262
INFO - 2019-07-21 08:49:52 --> Config Class Initialized
INFO - 2019-07-21 08:49:52 --> Hooks Class Initialized
DEBUG - 2019-07-21 08:49:52 --> UTF-8 Support Enabled
INFO - 2019-07-21 08:49:52 --> Utf8 Class Initialized
INFO - 2019-07-21 08:49:52 --> URI Class Initialized
INFO - 2019-07-21 08:49:52 --> Router Class Initialized
INFO - 2019-07-21 08:49:52 --> Output Class Initialized
INFO - 2019-07-21 08:49:52 --> Security Class Initialized
DEBUG - 2019-07-21 08:49:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 08:49:52 --> Input Class Initialized
INFO - 2019-07-21 08:49:52 --> Language Class Initialized
INFO - 2019-07-21 08:49:52 --> Loader Class Initialized
INFO - 2019-07-21 08:49:52 --> Database Driver Class Initialized
INFO - 2019-07-21 08:49:52 --> Controller Class Initialized
INFO - 2019-07-21 08:49:52 --> Model "Product" initialized
INFO - 2019-07-21 08:49:52 --> Final output sent to browser
DEBUG - 2019-07-21 08:49:52 --> Total execution time: 0.0270
INFO - 2019-07-21 08:50:03 --> Config Class Initialized
INFO - 2019-07-21 08:50:03 --> Hooks Class Initialized
DEBUG - 2019-07-21 08:50:03 --> UTF-8 Support Enabled
INFO - 2019-07-21 08:50:03 --> Utf8 Class Initialized
INFO - 2019-07-21 08:50:03 --> URI Class Initialized
INFO - 2019-07-21 08:50:03 --> Router Class Initialized
INFO - 2019-07-21 08:50:03 --> Output Class Initialized
INFO - 2019-07-21 08:50:03 --> Security Class Initialized
DEBUG - 2019-07-21 08:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 08:50:03 --> Input Class Initialized
INFO - 2019-07-21 08:50:03 --> Language Class Initialized
INFO - 2019-07-21 08:50:03 --> Loader Class Initialized
INFO - 2019-07-21 08:50:03 --> Database Driver Class Initialized
INFO - 2019-07-21 08:50:03 --> Controller Class Initialized
INFO - 2019-07-21 08:50:03 --> Model "Product" initialized
INFO - 2019-07-21 08:50:03 --> Final output sent to browser
DEBUG - 2019-07-21 08:50:03 --> Total execution time: 0.0250
INFO - 2019-07-21 08:52:09 --> Config Class Initialized
INFO - 2019-07-21 08:52:09 --> Hooks Class Initialized
DEBUG - 2019-07-21 08:52:09 --> UTF-8 Support Enabled
INFO - 2019-07-21 08:52:09 --> Utf8 Class Initialized
INFO - 2019-07-21 08:52:09 --> URI Class Initialized
INFO - 2019-07-21 08:52:09 --> Router Class Initialized
INFO - 2019-07-21 08:52:09 --> Output Class Initialized
INFO - 2019-07-21 08:52:09 --> Security Class Initialized
DEBUG - 2019-07-21 08:52:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 08:52:09 --> Input Class Initialized
INFO - 2019-07-21 08:52:09 --> Language Class Initialized
INFO - 2019-07-21 08:52:09 --> Loader Class Initialized
INFO - 2019-07-21 08:52:09 --> Database Driver Class Initialized
INFO - 2019-07-21 08:52:09 --> Controller Class Initialized
INFO - 2019-07-21 08:52:09 --> Model "Product" initialized
INFO - 2019-07-21 08:52:09 --> Final output sent to browser
DEBUG - 2019-07-21 08:52:09 --> Total execution time: 0.1073
INFO - 2019-07-21 08:57:53 --> Config Class Initialized
INFO - 2019-07-21 08:57:53 --> Hooks Class Initialized
DEBUG - 2019-07-21 08:57:53 --> UTF-8 Support Enabled
INFO - 2019-07-21 08:57:53 --> Utf8 Class Initialized
INFO - 2019-07-21 08:57:53 --> URI Class Initialized
INFO - 2019-07-21 08:57:53 --> Router Class Initialized
INFO - 2019-07-21 08:57:53 --> Output Class Initialized
INFO - 2019-07-21 08:57:53 --> Security Class Initialized
DEBUG - 2019-07-21 08:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 08:57:53 --> Input Class Initialized
INFO - 2019-07-21 08:57:53 --> Language Class Initialized
INFO - 2019-07-21 08:57:53 --> Loader Class Initialized
INFO - 2019-07-21 08:57:53 --> Database Driver Class Initialized
INFO - 2019-07-21 08:57:53 --> Controller Class Initialized
INFO - 2019-07-21 08:57:53 --> Model "Product" initialized
INFO - 2019-07-21 08:57:53 --> Final output sent to browser
DEBUG - 2019-07-21 08:57:53 --> Total execution time: 0.0350
INFO - 2019-07-21 08:59:19 --> Config Class Initialized
INFO - 2019-07-21 08:59:19 --> Hooks Class Initialized
DEBUG - 2019-07-21 08:59:19 --> UTF-8 Support Enabled
INFO - 2019-07-21 08:59:19 --> Utf8 Class Initialized
INFO - 2019-07-21 08:59:20 --> URI Class Initialized
INFO - 2019-07-21 08:59:20 --> Router Class Initialized
INFO - 2019-07-21 08:59:20 --> Output Class Initialized
INFO - 2019-07-21 08:59:20 --> Security Class Initialized
DEBUG - 2019-07-21 08:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 08:59:20 --> Input Class Initialized
INFO - 2019-07-21 08:59:20 --> Language Class Initialized
INFO - 2019-07-21 08:59:20 --> Loader Class Initialized
INFO - 2019-07-21 08:59:20 --> Database Driver Class Initialized
INFO - 2019-07-21 08:59:20 --> Controller Class Initialized
INFO - 2019-07-21 08:59:20 --> Model "Product" initialized
INFO - 2019-07-21 08:59:20 --> Final output sent to browser
DEBUG - 2019-07-21 08:59:20 --> Total execution time: 0.8804
INFO - 2019-07-21 08:59:29 --> Config Class Initialized
INFO - 2019-07-21 08:59:29 --> Hooks Class Initialized
DEBUG - 2019-07-21 08:59:29 --> UTF-8 Support Enabled
INFO - 2019-07-21 08:59:29 --> Utf8 Class Initialized
INFO - 2019-07-21 08:59:29 --> URI Class Initialized
INFO - 2019-07-21 08:59:29 --> Router Class Initialized
INFO - 2019-07-21 08:59:29 --> Output Class Initialized
INFO - 2019-07-21 08:59:29 --> Security Class Initialized
DEBUG - 2019-07-21 08:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 08:59:29 --> Input Class Initialized
INFO - 2019-07-21 08:59:29 --> Language Class Initialized
INFO - 2019-07-21 08:59:29 --> Loader Class Initialized
INFO - 2019-07-21 08:59:29 --> Database Driver Class Initialized
INFO - 2019-07-21 08:59:29 --> Controller Class Initialized
INFO - 2019-07-21 08:59:29 --> Model "Product" initialized
INFO - 2019-07-21 08:59:29 --> Final output sent to browser
DEBUG - 2019-07-21 08:59:29 --> Total execution time: 0.0216
INFO - 2019-07-21 08:59:46 --> Config Class Initialized
INFO - 2019-07-21 08:59:46 --> Hooks Class Initialized
DEBUG - 2019-07-21 08:59:46 --> UTF-8 Support Enabled
INFO - 2019-07-21 08:59:46 --> Utf8 Class Initialized
INFO - 2019-07-21 08:59:46 --> URI Class Initialized
INFO - 2019-07-21 08:59:46 --> Router Class Initialized
INFO - 2019-07-21 08:59:46 --> Output Class Initialized
INFO - 2019-07-21 08:59:46 --> Security Class Initialized
DEBUG - 2019-07-21 08:59:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 08:59:46 --> Input Class Initialized
INFO - 2019-07-21 08:59:46 --> Language Class Initialized
INFO - 2019-07-21 08:59:46 --> Loader Class Initialized
INFO - 2019-07-21 08:59:46 --> Database Driver Class Initialized
INFO - 2019-07-21 08:59:46 --> Controller Class Initialized
INFO - 2019-07-21 08:59:46 --> Model "Product" initialized
INFO - 2019-07-21 08:59:46 --> Final output sent to browser
DEBUG - 2019-07-21 08:59:46 --> Total execution time: 0.0254
INFO - 2019-07-21 09:00:02 --> Config Class Initialized
INFO - 2019-07-21 09:00:02 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:00:02 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:00:02 --> Utf8 Class Initialized
INFO - 2019-07-21 09:00:02 --> URI Class Initialized
INFO - 2019-07-21 09:00:02 --> Router Class Initialized
INFO - 2019-07-21 09:00:02 --> Output Class Initialized
INFO - 2019-07-21 09:00:02 --> Security Class Initialized
DEBUG - 2019-07-21 09:00:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:00:02 --> Input Class Initialized
INFO - 2019-07-21 09:00:02 --> Language Class Initialized
INFO - 2019-07-21 09:00:02 --> Loader Class Initialized
INFO - 2019-07-21 09:00:02 --> Database Driver Class Initialized
INFO - 2019-07-21 09:00:02 --> Controller Class Initialized
INFO - 2019-07-21 09:00:02 --> Model "Product" initialized
INFO - 2019-07-21 09:00:02 --> Final output sent to browser
DEBUG - 2019-07-21 09:00:02 --> Total execution time: 0.0392
INFO - 2019-07-21 09:00:39 --> Config Class Initialized
INFO - 2019-07-21 09:00:39 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:00:39 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:00:39 --> Utf8 Class Initialized
INFO - 2019-07-21 09:00:39 --> URI Class Initialized
INFO - 2019-07-21 09:00:39 --> Router Class Initialized
INFO - 2019-07-21 09:00:39 --> Output Class Initialized
INFO - 2019-07-21 09:00:39 --> Security Class Initialized
DEBUG - 2019-07-21 09:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:00:39 --> Input Class Initialized
INFO - 2019-07-21 09:00:39 --> Language Class Initialized
INFO - 2019-07-21 09:00:39 --> Loader Class Initialized
INFO - 2019-07-21 09:00:39 --> Database Driver Class Initialized
INFO - 2019-07-21 09:00:39 --> Controller Class Initialized
INFO - 2019-07-21 09:00:39 --> Model "Product" initialized
INFO - 2019-07-21 09:00:39 --> Final output sent to browser
DEBUG - 2019-07-21 09:00:39 --> Total execution time: 0.0517
INFO - 2019-07-21 09:01:03 --> Config Class Initialized
INFO - 2019-07-21 09:01:03 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:01:03 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:01:03 --> Utf8 Class Initialized
INFO - 2019-07-21 09:01:03 --> URI Class Initialized
INFO - 2019-07-21 09:01:03 --> Router Class Initialized
INFO - 2019-07-21 09:01:03 --> Output Class Initialized
INFO - 2019-07-21 09:01:03 --> Security Class Initialized
DEBUG - 2019-07-21 09:01:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:01:03 --> Input Class Initialized
INFO - 2019-07-21 09:01:03 --> Language Class Initialized
INFO - 2019-07-21 09:01:03 --> Loader Class Initialized
INFO - 2019-07-21 09:01:03 --> Database Driver Class Initialized
INFO - 2019-07-21 09:01:03 --> Controller Class Initialized
INFO - 2019-07-21 09:01:03 --> Model "Product" initialized
INFO - 2019-07-21 09:01:03 --> Final output sent to browser
DEBUG - 2019-07-21 09:01:03 --> Total execution time: 0.0333
INFO - 2019-07-21 09:01:36 --> Config Class Initialized
INFO - 2019-07-21 09:01:36 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:01:36 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:01:36 --> Utf8 Class Initialized
INFO - 2019-07-21 09:01:36 --> URI Class Initialized
INFO - 2019-07-21 09:01:36 --> Router Class Initialized
INFO - 2019-07-21 09:01:36 --> Output Class Initialized
INFO - 2019-07-21 09:01:36 --> Security Class Initialized
DEBUG - 2019-07-21 09:01:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:01:36 --> Input Class Initialized
INFO - 2019-07-21 09:01:36 --> Language Class Initialized
INFO - 2019-07-21 09:01:36 --> Loader Class Initialized
INFO - 2019-07-21 09:01:36 --> Database Driver Class Initialized
INFO - 2019-07-21 09:01:36 --> Controller Class Initialized
INFO - 2019-07-21 09:01:36 --> Model "Product" initialized
INFO - 2019-07-21 09:01:36 --> Final output sent to browser
DEBUG - 2019-07-21 09:01:36 --> Total execution time: 0.0310
INFO - 2019-07-21 09:01:45 --> Config Class Initialized
INFO - 2019-07-21 09:01:45 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:01:45 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:01:45 --> Utf8 Class Initialized
INFO - 2019-07-21 09:01:45 --> URI Class Initialized
INFO - 2019-07-21 09:01:45 --> Router Class Initialized
INFO - 2019-07-21 09:01:45 --> Output Class Initialized
INFO - 2019-07-21 09:01:45 --> Security Class Initialized
DEBUG - 2019-07-21 09:01:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:01:45 --> Input Class Initialized
INFO - 2019-07-21 09:01:45 --> Language Class Initialized
INFO - 2019-07-21 09:01:45 --> Loader Class Initialized
INFO - 2019-07-21 09:01:45 --> Database Driver Class Initialized
INFO - 2019-07-21 09:01:45 --> Controller Class Initialized
INFO - 2019-07-21 09:01:45 --> Model "Product" initialized
INFO - 2019-07-21 09:01:45 --> Final output sent to browser
DEBUG - 2019-07-21 09:01:45 --> Total execution time: 0.0292
INFO - 2019-07-21 09:01:54 --> Config Class Initialized
INFO - 2019-07-21 09:01:54 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:01:54 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:01:54 --> Utf8 Class Initialized
INFO - 2019-07-21 09:01:54 --> URI Class Initialized
INFO - 2019-07-21 09:01:54 --> Router Class Initialized
INFO - 2019-07-21 09:01:54 --> Output Class Initialized
INFO - 2019-07-21 09:01:54 --> Security Class Initialized
DEBUG - 2019-07-21 09:01:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:01:54 --> Input Class Initialized
INFO - 2019-07-21 09:01:54 --> Language Class Initialized
INFO - 2019-07-21 09:01:54 --> Loader Class Initialized
INFO - 2019-07-21 09:01:54 --> Database Driver Class Initialized
INFO - 2019-07-21 09:01:54 --> Controller Class Initialized
INFO - 2019-07-21 09:01:54 --> Model "Product" initialized
INFO - 2019-07-21 09:01:54 --> Final output sent to browser
DEBUG - 2019-07-21 09:01:54 --> Total execution time: 0.0244
INFO - 2019-07-21 09:02:10 --> Config Class Initialized
INFO - 2019-07-21 09:02:10 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:02:10 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:02:10 --> Utf8 Class Initialized
INFO - 2019-07-21 09:02:10 --> URI Class Initialized
INFO - 2019-07-21 09:02:10 --> Router Class Initialized
INFO - 2019-07-21 09:02:10 --> Output Class Initialized
INFO - 2019-07-21 09:02:10 --> Security Class Initialized
DEBUG - 2019-07-21 09:02:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:02:10 --> Input Class Initialized
INFO - 2019-07-21 09:02:10 --> Language Class Initialized
INFO - 2019-07-21 09:02:10 --> Loader Class Initialized
INFO - 2019-07-21 09:02:10 --> Database Driver Class Initialized
INFO - 2019-07-21 09:02:10 --> Controller Class Initialized
INFO - 2019-07-21 09:02:10 --> Model "Product" initialized
INFO - 2019-07-21 09:02:10 --> Final output sent to browser
DEBUG - 2019-07-21 09:02:10 --> Total execution time: 0.0433
INFO - 2019-07-21 09:02:38 --> Config Class Initialized
INFO - 2019-07-21 09:02:38 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:02:38 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:02:38 --> Utf8 Class Initialized
INFO - 2019-07-21 09:02:38 --> URI Class Initialized
INFO - 2019-07-21 09:02:38 --> Router Class Initialized
INFO - 2019-07-21 09:02:38 --> Output Class Initialized
INFO - 2019-07-21 09:02:38 --> Security Class Initialized
DEBUG - 2019-07-21 09:02:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:02:38 --> Input Class Initialized
INFO - 2019-07-21 09:02:38 --> Language Class Initialized
INFO - 2019-07-21 09:02:38 --> Loader Class Initialized
INFO - 2019-07-21 09:02:38 --> Database Driver Class Initialized
INFO - 2019-07-21 09:02:38 --> Controller Class Initialized
INFO - 2019-07-21 09:02:38 --> Model "Product" initialized
INFO - 2019-07-21 09:02:38 --> Final output sent to browser
DEBUG - 2019-07-21 09:02:38 --> Total execution time: 0.0407
INFO - 2019-07-21 09:03:18 --> Config Class Initialized
INFO - 2019-07-21 09:03:18 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:03:18 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:03:18 --> Utf8 Class Initialized
INFO - 2019-07-21 09:03:18 --> URI Class Initialized
INFO - 2019-07-21 09:03:18 --> Router Class Initialized
INFO - 2019-07-21 09:03:18 --> Output Class Initialized
INFO - 2019-07-21 09:03:18 --> Security Class Initialized
DEBUG - 2019-07-21 09:03:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:03:18 --> Input Class Initialized
INFO - 2019-07-21 09:03:18 --> Language Class Initialized
INFO - 2019-07-21 09:03:18 --> Loader Class Initialized
INFO - 2019-07-21 09:03:18 --> Database Driver Class Initialized
INFO - 2019-07-21 09:03:18 --> Controller Class Initialized
INFO - 2019-07-21 09:03:18 --> Model "Product" initialized
INFO - 2019-07-21 09:03:18 --> Final output sent to browser
DEBUG - 2019-07-21 09:03:18 --> Total execution time: 0.0188
INFO - 2019-07-21 09:03:25 --> Config Class Initialized
INFO - 2019-07-21 09:03:25 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:03:25 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:03:25 --> Utf8 Class Initialized
INFO - 2019-07-21 09:03:25 --> URI Class Initialized
INFO - 2019-07-21 09:03:25 --> Router Class Initialized
INFO - 2019-07-21 09:03:25 --> Output Class Initialized
INFO - 2019-07-21 09:03:25 --> Security Class Initialized
DEBUG - 2019-07-21 09:03:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:03:25 --> Input Class Initialized
INFO - 2019-07-21 09:03:25 --> Language Class Initialized
INFO - 2019-07-21 09:03:25 --> Loader Class Initialized
INFO - 2019-07-21 09:03:25 --> Database Driver Class Initialized
INFO - 2019-07-21 09:03:25 --> Controller Class Initialized
INFO - 2019-07-21 09:03:25 --> Model "Product" initialized
INFO - 2019-07-21 09:03:25 --> Final output sent to browser
DEBUG - 2019-07-21 09:03:25 --> Total execution time: 0.0248
INFO - 2019-07-21 09:03:49 --> Config Class Initialized
INFO - 2019-07-21 09:03:49 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:03:49 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:03:49 --> Utf8 Class Initialized
INFO - 2019-07-21 09:03:49 --> URI Class Initialized
INFO - 2019-07-21 09:03:49 --> Router Class Initialized
INFO - 2019-07-21 09:03:49 --> Output Class Initialized
INFO - 2019-07-21 09:03:49 --> Security Class Initialized
DEBUG - 2019-07-21 09:03:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:03:49 --> Input Class Initialized
INFO - 2019-07-21 09:03:49 --> Language Class Initialized
INFO - 2019-07-21 09:03:49 --> Loader Class Initialized
INFO - 2019-07-21 09:03:49 --> Database Driver Class Initialized
INFO - 2019-07-21 09:03:49 --> Controller Class Initialized
INFO - 2019-07-21 09:03:49 --> Model "Product" initialized
INFO - 2019-07-21 09:03:49 --> Final output sent to browser
DEBUG - 2019-07-21 09:03:49 --> Total execution time: 0.0264
INFO - 2019-07-21 09:04:43 --> Config Class Initialized
INFO - 2019-07-21 09:04:43 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:04:43 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:04:43 --> Utf8 Class Initialized
INFO - 2019-07-21 09:04:43 --> URI Class Initialized
INFO - 2019-07-21 09:04:43 --> Router Class Initialized
INFO - 2019-07-21 09:04:43 --> Output Class Initialized
INFO - 2019-07-21 09:04:43 --> Security Class Initialized
DEBUG - 2019-07-21 09:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:04:43 --> Input Class Initialized
INFO - 2019-07-21 09:04:43 --> Language Class Initialized
INFO - 2019-07-21 09:04:43 --> Loader Class Initialized
INFO - 2019-07-21 09:04:43 --> Database Driver Class Initialized
INFO - 2019-07-21 09:04:43 --> Controller Class Initialized
INFO - 2019-07-21 09:04:43 --> Model "Product" initialized
INFO - 2019-07-21 09:04:43 --> Final output sent to browser
DEBUG - 2019-07-21 09:04:43 --> Total execution time: 0.0285
INFO - 2019-07-21 09:04:52 --> Config Class Initialized
INFO - 2019-07-21 09:04:52 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:04:52 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:04:52 --> Utf8 Class Initialized
INFO - 2019-07-21 09:04:52 --> URI Class Initialized
INFO - 2019-07-21 09:04:52 --> Router Class Initialized
INFO - 2019-07-21 09:04:52 --> Output Class Initialized
INFO - 2019-07-21 09:04:52 --> Security Class Initialized
DEBUG - 2019-07-21 09:04:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:04:52 --> Input Class Initialized
INFO - 2019-07-21 09:04:52 --> Language Class Initialized
INFO - 2019-07-21 09:04:52 --> Loader Class Initialized
INFO - 2019-07-21 09:04:52 --> Database Driver Class Initialized
INFO - 2019-07-21 09:04:52 --> Controller Class Initialized
INFO - 2019-07-21 09:04:52 --> Model "Product" initialized
INFO - 2019-07-21 09:04:52 --> Final output sent to browser
DEBUG - 2019-07-21 09:04:52 --> Total execution time: 0.0287
INFO - 2019-07-21 09:05:09 --> Config Class Initialized
INFO - 2019-07-21 09:05:09 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:05:09 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:05:09 --> Utf8 Class Initialized
INFO - 2019-07-21 09:05:09 --> URI Class Initialized
INFO - 2019-07-21 09:05:09 --> Router Class Initialized
INFO - 2019-07-21 09:05:09 --> Output Class Initialized
INFO - 2019-07-21 09:05:09 --> Security Class Initialized
DEBUG - 2019-07-21 09:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:05:09 --> Input Class Initialized
INFO - 2019-07-21 09:05:09 --> Language Class Initialized
INFO - 2019-07-21 09:05:09 --> Loader Class Initialized
INFO - 2019-07-21 09:05:09 --> Database Driver Class Initialized
INFO - 2019-07-21 09:05:09 --> Controller Class Initialized
INFO - 2019-07-21 09:05:09 --> Model "Product" initialized
INFO - 2019-07-21 09:05:09 --> Final output sent to browser
DEBUG - 2019-07-21 09:05:09 --> Total execution time: 0.0347
INFO - 2019-07-21 09:05:19 --> Config Class Initialized
INFO - 2019-07-21 09:05:19 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:05:19 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:05:19 --> Utf8 Class Initialized
INFO - 2019-07-21 09:05:19 --> URI Class Initialized
INFO - 2019-07-21 09:05:19 --> Router Class Initialized
INFO - 2019-07-21 09:05:19 --> Output Class Initialized
INFO - 2019-07-21 09:05:19 --> Security Class Initialized
DEBUG - 2019-07-21 09:05:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:05:19 --> Input Class Initialized
INFO - 2019-07-21 09:05:19 --> Language Class Initialized
INFO - 2019-07-21 09:05:19 --> Loader Class Initialized
INFO - 2019-07-21 09:05:19 --> Database Driver Class Initialized
INFO - 2019-07-21 09:05:19 --> Controller Class Initialized
INFO - 2019-07-21 09:05:19 --> Model "Product" initialized
INFO - 2019-07-21 09:05:19 --> Final output sent to browser
DEBUG - 2019-07-21 09:05:19 --> Total execution time: 0.0286
INFO - 2019-07-21 09:06:29 --> Config Class Initialized
INFO - 2019-07-21 09:06:29 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:06:29 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:06:29 --> Utf8 Class Initialized
INFO - 2019-07-21 09:06:29 --> URI Class Initialized
INFO - 2019-07-21 09:06:29 --> Router Class Initialized
INFO - 2019-07-21 09:06:29 --> Output Class Initialized
INFO - 2019-07-21 09:06:29 --> Security Class Initialized
DEBUG - 2019-07-21 09:06:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:06:29 --> Input Class Initialized
INFO - 2019-07-21 09:06:29 --> Language Class Initialized
INFO - 2019-07-21 09:06:29 --> Loader Class Initialized
INFO - 2019-07-21 09:06:29 --> Database Driver Class Initialized
INFO - 2019-07-21 09:06:29 --> Controller Class Initialized
INFO - 2019-07-21 09:06:29 --> Model "Product" initialized
INFO - 2019-07-21 09:06:29 --> Final output sent to browser
DEBUG - 2019-07-21 09:06:29 --> Total execution time: 0.0379
INFO - 2019-07-21 09:07:26 --> Config Class Initialized
INFO - 2019-07-21 09:07:26 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:07:26 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:07:26 --> Utf8 Class Initialized
INFO - 2019-07-21 09:07:26 --> URI Class Initialized
INFO - 2019-07-21 09:07:26 --> Router Class Initialized
INFO - 2019-07-21 09:07:26 --> Output Class Initialized
INFO - 2019-07-21 09:07:26 --> Security Class Initialized
DEBUG - 2019-07-21 09:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:07:26 --> Input Class Initialized
INFO - 2019-07-21 09:07:26 --> Language Class Initialized
INFO - 2019-07-21 09:07:26 --> Loader Class Initialized
INFO - 2019-07-21 09:07:26 --> Database Driver Class Initialized
INFO - 2019-07-21 09:07:26 --> Controller Class Initialized
INFO - 2019-07-21 09:07:26 --> Model "Product" initialized
INFO - 2019-07-21 09:07:26 --> Final output sent to browser
DEBUG - 2019-07-21 09:07:26 --> Total execution time: 0.0391
INFO - 2019-07-21 09:08:26 --> Config Class Initialized
INFO - 2019-07-21 09:08:26 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:08:26 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:08:26 --> Utf8 Class Initialized
INFO - 2019-07-21 09:08:26 --> URI Class Initialized
INFO - 2019-07-21 09:08:26 --> Router Class Initialized
INFO - 2019-07-21 09:08:26 --> Output Class Initialized
INFO - 2019-07-21 09:08:26 --> Security Class Initialized
DEBUG - 2019-07-21 09:08:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:08:26 --> Input Class Initialized
INFO - 2019-07-21 09:08:26 --> Language Class Initialized
INFO - 2019-07-21 09:08:26 --> Loader Class Initialized
INFO - 2019-07-21 09:08:26 --> Database Driver Class Initialized
INFO - 2019-07-21 09:08:26 --> Controller Class Initialized
INFO - 2019-07-21 09:08:26 --> Model "Product" initialized
INFO - 2019-07-21 09:08:26 --> Final output sent to browser
DEBUG - 2019-07-21 09:08:26 --> Total execution time: 0.0472
INFO - 2019-07-21 09:08:34 --> Config Class Initialized
INFO - 2019-07-21 09:08:34 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:08:34 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:08:34 --> Utf8 Class Initialized
INFO - 2019-07-21 09:08:34 --> URI Class Initialized
INFO - 2019-07-21 09:08:34 --> Router Class Initialized
INFO - 2019-07-21 09:08:34 --> Output Class Initialized
INFO - 2019-07-21 09:08:34 --> Security Class Initialized
DEBUG - 2019-07-21 09:08:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:08:34 --> Input Class Initialized
INFO - 2019-07-21 09:08:34 --> Language Class Initialized
INFO - 2019-07-21 09:08:34 --> Loader Class Initialized
INFO - 2019-07-21 09:08:34 --> Database Driver Class Initialized
INFO - 2019-07-21 09:08:34 --> Controller Class Initialized
INFO - 2019-07-21 09:08:34 --> Model "Product" initialized
INFO - 2019-07-21 09:08:34 --> Final output sent to browser
DEBUG - 2019-07-21 09:08:34 --> Total execution time: 0.0331
INFO - 2019-07-21 09:09:27 --> Config Class Initialized
INFO - 2019-07-21 09:09:27 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:09:27 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:09:27 --> Utf8 Class Initialized
INFO - 2019-07-21 09:09:27 --> URI Class Initialized
INFO - 2019-07-21 09:09:27 --> Router Class Initialized
INFO - 2019-07-21 09:09:27 --> Output Class Initialized
INFO - 2019-07-21 09:09:27 --> Security Class Initialized
DEBUG - 2019-07-21 09:09:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:09:27 --> Input Class Initialized
INFO - 2019-07-21 09:09:27 --> Language Class Initialized
INFO - 2019-07-21 09:09:27 --> Loader Class Initialized
INFO - 2019-07-21 09:09:28 --> Database Driver Class Initialized
INFO - 2019-07-21 09:09:28 --> Controller Class Initialized
INFO - 2019-07-21 09:09:28 --> Model "Product" initialized
INFO - 2019-07-21 09:09:28 --> Final output sent to browser
DEBUG - 2019-07-21 09:09:28 --> Total execution time: 0.0362
INFO - 2019-07-21 09:09:32 --> Config Class Initialized
INFO - 2019-07-21 09:09:32 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:09:32 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:09:32 --> Utf8 Class Initialized
INFO - 2019-07-21 09:09:32 --> URI Class Initialized
INFO - 2019-07-21 09:09:32 --> Router Class Initialized
INFO - 2019-07-21 09:09:32 --> Output Class Initialized
INFO - 2019-07-21 09:09:32 --> Security Class Initialized
DEBUG - 2019-07-21 09:09:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:09:32 --> Input Class Initialized
INFO - 2019-07-21 09:09:32 --> Language Class Initialized
INFO - 2019-07-21 09:09:32 --> Loader Class Initialized
INFO - 2019-07-21 09:09:32 --> Database Driver Class Initialized
INFO - 2019-07-21 09:09:32 --> Controller Class Initialized
INFO - 2019-07-21 09:09:32 --> Model "Product" initialized
INFO - 2019-07-21 09:09:32 --> Final output sent to browser
DEBUG - 2019-07-21 09:09:32 --> Total execution time: 0.0279
INFO - 2019-07-21 09:09:35 --> Config Class Initialized
INFO - 2019-07-21 09:09:35 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:09:35 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:09:35 --> Utf8 Class Initialized
INFO - 2019-07-21 09:09:35 --> URI Class Initialized
INFO - 2019-07-21 09:09:35 --> Router Class Initialized
INFO - 2019-07-21 09:09:35 --> Output Class Initialized
INFO - 2019-07-21 09:09:35 --> Security Class Initialized
DEBUG - 2019-07-21 09:09:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:09:35 --> Input Class Initialized
INFO - 2019-07-21 09:09:35 --> Language Class Initialized
INFO - 2019-07-21 09:09:35 --> Loader Class Initialized
INFO - 2019-07-21 09:09:35 --> Database Driver Class Initialized
INFO - 2019-07-21 09:09:35 --> Controller Class Initialized
INFO - 2019-07-21 09:09:35 --> Model "Product" initialized
INFO - 2019-07-21 09:09:35 --> Final output sent to browser
DEBUG - 2019-07-21 09:09:35 --> Total execution time: 0.0271
INFO - 2019-07-21 09:10:35 --> Config Class Initialized
INFO - 2019-07-21 09:10:35 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:10:35 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:10:35 --> Utf8 Class Initialized
INFO - 2019-07-21 09:10:35 --> URI Class Initialized
INFO - 2019-07-21 09:10:35 --> Router Class Initialized
INFO - 2019-07-21 09:10:35 --> Output Class Initialized
INFO - 2019-07-21 09:10:35 --> Security Class Initialized
DEBUG - 2019-07-21 09:10:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:10:35 --> Input Class Initialized
INFO - 2019-07-21 09:10:35 --> Language Class Initialized
INFO - 2019-07-21 09:10:35 --> Loader Class Initialized
INFO - 2019-07-21 09:10:35 --> Database Driver Class Initialized
INFO - 2019-07-21 09:10:35 --> Controller Class Initialized
INFO - 2019-07-21 09:10:35 --> Model "Product" initialized
INFO - 2019-07-21 09:10:35 --> Final output sent to browser
DEBUG - 2019-07-21 09:10:35 --> Total execution time: 0.0307
INFO - 2019-07-21 09:11:18 --> Config Class Initialized
INFO - 2019-07-21 09:11:18 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:11:18 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:11:18 --> Utf8 Class Initialized
INFO - 2019-07-21 09:11:18 --> URI Class Initialized
INFO - 2019-07-21 09:11:18 --> Router Class Initialized
INFO - 2019-07-21 09:11:18 --> Output Class Initialized
INFO - 2019-07-21 09:11:18 --> Security Class Initialized
DEBUG - 2019-07-21 09:11:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:11:18 --> Input Class Initialized
INFO - 2019-07-21 09:11:18 --> Language Class Initialized
INFO - 2019-07-21 09:11:18 --> Loader Class Initialized
INFO - 2019-07-21 09:11:18 --> Database Driver Class Initialized
INFO - 2019-07-21 09:11:18 --> Controller Class Initialized
INFO - 2019-07-21 09:11:18 --> Model "Product" initialized
INFO - 2019-07-21 09:11:18 --> Final output sent to browser
DEBUG - 2019-07-21 09:11:18 --> Total execution time: 0.0274
INFO - 2019-07-21 09:11:22 --> Config Class Initialized
INFO - 2019-07-21 09:11:22 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:11:22 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:11:22 --> Utf8 Class Initialized
INFO - 2019-07-21 09:11:22 --> URI Class Initialized
INFO - 2019-07-21 09:11:22 --> Router Class Initialized
INFO - 2019-07-21 09:11:22 --> Output Class Initialized
INFO - 2019-07-21 09:11:22 --> Security Class Initialized
DEBUG - 2019-07-21 09:11:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:11:22 --> Input Class Initialized
INFO - 2019-07-21 09:11:22 --> Language Class Initialized
INFO - 2019-07-21 09:11:22 --> Loader Class Initialized
INFO - 2019-07-21 09:11:22 --> Database Driver Class Initialized
INFO - 2019-07-21 09:11:22 --> Controller Class Initialized
INFO - 2019-07-21 09:11:22 --> Model "Product" initialized
INFO - 2019-07-21 09:11:22 --> Final output sent to browser
DEBUG - 2019-07-21 09:11:22 --> Total execution time: 0.0307
INFO - 2019-07-21 09:11:32 --> Config Class Initialized
INFO - 2019-07-21 09:11:32 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:11:32 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:11:32 --> Utf8 Class Initialized
INFO - 2019-07-21 09:11:32 --> URI Class Initialized
INFO - 2019-07-21 09:11:32 --> Router Class Initialized
INFO - 2019-07-21 09:11:32 --> Output Class Initialized
INFO - 2019-07-21 09:11:32 --> Security Class Initialized
DEBUG - 2019-07-21 09:11:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:11:32 --> Input Class Initialized
INFO - 2019-07-21 09:11:32 --> Language Class Initialized
INFO - 2019-07-21 09:11:32 --> Loader Class Initialized
INFO - 2019-07-21 09:11:32 --> Database Driver Class Initialized
INFO - 2019-07-21 09:11:32 --> Controller Class Initialized
INFO - 2019-07-21 09:11:32 --> Model "Product" initialized
INFO - 2019-07-21 09:11:32 --> Final output sent to browser
DEBUG - 2019-07-21 09:11:32 --> Total execution time: 0.0295
INFO - 2019-07-21 09:11:44 --> Config Class Initialized
INFO - 2019-07-21 09:11:44 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:11:44 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:11:44 --> Utf8 Class Initialized
INFO - 2019-07-21 09:11:44 --> URI Class Initialized
INFO - 2019-07-21 09:11:44 --> Router Class Initialized
INFO - 2019-07-21 09:11:44 --> Output Class Initialized
INFO - 2019-07-21 09:11:44 --> Security Class Initialized
DEBUG - 2019-07-21 09:11:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:11:44 --> Input Class Initialized
INFO - 2019-07-21 09:11:44 --> Language Class Initialized
INFO - 2019-07-21 09:11:44 --> Loader Class Initialized
INFO - 2019-07-21 09:11:44 --> Database Driver Class Initialized
INFO - 2019-07-21 09:11:44 --> Controller Class Initialized
INFO - 2019-07-21 09:11:44 --> Model "Product" initialized
INFO - 2019-07-21 09:11:44 --> Final output sent to browser
DEBUG - 2019-07-21 09:11:44 --> Total execution time: 0.0289
INFO - 2019-07-21 09:12:13 --> Config Class Initialized
INFO - 2019-07-21 09:12:13 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:12:13 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:12:13 --> Utf8 Class Initialized
INFO - 2019-07-21 09:12:13 --> URI Class Initialized
INFO - 2019-07-21 09:12:13 --> Router Class Initialized
INFO - 2019-07-21 09:12:13 --> Output Class Initialized
INFO - 2019-07-21 09:12:13 --> Security Class Initialized
DEBUG - 2019-07-21 09:12:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:12:13 --> Input Class Initialized
INFO - 2019-07-21 09:12:13 --> Language Class Initialized
INFO - 2019-07-21 09:12:13 --> Loader Class Initialized
INFO - 2019-07-21 09:12:13 --> Database Driver Class Initialized
INFO - 2019-07-21 09:12:13 --> Controller Class Initialized
INFO - 2019-07-21 09:12:13 --> Model "Product" initialized
INFO - 2019-07-21 09:12:13 --> Final output sent to browser
DEBUG - 2019-07-21 09:12:13 --> Total execution time: 0.0393
INFO - 2019-07-21 09:12:24 --> Config Class Initialized
INFO - 2019-07-21 09:12:24 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:12:24 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:12:24 --> Utf8 Class Initialized
INFO - 2019-07-21 09:12:24 --> URI Class Initialized
INFO - 2019-07-21 09:12:24 --> Router Class Initialized
INFO - 2019-07-21 09:12:24 --> Output Class Initialized
INFO - 2019-07-21 09:12:24 --> Security Class Initialized
DEBUG - 2019-07-21 09:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:12:24 --> Input Class Initialized
INFO - 2019-07-21 09:12:24 --> Language Class Initialized
INFO - 2019-07-21 09:12:24 --> Loader Class Initialized
INFO - 2019-07-21 09:12:24 --> Database Driver Class Initialized
INFO - 2019-07-21 09:12:24 --> Controller Class Initialized
INFO - 2019-07-21 09:12:24 --> Model "Product" initialized
INFO - 2019-07-21 09:12:24 --> Final output sent to browser
DEBUG - 2019-07-21 09:12:24 --> Total execution time: 0.0338
INFO - 2019-07-21 09:14:32 --> Config Class Initialized
INFO - 2019-07-21 09:14:32 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:14:32 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:14:32 --> Utf8 Class Initialized
INFO - 2019-07-21 09:14:32 --> URI Class Initialized
INFO - 2019-07-21 09:14:32 --> Router Class Initialized
INFO - 2019-07-21 09:14:32 --> Output Class Initialized
INFO - 2019-07-21 09:14:32 --> Security Class Initialized
DEBUG - 2019-07-21 09:14:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:14:32 --> Input Class Initialized
INFO - 2019-07-21 09:14:32 --> Language Class Initialized
INFO - 2019-07-21 09:14:32 --> Loader Class Initialized
INFO - 2019-07-21 09:14:32 --> Database Driver Class Initialized
INFO - 2019-07-21 09:14:32 --> Controller Class Initialized
INFO - 2019-07-21 09:14:32 --> Model "Product" initialized
INFO - 2019-07-21 09:14:33 --> Final output sent to browser
DEBUG - 2019-07-21 09:14:33 --> Total execution time: 0.8657
INFO - 2019-07-21 09:14:53 --> Config Class Initialized
INFO - 2019-07-21 09:14:53 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:14:53 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:14:53 --> Utf8 Class Initialized
INFO - 2019-07-21 09:14:53 --> URI Class Initialized
INFO - 2019-07-21 09:14:53 --> Router Class Initialized
INFO - 2019-07-21 09:14:53 --> Output Class Initialized
INFO - 2019-07-21 09:14:53 --> Security Class Initialized
DEBUG - 2019-07-21 09:14:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:14:53 --> Input Class Initialized
INFO - 2019-07-21 09:14:53 --> Language Class Initialized
INFO - 2019-07-21 09:14:53 --> Loader Class Initialized
INFO - 2019-07-21 09:14:53 --> Database Driver Class Initialized
INFO - 2019-07-21 09:14:53 --> Controller Class Initialized
INFO - 2019-07-21 09:14:53 --> Model "Product" initialized
INFO - 2019-07-21 09:14:53 --> Final output sent to browser
DEBUG - 2019-07-21 09:14:53 --> Total execution time: 0.0278
INFO - 2019-07-21 09:15:15 --> Config Class Initialized
INFO - 2019-07-21 09:15:15 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:15:15 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:15:15 --> Utf8 Class Initialized
INFO - 2019-07-21 09:15:15 --> URI Class Initialized
INFO - 2019-07-21 09:15:15 --> Router Class Initialized
INFO - 2019-07-21 09:15:15 --> Output Class Initialized
INFO - 2019-07-21 09:15:15 --> Security Class Initialized
DEBUG - 2019-07-21 09:15:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:15:15 --> Input Class Initialized
INFO - 2019-07-21 09:15:15 --> Language Class Initialized
INFO - 2019-07-21 09:15:15 --> Loader Class Initialized
INFO - 2019-07-21 09:15:15 --> Database Driver Class Initialized
INFO - 2019-07-21 09:15:15 --> Controller Class Initialized
INFO - 2019-07-21 09:15:15 --> Model "Product" initialized
INFO - 2019-07-21 09:15:15 --> Final output sent to browser
DEBUG - 2019-07-21 09:15:15 --> Total execution time: 0.0385
INFO - 2019-07-21 09:15:44 --> Config Class Initialized
INFO - 2019-07-21 09:15:44 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:15:44 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:15:44 --> Utf8 Class Initialized
INFO - 2019-07-21 09:15:44 --> URI Class Initialized
INFO - 2019-07-21 09:15:44 --> Router Class Initialized
INFO - 2019-07-21 09:15:44 --> Output Class Initialized
INFO - 2019-07-21 09:15:44 --> Security Class Initialized
DEBUG - 2019-07-21 09:15:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:15:44 --> Input Class Initialized
INFO - 2019-07-21 09:15:44 --> Language Class Initialized
INFO - 2019-07-21 09:15:44 --> Loader Class Initialized
INFO - 2019-07-21 09:15:44 --> Database Driver Class Initialized
INFO - 2019-07-21 09:15:44 --> Controller Class Initialized
INFO - 2019-07-21 09:15:44 --> Model "Product" initialized
INFO - 2019-07-21 09:15:44 --> Final output sent to browser
DEBUG - 2019-07-21 09:15:44 --> Total execution time: 0.0255
INFO - 2019-07-21 09:16:07 --> Config Class Initialized
INFO - 2019-07-21 09:16:07 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:16:07 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:16:07 --> Utf8 Class Initialized
INFO - 2019-07-21 09:16:07 --> URI Class Initialized
INFO - 2019-07-21 09:16:07 --> Router Class Initialized
INFO - 2019-07-21 09:16:07 --> Output Class Initialized
INFO - 2019-07-21 09:16:07 --> Security Class Initialized
DEBUG - 2019-07-21 09:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:16:07 --> Input Class Initialized
INFO - 2019-07-21 09:16:07 --> Language Class Initialized
INFO - 2019-07-21 09:16:07 --> Loader Class Initialized
INFO - 2019-07-21 09:16:07 --> Database Driver Class Initialized
INFO - 2019-07-21 09:16:07 --> Controller Class Initialized
INFO - 2019-07-21 09:16:07 --> Model "Product" initialized
INFO - 2019-07-21 09:16:07 --> Final output sent to browser
DEBUG - 2019-07-21 09:16:07 --> Total execution time: 0.0264
INFO - 2019-07-21 09:16:18 --> Config Class Initialized
INFO - 2019-07-21 09:16:18 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:16:18 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:16:18 --> Utf8 Class Initialized
INFO - 2019-07-21 09:16:18 --> URI Class Initialized
INFO - 2019-07-21 09:16:18 --> Router Class Initialized
INFO - 2019-07-21 09:16:18 --> Output Class Initialized
INFO - 2019-07-21 09:16:18 --> Security Class Initialized
DEBUG - 2019-07-21 09:16:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:16:18 --> Input Class Initialized
INFO - 2019-07-21 09:16:18 --> Language Class Initialized
INFO - 2019-07-21 09:16:18 --> Loader Class Initialized
INFO - 2019-07-21 09:16:18 --> Database Driver Class Initialized
INFO - 2019-07-21 09:16:18 --> Controller Class Initialized
INFO - 2019-07-21 09:16:18 --> Model "Product" initialized
INFO - 2019-07-21 09:16:18 --> Final output sent to browser
DEBUG - 2019-07-21 09:16:18 --> Total execution time: 0.0320
INFO - 2019-07-21 09:16:29 --> Config Class Initialized
INFO - 2019-07-21 09:16:29 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:16:29 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:16:29 --> Utf8 Class Initialized
INFO - 2019-07-21 09:16:29 --> URI Class Initialized
INFO - 2019-07-21 09:16:29 --> Router Class Initialized
INFO - 2019-07-21 09:16:29 --> Output Class Initialized
INFO - 2019-07-21 09:16:29 --> Security Class Initialized
DEBUG - 2019-07-21 09:16:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:16:29 --> Input Class Initialized
INFO - 2019-07-21 09:16:29 --> Language Class Initialized
INFO - 2019-07-21 09:16:29 --> Loader Class Initialized
INFO - 2019-07-21 09:16:29 --> Database Driver Class Initialized
INFO - 2019-07-21 09:16:29 --> Controller Class Initialized
INFO - 2019-07-21 09:16:29 --> Model "Product" initialized
INFO - 2019-07-21 09:16:29 --> Final output sent to browser
DEBUG - 2019-07-21 09:16:29 --> Total execution time: 0.0358
INFO - 2019-07-21 09:16:39 --> Config Class Initialized
INFO - 2019-07-21 09:16:39 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:16:39 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:16:39 --> Utf8 Class Initialized
INFO - 2019-07-21 09:16:39 --> URI Class Initialized
INFO - 2019-07-21 09:16:39 --> Router Class Initialized
INFO - 2019-07-21 09:16:39 --> Output Class Initialized
INFO - 2019-07-21 09:16:39 --> Security Class Initialized
DEBUG - 2019-07-21 09:16:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:16:39 --> Input Class Initialized
INFO - 2019-07-21 09:16:39 --> Language Class Initialized
INFO - 2019-07-21 09:16:39 --> Loader Class Initialized
INFO - 2019-07-21 09:16:39 --> Database Driver Class Initialized
INFO - 2019-07-21 09:16:39 --> Controller Class Initialized
INFO - 2019-07-21 09:16:39 --> Model "Product" initialized
INFO - 2019-07-21 09:16:39 --> Final output sent to browser
DEBUG - 2019-07-21 09:16:39 --> Total execution time: 0.0296
INFO - 2019-07-21 09:16:54 --> Config Class Initialized
INFO - 2019-07-21 09:16:54 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:16:54 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:16:54 --> Utf8 Class Initialized
INFO - 2019-07-21 09:16:54 --> URI Class Initialized
INFO - 2019-07-21 09:16:54 --> Router Class Initialized
INFO - 2019-07-21 09:16:54 --> Output Class Initialized
INFO - 2019-07-21 09:16:54 --> Security Class Initialized
DEBUG - 2019-07-21 09:16:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:16:54 --> Input Class Initialized
INFO - 2019-07-21 09:16:54 --> Language Class Initialized
INFO - 2019-07-21 09:16:54 --> Loader Class Initialized
INFO - 2019-07-21 09:16:54 --> Database Driver Class Initialized
INFO - 2019-07-21 09:16:54 --> Controller Class Initialized
INFO - 2019-07-21 09:16:54 --> Model "Product" initialized
INFO - 2019-07-21 09:16:54 --> Final output sent to browser
DEBUG - 2019-07-21 09:16:54 --> Total execution time: 0.0403
INFO - 2019-07-21 09:17:03 --> Config Class Initialized
INFO - 2019-07-21 09:17:03 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:17:03 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:17:03 --> Utf8 Class Initialized
INFO - 2019-07-21 09:17:03 --> URI Class Initialized
INFO - 2019-07-21 09:17:03 --> Router Class Initialized
INFO - 2019-07-21 09:17:03 --> Output Class Initialized
INFO - 2019-07-21 09:17:03 --> Security Class Initialized
DEBUG - 2019-07-21 09:17:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:17:03 --> Input Class Initialized
INFO - 2019-07-21 09:17:03 --> Language Class Initialized
INFO - 2019-07-21 09:17:03 --> Loader Class Initialized
INFO - 2019-07-21 09:17:03 --> Database Driver Class Initialized
INFO - 2019-07-21 09:17:03 --> Controller Class Initialized
INFO - 2019-07-21 09:17:03 --> Model "Product" initialized
INFO - 2019-07-21 09:17:03 --> Final output sent to browser
DEBUG - 2019-07-21 09:17:03 --> Total execution time: 0.0346
INFO - 2019-07-21 09:17:41 --> Config Class Initialized
INFO - 2019-07-21 09:17:41 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:17:41 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:17:41 --> Utf8 Class Initialized
INFO - 2019-07-21 09:17:41 --> URI Class Initialized
INFO - 2019-07-21 09:17:41 --> Router Class Initialized
INFO - 2019-07-21 09:17:41 --> Output Class Initialized
INFO - 2019-07-21 09:17:41 --> Security Class Initialized
DEBUG - 2019-07-21 09:17:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:17:41 --> Input Class Initialized
INFO - 2019-07-21 09:17:41 --> Language Class Initialized
INFO - 2019-07-21 09:17:41 --> Loader Class Initialized
INFO - 2019-07-21 09:17:41 --> Database Driver Class Initialized
INFO - 2019-07-21 09:17:41 --> Controller Class Initialized
INFO - 2019-07-21 09:17:41 --> Model "Product" initialized
INFO - 2019-07-21 09:17:41 --> Final output sent to browser
DEBUG - 2019-07-21 09:17:41 --> Total execution time: 0.0354
INFO - 2019-07-21 09:17:57 --> Config Class Initialized
INFO - 2019-07-21 09:17:57 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:17:57 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:17:57 --> Utf8 Class Initialized
INFO - 2019-07-21 09:17:57 --> URI Class Initialized
INFO - 2019-07-21 09:17:57 --> Router Class Initialized
INFO - 2019-07-21 09:17:57 --> Output Class Initialized
INFO - 2019-07-21 09:17:57 --> Security Class Initialized
DEBUG - 2019-07-21 09:17:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:17:57 --> Input Class Initialized
INFO - 2019-07-21 09:17:57 --> Language Class Initialized
INFO - 2019-07-21 09:17:57 --> Loader Class Initialized
INFO - 2019-07-21 09:17:57 --> Database Driver Class Initialized
INFO - 2019-07-21 09:17:57 --> Controller Class Initialized
INFO - 2019-07-21 09:17:57 --> Model "Product" initialized
INFO - 2019-07-21 09:17:57 --> Final output sent to browser
DEBUG - 2019-07-21 09:17:57 --> Total execution time: 0.0293
INFO - 2019-07-21 09:18:05 --> Config Class Initialized
INFO - 2019-07-21 09:18:05 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:18:05 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:18:05 --> Utf8 Class Initialized
INFO - 2019-07-21 09:18:05 --> URI Class Initialized
INFO - 2019-07-21 09:18:05 --> Router Class Initialized
INFO - 2019-07-21 09:18:05 --> Output Class Initialized
INFO - 2019-07-21 09:18:05 --> Security Class Initialized
DEBUG - 2019-07-21 09:18:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:18:05 --> Input Class Initialized
INFO - 2019-07-21 09:18:05 --> Language Class Initialized
INFO - 2019-07-21 09:18:05 --> Loader Class Initialized
INFO - 2019-07-21 09:18:05 --> Database Driver Class Initialized
INFO - 2019-07-21 09:18:05 --> Controller Class Initialized
INFO - 2019-07-21 09:18:05 --> Model "Product" initialized
INFO - 2019-07-21 09:18:05 --> Final output sent to browser
DEBUG - 2019-07-21 09:18:05 --> Total execution time: 0.0302
INFO - 2019-07-21 09:18:46 --> Config Class Initialized
INFO - 2019-07-21 09:18:46 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:18:46 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:18:46 --> Utf8 Class Initialized
INFO - 2019-07-21 09:18:46 --> URI Class Initialized
INFO - 2019-07-21 09:18:46 --> Router Class Initialized
INFO - 2019-07-21 09:18:46 --> Output Class Initialized
INFO - 2019-07-21 09:18:46 --> Security Class Initialized
DEBUG - 2019-07-21 09:18:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:18:46 --> Input Class Initialized
INFO - 2019-07-21 09:18:46 --> Language Class Initialized
INFO - 2019-07-21 09:18:46 --> Loader Class Initialized
INFO - 2019-07-21 09:18:46 --> Database Driver Class Initialized
INFO - 2019-07-21 09:18:46 --> Controller Class Initialized
INFO - 2019-07-21 09:18:46 --> Model "Product" initialized
INFO - 2019-07-21 09:18:46 --> Final output sent to browser
DEBUG - 2019-07-21 09:18:46 --> Total execution time: 0.0295
INFO - 2019-07-21 09:19:02 --> Config Class Initialized
INFO - 2019-07-21 09:19:02 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:19:02 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:19:02 --> Utf8 Class Initialized
INFO - 2019-07-21 09:19:02 --> URI Class Initialized
INFO - 2019-07-21 09:19:02 --> Router Class Initialized
INFO - 2019-07-21 09:19:02 --> Output Class Initialized
INFO - 2019-07-21 09:19:02 --> Security Class Initialized
DEBUG - 2019-07-21 09:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:19:02 --> Input Class Initialized
INFO - 2019-07-21 09:19:02 --> Language Class Initialized
INFO - 2019-07-21 09:19:02 --> Loader Class Initialized
INFO - 2019-07-21 09:19:02 --> Database Driver Class Initialized
INFO - 2019-07-21 09:19:02 --> Controller Class Initialized
INFO - 2019-07-21 09:19:02 --> Model "Product" initialized
INFO - 2019-07-21 09:19:02 --> Final output sent to browser
DEBUG - 2019-07-21 09:19:02 --> Total execution time: 0.0406
INFO - 2019-07-21 09:19:05 --> Config Class Initialized
INFO - 2019-07-21 09:19:05 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:19:05 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:19:05 --> Utf8 Class Initialized
INFO - 2019-07-21 09:19:05 --> URI Class Initialized
INFO - 2019-07-21 09:19:05 --> Router Class Initialized
INFO - 2019-07-21 09:19:05 --> Output Class Initialized
INFO - 2019-07-21 09:19:05 --> Security Class Initialized
DEBUG - 2019-07-21 09:19:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:19:05 --> Input Class Initialized
INFO - 2019-07-21 09:19:05 --> Language Class Initialized
INFO - 2019-07-21 09:19:05 --> Loader Class Initialized
INFO - 2019-07-21 09:19:05 --> Database Driver Class Initialized
INFO - 2019-07-21 09:19:05 --> Controller Class Initialized
INFO - 2019-07-21 09:19:05 --> Model "Product" initialized
INFO - 2019-07-21 09:19:05 --> Final output sent to browser
DEBUG - 2019-07-21 09:19:05 --> Total execution time: 0.0398
INFO - 2019-07-21 09:20:21 --> Config Class Initialized
INFO - 2019-07-21 09:20:21 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:20:21 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:20:21 --> Utf8 Class Initialized
INFO - 2019-07-21 09:20:21 --> URI Class Initialized
INFO - 2019-07-21 09:20:21 --> Router Class Initialized
INFO - 2019-07-21 09:20:21 --> Output Class Initialized
INFO - 2019-07-21 09:20:21 --> Security Class Initialized
DEBUG - 2019-07-21 09:20:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:20:21 --> Input Class Initialized
INFO - 2019-07-21 09:20:21 --> Language Class Initialized
INFO - 2019-07-21 09:20:21 --> Loader Class Initialized
INFO - 2019-07-21 09:20:21 --> Database Driver Class Initialized
INFO - 2019-07-21 09:20:21 --> Controller Class Initialized
INFO - 2019-07-21 09:20:21 --> Model "Product" initialized
INFO - 2019-07-21 09:20:21 --> Final output sent to browser
DEBUG - 2019-07-21 09:20:21 --> Total execution time: 0.0337
INFO - 2019-07-21 09:20:39 --> Config Class Initialized
INFO - 2019-07-21 09:20:39 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:20:39 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:20:39 --> Utf8 Class Initialized
INFO - 2019-07-21 09:20:39 --> URI Class Initialized
INFO - 2019-07-21 09:20:39 --> Router Class Initialized
INFO - 2019-07-21 09:20:39 --> Output Class Initialized
INFO - 2019-07-21 09:20:39 --> Security Class Initialized
DEBUG - 2019-07-21 09:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:20:39 --> Input Class Initialized
INFO - 2019-07-21 09:20:39 --> Language Class Initialized
INFO - 2019-07-21 09:20:39 --> Loader Class Initialized
INFO - 2019-07-21 09:20:39 --> Database Driver Class Initialized
INFO - 2019-07-21 09:20:39 --> Controller Class Initialized
INFO - 2019-07-21 09:20:39 --> Model "Product" initialized
INFO - 2019-07-21 09:20:39 --> Final output sent to browser
DEBUG - 2019-07-21 09:20:39 --> Total execution time: 0.0307
INFO - 2019-07-21 09:21:04 --> Config Class Initialized
INFO - 2019-07-21 09:21:04 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:21:04 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:21:04 --> Utf8 Class Initialized
INFO - 2019-07-21 09:21:04 --> URI Class Initialized
INFO - 2019-07-21 09:21:04 --> Router Class Initialized
INFO - 2019-07-21 09:21:04 --> Output Class Initialized
INFO - 2019-07-21 09:21:04 --> Security Class Initialized
DEBUG - 2019-07-21 09:21:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:21:04 --> Input Class Initialized
INFO - 2019-07-21 09:21:04 --> Language Class Initialized
INFO - 2019-07-21 09:21:04 --> Loader Class Initialized
INFO - 2019-07-21 09:21:04 --> Database Driver Class Initialized
INFO - 2019-07-21 09:21:04 --> Controller Class Initialized
INFO - 2019-07-21 09:21:04 --> Model "Product" initialized
INFO - 2019-07-21 09:21:04 --> Final output sent to browser
DEBUG - 2019-07-21 09:21:04 --> Total execution time: 0.0254
INFO - 2019-07-21 09:21:44 --> Config Class Initialized
INFO - 2019-07-21 09:21:44 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:21:44 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:21:44 --> Utf8 Class Initialized
INFO - 2019-07-21 09:21:44 --> URI Class Initialized
INFO - 2019-07-21 09:21:44 --> Router Class Initialized
INFO - 2019-07-21 09:21:44 --> Output Class Initialized
INFO - 2019-07-21 09:21:44 --> Security Class Initialized
DEBUG - 2019-07-21 09:21:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:21:44 --> Input Class Initialized
INFO - 2019-07-21 09:21:44 --> Language Class Initialized
INFO - 2019-07-21 09:21:44 --> Loader Class Initialized
INFO - 2019-07-21 09:21:44 --> Database Driver Class Initialized
INFO - 2019-07-21 09:21:44 --> Controller Class Initialized
INFO - 2019-07-21 09:21:44 --> Model "Product" initialized
INFO - 2019-07-21 09:21:44 --> Final output sent to browser
DEBUG - 2019-07-21 09:21:44 --> Total execution time: 0.0587
INFO - 2019-07-21 09:22:07 --> Config Class Initialized
INFO - 2019-07-21 09:22:07 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:22:07 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:22:07 --> Utf8 Class Initialized
INFO - 2019-07-21 09:22:07 --> URI Class Initialized
INFO - 2019-07-21 09:22:07 --> Router Class Initialized
INFO - 2019-07-21 09:22:07 --> Output Class Initialized
INFO - 2019-07-21 09:22:07 --> Security Class Initialized
DEBUG - 2019-07-21 09:22:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:22:07 --> Input Class Initialized
INFO - 2019-07-21 09:22:07 --> Language Class Initialized
INFO - 2019-07-21 09:22:07 --> Loader Class Initialized
INFO - 2019-07-21 09:22:07 --> Database Driver Class Initialized
INFO - 2019-07-21 09:22:07 --> Controller Class Initialized
INFO - 2019-07-21 09:22:07 --> Model "Product" initialized
INFO - 2019-07-21 09:22:07 --> Final output sent to browser
DEBUG - 2019-07-21 09:22:07 --> Total execution time: 0.0213
INFO - 2019-07-21 09:23:38 --> Config Class Initialized
INFO - 2019-07-21 09:23:38 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:23:38 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:23:38 --> Utf8 Class Initialized
INFO - 2019-07-21 09:23:38 --> URI Class Initialized
INFO - 2019-07-21 09:23:38 --> Router Class Initialized
INFO - 2019-07-21 09:23:38 --> Output Class Initialized
INFO - 2019-07-21 09:23:38 --> Security Class Initialized
DEBUG - 2019-07-21 09:23:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:23:38 --> Input Class Initialized
INFO - 2019-07-21 09:23:38 --> Language Class Initialized
INFO - 2019-07-21 09:23:38 --> Loader Class Initialized
INFO - 2019-07-21 09:23:38 --> Database Driver Class Initialized
INFO - 2019-07-21 09:23:38 --> Controller Class Initialized
INFO - 2019-07-21 09:23:38 --> Model "Product" initialized
INFO - 2019-07-21 09:23:38 --> Final output sent to browser
DEBUG - 2019-07-21 09:23:38 --> Total execution time: 0.0307
INFO - 2019-07-21 09:24:17 --> Config Class Initialized
INFO - 2019-07-21 09:24:17 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:24:17 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:24:17 --> Utf8 Class Initialized
INFO - 2019-07-21 09:24:17 --> URI Class Initialized
INFO - 2019-07-21 09:24:17 --> Router Class Initialized
INFO - 2019-07-21 09:24:17 --> Output Class Initialized
INFO - 2019-07-21 09:24:17 --> Security Class Initialized
DEBUG - 2019-07-21 09:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:24:17 --> Input Class Initialized
INFO - 2019-07-21 09:24:17 --> Language Class Initialized
INFO - 2019-07-21 09:24:17 --> Loader Class Initialized
INFO - 2019-07-21 09:24:17 --> Database Driver Class Initialized
INFO - 2019-07-21 09:24:17 --> Controller Class Initialized
INFO - 2019-07-21 09:24:17 --> Model "Product" initialized
INFO - 2019-07-21 09:24:17 --> Final output sent to browser
DEBUG - 2019-07-21 09:24:17 --> Total execution time: 0.0276
INFO - 2019-07-21 09:24:26 --> Config Class Initialized
INFO - 2019-07-21 09:24:26 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:24:26 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:24:26 --> Utf8 Class Initialized
INFO - 2019-07-21 09:24:26 --> URI Class Initialized
INFO - 2019-07-21 09:24:26 --> Router Class Initialized
INFO - 2019-07-21 09:24:26 --> Output Class Initialized
INFO - 2019-07-21 09:24:26 --> Security Class Initialized
DEBUG - 2019-07-21 09:24:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:24:26 --> Input Class Initialized
INFO - 2019-07-21 09:24:26 --> Language Class Initialized
INFO - 2019-07-21 09:24:26 --> Loader Class Initialized
INFO - 2019-07-21 09:24:26 --> Database Driver Class Initialized
INFO - 2019-07-21 09:24:26 --> Controller Class Initialized
INFO - 2019-07-21 09:24:26 --> Model "Product" initialized
INFO - 2019-07-21 09:24:26 --> Final output sent to browser
DEBUG - 2019-07-21 09:24:26 --> Total execution time: 0.0261
INFO - 2019-07-21 09:24:50 --> Config Class Initialized
INFO - 2019-07-21 09:24:50 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:24:50 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:24:50 --> Utf8 Class Initialized
INFO - 2019-07-21 09:24:50 --> URI Class Initialized
INFO - 2019-07-21 09:24:50 --> Router Class Initialized
INFO - 2019-07-21 09:24:50 --> Output Class Initialized
INFO - 2019-07-21 09:24:50 --> Security Class Initialized
DEBUG - 2019-07-21 09:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:24:50 --> Input Class Initialized
INFO - 2019-07-21 09:24:50 --> Language Class Initialized
INFO - 2019-07-21 09:24:50 --> Loader Class Initialized
INFO - 2019-07-21 09:24:50 --> Database Driver Class Initialized
INFO - 2019-07-21 09:24:50 --> Controller Class Initialized
INFO - 2019-07-21 09:24:50 --> Model "Product" initialized
INFO - 2019-07-21 09:24:50 --> Final output sent to browser
DEBUG - 2019-07-21 09:24:50 --> Total execution time: 0.0264
INFO - 2019-07-21 09:24:56 --> Config Class Initialized
INFO - 2019-07-21 09:24:56 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:24:56 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:24:56 --> Utf8 Class Initialized
INFO - 2019-07-21 09:24:56 --> URI Class Initialized
INFO - 2019-07-21 09:24:56 --> Router Class Initialized
INFO - 2019-07-21 09:24:56 --> Output Class Initialized
INFO - 2019-07-21 09:24:56 --> Security Class Initialized
DEBUG - 2019-07-21 09:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:24:56 --> Input Class Initialized
INFO - 2019-07-21 09:24:56 --> Language Class Initialized
INFO - 2019-07-21 09:24:56 --> Loader Class Initialized
INFO - 2019-07-21 09:24:56 --> Database Driver Class Initialized
INFO - 2019-07-21 09:24:56 --> Controller Class Initialized
INFO - 2019-07-21 09:24:56 --> Model "Product" initialized
INFO - 2019-07-21 09:24:56 --> Final output sent to browser
DEBUG - 2019-07-21 09:24:56 --> Total execution time: 0.0214
INFO - 2019-07-21 09:25:24 --> Config Class Initialized
INFO - 2019-07-21 09:25:24 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:25:24 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:25:24 --> Utf8 Class Initialized
INFO - 2019-07-21 09:25:24 --> URI Class Initialized
INFO - 2019-07-21 09:25:24 --> Router Class Initialized
INFO - 2019-07-21 09:25:24 --> Output Class Initialized
INFO - 2019-07-21 09:25:24 --> Security Class Initialized
DEBUG - 2019-07-21 09:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:25:24 --> Input Class Initialized
INFO - 2019-07-21 09:25:24 --> Language Class Initialized
INFO - 2019-07-21 09:25:24 --> Loader Class Initialized
INFO - 2019-07-21 09:25:24 --> Database Driver Class Initialized
INFO - 2019-07-21 09:25:24 --> Controller Class Initialized
INFO - 2019-07-21 09:25:24 --> Model "Product" initialized
INFO - 2019-07-21 09:25:24 --> Final output sent to browser
DEBUG - 2019-07-21 09:25:24 --> Total execution time: 0.0284
INFO - 2019-07-21 09:25:35 --> Config Class Initialized
INFO - 2019-07-21 09:25:35 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:25:35 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:25:35 --> Utf8 Class Initialized
INFO - 2019-07-21 09:25:35 --> URI Class Initialized
INFO - 2019-07-21 09:25:35 --> Router Class Initialized
INFO - 2019-07-21 09:25:35 --> Output Class Initialized
INFO - 2019-07-21 09:25:35 --> Security Class Initialized
DEBUG - 2019-07-21 09:25:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:25:35 --> Input Class Initialized
INFO - 2019-07-21 09:25:35 --> Language Class Initialized
INFO - 2019-07-21 09:25:35 --> Loader Class Initialized
INFO - 2019-07-21 09:25:35 --> Database Driver Class Initialized
INFO - 2019-07-21 09:25:35 --> Controller Class Initialized
INFO - 2019-07-21 09:25:35 --> Model "Product" initialized
INFO - 2019-07-21 09:25:35 --> Final output sent to browser
DEBUG - 2019-07-21 09:25:35 --> Total execution time: 0.0318
INFO - 2019-07-21 09:26:55 --> Config Class Initialized
INFO - 2019-07-21 09:26:55 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:26:55 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:26:55 --> Utf8 Class Initialized
INFO - 2019-07-21 09:26:55 --> URI Class Initialized
INFO - 2019-07-21 09:26:55 --> Router Class Initialized
INFO - 2019-07-21 09:26:55 --> Output Class Initialized
INFO - 2019-07-21 09:26:55 --> Security Class Initialized
DEBUG - 2019-07-21 09:26:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:26:55 --> Input Class Initialized
INFO - 2019-07-21 09:26:55 --> Language Class Initialized
INFO - 2019-07-21 09:26:55 --> Loader Class Initialized
INFO - 2019-07-21 09:26:55 --> Database Driver Class Initialized
INFO - 2019-07-21 09:26:55 --> Controller Class Initialized
INFO - 2019-07-21 09:26:55 --> Model "Product" initialized
INFO - 2019-07-21 09:26:55 --> Final output sent to browser
DEBUG - 2019-07-21 09:26:55 --> Total execution time: 0.0219
INFO - 2019-07-21 09:27:08 --> Config Class Initialized
INFO - 2019-07-21 09:27:08 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:27:08 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:27:08 --> Utf8 Class Initialized
INFO - 2019-07-21 09:27:08 --> URI Class Initialized
INFO - 2019-07-21 09:27:08 --> Router Class Initialized
INFO - 2019-07-21 09:27:08 --> Output Class Initialized
INFO - 2019-07-21 09:27:08 --> Security Class Initialized
DEBUG - 2019-07-21 09:27:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:27:08 --> Input Class Initialized
INFO - 2019-07-21 09:27:08 --> Language Class Initialized
INFO - 2019-07-21 09:27:08 --> Loader Class Initialized
INFO - 2019-07-21 09:27:08 --> Database Driver Class Initialized
INFO - 2019-07-21 09:27:08 --> Controller Class Initialized
INFO - 2019-07-21 09:27:08 --> Model "Product" initialized
INFO - 2019-07-21 09:27:08 --> Final output sent to browser
DEBUG - 2019-07-21 09:27:08 --> Total execution time: 0.0304
INFO - 2019-07-21 09:27:12 --> Config Class Initialized
INFO - 2019-07-21 09:27:12 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:27:12 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:27:12 --> Utf8 Class Initialized
INFO - 2019-07-21 09:27:12 --> URI Class Initialized
INFO - 2019-07-21 09:27:12 --> Router Class Initialized
INFO - 2019-07-21 09:27:12 --> Output Class Initialized
INFO - 2019-07-21 09:27:12 --> Security Class Initialized
DEBUG - 2019-07-21 09:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:27:12 --> Input Class Initialized
INFO - 2019-07-21 09:27:12 --> Language Class Initialized
INFO - 2019-07-21 09:27:12 --> Loader Class Initialized
INFO - 2019-07-21 09:27:12 --> Database Driver Class Initialized
INFO - 2019-07-21 09:27:12 --> Controller Class Initialized
INFO - 2019-07-21 09:27:12 --> Model "Product" initialized
INFO - 2019-07-21 09:27:12 --> Final output sent to browser
DEBUG - 2019-07-21 09:27:12 --> Total execution time: 0.0218
INFO - 2019-07-21 09:27:25 --> Config Class Initialized
INFO - 2019-07-21 09:27:25 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:27:25 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:27:25 --> Utf8 Class Initialized
INFO - 2019-07-21 09:27:25 --> URI Class Initialized
INFO - 2019-07-21 09:27:25 --> Router Class Initialized
INFO - 2019-07-21 09:27:25 --> Output Class Initialized
INFO - 2019-07-21 09:27:25 --> Security Class Initialized
DEBUG - 2019-07-21 09:27:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:27:25 --> Input Class Initialized
INFO - 2019-07-21 09:27:25 --> Language Class Initialized
INFO - 2019-07-21 09:27:25 --> Loader Class Initialized
INFO - 2019-07-21 09:27:25 --> Database Driver Class Initialized
INFO - 2019-07-21 09:27:25 --> Controller Class Initialized
INFO - 2019-07-21 09:27:25 --> Model "Product" initialized
INFO - 2019-07-21 09:27:25 --> Final output sent to browser
DEBUG - 2019-07-21 09:27:25 --> Total execution time: 0.0382
INFO - 2019-07-21 09:27:52 --> Config Class Initialized
INFO - 2019-07-21 09:27:52 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:27:52 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:27:52 --> Utf8 Class Initialized
INFO - 2019-07-21 09:27:52 --> URI Class Initialized
INFO - 2019-07-21 09:27:52 --> Router Class Initialized
INFO - 2019-07-21 09:27:52 --> Output Class Initialized
INFO - 2019-07-21 09:27:52 --> Security Class Initialized
DEBUG - 2019-07-21 09:27:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:27:52 --> Input Class Initialized
INFO - 2019-07-21 09:27:52 --> Language Class Initialized
INFO - 2019-07-21 09:27:52 --> Loader Class Initialized
INFO - 2019-07-21 09:27:52 --> Database Driver Class Initialized
INFO - 2019-07-21 09:27:52 --> Controller Class Initialized
INFO - 2019-07-21 09:27:52 --> Model "Product" initialized
INFO - 2019-07-21 09:27:52 --> Final output sent to browser
DEBUG - 2019-07-21 09:27:52 --> Total execution time: 0.0353
INFO - 2019-07-21 09:28:05 --> Config Class Initialized
INFO - 2019-07-21 09:28:05 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:28:05 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:28:05 --> Utf8 Class Initialized
INFO - 2019-07-21 09:28:05 --> URI Class Initialized
INFO - 2019-07-21 09:28:05 --> Router Class Initialized
INFO - 2019-07-21 09:28:05 --> Output Class Initialized
INFO - 2019-07-21 09:28:05 --> Security Class Initialized
DEBUG - 2019-07-21 09:28:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:28:05 --> Input Class Initialized
INFO - 2019-07-21 09:28:05 --> Language Class Initialized
INFO - 2019-07-21 09:28:05 --> Loader Class Initialized
INFO - 2019-07-21 09:28:05 --> Database Driver Class Initialized
INFO - 2019-07-21 09:28:05 --> Controller Class Initialized
INFO - 2019-07-21 09:28:05 --> Model "Product" initialized
INFO - 2019-07-21 09:28:05 --> Final output sent to browser
DEBUG - 2019-07-21 09:28:05 --> Total execution time: 0.0295
INFO - 2019-07-21 09:28:13 --> Config Class Initialized
INFO - 2019-07-21 09:28:13 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:28:13 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:28:13 --> Utf8 Class Initialized
INFO - 2019-07-21 09:28:13 --> URI Class Initialized
INFO - 2019-07-21 09:28:13 --> Router Class Initialized
INFO - 2019-07-21 09:28:13 --> Output Class Initialized
INFO - 2019-07-21 09:28:13 --> Security Class Initialized
DEBUG - 2019-07-21 09:28:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:28:13 --> Input Class Initialized
INFO - 2019-07-21 09:28:13 --> Language Class Initialized
INFO - 2019-07-21 09:28:13 --> Loader Class Initialized
INFO - 2019-07-21 09:28:13 --> Database Driver Class Initialized
INFO - 2019-07-21 09:28:13 --> Controller Class Initialized
INFO - 2019-07-21 09:28:13 --> Model "Product" initialized
INFO - 2019-07-21 09:28:13 --> Final output sent to browser
DEBUG - 2019-07-21 09:28:13 --> Total execution time: 0.0307
INFO - 2019-07-21 09:28:19 --> Config Class Initialized
INFO - 2019-07-21 09:28:19 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:28:19 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:28:19 --> Utf8 Class Initialized
INFO - 2019-07-21 09:28:19 --> URI Class Initialized
INFO - 2019-07-21 09:28:19 --> Router Class Initialized
INFO - 2019-07-21 09:28:19 --> Output Class Initialized
INFO - 2019-07-21 09:28:19 --> Security Class Initialized
DEBUG - 2019-07-21 09:28:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:28:19 --> Input Class Initialized
INFO - 2019-07-21 09:28:19 --> Language Class Initialized
INFO - 2019-07-21 09:28:19 --> Loader Class Initialized
INFO - 2019-07-21 09:28:19 --> Database Driver Class Initialized
INFO - 2019-07-21 09:28:19 --> Controller Class Initialized
INFO - 2019-07-21 09:28:19 --> Model "Product" initialized
INFO - 2019-07-21 09:28:19 --> Final output sent to browser
DEBUG - 2019-07-21 09:28:19 --> Total execution time: 0.0465
INFO - 2019-07-21 09:30:11 --> Config Class Initialized
INFO - 2019-07-21 09:30:11 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:30:11 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:30:11 --> Utf8 Class Initialized
INFO - 2019-07-21 09:30:11 --> URI Class Initialized
INFO - 2019-07-21 09:30:11 --> Router Class Initialized
INFO - 2019-07-21 09:30:11 --> Output Class Initialized
INFO - 2019-07-21 09:30:11 --> Security Class Initialized
DEBUG - 2019-07-21 09:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:30:11 --> Input Class Initialized
INFO - 2019-07-21 09:30:11 --> Language Class Initialized
INFO - 2019-07-21 09:30:11 --> Loader Class Initialized
INFO - 2019-07-21 09:30:11 --> Database Driver Class Initialized
INFO - 2019-07-21 09:30:11 --> Controller Class Initialized
INFO - 2019-07-21 09:30:11 --> Model "Product" initialized
INFO - 2019-07-21 09:30:11 --> Final output sent to browser
DEBUG - 2019-07-21 09:30:11 --> Total execution time: 0.0252
INFO - 2019-07-21 09:30:28 --> Config Class Initialized
INFO - 2019-07-21 09:30:28 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:30:28 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:30:28 --> Utf8 Class Initialized
INFO - 2019-07-21 09:30:28 --> URI Class Initialized
INFO - 2019-07-21 09:30:28 --> Router Class Initialized
INFO - 2019-07-21 09:30:28 --> Output Class Initialized
INFO - 2019-07-21 09:30:28 --> Security Class Initialized
DEBUG - 2019-07-21 09:30:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:30:28 --> Input Class Initialized
INFO - 2019-07-21 09:30:28 --> Language Class Initialized
INFO - 2019-07-21 09:30:28 --> Loader Class Initialized
INFO - 2019-07-21 09:30:28 --> Database Driver Class Initialized
INFO - 2019-07-21 09:30:28 --> Controller Class Initialized
INFO - 2019-07-21 09:30:28 --> Model "Product" initialized
INFO - 2019-07-21 09:30:28 --> Final output sent to browser
DEBUG - 2019-07-21 09:30:28 --> Total execution time: 0.5865
INFO - 2019-07-21 09:30:32 --> Config Class Initialized
INFO - 2019-07-21 09:30:32 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:30:32 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:30:32 --> Utf8 Class Initialized
INFO - 2019-07-21 09:30:32 --> URI Class Initialized
INFO - 2019-07-21 09:30:32 --> Router Class Initialized
INFO - 2019-07-21 09:30:32 --> Output Class Initialized
INFO - 2019-07-21 09:30:32 --> Security Class Initialized
DEBUG - 2019-07-21 09:30:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:30:32 --> Input Class Initialized
INFO - 2019-07-21 09:30:32 --> Language Class Initialized
INFO - 2019-07-21 09:30:32 --> Loader Class Initialized
INFO - 2019-07-21 09:30:32 --> Database Driver Class Initialized
INFO - 2019-07-21 09:30:32 --> Controller Class Initialized
INFO - 2019-07-21 09:30:32 --> Model "Product" initialized
INFO - 2019-07-21 09:30:32 --> Final output sent to browser
DEBUG - 2019-07-21 09:30:32 --> Total execution time: 0.0250
INFO - 2019-07-21 09:31:13 --> Config Class Initialized
INFO - 2019-07-21 09:31:13 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:31:13 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:31:13 --> Utf8 Class Initialized
INFO - 2019-07-21 09:31:13 --> URI Class Initialized
INFO - 2019-07-21 09:31:13 --> Router Class Initialized
INFO - 2019-07-21 09:31:13 --> Output Class Initialized
INFO - 2019-07-21 09:31:13 --> Security Class Initialized
DEBUG - 2019-07-21 09:31:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:31:13 --> Input Class Initialized
INFO - 2019-07-21 09:31:13 --> Language Class Initialized
INFO - 2019-07-21 09:31:13 --> Loader Class Initialized
INFO - 2019-07-21 09:31:13 --> Database Driver Class Initialized
INFO - 2019-07-21 09:31:13 --> Controller Class Initialized
INFO - 2019-07-21 09:31:13 --> Model "Product" initialized
INFO - 2019-07-21 09:31:13 --> Final output sent to browser
DEBUG - 2019-07-21 09:31:13 --> Total execution time: 0.0404
INFO - 2019-07-21 09:33:19 --> Config Class Initialized
INFO - 2019-07-21 09:33:19 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:33:19 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:33:19 --> Utf8 Class Initialized
INFO - 2019-07-21 09:33:19 --> URI Class Initialized
INFO - 2019-07-21 09:33:19 --> Router Class Initialized
INFO - 2019-07-21 09:33:19 --> Output Class Initialized
INFO - 2019-07-21 09:33:19 --> Security Class Initialized
DEBUG - 2019-07-21 09:33:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:33:19 --> Input Class Initialized
INFO - 2019-07-21 09:33:19 --> Language Class Initialized
INFO - 2019-07-21 09:33:19 --> Loader Class Initialized
INFO - 2019-07-21 09:33:19 --> Database Driver Class Initialized
INFO - 2019-07-21 09:33:19 --> Controller Class Initialized
INFO - 2019-07-21 09:33:19 --> Model "Product" initialized
INFO - 2019-07-21 09:33:19 --> Final output sent to browser
DEBUG - 2019-07-21 09:33:19 --> Total execution time: 0.0628
INFO - 2019-07-21 09:34:23 --> Config Class Initialized
INFO - 2019-07-21 09:34:23 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:34:23 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:34:23 --> Utf8 Class Initialized
INFO - 2019-07-21 09:34:23 --> URI Class Initialized
INFO - 2019-07-21 09:34:23 --> Router Class Initialized
INFO - 2019-07-21 09:34:23 --> Output Class Initialized
INFO - 2019-07-21 09:34:23 --> Security Class Initialized
DEBUG - 2019-07-21 09:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:34:23 --> Input Class Initialized
INFO - 2019-07-21 09:34:23 --> Language Class Initialized
INFO - 2019-07-21 09:34:23 --> Loader Class Initialized
INFO - 2019-07-21 09:34:23 --> Database Driver Class Initialized
INFO - 2019-07-21 09:34:23 --> Controller Class Initialized
INFO - 2019-07-21 09:34:23 --> Model "Product" initialized
INFO - 2019-07-21 09:34:23 --> Final output sent to browser
DEBUG - 2019-07-21 09:34:23 --> Total execution time: 0.0235
INFO - 2019-07-21 09:35:26 --> Config Class Initialized
INFO - 2019-07-21 09:35:26 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:35:26 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:35:26 --> Utf8 Class Initialized
INFO - 2019-07-21 09:35:26 --> URI Class Initialized
INFO - 2019-07-21 09:35:26 --> Router Class Initialized
INFO - 2019-07-21 09:35:26 --> Output Class Initialized
INFO - 2019-07-21 09:35:26 --> Security Class Initialized
DEBUG - 2019-07-21 09:35:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:35:26 --> Input Class Initialized
INFO - 2019-07-21 09:35:26 --> Language Class Initialized
INFO - 2019-07-21 09:35:26 --> Loader Class Initialized
INFO - 2019-07-21 09:35:26 --> Database Driver Class Initialized
INFO - 2019-07-21 09:35:26 --> Controller Class Initialized
INFO - 2019-07-21 09:35:26 --> Model "Product" initialized
INFO - 2019-07-21 09:35:26 --> Final output sent to browser
DEBUG - 2019-07-21 09:35:26 --> Total execution time: 0.0345
INFO - 2019-07-21 09:36:11 --> Config Class Initialized
INFO - 2019-07-21 09:36:11 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:36:11 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:36:11 --> Utf8 Class Initialized
INFO - 2019-07-21 09:36:11 --> URI Class Initialized
INFO - 2019-07-21 09:36:11 --> Router Class Initialized
INFO - 2019-07-21 09:36:11 --> Output Class Initialized
INFO - 2019-07-21 09:36:11 --> Security Class Initialized
DEBUG - 2019-07-21 09:36:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:36:11 --> Input Class Initialized
INFO - 2019-07-21 09:36:11 --> Language Class Initialized
INFO - 2019-07-21 09:36:11 --> Loader Class Initialized
INFO - 2019-07-21 09:36:11 --> Database Driver Class Initialized
INFO - 2019-07-21 09:36:11 --> Controller Class Initialized
INFO - 2019-07-21 09:36:11 --> Model "Product" initialized
INFO - 2019-07-21 09:36:11 --> Final output sent to browser
DEBUG - 2019-07-21 09:36:11 --> Total execution time: 0.0341
INFO - 2019-07-21 09:38:55 --> Config Class Initialized
INFO - 2019-07-21 09:38:55 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:38:55 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:38:55 --> Utf8 Class Initialized
INFO - 2019-07-21 09:38:55 --> URI Class Initialized
INFO - 2019-07-21 09:38:55 --> Router Class Initialized
INFO - 2019-07-21 09:38:55 --> Output Class Initialized
INFO - 2019-07-21 09:38:55 --> Security Class Initialized
DEBUG - 2019-07-21 09:38:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:38:55 --> Input Class Initialized
INFO - 2019-07-21 09:38:55 --> Language Class Initialized
INFO - 2019-07-21 09:38:55 --> Loader Class Initialized
INFO - 2019-07-21 09:38:55 --> Database Driver Class Initialized
INFO - 2019-07-21 09:38:55 --> Controller Class Initialized
INFO - 2019-07-21 09:38:55 --> Model "Product" initialized
INFO - 2019-07-21 09:38:55 --> Final output sent to browser
DEBUG - 2019-07-21 09:38:55 --> Total execution time: 0.0245
INFO - 2019-07-21 09:38:55 --> Config Class Initialized
INFO - 2019-07-21 09:38:55 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:38:55 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:38:55 --> Utf8 Class Initialized
INFO - 2019-07-21 09:38:55 --> URI Class Initialized
INFO - 2019-07-21 09:38:55 --> Router Class Initialized
INFO - 2019-07-21 09:38:55 --> Output Class Initialized
INFO - 2019-07-21 09:38:55 --> Security Class Initialized
DEBUG - 2019-07-21 09:38:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:38:55 --> Input Class Initialized
INFO - 2019-07-21 09:38:55 --> Language Class Initialized
INFO - 2019-07-21 09:38:55 --> Loader Class Initialized
INFO - 2019-07-21 09:38:55 --> Database Driver Class Initialized
INFO - 2019-07-21 09:38:55 --> Controller Class Initialized
INFO - 2019-07-21 09:38:55 --> Model "Product" initialized
INFO - 2019-07-21 09:40:54 --> Config Class Initialized
INFO - 2019-07-21 09:40:55 --> Config Class Initialized
INFO - 2019-07-21 09:40:55 --> Hooks Class Initialized
INFO - 2019-07-21 09:40:55 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:40:55 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:40:55 --> Utf8 Class Initialized
INFO - 2019-07-21 09:40:55 --> URI Class Initialized
DEBUG - 2019-07-21 09:40:55 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:40:55 --> Utf8 Class Initialized
INFO - 2019-07-21 09:40:55 --> Router Class Initialized
INFO - 2019-07-21 09:40:55 --> URI Class Initialized
INFO - 2019-07-21 09:40:55 --> Router Class Initialized
INFO - 2019-07-21 09:40:55 --> Output Class Initialized
INFO - 2019-07-21 09:40:55 --> Output Class Initialized
INFO - 2019-07-21 09:40:55 --> Security Class Initialized
INFO - 2019-07-21 09:40:55 --> Security Class Initialized
DEBUG - 2019-07-21 09:40:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:40:55 --> Input Class Initialized
DEBUG - 2019-07-21 09:40:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:40:55 --> Input Class Initialized
INFO - 2019-07-21 09:40:55 --> Language Class Initialized
INFO - 2019-07-21 09:40:55 --> Language Class Initialized
INFO - 2019-07-21 09:40:55 --> Loader Class Initialized
INFO - 2019-07-21 09:40:55 --> Loader Class Initialized
INFO - 2019-07-21 09:40:55 --> Database Driver Class Initialized
INFO - 2019-07-21 09:40:55 --> Database Driver Class Initialized
INFO - 2019-07-21 09:40:55 --> Controller Class Initialized
INFO - 2019-07-21 09:40:55 --> Model "Product" initialized
INFO - 2019-07-21 09:40:55 --> Controller Class Initialized
INFO - 2019-07-21 09:40:55 --> Model "Product" initialized
INFO - 2019-07-21 09:40:55 --> Final output sent to browser
DEBUG - 2019-07-21 09:40:55 --> Total execution time: 1.3398
INFO - 2019-07-21 09:43:13 --> Config Class Initialized
INFO - 2019-07-21 09:43:13 --> Hooks Class Initialized
INFO - 2019-07-21 09:43:13 --> Config Class Initialized
INFO - 2019-07-21 09:43:13 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:43:13 --> UTF-8 Support Enabled
DEBUG - 2019-07-21 09:43:13 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:43:13 --> Utf8 Class Initialized
INFO - 2019-07-21 09:43:13 --> Utf8 Class Initialized
INFO - 2019-07-21 09:43:13 --> URI Class Initialized
INFO - 2019-07-21 09:43:13 --> URI Class Initialized
INFO - 2019-07-21 09:43:13 --> Router Class Initialized
INFO - 2019-07-21 09:43:13 --> Router Class Initialized
INFO - 2019-07-21 09:43:13 --> Output Class Initialized
INFO - 2019-07-21 09:43:13 --> Output Class Initialized
INFO - 2019-07-21 09:43:13 --> Security Class Initialized
INFO - 2019-07-21 09:43:13 --> Security Class Initialized
DEBUG - 2019-07-21 09:43:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-21 09:43:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:43:13 --> Input Class Initialized
INFO - 2019-07-21 09:43:13 --> Input Class Initialized
INFO - 2019-07-21 09:43:13 --> Language Class Initialized
INFO - 2019-07-21 09:43:13 --> Language Class Initialized
INFO - 2019-07-21 09:43:13 --> Loader Class Initialized
INFO - 2019-07-21 09:43:13 --> Loader Class Initialized
INFO - 2019-07-21 09:43:13 --> Database Driver Class Initialized
INFO - 2019-07-21 09:43:13 --> Database Driver Class Initialized
INFO - 2019-07-21 09:43:14 --> Controller Class Initialized
INFO - 2019-07-21 09:43:14 --> Controller Class Initialized
INFO - 2019-07-21 09:43:14 --> Model "Product" initialized
INFO - 2019-07-21 09:43:14 --> Model "Product" initialized
INFO - 2019-07-21 09:43:14 --> Final output sent to browser
DEBUG - 2019-07-21 09:43:14 --> Total execution time: 1.0071
INFO - 2019-07-21 09:43:59 --> Config Class Initialized
INFO - 2019-07-21 09:43:59 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:43:59 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:43:59 --> Utf8 Class Initialized
INFO - 2019-07-21 09:43:59 --> URI Class Initialized
INFO - 2019-07-21 09:43:59 --> Router Class Initialized
INFO - 2019-07-21 09:43:59 --> Output Class Initialized
INFO - 2019-07-21 09:43:59 --> Security Class Initialized
DEBUG - 2019-07-21 09:43:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:43:59 --> Input Class Initialized
INFO - 2019-07-21 09:43:59 --> Language Class Initialized
INFO - 2019-07-21 09:43:59 --> Loader Class Initialized
INFO - 2019-07-21 09:43:59 --> Database Driver Class Initialized
INFO - 2019-07-21 09:43:59 --> Controller Class Initialized
INFO - 2019-07-21 09:43:59 --> Model "Product" initialized
INFO - 2019-07-21 09:43:59 --> Final output sent to browser
DEBUG - 2019-07-21 09:43:59 --> Total execution time: 0.0592
INFO - 2019-07-21 09:43:59 --> Config Class Initialized
INFO - 2019-07-21 09:43:59 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:43:59 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:43:59 --> Utf8 Class Initialized
INFO - 2019-07-21 09:44:00 --> URI Class Initialized
INFO - 2019-07-21 09:44:00 --> Router Class Initialized
INFO - 2019-07-21 09:44:00 --> Output Class Initialized
INFO - 2019-07-21 09:44:00 --> Security Class Initialized
DEBUG - 2019-07-21 09:44:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:44:00 --> Input Class Initialized
INFO - 2019-07-21 09:44:00 --> Language Class Initialized
INFO - 2019-07-21 09:44:00 --> Loader Class Initialized
INFO - 2019-07-21 09:44:00 --> Database Driver Class Initialized
INFO - 2019-07-21 09:44:00 --> Controller Class Initialized
INFO - 2019-07-21 09:44:00 --> Model "Product" initialized
INFO - 2019-07-21 09:44:00 --> Final output sent to browser
DEBUG - 2019-07-21 09:44:00 --> Total execution time: 0.2261
INFO - 2019-07-21 09:44:11 --> Config Class Initialized
INFO - 2019-07-21 09:44:11 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:44:11 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:44:11 --> Utf8 Class Initialized
INFO - 2019-07-21 09:44:11 --> URI Class Initialized
INFO - 2019-07-21 09:44:11 --> Config Class Initialized
INFO - 2019-07-21 09:44:11 --> Hooks Class Initialized
INFO - 2019-07-21 09:44:11 --> Router Class Initialized
INFO - 2019-07-21 09:44:11 --> Output Class Initialized
DEBUG - 2019-07-21 09:44:11 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:44:11 --> Utf8 Class Initialized
INFO - 2019-07-21 09:44:11 --> Security Class Initialized
INFO - 2019-07-21 09:44:11 --> URI Class Initialized
DEBUG - 2019-07-21 09:44:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:44:11 --> Input Class Initialized
INFO - 2019-07-21 09:44:11 --> Language Class Initialized
INFO - 2019-07-21 09:44:11 --> Router Class Initialized
INFO - 2019-07-21 09:44:11 --> Loader Class Initialized
INFO - 2019-07-21 09:44:11 --> Output Class Initialized
INFO - 2019-07-21 09:44:11 --> Security Class Initialized
DEBUG - 2019-07-21 09:44:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:44:11 --> Input Class Initialized
INFO - 2019-07-21 09:44:11 --> Language Class Initialized
INFO - 2019-07-21 09:44:11 --> Loader Class Initialized
INFO - 2019-07-21 09:44:11 --> Database Driver Class Initialized
INFO - 2019-07-21 09:44:11 --> Controller Class Initialized
INFO - 2019-07-21 09:44:11 --> Model "Product" initialized
INFO - 2019-07-21 09:44:11 --> Final output sent to browser
DEBUG - 2019-07-21 09:44:11 --> Total execution time: 0.0326
INFO - 2019-07-21 09:44:11 --> Database Driver Class Initialized
INFO - 2019-07-21 09:44:11 --> Controller Class Initialized
INFO - 2019-07-21 09:44:11 --> Model "Product" initialized
INFO - 2019-07-21 09:44:11 --> Final output sent to browser
DEBUG - 2019-07-21 09:44:11 --> Total execution time: 0.0746
INFO - 2019-07-21 09:47:10 --> Config Class Initialized
INFO - 2019-07-21 09:47:10 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:47:10 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:47:10 --> Utf8 Class Initialized
INFO - 2019-07-21 09:47:10 --> URI Class Initialized
INFO - 2019-07-21 09:47:10 --> Router Class Initialized
INFO - 2019-07-21 09:47:10 --> Config Class Initialized
INFO - 2019-07-21 09:47:10 --> Hooks Class Initialized
INFO - 2019-07-21 09:47:10 --> Output Class Initialized
DEBUG - 2019-07-21 09:47:10 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:47:10 --> Utf8 Class Initialized
INFO - 2019-07-21 09:47:10 --> Security Class Initialized
INFO - 2019-07-21 09:47:10 --> URI Class Initialized
DEBUG - 2019-07-21 09:47:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:47:10 --> Input Class Initialized
INFO - 2019-07-21 09:47:10 --> Language Class Initialized
INFO - 2019-07-21 09:47:10 --> Router Class Initialized
INFO - 2019-07-21 09:47:10 --> Loader Class Initialized
INFO - 2019-07-21 09:47:10 --> Output Class Initialized
INFO - 2019-07-21 09:47:10 --> Security Class Initialized
DEBUG - 2019-07-21 09:47:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:47:10 --> Input Class Initialized
INFO - 2019-07-21 09:47:10 --> Language Class Initialized
INFO - 2019-07-21 09:47:10 --> Loader Class Initialized
INFO - 2019-07-21 09:47:10 --> Database Driver Class Initialized
INFO - 2019-07-21 09:47:10 --> Controller Class Initialized
INFO - 2019-07-21 09:47:10 --> Model "Product" initialized
INFO - 2019-07-21 09:47:10 --> Final output sent to browser
DEBUG - 2019-07-21 09:47:10 --> Total execution time: 0.0254
INFO - 2019-07-21 09:47:10 --> Database Driver Class Initialized
INFO - 2019-07-21 09:47:10 --> Controller Class Initialized
INFO - 2019-07-21 09:47:10 --> Model "Product" initialized
INFO - 2019-07-21 09:47:10 --> Final output sent to browser
DEBUG - 2019-07-21 09:47:10 --> Total execution time: 0.1445
INFO - 2019-07-21 09:47:30 --> Config Class Initialized
INFO - 2019-07-21 09:47:30 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:47:30 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:47:30 --> Utf8 Class Initialized
INFO - 2019-07-21 09:47:30 --> URI Class Initialized
INFO - 2019-07-21 09:47:30 --> Router Class Initialized
INFO - 2019-07-21 09:47:30 --> Output Class Initialized
INFO - 2019-07-21 09:47:30 --> Security Class Initialized
DEBUG - 2019-07-21 09:47:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:47:30 --> Input Class Initialized
INFO - 2019-07-21 09:47:30 --> Language Class Initialized
INFO - 2019-07-21 09:47:30 --> Config Class Initialized
INFO - 2019-07-21 09:47:30 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:47:30 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:47:30 --> Utf8 Class Initialized
INFO - 2019-07-21 09:47:30 --> Loader Class Initialized
INFO - 2019-07-21 09:47:30 --> URI Class Initialized
INFO - 2019-07-21 09:47:30 --> Router Class Initialized
INFO - 2019-07-21 09:47:30 --> Database Driver Class Initialized
INFO - 2019-07-21 09:47:30 --> Controller Class Initialized
INFO - 2019-07-21 09:47:30 --> Model "Product" initialized
INFO - 2019-07-21 09:47:30 --> Output Class Initialized
INFO - 2019-07-21 09:47:30 --> Final output sent to browser
DEBUG - 2019-07-21 09:47:30 --> Total execution time: 0.0275
INFO - 2019-07-21 09:47:30 --> Security Class Initialized
DEBUG - 2019-07-21 09:47:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:47:30 --> Input Class Initialized
INFO - 2019-07-21 09:47:30 --> Language Class Initialized
INFO - 2019-07-21 09:47:30 --> Loader Class Initialized
INFO - 2019-07-21 09:47:30 --> Database Driver Class Initialized
INFO - 2019-07-21 09:47:30 --> Controller Class Initialized
INFO - 2019-07-21 09:47:30 --> Model "Product" initialized
INFO - 2019-07-21 09:47:30 --> Final output sent to browser
DEBUG - 2019-07-21 09:47:30 --> Total execution time: 0.1153
INFO - 2019-07-21 09:48:13 --> Config Class Initialized
INFO - 2019-07-21 09:48:13 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:48:13 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:48:13 --> Utf8 Class Initialized
INFO - 2019-07-21 09:48:13 --> URI Class Initialized
INFO - 2019-07-21 09:48:13 --> Router Class Initialized
INFO - 2019-07-21 09:48:13 --> Config Class Initialized
INFO - 2019-07-21 09:48:13 --> Hooks Class Initialized
INFO - 2019-07-21 09:48:13 --> Output Class Initialized
INFO - 2019-07-21 09:48:13 --> Security Class Initialized
DEBUG - 2019-07-21 09:48:13 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:48:13 --> Utf8 Class Initialized
INFO - 2019-07-21 09:48:13 --> URI Class Initialized
DEBUG - 2019-07-21 09:48:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:48:13 --> Input Class Initialized
INFO - 2019-07-21 09:48:13 --> Language Class Initialized
INFO - 2019-07-21 09:48:13 --> Router Class Initialized
INFO - 2019-07-21 09:48:13 --> Output Class Initialized
INFO - 2019-07-21 09:48:13 --> Loader Class Initialized
INFO - 2019-07-21 09:48:13 --> Security Class Initialized
DEBUG - 2019-07-21 09:48:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:48:13 --> Input Class Initialized
INFO - 2019-07-21 09:48:13 --> Language Class Initialized
INFO - 2019-07-21 09:48:13 --> Database Driver Class Initialized
INFO - 2019-07-21 09:48:13 --> Controller Class Initialized
INFO - 2019-07-21 09:48:13 --> Model "Product" initialized
INFO - 2019-07-21 09:48:13 --> Loader Class Initialized
INFO - 2019-07-21 09:48:13 --> Final output sent to browser
DEBUG - 2019-07-21 09:48:13 --> Total execution time: 0.0261
INFO - 2019-07-21 09:48:13 --> Database Driver Class Initialized
INFO - 2019-07-21 09:48:13 --> Controller Class Initialized
INFO - 2019-07-21 09:48:13 --> Model "Product" initialized
INFO - 2019-07-21 09:48:13 --> Final output sent to browser
DEBUG - 2019-07-21 09:48:13 --> Total execution time: 0.0333
INFO - 2019-07-21 09:48:44 --> Config Class Initialized
INFO - 2019-07-21 09:48:44 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:48:44 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:48:44 --> Utf8 Class Initialized
INFO - 2019-07-21 09:48:44 --> URI Class Initialized
INFO - 2019-07-21 09:48:44 --> Router Class Initialized
INFO - 2019-07-21 09:48:44 --> Output Class Initialized
INFO - 2019-07-21 09:48:44 --> Security Class Initialized
INFO - 2019-07-21 09:48:44 --> Config Class Initialized
INFO - 2019-07-21 09:48:44 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:48:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:48:44 --> Input Class Initialized
INFO - 2019-07-21 09:48:44 --> Language Class Initialized
DEBUG - 2019-07-21 09:48:44 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:48:44 --> Utf8 Class Initialized
INFO - 2019-07-21 09:48:44 --> Loader Class Initialized
INFO - 2019-07-21 09:48:44 --> Config Class Initialized
INFO - 2019-07-21 09:48:44 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:48:44 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:48:44 --> Utf8 Class Initialized
INFO - 2019-07-21 09:48:44 --> URI Class Initialized
INFO - 2019-07-21 09:48:44 --> Database Driver Class Initialized
INFO - 2019-07-21 09:48:44 --> Router Class Initialized
INFO - 2019-07-21 09:48:44 --> Controller Class Initialized
INFO - 2019-07-21 09:48:44 --> Model "Product" initialized
INFO - 2019-07-21 09:48:44 --> URI Class Initialized
INFO - 2019-07-21 09:48:44 --> Router Class Initialized
INFO - 2019-07-21 09:48:44 --> Output Class Initialized
INFO - 2019-07-21 09:48:44 --> Output Class Initialized
INFO - 2019-07-21 09:48:44 --> Security Class Initialized
DEBUG - 2019-07-21 09:48:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:48:44 --> Input Class Initialized
INFO - 2019-07-21 09:48:44 --> Security Class Initialized
INFO - 2019-07-21 09:48:44 --> Language Class Initialized
DEBUG - 2019-07-21 09:48:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:48:44 --> Input Class Initialized
INFO - 2019-07-21 09:48:44 --> Loader Class Initialized
INFO - 2019-07-21 09:48:44 --> Language Class Initialized
INFO - 2019-07-21 09:48:44 --> Loader Class Initialized
INFO - 2019-07-21 09:48:44 --> Final output sent to browser
DEBUG - 2019-07-21 09:48:44 --> Total execution time: 0.0514
INFO - 2019-07-21 09:48:44 --> Database Driver Class Initialized
INFO - 2019-07-21 09:48:44 --> Controller Class Initialized
INFO - 2019-07-21 09:48:44 --> Database Driver Class Initialized
INFO - 2019-07-21 09:48:44 --> Model "Product" initialized
INFO - 2019-07-21 09:48:44 --> Controller Class Initialized
INFO - 2019-07-21 09:48:44 --> Model "Product" initialized
INFO - 2019-07-21 09:48:44 --> Final output sent to browser
DEBUG - 2019-07-21 09:48:44 --> Total execution time: 0.0496
INFO - 2019-07-21 09:48:44 --> Final output sent to browser
DEBUG - 2019-07-21 09:48:44 --> Total execution time: 0.0966
INFO - 2019-07-21 09:48:48 --> Config Class Initialized
INFO - 2019-07-21 09:48:48 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:48:48 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:48:48 --> Utf8 Class Initialized
INFO - 2019-07-21 09:48:48 --> URI Class Initialized
INFO - 2019-07-21 09:48:48 --> Router Class Initialized
INFO - 2019-07-21 09:48:48 --> Output Class Initialized
INFO - 2019-07-21 09:48:48 --> Security Class Initialized
DEBUG - 2019-07-21 09:48:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:48:48 --> Input Class Initialized
INFO - 2019-07-21 09:48:48 --> Language Class Initialized
INFO - 2019-07-21 09:48:48 --> Loader Class Initialized
INFO - 2019-07-21 09:48:48 --> Database Driver Class Initialized
INFO - 2019-07-21 09:48:48 --> Controller Class Initialized
INFO - 2019-07-21 09:48:48 --> Model "Product" initialized
INFO - 2019-07-21 09:48:48 --> Final output sent to browser
DEBUG - 2019-07-21 09:48:48 --> Total execution time: 0.0217
INFO - 2019-07-21 09:48:50 --> Config Class Initialized
INFO - 2019-07-21 09:48:50 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:48:50 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:48:50 --> Utf8 Class Initialized
INFO - 2019-07-21 09:48:50 --> URI Class Initialized
INFO - 2019-07-21 09:48:50 --> Router Class Initialized
INFO - 2019-07-21 09:48:50 --> Output Class Initialized
INFO - 2019-07-21 09:48:50 --> Security Class Initialized
DEBUG - 2019-07-21 09:48:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:48:50 --> Input Class Initialized
INFO - 2019-07-21 09:48:50 --> Language Class Initialized
INFO - 2019-07-21 09:48:50 --> Loader Class Initialized
INFO - 2019-07-21 09:48:50 --> Database Driver Class Initialized
INFO - 2019-07-21 09:48:50 --> Controller Class Initialized
INFO - 2019-07-21 09:48:50 --> Model "Product" initialized
INFO - 2019-07-21 09:48:50 --> Final output sent to browser
DEBUG - 2019-07-21 09:48:50 --> Total execution time: 0.0180
INFO - 2019-07-21 09:49:06 --> Config Class Initialized
INFO - 2019-07-21 09:49:06 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:49:06 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:49:06 --> Utf8 Class Initialized
INFO - 2019-07-21 09:49:06 --> URI Class Initialized
INFO - 2019-07-21 09:49:06 --> Router Class Initialized
INFO - 2019-07-21 09:49:06 --> Output Class Initialized
INFO - 2019-07-21 09:49:06 --> Security Class Initialized
DEBUG - 2019-07-21 09:49:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:49:06 --> Input Class Initialized
INFO - 2019-07-21 09:49:06 --> Language Class Initialized
INFO - 2019-07-21 09:49:06 --> Loader Class Initialized
INFO - 2019-07-21 09:49:06 --> Config Class Initialized
INFO - 2019-07-21 09:49:06 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:49:06 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:49:06 --> Utf8 Class Initialized
INFO - 2019-07-21 09:49:06 --> URI Class Initialized
INFO - 2019-07-21 09:49:06 --> Router Class Initialized
INFO - 2019-07-21 09:49:06 --> Output Class Initialized
INFO - 2019-07-21 09:49:06 --> Security Class Initialized
INFO - 2019-07-21 09:49:06 --> Database Driver Class Initialized
DEBUG - 2019-07-21 09:49:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:49:06 --> Input Class Initialized
INFO - 2019-07-21 09:49:06 --> Controller Class Initialized
INFO - 2019-07-21 09:49:06 --> Language Class Initialized
INFO - 2019-07-21 09:49:06 --> Model "Product" initialized
INFO - 2019-07-21 09:49:06 --> Final output sent to browser
DEBUG - 2019-07-21 09:49:06 --> Total execution time: 0.0364
INFO - 2019-07-21 09:49:06 --> Loader Class Initialized
INFO - 2019-07-21 09:49:06 --> Database Driver Class Initialized
INFO - 2019-07-21 09:49:06 --> Controller Class Initialized
INFO - 2019-07-21 09:49:06 --> Model "Product" initialized
INFO - 2019-07-21 09:49:06 --> Final output sent to browser
DEBUG - 2019-07-21 09:49:06 --> Total execution time: 0.0357
INFO - 2019-07-21 09:49:27 --> Config Class Initialized
INFO - 2019-07-21 09:49:27 --> Hooks Class Initialized
INFO - 2019-07-21 09:49:27 --> Config Class Initialized
INFO - 2019-07-21 09:49:27 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:49:27 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:49:27 --> Utf8 Class Initialized
INFO - 2019-07-21 09:49:27 --> URI Class Initialized
INFO - 2019-07-21 09:49:27 --> Config Class Initialized
INFO - 2019-07-21 09:49:27 --> Hooks Class Initialized
INFO - 2019-07-21 09:49:27 --> Router Class Initialized
DEBUG - 2019-07-21 09:49:27 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:49:27 --> Output Class Initialized
INFO - 2019-07-21 09:49:27 --> Utf8 Class Initialized
INFO - 2019-07-21 09:49:27 --> URI Class Initialized
INFO - 2019-07-21 09:49:27 --> Security Class Initialized
DEBUG - 2019-07-21 09:49:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:49:27 --> Input Class Initialized
INFO - 2019-07-21 09:49:27 --> Language Class Initialized
INFO - 2019-07-21 09:49:27 --> Router Class Initialized
DEBUG - 2019-07-21 09:49:27 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:49:27 --> Utf8 Class Initialized
INFO - 2019-07-21 09:49:27 --> Loader Class Initialized
INFO - 2019-07-21 09:49:27 --> URI Class Initialized
INFO - 2019-07-21 09:49:27 --> Router Class Initialized
INFO - 2019-07-21 09:49:27 --> Output Class Initialized
INFO - 2019-07-21 09:49:27 --> Security Class Initialized
INFO - 2019-07-21 09:49:27 --> Output Class Initialized
DEBUG - 2019-07-21 09:49:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:49:27 --> Input Class Initialized
INFO - 2019-07-21 09:49:27 --> Language Class Initialized
INFO - 2019-07-21 09:49:27 --> Security Class Initialized
DEBUG - 2019-07-21 09:49:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:49:27 --> Input Class Initialized
INFO - 2019-07-21 09:49:27 --> Loader Class Initialized
INFO - 2019-07-21 09:49:27 --> Language Class Initialized
INFO - 2019-07-21 09:49:27 --> Loader Class Initialized
INFO - 2019-07-21 09:49:27 --> Database Driver Class Initialized
INFO - 2019-07-21 09:49:27 --> Controller Class Initialized
INFO - 2019-07-21 09:49:27 --> Model "Product" initialized
INFO - 2019-07-21 09:49:27 --> Final output sent to browser
DEBUG - 2019-07-21 09:49:27 --> Total execution time: 0.0552
INFO - 2019-07-21 09:49:27 --> Database Driver Class Initialized
INFO - 2019-07-21 09:49:27 --> Controller Class Initialized
INFO - 2019-07-21 09:49:27 --> Model "Product" initialized
INFO - 2019-07-21 09:49:27 --> Final output sent to browser
DEBUG - 2019-07-21 09:49:27 --> Total execution time: 0.0486
INFO - 2019-07-21 09:49:27 --> Database Driver Class Initialized
INFO - 2019-07-21 09:49:27 --> Controller Class Initialized
INFO - 2019-07-21 09:49:27 --> Model "Product" initialized
INFO - 2019-07-21 09:49:27 --> Final output sent to browser
DEBUG - 2019-07-21 09:49:27 --> Total execution time: 0.0540
INFO - 2019-07-21 09:49:38 --> Config Class Initialized
INFO - 2019-07-21 09:49:38 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:49:38 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:49:38 --> Utf8 Class Initialized
INFO - 2019-07-21 09:49:38 --> URI Class Initialized
INFO - 2019-07-21 09:49:38 --> Router Class Initialized
INFO - 2019-07-21 09:49:38 --> Output Class Initialized
INFO - 2019-07-21 09:49:38 --> Security Class Initialized
DEBUG - 2019-07-21 09:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:49:38 --> Input Class Initialized
INFO - 2019-07-21 09:49:38 --> Language Class Initialized
INFO - 2019-07-21 09:49:38 --> Loader Class Initialized
INFO - 2019-07-21 09:49:38 --> Config Class Initialized
INFO - 2019-07-21 09:49:38 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:49:38 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:49:38 --> Utf8 Class Initialized
INFO - 2019-07-21 09:49:38 --> URI Class Initialized
INFO - 2019-07-21 09:49:38 --> Router Class Initialized
INFO - 2019-07-21 09:49:38 --> Output Class Initialized
INFO - 2019-07-21 09:49:38 --> Security Class Initialized
INFO - 2019-07-21 09:49:38 --> Database Driver Class Initialized
DEBUG - 2019-07-21 09:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:49:38 --> Input Class Initialized
INFO - 2019-07-21 09:49:38 --> Language Class Initialized
INFO - 2019-07-21 09:49:38 --> Loader Class Initialized
INFO - 2019-07-21 09:49:38 --> Controller Class Initialized
INFO - 2019-07-21 09:49:38 --> Model "Product" initialized
INFO - 2019-07-21 09:49:38 --> Final output sent to browser
DEBUG - 2019-07-21 09:49:38 --> Total execution time: 0.0426
INFO - 2019-07-21 09:49:38 --> Database Driver Class Initialized
INFO - 2019-07-21 09:49:38 --> Controller Class Initialized
INFO - 2019-07-21 09:49:38 --> Model "Product" initialized
INFO - 2019-07-21 09:49:38 --> Final output sent to browser
DEBUG - 2019-07-21 09:49:38 --> Total execution time: 0.0295
INFO - 2019-07-21 09:49:44 --> Config Class Initialized
INFO - 2019-07-21 09:49:44 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:49:44 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:49:44 --> Utf8 Class Initialized
INFO - 2019-07-21 09:49:44 --> URI Class Initialized
INFO - 2019-07-21 09:49:44 --> Router Class Initialized
INFO - 2019-07-21 09:49:44 --> Output Class Initialized
INFO - 2019-07-21 09:49:44 --> Security Class Initialized
DEBUG - 2019-07-21 09:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:49:44 --> Input Class Initialized
INFO - 2019-07-21 09:49:44 --> Language Class Initialized
INFO - 2019-07-21 09:49:44 --> Loader Class Initialized
INFO - 2019-07-21 09:49:44 --> Database Driver Class Initialized
INFO - 2019-07-21 09:49:44 --> Controller Class Initialized
INFO - 2019-07-21 09:49:44 --> Model "Product" initialized
INFO - 2019-07-21 09:49:44 --> Final output sent to browser
DEBUG - 2019-07-21 09:49:44 --> Total execution time: 0.0465
INFO - 2019-07-21 09:49:46 --> Config Class Initialized
INFO - 2019-07-21 09:49:46 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:49:46 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:49:46 --> Utf8 Class Initialized
INFO - 2019-07-21 09:49:46 --> URI Class Initialized
INFO - 2019-07-21 09:49:46 --> Router Class Initialized
INFO - 2019-07-21 09:49:46 --> Output Class Initialized
INFO - 2019-07-21 09:49:46 --> Security Class Initialized
DEBUG - 2019-07-21 09:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:49:46 --> Input Class Initialized
INFO - 2019-07-21 09:49:46 --> Language Class Initialized
INFO - 2019-07-21 09:49:46 --> Loader Class Initialized
INFO - 2019-07-21 09:49:46 --> Database Driver Class Initialized
INFO - 2019-07-21 09:49:46 --> Controller Class Initialized
INFO - 2019-07-21 09:49:46 --> Model "Product" initialized
INFO - 2019-07-21 09:49:46 --> Final output sent to browser
DEBUG - 2019-07-21 09:49:46 --> Total execution time: 0.0202
INFO - 2019-07-21 09:49:54 --> Config Class Initialized
INFO - 2019-07-21 09:49:54 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:49:54 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:49:54 --> Utf8 Class Initialized
INFO - 2019-07-21 09:49:54 --> URI Class Initialized
INFO - 2019-07-21 09:49:54 --> Router Class Initialized
INFO - 2019-07-21 09:49:54 --> Output Class Initialized
INFO - 2019-07-21 09:49:54 --> Security Class Initialized
DEBUG - 2019-07-21 09:49:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:49:54 --> Input Class Initialized
INFO - 2019-07-21 09:49:54 --> Language Class Initialized
INFO - 2019-07-21 09:49:54 --> Loader Class Initialized
INFO - 2019-07-21 09:49:54 --> Database Driver Class Initialized
INFO - 2019-07-21 09:49:54 --> Controller Class Initialized
INFO - 2019-07-21 09:49:54 --> Model "Product" initialized
INFO - 2019-07-21 09:49:54 --> Final output sent to browser
DEBUG - 2019-07-21 09:49:54 --> Total execution time: 0.0234
INFO - 2019-07-21 09:50:41 --> Config Class Initialized
INFO - 2019-07-21 09:50:41 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:50:41 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:50:41 --> Utf8 Class Initialized
INFO - 2019-07-21 09:50:41 --> URI Class Initialized
INFO - 2019-07-21 09:50:41 --> Router Class Initialized
INFO - 2019-07-21 09:50:41 --> Output Class Initialized
INFO - 2019-07-21 09:50:41 --> Security Class Initialized
DEBUG - 2019-07-21 09:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:50:41 --> Input Class Initialized
INFO - 2019-07-21 09:50:41 --> Language Class Initialized
INFO - 2019-07-21 09:50:41 --> Loader Class Initialized
INFO - 2019-07-21 09:50:41 --> Database Driver Class Initialized
INFO - 2019-07-21 09:50:41 --> Controller Class Initialized
INFO - 2019-07-21 09:50:41 --> Model "Product" initialized
INFO - 2019-07-21 09:50:41 --> Final output sent to browser
DEBUG - 2019-07-21 09:50:41 --> Total execution time: 0.0210
INFO - 2019-07-21 09:52:33 --> Config Class Initialized
INFO - 2019-07-21 09:52:33 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:52:33 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:52:33 --> Utf8 Class Initialized
INFO - 2019-07-21 09:52:33 --> URI Class Initialized
INFO - 2019-07-21 09:52:33 --> Router Class Initialized
INFO - 2019-07-21 09:52:33 --> Output Class Initialized
INFO - 2019-07-21 09:52:33 --> Security Class Initialized
DEBUG - 2019-07-21 09:52:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:52:33 --> Input Class Initialized
INFO - 2019-07-21 09:52:33 --> Language Class Initialized
INFO - 2019-07-21 09:52:33 --> Loader Class Initialized
INFO - 2019-07-21 09:52:33 --> Database Driver Class Initialized
INFO - 2019-07-21 09:52:33 --> Controller Class Initialized
INFO - 2019-07-21 09:52:33 --> Model "Product" initialized
INFO - 2019-07-21 09:52:33 --> Final output sent to browser
DEBUG - 2019-07-21 09:52:33 --> Total execution time: 0.0321
INFO - 2019-07-21 09:52:53 --> Config Class Initialized
INFO - 2019-07-21 09:52:53 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:52:53 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:52:53 --> Utf8 Class Initialized
INFO - 2019-07-21 09:52:53 --> URI Class Initialized
INFO - 2019-07-21 09:52:53 --> Router Class Initialized
INFO - 2019-07-21 09:52:53 --> Output Class Initialized
INFO - 2019-07-21 09:52:53 --> Security Class Initialized
DEBUG - 2019-07-21 09:52:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:52:53 --> Input Class Initialized
INFO - 2019-07-21 09:52:53 --> Language Class Initialized
INFO - 2019-07-21 09:52:53 --> Loader Class Initialized
INFO - 2019-07-21 09:52:53 --> Database Driver Class Initialized
INFO - 2019-07-21 09:52:53 --> Controller Class Initialized
INFO - 2019-07-21 09:52:53 --> Model "Product" initialized
INFO - 2019-07-21 09:52:53 --> Final output sent to browser
DEBUG - 2019-07-21 09:52:53 --> Total execution time: 0.0238
INFO - 2019-07-21 09:53:22 --> Config Class Initialized
INFO - 2019-07-21 09:53:22 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:53:22 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:53:22 --> Utf8 Class Initialized
INFO - 2019-07-21 09:53:22 --> URI Class Initialized
INFO - 2019-07-21 09:53:22 --> Router Class Initialized
INFO - 2019-07-21 09:53:22 --> Output Class Initialized
INFO - 2019-07-21 09:53:22 --> Security Class Initialized
DEBUG - 2019-07-21 09:53:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:53:22 --> Input Class Initialized
INFO - 2019-07-21 09:53:22 --> Language Class Initialized
INFO - 2019-07-21 09:53:22 --> Loader Class Initialized
INFO - 2019-07-21 09:53:22 --> Database Driver Class Initialized
INFO - 2019-07-21 09:53:22 --> Controller Class Initialized
INFO - 2019-07-21 09:53:22 --> Model "Product" initialized
INFO - 2019-07-21 09:53:22 --> Final output sent to browser
DEBUG - 2019-07-21 09:53:22 --> Total execution time: 0.0307
INFO - 2019-07-21 09:53:24 --> Config Class Initialized
INFO - 2019-07-21 09:53:24 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:53:24 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:53:24 --> Utf8 Class Initialized
INFO - 2019-07-21 09:53:24 --> URI Class Initialized
INFO - 2019-07-21 09:53:24 --> Router Class Initialized
INFO - 2019-07-21 09:53:24 --> Output Class Initialized
INFO - 2019-07-21 09:53:24 --> Security Class Initialized
DEBUG - 2019-07-21 09:53:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:53:24 --> Input Class Initialized
INFO - 2019-07-21 09:53:24 --> Language Class Initialized
INFO - 2019-07-21 09:53:24 --> Loader Class Initialized
INFO - 2019-07-21 09:53:24 --> Database Driver Class Initialized
INFO - 2019-07-21 09:53:24 --> Controller Class Initialized
INFO - 2019-07-21 09:53:24 --> Model "Product" initialized
INFO - 2019-07-21 09:53:24 --> Final output sent to browser
DEBUG - 2019-07-21 09:53:24 --> Total execution time: 0.0192
INFO - 2019-07-21 09:53:26 --> Config Class Initialized
INFO - 2019-07-21 09:53:26 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:53:26 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:53:26 --> Utf8 Class Initialized
INFO - 2019-07-21 09:53:26 --> URI Class Initialized
INFO - 2019-07-21 09:53:26 --> Router Class Initialized
INFO - 2019-07-21 09:53:26 --> Output Class Initialized
INFO - 2019-07-21 09:53:26 --> Security Class Initialized
DEBUG - 2019-07-21 09:53:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:53:26 --> Input Class Initialized
INFO - 2019-07-21 09:53:26 --> Language Class Initialized
INFO - 2019-07-21 09:53:26 --> Loader Class Initialized
INFO - 2019-07-21 09:53:26 --> Database Driver Class Initialized
INFO - 2019-07-21 09:53:26 --> Controller Class Initialized
INFO - 2019-07-21 09:53:26 --> Model "Product" initialized
INFO - 2019-07-21 09:53:26 --> Final output sent to browser
DEBUG - 2019-07-21 09:53:26 --> Total execution time: 0.0190
INFO - 2019-07-21 09:53:28 --> Config Class Initialized
INFO - 2019-07-21 09:53:28 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:53:28 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:53:28 --> Utf8 Class Initialized
INFO - 2019-07-21 09:53:28 --> URI Class Initialized
INFO - 2019-07-21 09:53:28 --> Router Class Initialized
INFO - 2019-07-21 09:53:28 --> Output Class Initialized
INFO - 2019-07-21 09:53:28 --> Security Class Initialized
DEBUG - 2019-07-21 09:53:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:53:28 --> Input Class Initialized
INFO - 2019-07-21 09:53:28 --> Language Class Initialized
INFO - 2019-07-21 09:53:28 --> Loader Class Initialized
INFO - 2019-07-21 09:53:28 --> Database Driver Class Initialized
INFO - 2019-07-21 09:53:28 --> Controller Class Initialized
INFO - 2019-07-21 09:53:28 --> Model "Product" initialized
INFO - 2019-07-21 09:53:28 --> Final output sent to browser
DEBUG - 2019-07-21 09:53:28 --> Total execution time: 0.0211
INFO - 2019-07-21 09:53:31 --> Config Class Initialized
INFO - 2019-07-21 09:53:31 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:53:31 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:53:31 --> Utf8 Class Initialized
INFO - 2019-07-21 09:53:31 --> URI Class Initialized
INFO - 2019-07-21 09:53:31 --> Router Class Initialized
INFO - 2019-07-21 09:53:31 --> Output Class Initialized
INFO - 2019-07-21 09:53:31 --> Security Class Initialized
INFO - 2019-07-21 09:53:31 --> Config Class Initialized
INFO - 2019-07-21 09:53:31 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:53:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:53:31 --> Input Class Initialized
INFO - 2019-07-21 09:53:31 --> Language Class Initialized
DEBUG - 2019-07-21 09:53:31 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:53:31 --> Utf8 Class Initialized
INFO - 2019-07-21 09:53:31 --> URI Class Initialized
INFO - 2019-07-21 09:53:31 --> Router Class Initialized
INFO - 2019-07-21 09:53:31 --> Loader Class Initialized
INFO - 2019-07-21 09:53:31 --> Output Class Initialized
INFO - 2019-07-21 09:53:31 --> Security Class Initialized
DEBUG - 2019-07-21 09:53:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:53:31 --> Input Class Initialized
INFO - 2019-07-21 09:53:31 --> Language Class Initialized
INFO - 2019-07-21 09:53:31 --> Loader Class Initialized
INFO - 2019-07-21 09:53:31 --> Database Driver Class Initialized
INFO - 2019-07-21 09:53:31 --> Controller Class Initialized
INFO - 2019-07-21 09:53:31 --> Model "Product" initialized
INFO - 2019-07-21 09:53:31 --> Database Driver Class Initialized
INFO - 2019-07-21 09:53:31 --> Controller Class Initialized
INFO - 2019-07-21 09:53:31 --> Model "Product" initialized
INFO - 2019-07-21 09:53:31 --> Final output sent to browser
DEBUG - 2019-07-21 09:53:31 --> Total execution time: 0.0345
INFO - 2019-07-21 09:53:31 --> Final output sent to browser
DEBUG - 2019-07-21 09:53:31 --> Total execution time: 0.0855
INFO - 2019-07-21 09:53:33 --> Config Class Initialized
INFO - 2019-07-21 09:53:33 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:53:33 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:53:33 --> Utf8 Class Initialized
INFO - 2019-07-21 09:53:33 --> URI Class Initialized
INFO - 2019-07-21 09:53:33 --> Router Class Initialized
INFO - 2019-07-21 09:53:33 --> Output Class Initialized
INFO - 2019-07-21 09:53:33 --> Security Class Initialized
DEBUG - 2019-07-21 09:53:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:53:33 --> Input Class Initialized
INFO - 2019-07-21 09:53:33 --> Language Class Initialized
INFO - 2019-07-21 09:53:33 --> Loader Class Initialized
INFO - 2019-07-21 09:53:33 --> Database Driver Class Initialized
INFO - 2019-07-21 09:53:33 --> Controller Class Initialized
INFO - 2019-07-21 09:53:33 --> Model "Product" initialized
INFO - 2019-07-21 09:53:33 --> Final output sent to browser
DEBUG - 2019-07-21 09:53:33 --> Total execution time: 0.0242
INFO - 2019-07-21 09:53:38 --> Config Class Initialized
INFO - 2019-07-21 09:53:38 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:53:38 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:53:38 --> Utf8 Class Initialized
INFO - 2019-07-21 09:53:38 --> URI Class Initialized
INFO - 2019-07-21 09:53:38 --> Router Class Initialized
INFO - 2019-07-21 09:53:38 --> Output Class Initialized
INFO - 2019-07-21 09:53:38 --> Security Class Initialized
DEBUG - 2019-07-21 09:53:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:53:38 --> Input Class Initialized
INFO - 2019-07-21 09:53:38 --> Language Class Initialized
INFO - 2019-07-21 09:53:38 --> Loader Class Initialized
INFO - 2019-07-21 09:53:38 --> Database Driver Class Initialized
INFO - 2019-07-21 09:53:38 --> Controller Class Initialized
INFO - 2019-07-21 09:53:38 --> Model "Product" initialized
INFO - 2019-07-21 09:53:38 --> Final output sent to browser
DEBUG - 2019-07-21 09:53:38 --> Total execution time: 0.0919
INFO - 2019-07-21 09:53:45 --> Config Class Initialized
INFO - 2019-07-21 09:53:45 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:53:45 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:53:45 --> Utf8 Class Initialized
INFO - 2019-07-21 09:53:45 --> URI Class Initialized
INFO - 2019-07-21 09:53:45 --> Router Class Initialized
INFO - 2019-07-21 09:53:45 --> Output Class Initialized
INFO - 2019-07-21 09:53:45 --> Security Class Initialized
DEBUG - 2019-07-21 09:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:53:45 --> Input Class Initialized
INFO - 2019-07-21 09:53:45 --> Language Class Initialized
INFO - 2019-07-21 09:53:45 --> Loader Class Initialized
INFO - 2019-07-21 09:53:45 --> Database Driver Class Initialized
INFO - 2019-07-21 09:53:45 --> Controller Class Initialized
INFO - 2019-07-21 09:53:45 --> Model "Product" initialized
INFO - 2019-07-21 09:53:45 --> Final output sent to browser
DEBUG - 2019-07-21 09:53:45 --> Total execution time: 0.0194
INFO - 2019-07-21 09:54:02 --> Config Class Initialized
INFO - 2019-07-21 09:54:02 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:54:02 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:54:02 --> Utf8 Class Initialized
INFO - 2019-07-21 09:54:02 --> URI Class Initialized
INFO - 2019-07-21 09:54:02 --> Router Class Initialized
INFO - 2019-07-21 09:54:02 --> Output Class Initialized
INFO - 2019-07-21 09:54:02 --> Security Class Initialized
DEBUG - 2019-07-21 09:54:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:54:02 --> Input Class Initialized
INFO - 2019-07-21 09:54:02 --> Language Class Initialized
INFO - 2019-07-21 09:54:02 --> Loader Class Initialized
INFO - 2019-07-21 09:54:02 --> Database Driver Class Initialized
INFO - 2019-07-21 09:54:02 --> Controller Class Initialized
INFO - 2019-07-21 09:54:02 --> Model "Product" initialized
INFO - 2019-07-21 09:54:02 --> Final output sent to browser
DEBUG - 2019-07-21 09:54:02 --> Total execution time: 0.0291
INFO - 2019-07-21 09:54:02 --> Config Class Initialized
INFO - 2019-07-21 09:54:02 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:54:02 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:54:02 --> Utf8 Class Initialized
INFO - 2019-07-21 09:54:02 --> URI Class Initialized
INFO - 2019-07-21 09:54:02 --> Router Class Initialized
INFO - 2019-07-21 09:54:02 --> Output Class Initialized
INFO - 2019-07-21 09:54:02 --> Security Class Initialized
DEBUG - 2019-07-21 09:54:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:54:02 --> Input Class Initialized
INFO - 2019-07-21 09:54:02 --> Language Class Initialized
INFO - 2019-07-21 09:54:02 --> Loader Class Initialized
INFO - 2019-07-21 09:54:02 --> Database Driver Class Initialized
INFO - 2019-07-21 09:54:02 --> Controller Class Initialized
INFO - 2019-07-21 09:54:02 --> Model "Product" initialized
INFO - 2019-07-21 09:54:02 --> Final output sent to browser
DEBUG - 2019-07-21 09:54:02 --> Total execution time: 0.0390
INFO - 2019-07-21 09:55:07 --> Config Class Initialized
INFO - 2019-07-21 09:55:07 --> Hooks Class Initialized
INFO - 2019-07-21 09:55:07 --> Config Class Initialized
INFO - 2019-07-21 09:55:07 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:55:07 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:55:07 --> Utf8 Class Initialized
DEBUG - 2019-07-21 09:55:07 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:55:07 --> Utf8 Class Initialized
INFO - 2019-07-21 09:55:07 --> URI Class Initialized
INFO - 2019-07-21 09:55:07 --> URI Class Initialized
INFO - 2019-07-21 09:55:07 --> Router Class Initialized
INFO - 2019-07-21 09:55:07 --> Router Class Initialized
INFO - 2019-07-21 09:55:07 --> Output Class Initialized
INFO - 2019-07-21 09:55:07 --> Output Class Initialized
INFO - 2019-07-21 09:55:07 --> Security Class Initialized
INFO - 2019-07-21 09:55:07 --> Security Class Initialized
DEBUG - 2019-07-21 09:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:55:07 --> Input Class Initialized
DEBUG - 2019-07-21 09:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:55:07 --> Input Class Initialized
INFO - 2019-07-21 09:55:07 --> Language Class Initialized
INFO - 2019-07-21 09:55:07 --> Language Class Initialized
INFO - 2019-07-21 09:55:07 --> Loader Class Initialized
INFO - 2019-07-21 09:55:07 --> Loader Class Initialized
INFO - 2019-07-21 09:55:07 --> Database Driver Class Initialized
INFO - 2019-07-21 09:55:07 --> Database Driver Class Initialized
INFO - 2019-07-21 09:55:07 --> Controller Class Initialized
INFO - 2019-07-21 09:55:07 --> Controller Class Initialized
INFO - 2019-07-21 09:55:07 --> Model "Product" initialized
INFO - 2019-07-21 09:55:07 --> Model "Product" initialized
INFO - 2019-07-21 09:55:08 --> Final output sent to browser
DEBUG - 2019-07-21 09:55:08 --> Total execution time: 1.0609
INFO - 2019-07-21 09:55:08 --> Final output sent to browser
DEBUG - 2019-07-21 09:55:08 --> Total execution time: 1.0849
INFO - 2019-07-21 09:56:49 --> Config Class Initialized
INFO - 2019-07-21 09:56:49 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:56:49 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:56:49 --> Utf8 Class Initialized
INFO - 2019-07-21 09:56:49 --> URI Class Initialized
INFO - 2019-07-21 09:56:49 --> Router Class Initialized
INFO - 2019-07-21 09:56:49 --> Output Class Initialized
INFO - 2019-07-21 09:56:49 --> Security Class Initialized
DEBUG - 2019-07-21 09:56:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:56:49 --> Input Class Initialized
INFO - 2019-07-21 09:56:49 --> Language Class Initialized
INFO - 2019-07-21 09:56:50 --> Loader Class Initialized
INFO - 2019-07-21 09:56:50 --> Config Class Initialized
INFO - 2019-07-21 09:56:50 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:56:50 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:56:50 --> Utf8 Class Initialized
INFO - 2019-07-21 09:56:50 --> URI Class Initialized
INFO - 2019-07-21 09:56:50 --> Router Class Initialized
INFO - 2019-07-21 09:56:50 --> Output Class Initialized
INFO - 2019-07-21 09:56:50 --> Database Driver Class Initialized
INFO - 2019-07-21 09:56:50 --> Security Class Initialized
INFO - 2019-07-21 09:56:50 --> Controller Class Initialized
INFO - 2019-07-21 09:56:50 --> Model "Product" initialized
DEBUG - 2019-07-21 09:56:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:56:50 --> Input Class Initialized
INFO - 2019-07-21 09:56:50 --> Language Class Initialized
INFO - 2019-07-21 09:56:50 --> Final output sent to browser
DEBUG - 2019-07-21 09:56:50 --> Total execution time: 0.0294
INFO - 2019-07-21 09:56:50 --> Loader Class Initialized
INFO - 2019-07-21 09:56:50 --> Database Driver Class Initialized
INFO - 2019-07-21 09:56:50 --> Controller Class Initialized
INFO - 2019-07-21 09:56:50 --> Model "Product" initialized
INFO - 2019-07-21 09:56:50 --> Final output sent to browser
DEBUG - 2019-07-21 09:56:50 --> Total execution time: 0.0279
INFO - 2019-07-21 09:56:57 --> Config Class Initialized
INFO - 2019-07-21 09:56:57 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:56:57 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:56:57 --> Utf8 Class Initialized
INFO - 2019-07-21 09:56:57 --> URI Class Initialized
INFO - 2019-07-21 09:56:57 --> Router Class Initialized
INFO - 2019-07-21 09:56:57 --> Output Class Initialized
INFO - 2019-07-21 09:56:57 --> Security Class Initialized
DEBUG - 2019-07-21 09:56:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:56:57 --> Input Class Initialized
INFO - 2019-07-21 09:56:57 --> Language Class Initialized
INFO - 2019-07-21 09:56:57 --> Loader Class Initialized
INFO - 2019-07-21 09:56:57 --> Database Driver Class Initialized
INFO - 2019-07-21 09:56:57 --> Controller Class Initialized
INFO - 2019-07-21 09:56:57 --> Model "Product" initialized
INFO - 2019-07-21 09:56:57 --> Final output sent to browser
DEBUG - 2019-07-21 09:56:57 --> Total execution time: 0.0270
INFO - 2019-07-21 09:56:59 --> Config Class Initialized
INFO - 2019-07-21 09:56:59 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:56:59 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:56:59 --> Utf8 Class Initialized
INFO - 2019-07-21 09:56:59 --> URI Class Initialized
INFO - 2019-07-21 09:56:59 --> Router Class Initialized
INFO - 2019-07-21 09:56:59 --> Output Class Initialized
INFO - 2019-07-21 09:56:59 --> Security Class Initialized
DEBUG - 2019-07-21 09:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:56:59 --> Input Class Initialized
INFO - 2019-07-21 09:56:59 --> Language Class Initialized
INFO - 2019-07-21 09:56:59 --> Loader Class Initialized
INFO - 2019-07-21 09:56:59 --> Database Driver Class Initialized
INFO - 2019-07-21 09:56:59 --> Controller Class Initialized
INFO - 2019-07-21 09:56:59 --> Model "Product" initialized
INFO - 2019-07-21 09:56:59 --> Final output sent to browser
DEBUG - 2019-07-21 09:56:59 --> Total execution time: 0.0226
INFO - 2019-07-21 09:57:44 --> Config Class Initialized
INFO - 2019-07-21 09:57:44 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:57:44 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:57:44 --> Utf8 Class Initialized
INFO - 2019-07-21 09:57:44 --> URI Class Initialized
INFO - 2019-07-21 09:57:44 --> Router Class Initialized
INFO - 2019-07-21 09:57:44 --> Config Class Initialized
INFO - 2019-07-21 09:57:44 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:57:44 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:57:44 --> Utf8 Class Initialized
INFO - 2019-07-21 09:57:44 --> URI Class Initialized
INFO - 2019-07-21 09:57:44 --> Router Class Initialized
INFO - 2019-07-21 09:57:44 --> Output Class Initialized
INFO - 2019-07-21 09:57:44 --> Security Class Initialized
DEBUG - 2019-07-21 09:57:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:57:44 --> Input Class Initialized
INFO - 2019-07-21 09:57:44 --> Language Class Initialized
INFO - 2019-07-21 09:57:44 --> Output Class Initialized
INFO - 2019-07-21 09:57:44 --> Security Class Initialized
DEBUG - 2019-07-21 09:57:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:57:44 --> Input Class Initialized
INFO - 2019-07-21 09:57:44 --> Language Class Initialized
INFO - 2019-07-21 09:57:44 --> Loader Class Initialized
INFO - 2019-07-21 09:57:44 --> Loader Class Initialized
INFO - 2019-07-21 09:57:44 --> Database Driver Class Initialized
INFO - 2019-07-21 09:57:44 --> Database Driver Class Initialized
INFO - 2019-07-21 09:57:44 --> Controller Class Initialized
INFO - 2019-07-21 09:57:44 --> Model "Product" initialized
INFO - 2019-07-21 09:57:44 --> Controller Class Initialized
INFO - 2019-07-21 09:57:44 --> Model "Product" initialized
INFO - 2019-07-21 09:57:44 --> Final output sent to browser
DEBUG - 2019-07-21 09:57:44 --> Total execution time: 0.0595
INFO - 2019-07-21 09:57:44 --> Final output sent to browser
DEBUG - 2019-07-21 09:57:44 --> Total execution time: 0.0497
INFO - 2019-07-21 09:58:10 --> Config Class Initialized
INFO - 2019-07-21 09:58:10 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:58:10 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:58:10 --> Utf8 Class Initialized
INFO - 2019-07-21 09:58:10 --> URI Class Initialized
INFO - 2019-07-21 09:58:10 --> Router Class Initialized
INFO - 2019-07-21 09:58:10 --> Output Class Initialized
INFO - 2019-07-21 09:58:10 --> Security Class Initialized
DEBUG - 2019-07-21 09:58:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:58:10 --> Input Class Initialized
INFO - 2019-07-21 09:58:10 --> Language Class Initialized
INFO - 2019-07-21 09:58:10 --> Loader Class Initialized
INFO - 2019-07-21 09:58:10 --> Config Class Initialized
INFO - 2019-07-21 09:58:10 --> Hooks Class Initialized
INFO - 2019-07-21 09:58:10 --> Database Driver Class Initialized
INFO - 2019-07-21 09:58:10 --> Controller Class Initialized
INFO - 2019-07-21 09:58:10 --> Model "Product" initialized
DEBUG - 2019-07-21 09:58:10 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:58:10 --> Utf8 Class Initialized
INFO - 2019-07-21 09:58:10 --> Final output sent to browser
DEBUG - 2019-07-21 09:58:10 --> Total execution time: 0.0270
INFO - 2019-07-21 09:58:10 --> URI Class Initialized
INFO - 2019-07-21 09:58:10 --> Router Class Initialized
INFO - 2019-07-21 09:58:10 --> Output Class Initialized
INFO - 2019-07-21 09:58:10 --> Security Class Initialized
DEBUG - 2019-07-21 09:58:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:58:10 --> Input Class Initialized
INFO - 2019-07-21 09:58:10 --> Language Class Initialized
INFO - 2019-07-21 09:58:10 --> Loader Class Initialized
INFO - 2019-07-21 09:58:10 --> Database Driver Class Initialized
INFO - 2019-07-21 09:58:10 --> Controller Class Initialized
INFO - 2019-07-21 09:58:10 --> Model "Product" initialized
INFO - 2019-07-21 09:58:10 --> Final output sent to browser
DEBUG - 2019-07-21 09:58:10 --> Total execution time: 0.0437
INFO - 2019-07-21 09:58:12 --> Config Class Initialized
INFO - 2019-07-21 09:58:12 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:58:12 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:58:12 --> Utf8 Class Initialized
INFO - 2019-07-21 09:58:12 --> URI Class Initialized
INFO - 2019-07-21 09:58:12 --> Router Class Initialized
INFO - 2019-07-21 09:58:12 --> Output Class Initialized
INFO - 2019-07-21 09:58:12 --> Security Class Initialized
DEBUG - 2019-07-21 09:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:58:12 --> Input Class Initialized
INFO - 2019-07-21 09:58:12 --> Language Class Initialized
INFO - 2019-07-21 09:58:12 --> Loader Class Initialized
INFO - 2019-07-21 09:58:12 --> Database Driver Class Initialized
INFO - 2019-07-21 09:58:12 --> Controller Class Initialized
INFO - 2019-07-21 09:58:12 --> Model "Product" initialized
INFO - 2019-07-21 09:58:12 --> Final output sent to browser
DEBUG - 2019-07-21 09:58:12 --> Total execution time: 0.0205
INFO - 2019-07-21 09:58:14 --> Config Class Initialized
INFO - 2019-07-21 09:58:14 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:58:14 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:58:14 --> Utf8 Class Initialized
INFO - 2019-07-21 09:58:14 --> URI Class Initialized
INFO - 2019-07-21 09:58:14 --> Router Class Initialized
INFO - 2019-07-21 09:58:14 --> Output Class Initialized
INFO - 2019-07-21 09:58:14 --> Security Class Initialized
DEBUG - 2019-07-21 09:58:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:58:14 --> Input Class Initialized
INFO - 2019-07-21 09:58:14 --> Language Class Initialized
INFO - 2019-07-21 09:58:14 --> Loader Class Initialized
INFO - 2019-07-21 09:58:14 --> Database Driver Class Initialized
INFO - 2019-07-21 09:58:14 --> Controller Class Initialized
INFO - 2019-07-21 09:58:14 --> Model "Product" initialized
INFO - 2019-07-21 09:58:14 --> Final output sent to browser
DEBUG - 2019-07-21 09:58:14 --> Total execution time: 0.0198
INFO - 2019-07-21 09:58:15 --> Config Class Initialized
INFO - 2019-07-21 09:58:15 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:58:15 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:58:15 --> Utf8 Class Initialized
INFO - 2019-07-21 09:58:15 --> URI Class Initialized
INFO - 2019-07-21 09:58:15 --> Router Class Initialized
INFO - 2019-07-21 09:58:15 --> Output Class Initialized
INFO - 2019-07-21 09:58:15 --> Security Class Initialized
DEBUG - 2019-07-21 09:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:58:15 --> Input Class Initialized
INFO - 2019-07-21 09:58:15 --> Language Class Initialized
INFO - 2019-07-21 09:58:15 --> Loader Class Initialized
INFO - 2019-07-21 09:58:15 --> Database Driver Class Initialized
INFO - 2019-07-21 09:58:15 --> Controller Class Initialized
INFO - 2019-07-21 09:58:15 --> Model "Product" initialized
INFO - 2019-07-21 09:58:15 --> Final output sent to browser
DEBUG - 2019-07-21 09:58:15 --> Total execution time: 0.0192
INFO - 2019-07-21 09:58:16 --> Config Class Initialized
INFO - 2019-07-21 09:58:16 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:58:16 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:58:16 --> Utf8 Class Initialized
INFO - 2019-07-21 09:58:16 --> URI Class Initialized
INFO - 2019-07-21 09:58:16 --> Router Class Initialized
INFO - 2019-07-21 09:58:16 --> Output Class Initialized
INFO - 2019-07-21 09:58:16 --> Security Class Initialized
DEBUG - 2019-07-21 09:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:58:16 --> Input Class Initialized
INFO - 2019-07-21 09:58:16 --> Language Class Initialized
INFO - 2019-07-21 09:58:16 --> Loader Class Initialized
INFO - 2019-07-21 09:58:16 --> Database Driver Class Initialized
INFO - 2019-07-21 09:58:16 --> Controller Class Initialized
INFO - 2019-07-21 09:58:16 --> Model "Product" initialized
INFO - 2019-07-21 09:58:16 --> Final output sent to browser
DEBUG - 2019-07-21 09:58:16 --> Total execution time: 0.0245
INFO - 2019-07-21 09:58:17 --> Config Class Initialized
INFO - 2019-07-21 09:58:17 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:58:17 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:58:17 --> Utf8 Class Initialized
INFO - 2019-07-21 09:58:17 --> URI Class Initialized
INFO - 2019-07-21 09:58:17 --> Router Class Initialized
INFO - 2019-07-21 09:58:17 --> Output Class Initialized
INFO - 2019-07-21 09:58:17 --> Security Class Initialized
DEBUG - 2019-07-21 09:58:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:58:17 --> Input Class Initialized
INFO - 2019-07-21 09:58:17 --> Language Class Initialized
INFO - 2019-07-21 09:58:17 --> Loader Class Initialized
INFO - 2019-07-21 09:58:17 --> Database Driver Class Initialized
INFO - 2019-07-21 09:58:17 --> Controller Class Initialized
INFO - 2019-07-21 09:58:17 --> Model "Product" initialized
INFO - 2019-07-21 09:58:17 --> Final output sent to browser
DEBUG - 2019-07-21 09:58:17 --> Total execution time: 0.0208
INFO - 2019-07-21 09:58:18 --> Config Class Initialized
INFO - 2019-07-21 09:58:18 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:58:18 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:58:18 --> Utf8 Class Initialized
INFO - 2019-07-21 09:58:18 --> URI Class Initialized
INFO - 2019-07-21 09:58:18 --> Router Class Initialized
INFO - 2019-07-21 09:58:18 --> Output Class Initialized
INFO - 2019-07-21 09:58:18 --> Security Class Initialized
DEBUG - 2019-07-21 09:58:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:58:18 --> Input Class Initialized
INFO - 2019-07-21 09:58:18 --> Language Class Initialized
INFO - 2019-07-21 09:58:18 --> Loader Class Initialized
INFO - 2019-07-21 09:58:18 --> Database Driver Class Initialized
INFO - 2019-07-21 09:58:18 --> Controller Class Initialized
INFO - 2019-07-21 09:58:18 --> Model "Product" initialized
INFO - 2019-07-21 09:58:18 --> Final output sent to browser
DEBUG - 2019-07-21 09:58:18 --> Total execution time: 0.0220
INFO - 2019-07-21 09:58:19 --> Config Class Initialized
INFO - 2019-07-21 09:58:19 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:58:19 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:58:19 --> Utf8 Class Initialized
INFO - 2019-07-21 09:58:19 --> URI Class Initialized
INFO - 2019-07-21 09:58:19 --> Router Class Initialized
INFO - 2019-07-21 09:58:19 --> Output Class Initialized
INFO - 2019-07-21 09:58:19 --> Security Class Initialized
DEBUG - 2019-07-21 09:58:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:58:19 --> Input Class Initialized
INFO - 2019-07-21 09:58:19 --> Language Class Initialized
INFO - 2019-07-21 09:58:19 --> Loader Class Initialized
INFO - 2019-07-21 09:58:19 --> Database Driver Class Initialized
INFO - 2019-07-21 09:58:19 --> Controller Class Initialized
INFO - 2019-07-21 09:58:19 --> Model "Product" initialized
INFO - 2019-07-21 09:58:19 --> Final output sent to browser
DEBUG - 2019-07-21 09:58:19 --> Total execution time: 0.0182
INFO - 2019-07-21 09:58:19 --> Config Class Initialized
INFO - 2019-07-21 09:58:19 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:58:19 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:58:19 --> Utf8 Class Initialized
INFO - 2019-07-21 09:58:19 --> URI Class Initialized
INFO - 2019-07-21 09:58:19 --> Router Class Initialized
INFO - 2019-07-21 09:58:19 --> Output Class Initialized
INFO - 2019-07-21 09:58:19 --> Security Class Initialized
DEBUG - 2019-07-21 09:58:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:58:19 --> Input Class Initialized
INFO - 2019-07-21 09:58:19 --> Language Class Initialized
INFO - 2019-07-21 09:58:19 --> Loader Class Initialized
INFO - 2019-07-21 09:58:19 --> Database Driver Class Initialized
INFO - 2019-07-21 09:58:19 --> Controller Class Initialized
INFO - 2019-07-21 09:58:19 --> Model "Product" initialized
INFO - 2019-07-21 09:58:19 --> Final output sent to browser
DEBUG - 2019-07-21 09:58:19 --> Total execution time: 0.0201
INFO - 2019-07-21 09:58:20 --> Config Class Initialized
INFO - 2019-07-21 09:58:20 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:58:20 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:58:20 --> Utf8 Class Initialized
INFO - 2019-07-21 09:58:20 --> URI Class Initialized
INFO - 2019-07-21 09:58:20 --> Router Class Initialized
INFO - 2019-07-21 09:58:20 --> Output Class Initialized
INFO - 2019-07-21 09:58:20 --> Security Class Initialized
DEBUG - 2019-07-21 09:58:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:58:20 --> Input Class Initialized
INFO - 2019-07-21 09:58:20 --> Language Class Initialized
INFO - 2019-07-21 09:58:20 --> Loader Class Initialized
INFO - 2019-07-21 09:58:20 --> Database Driver Class Initialized
INFO - 2019-07-21 09:58:20 --> Controller Class Initialized
INFO - 2019-07-21 09:58:20 --> Model "Product" initialized
INFO - 2019-07-21 09:58:20 --> Final output sent to browser
DEBUG - 2019-07-21 09:58:20 --> Total execution time: 0.0206
INFO - 2019-07-21 09:58:22 --> Config Class Initialized
INFO - 2019-07-21 09:58:22 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:58:22 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:58:22 --> Utf8 Class Initialized
INFO - 2019-07-21 09:58:22 --> URI Class Initialized
INFO - 2019-07-21 09:58:22 --> Router Class Initialized
INFO - 2019-07-21 09:58:22 --> Output Class Initialized
INFO - 2019-07-21 09:58:22 --> Security Class Initialized
DEBUG - 2019-07-21 09:58:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:58:22 --> Input Class Initialized
INFO - 2019-07-21 09:58:22 --> Language Class Initialized
INFO - 2019-07-21 09:58:22 --> Loader Class Initialized
INFO - 2019-07-21 09:58:22 --> Database Driver Class Initialized
INFO - 2019-07-21 09:58:22 --> Controller Class Initialized
INFO - 2019-07-21 09:58:22 --> Model "Product" initialized
INFO - 2019-07-21 09:58:22 --> Final output sent to browser
DEBUG - 2019-07-21 09:58:22 --> Total execution time: 0.0212
INFO - 2019-07-21 09:58:33 --> Config Class Initialized
INFO - 2019-07-21 09:58:33 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:58:33 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:58:33 --> Utf8 Class Initialized
INFO - 2019-07-21 09:58:33 --> URI Class Initialized
INFO - 2019-07-21 09:58:33 --> Router Class Initialized
INFO - 2019-07-21 09:58:33 --> Output Class Initialized
INFO - 2019-07-21 09:58:33 --> Security Class Initialized
DEBUG - 2019-07-21 09:58:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:58:33 --> Input Class Initialized
INFO - 2019-07-21 09:58:33 --> Language Class Initialized
INFO - 2019-07-21 09:58:33 --> Loader Class Initialized
INFO - 2019-07-21 09:58:33 --> Database Driver Class Initialized
INFO - 2019-07-21 09:58:33 --> Controller Class Initialized
INFO - 2019-07-21 09:58:33 --> Model "Product" initialized
INFO - 2019-07-21 09:58:33 --> Final output sent to browser
DEBUG - 2019-07-21 09:58:33 --> Total execution time: 0.0221
INFO - 2019-07-21 09:58:35 --> Config Class Initialized
INFO - 2019-07-21 09:58:35 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:58:35 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:58:35 --> Utf8 Class Initialized
INFO - 2019-07-21 09:58:35 --> URI Class Initialized
INFO - 2019-07-21 09:58:35 --> Router Class Initialized
INFO - 2019-07-21 09:58:35 --> Output Class Initialized
INFO - 2019-07-21 09:58:35 --> Security Class Initialized
DEBUG - 2019-07-21 09:58:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:58:35 --> Input Class Initialized
INFO - 2019-07-21 09:58:35 --> Language Class Initialized
INFO - 2019-07-21 09:58:35 --> Loader Class Initialized
INFO - 2019-07-21 09:58:35 --> Database Driver Class Initialized
INFO - 2019-07-21 09:58:35 --> Controller Class Initialized
INFO - 2019-07-21 09:58:35 --> Model "Product" initialized
INFO - 2019-07-21 09:58:35 --> Final output sent to browser
DEBUG - 2019-07-21 09:58:35 --> Total execution time: 0.0202
INFO - 2019-07-21 09:59:09 --> Config Class Initialized
INFO - 2019-07-21 09:59:09 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:59:09 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:59:09 --> Utf8 Class Initialized
INFO - 2019-07-21 09:59:09 --> Config Class Initialized
INFO - 2019-07-21 09:59:09 --> Hooks Class Initialized
INFO - 2019-07-21 09:59:09 --> URI Class Initialized
INFO - 2019-07-21 09:59:09 --> Router Class Initialized
INFO - 2019-07-21 09:59:09 --> Output Class Initialized
DEBUG - 2019-07-21 09:59:09 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:59:09 --> Utf8 Class Initialized
INFO - 2019-07-21 09:59:09 --> URI Class Initialized
INFO - 2019-07-21 09:59:09 --> Security Class Initialized
DEBUG - 2019-07-21 09:59:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:59:09 --> Router Class Initialized
INFO - 2019-07-21 09:59:09 --> Input Class Initialized
INFO - 2019-07-21 09:59:09 --> Language Class Initialized
INFO - 2019-07-21 09:59:09 --> Output Class Initialized
INFO - 2019-07-21 09:59:09 --> Security Class Initialized
INFO - 2019-07-21 09:59:09 --> Loader Class Initialized
DEBUG - 2019-07-21 09:59:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:59:09 --> Input Class Initialized
INFO - 2019-07-21 09:59:09 --> Language Class Initialized
INFO - 2019-07-21 09:59:09 --> Loader Class Initialized
INFO - 2019-07-21 09:59:09 --> Database Driver Class Initialized
INFO - 2019-07-21 09:59:09 --> Controller Class Initialized
INFO - 2019-07-21 09:59:09 --> Model "Product" initialized
INFO - 2019-07-21 09:59:09 --> Final output sent to browser
DEBUG - 2019-07-21 09:59:09 --> Total execution time: 0.0361
INFO - 2019-07-21 09:59:09 --> Database Driver Class Initialized
INFO - 2019-07-21 09:59:09 --> Controller Class Initialized
INFO - 2019-07-21 09:59:09 --> Model "Product" initialized
INFO - 2019-07-21 09:59:09 --> Final output sent to browser
DEBUG - 2019-07-21 09:59:09 --> Total execution time: 0.0510
INFO - 2019-07-21 09:59:31 --> Config Class Initialized
INFO - 2019-07-21 09:59:31 --> Hooks Class Initialized
DEBUG - 2019-07-21 09:59:31 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:59:31 --> Utf8 Class Initialized
INFO - 2019-07-21 09:59:31 --> URI Class Initialized
INFO - 2019-07-21 09:59:31 --> Router Class Initialized
INFO - 2019-07-21 09:59:31 --> Config Class Initialized
INFO - 2019-07-21 09:59:31 --> Hooks Class Initialized
INFO - 2019-07-21 09:59:31 --> Output Class Initialized
DEBUG - 2019-07-21 09:59:31 --> UTF-8 Support Enabled
INFO - 2019-07-21 09:59:31 --> Security Class Initialized
INFO - 2019-07-21 09:59:31 --> Utf8 Class Initialized
INFO - 2019-07-21 09:59:31 --> URI Class Initialized
INFO - 2019-07-21 09:59:31 --> Router Class Initialized
DEBUG - 2019-07-21 09:59:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:59:31 --> Input Class Initialized
INFO - 2019-07-21 09:59:31 --> Language Class Initialized
INFO - 2019-07-21 09:59:31 --> Loader Class Initialized
INFO - 2019-07-21 09:59:31 --> Output Class Initialized
INFO - 2019-07-21 09:59:31 --> Security Class Initialized
DEBUG - 2019-07-21 09:59:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 09:59:31 --> Input Class Initialized
INFO - 2019-07-21 09:59:31 --> Language Class Initialized
INFO - 2019-07-21 09:59:31 --> Loader Class Initialized
INFO - 2019-07-21 09:59:31 --> Database Driver Class Initialized
INFO - 2019-07-21 09:59:31 --> Controller Class Initialized
INFO - 2019-07-21 09:59:31 --> Model "Product" initialized
INFO - 2019-07-21 09:59:31 --> Final output sent to browser
DEBUG - 2019-07-21 09:59:31 --> Total execution time: 0.0267
INFO - 2019-07-21 09:59:31 --> Database Driver Class Initialized
INFO - 2019-07-21 09:59:31 --> Controller Class Initialized
INFO - 2019-07-21 09:59:31 --> Model "Product" initialized
INFO - 2019-07-21 09:59:31 --> Final output sent to browser
DEBUG - 2019-07-21 09:59:31 --> Total execution time: 0.0275
INFO - 2019-07-21 10:00:19 --> Config Class Initialized
INFO - 2019-07-21 10:00:19 --> Hooks Class Initialized
DEBUG - 2019-07-21 10:00:19 --> UTF-8 Support Enabled
INFO - 2019-07-21 10:00:19 --> Utf8 Class Initialized
INFO - 2019-07-21 10:00:19 --> URI Class Initialized
INFO - 2019-07-21 10:00:19 --> Config Class Initialized
INFO - 2019-07-21 10:00:19 --> Hooks Class Initialized
INFO - 2019-07-21 10:00:19 --> Router Class Initialized
DEBUG - 2019-07-21 10:00:19 --> UTF-8 Support Enabled
INFO - 2019-07-21 10:00:19 --> Utf8 Class Initialized
INFO - 2019-07-21 10:00:19 --> Output Class Initialized
INFO - 2019-07-21 10:00:19 --> URI Class Initialized
INFO - 2019-07-21 10:00:19 --> Security Class Initialized
DEBUG - 2019-07-21 10:00:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 10:00:19 --> Input Class Initialized
INFO - 2019-07-21 10:00:19 --> Language Class Initialized
INFO - 2019-07-21 10:00:19 --> Router Class Initialized
INFO - 2019-07-21 10:00:19 --> Loader Class Initialized
INFO - 2019-07-21 10:00:19 --> Output Class Initialized
INFO - 2019-07-21 10:00:19 --> Security Class Initialized
INFO - 2019-07-21 10:00:19 --> Database Driver Class Initialized
DEBUG - 2019-07-21 10:00:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 10:00:19 --> Input Class Initialized
INFO - 2019-07-21 10:00:19 --> Controller Class Initialized
INFO - 2019-07-21 10:00:19 --> Model "Product" initialized
INFO - 2019-07-21 10:00:19 --> Final output sent to browser
DEBUG - 2019-07-21 10:00:19 --> Total execution time: 0.0272
INFO - 2019-07-21 10:00:19 --> Language Class Initialized
INFO - 2019-07-21 10:00:19 --> Loader Class Initialized
INFO - 2019-07-21 10:00:19 --> Database Driver Class Initialized
INFO - 2019-07-21 10:00:19 --> Controller Class Initialized
INFO - 2019-07-21 10:00:19 --> Model "Product" initialized
INFO - 2019-07-21 10:00:19 --> Final output sent to browser
DEBUG - 2019-07-21 10:00:19 --> Total execution time: 0.0450
INFO - 2019-07-21 10:00:51 --> Config Class Initialized
INFO - 2019-07-21 10:00:51 --> Hooks Class Initialized
DEBUG - 2019-07-21 10:00:51 --> UTF-8 Support Enabled
INFO - 2019-07-21 10:00:51 --> Utf8 Class Initialized
INFO - 2019-07-21 10:00:51 --> URI Class Initialized
INFO - 2019-07-21 10:00:51 --> Router Class Initialized
INFO - 2019-07-21 10:00:51 --> Output Class Initialized
INFO - 2019-07-21 10:00:51 --> Security Class Initialized
DEBUG - 2019-07-21 10:00:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 10:00:51 --> Input Class Initialized
INFO - 2019-07-21 10:00:51 --> Language Class Initialized
INFO - 2019-07-21 10:00:51 --> Config Class Initialized
INFO - 2019-07-21 10:00:51 --> Hooks Class Initialized
INFO - 2019-07-21 10:00:51 --> Loader Class Initialized
DEBUG - 2019-07-21 10:00:51 --> UTF-8 Support Enabled
INFO - 2019-07-21 10:00:51 --> Utf8 Class Initialized
INFO - 2019-07-21 10:00:51 --> URI Class Initialized
INFO - 2019-07-21 10:00:51 --> Database Driver Class Initialized
INFO - 2019-07-21 10:00:51 --> Router Class Initialized
INFO - 2019-07-21 10:00:51 --> Controller Class Initialized
INFO - 2019-07-21 10:00:51 --> Model "Product" initialized
INFO - 2019-07-21 10:00:51 --> Final output sent to browser
DEBUG - 2019-07-21 10:00:51 --> Total execution time: 0.0234
INFO - 2019-07-21 10:00:51 --> Output Class Initialized
INFO - 2019-07-21 10:00:51 --> Security Class Initialized
DEBUG - 2019-07-21 10:00:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 10:00:51 --> Input Class Initialized
INFO - 2019-07-21 10:00:51 --> Language Class Initialized
INFO - 2019-07-21 10:00:51 --> Loader Class Initialized
INFO - 2019-07-21 10:00:51 --> Database Driver Class Initialized
INFO - 2019-07-21 10:00:51 --> Controller Class Initialized
INFO - 2019-07-21 10:00:51 --> Model "Product" initialized
INFO - 2019-07-21 10:00:51 --> Final output sent to browser
DEBUG - 2019-07-21 10:00:51 --> Total execution time: 0.0363
INFO - 2019-07-21 10:00:55 --> Config Class Initialized
INFO - 2019-07-21 10:00:55 --> Hooks Class Initialized
DEBUG - 2019-07-21 10:00:55 --> UTF-8 Support Enabled
INFO - 2019-07-21 10:00:55 --> Utf8 Class Initialized
INFO - 2019-07-21 10:00:55 --> URI Class Initialized
INFO - 2019-07-21 10:00:55 --> Router Class Initialized
INFO - 2019-07-21 10:00:55 --> Output Class Initialized
INFO - 2019-07-21 10:00:55 --> Security Class Initialized
DEBUG - 2019-07-21 10:00:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 10:00:55 --> Input Class Initialized
INFO - 2019-07-21 10:00:55 --> Language Class Initialized
INFO - 2019-07-21 10:00:55 --> Loader Class Initialized
INFO - 2019-07-21 10:00:55 --> Database Driver Class Initialized
INFO - 2019-07-21 10:00:55 --> Controller Class Initialized
INFO - 2019-07-21 10:00:55 --> Model "Product" initialized
INFO - 2019-07-21 10:00:55 --> Final output sent to browser
DEBUG - 2019-07-21 10:00:55 --> Total execution time: 0.0211
INFO - 2019-07-21 10:00:56 --> Config Class Initialized
INFO - 2019-07-21 10:00:56 --> Hooks Class Initialized
DEBUG - 2019-07-21 10:00:56 --> UTF-8 Support Enabled
INFO - 2019-07-21 10:00:56 --> Utf8 Class Initialized
INFO - 2019-07-21 10:00:56 --> URI Class Initialized
INFO - 2019-07-21 10:00:56 --> Router Class Initialized
INFO - 2019-07-21 10:00:56 --> Output Class Initialized
INFO - 2019-07-21 10:00:56 --> Security Class Initialized
DEBUG - 2019-07-21 10:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 10:00:56 --> Input Class Initialized
INFO - 2019-07-21 10:00:56 --> Language Class Initialized
INFO - 2019-07-21 10:00:56 --> Loader Class Initialized
INFO - 2019-07-21 10:00:56 --> Database Driver Class Initialized
INFO - 2019-07-21 10:00:56 --> Controller Class Initialized
INFO - 2019-07-21 10:00:56 --> Model "Product" initialized
INFO - 2019-07-21 10:00:56 --> Final output sent to browser
DEBUG - 2019-07-21 10:00:56 --> Total execution time: 0.0216
INFO - 2019-07-21 10:01:27 --> Config Class Initialized
INFO - 2019-07-21 10:01:27 --> Hooks Class Initialized
DEBUG - 2019-07-21 10:01:27 --> UTF-8 Support Enabled
INFO - 2019-07-21 10:01:27 --> Utf8 Class Initialized
INFO - 2019-07-21 10:01:27 --> URI Class Initialized
INFO - 2019-07-21 10:01:27 --> Router Class Initialized
INFO - 2019-07-21 10:01:27 --> Output Class Initialized
INFO - 2019-07-21 10:01:27 --> Security Class Initialized
DEBUG - 2019-07-21 10:01:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 10:01:27 --> Input Class Initialized
INFO - 2019-07-21 10:01:27 --> Language Class Initialized
INFO - 2019-07-21 10:01:27 --> Loader Class Initialized
INFO - 2019-07-21 10:01:27 --> Config Class Initialized
INFO - 2019-07-21 10:01:27 --> Hooks Class Initialized
DEBUG - 2019-07-21 10:01:27 --> UTF-8 Support Enabled
INFO - 2019-07-21 10:01:27 --> Utf8 Class Initialized
INFO - 2019-07-21 10:01:27 --> URI Class Initialized
INFO - 2019-07-21 10:01:27 --> Router Class Initialized
INFO - 2019-07-21 10:01:27 --> Database Driver Class Initialized
INFO - 2019-07-21 10:01:27 --> Output Class Initialized
INFO - 2019-07-21 10:01:27 --> Controller Class Initialized
INFO - 2019-07-21 10:01:27 --> Model "Product" initialized
INFO - 2019-07-21 10:01:27 --> Security Class Initialized
DEBUG - 2019-07-21 10:01:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 10:01:27 --> Input Class Initialized
INFO - 2019-07-21 10:01:27 --> Final output sent to browser
DEBUG - 2019-07-21 10:01:27 --> Total execution time: 0.0287
INFO - 2019-07-21 10:01:27 --> Language Class Initialized
INFO - 2019-07-21 10:01:27 --> Loader Class Initialized
INFO - 2019-07-21 10:01:27 --> Database Driver Class Initialized
INFO - 2019-07-21 10:01:27 --> Controller Class Initialized
INFO - 2019-07-21 10:01:27 --> Model "Product" initialized
INFO - 2019-07-21 10:01:27 --> Final output sent to browser
DEBUG - 2019-07-21 10:01:27 --> Total execution time: 0.0390
INFO - 2019-07-21 10:01:41 --> Config Class Initialized
INFO - 2019-07-21 10:01:41 --> Hooks Class Initialized
INFO - 2019-07-21 10:01:41 --> Config Class Initialized
INFO - 2019-07-21 10:01:41 --> Hooks Class Initialized
DEBUG - 2019-07-21 10:01:41 --> UTF-8 Support Enabled
INFO - 2019-07-21 10:01:41 --> Utf8 Class Initialized
DEBUG - 2019-07-21 10:01:41 --> UTF-8 Support Enabled
INFO - 2019-07-21 10:01:41 --> Utf8 Class Initialized
INFO - 2019-07-21 10:01:41 --> URI Class Initialized
INFO - 2019-07-21 10:01:41 --> URI Class Initialized
INFO - 2019-07-21 10:01:41 --> Router Class Initialized
INFO - 2019-07-21 10:01:41 --> Router Class Initialized
INFO - 2019-07-21 10:01:41 --> Output Class Initialized
INFO - 2019-07-21 10:01:41 --> Output Class Initialized
INFO - 2019-07-21 10:01:41 --> Security Class Initialized
DEBUG - 2019-07-21 10:01:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 10:01:41 --> Input Class Initialized
INFO - 2019-07-21 10:01:41 --> Language Class Initialized
INFO - 2019-07-21 10:01:41 --> Loader Class Initialized
INFO - 2019-07-21 10:01:41 --> Security Class Initialized
DEBUG - 2019-07-21 10:01:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 10:01:41 --> Input Class Initialized
INFO - 2019-07-21 10:01:41 --> Language Class Initialized
INFO - 2019-07-21 10:01:41 --> Database Driver Class Initialized
INFO - 2019-07-21 10:01:41 --> Controller Class Initialized
INFO - 2019-07-21 10:01:41 --> Model "Product" initialized
INFO - 2019-07-21 10:01:41 --> Final output sent to browser
DEBUG - 2019-07-21 10:01:41 --> Total execution time: 0.0293
INFO - 2019-07-21 10:01:41 --> Loader Class Initialized
INFO - 2019-07-21 10:01:41 --> Database Driver Class Initialized
INFO - 2019-07-21 10:01:41 --> Controller Class Initialized
INFO - 2019-07-21 10:01:41 --> Model "Product" initialized
INFO - 2019-07-21 10:01:41 --> Final output sent to browser
DEBUG - 2019-07-21 10:01:41 --> Total execution time: 0.0554
INFO - 2019-07-21 10:02:35 --> Config Class Initialized
INFO - 2019-07-21 10:02:35 --> Hooks Class Initialized
DEBUG - 2019-07-21 10:02:35 --> UTF-8 Support Enabled
INFO - 2019-07-21 10:02:35 --> Utf8 Class Initialized
INFO - 2019-07-21 10:02:35 --> URI Class Initialized
INFO - 2019-07-21 10:02:35 --> Router Class Initialized
INFO - 2019-07-21 10:02:35 --> Output Class Initialized
INFO - 2019-07-21 10:02:35 --> Security Class Initialized
DEBUG - 2019-07-21 10:02:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 10:02:35 --> Input Class Initialized
INFO - 2019-07-21 10:02:35 --> Language Class Initialized
INFO - 2019-07-21 10:02:35 --> Loader Class Initialized
INFO - 2019-07-21 10:02:35 --> Database Driver Class Initialized
INFO - 2019-07-21 10:02:35 --> Controller Class Initialized
INFO - 2019-07-21 10:02:35 --> Model "Product" initialized
INFO - 2019-07-21 10:02:35 --> Final output sent to browser
DEBUG - 2019-07-21 10:02:35 --> Total execution time: 0.0197
INFO - 2019-07-21 10:02:38 --> Config Class Initialized
INFO - 2019-07-21 10:02:38 --> Hooks Class Initialized
DEBUG - 2019-07-21 10:02:38 --> UTF-8 Support Enabled
INFO - 2019-07-21 10:02:38 --> Utf8 Class Initialized
INFO - 2019-07-21 10:02:38 --> URI Class Initialized
INFO - 2019-07-21 10:02:38 --> Router Class Initialized
INFO - 2019-07-21 10:02:38 --> Output Class Initialized
INFO - 2019-07-21 10:02:38 --> Security Class Initialized
DEBUG - 2019-07-21 10:02:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 10:02:38 --> Input Class Initialized
INFO - 2019-07-21 10:02:38 --> Language Class Initialized
INFO - 2019-07-21 10:02:38 --> Loader Class Initialized
INFO - 2019-07-21 10:02:38 --> Database Driver Class Initialized
INFO - 2019-07-21 10:02:38 --> Controller Class Initialized
INFO - 2019-07-21 10:02:38 --> Model "Product" initialized
INFO - 2019-07-21 10:02:38 --> Final output sent to browser
DEBUG - 2019-07-21 10:02:38 --> Total execution time: 0.0214
INFO - 2019-07-21 10:09:53 --> Config Class Initialized
INFO - 2019-07-21 10:09:53 --> Hooks Class Initialized
DEBUG - 2019-07-21 10:09:53 --> UTF-8 Support Enabled
INFO - 2019-07-21 10:09:53 --> Utf8 Class Initialized
INFO - 2019-07-21 10:09:53 --> URI Class Initialized
INFO - 2019-07-21 10:09:53 --> Router Class Initialized
INFO - 2019-07-21 10:09:53 --> Output Class Initialized
INFO - 2019-07-21 10:09:53 --> Security Class Initialized
DEBUG - 2019-07-21 10:09:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 10:09:53 --> Input Class Initialized
INFO - 2019-07-21 10:09:53 --> Language Class Initialized
INFO - 2019-07-21 10:09:53 --> Loader Class Initialized
INFO - 2019-07-21 10:09:53 --> Config Class Initialized
INFO - 2019-07-21 10:09:53 --> Hooks Class Initialized
DEBUG - 2019-07-21 10:09:53 --> UTF-8 Support Enabled
INFO - 2019-07-21 10:09:53 --> Utf8 Class Initialized
INFO - 2019-07-21 10:09:53 --> Database Driver Class Initialized
INFO - 2019-07-21 10:09:53 --> URI Class Initialized
INFO - 2019-07-21 10:09:53 --> Router Class Initialized
INFO - 2019-07-21 10:09:53 --> Output Class Initialized
INFO - 2019-07-21 10:09:53 --> Security Class Initialized
DEBUG - 2019-07-21 10:09:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 10:09:53 --> Input Class Initialized
INFO - 2019-07-21 10:09:53 --> Language Class Initialized
INFO - 2019-07-21 10:09:53 --> Loader Class Initialized
INFO - 2019-07-21 10:09:53 --> Database Driver Class Initialized
INFO - 2019-07-21 10:09:53 --> Controller Class Initialized
INFO - 2019-07-21 10:09:53 --> Model "Product" initialized
INFO - 2019-07-21 10:09:53 --> Final output sent to browser
DEBUG - 2019-07-21 10:09:53 --> Total execution time: 0.0596
INFO - 2019-07-21 10:09:53 --> Controller Class Initialized
INFO - 2019-07-21 10:09:53 --> Model "Product" initialized
INFO - 2019-07-21 10:09:53 --> Final output sent to browser
DEBUG - 2019-07-21 10:09:53 --> Total execution time: 0.0465
INFO - 2019-07-21 10:18:08 --> Config Class Initialized
INFO - 2019-07-21 10:18:08 --> Config Class Initialized
INFO - 2019-07-21 10:18:08 --> Hooks Class Initialized
INFO - 2019-07-21 10:18:08 --> Hooks Class Initialized
DEBUG - 2019-07-21 10:18:08 --> UTF-8 Support Enabled
DEBUG - 2019-07-21 10:18:08 --> UTF-8 Support Enabled
INFO - 2019-07-21 10:18:08 --> Utf8 Class Initialized
INFO - 2019-07-21 10:18:08 --> Utf8 Class Initialized
INFO - 2019-07-21 10:18:08 --> URI Class Initialized
INFO - 2019-07-21 10:18:08 --> URI Class Initialized
INFO - 2019-07-21 10:18:08 --> Router Class Initialized
INFO - 2019-07-21 10:18:08 --> Router Class Initialized
INFO - 2019-07-21 10:18:08 --> Output Class Initialized
INFO - 2019-07-21 10:18:08 --> Output Class Initialized
INFO - 2019-07-21 10:18:08 --> Security Class Initialized
INFO - 2019-07-21 10:18:08 --> Security Class Initialized
DEBUG - 2019-07-21 10:18:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-21 10:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 10:18:08 --> Input Class Initialized
INFO - 2019-07-21 10:18:08 --> Input Class Initialized
INFO - 2019-07-21 10:18:08 --> Language Class Initialized
INFO - 2019-07-21 10:18:08 --> Language Class Initialized
INFO - 2019-07-21 10:18:08 --> Loader Class Initialized
INFO - 2019-07-21 10:18:08 --> Loader Class Initialized
INFO - 2019-07-21 10:18:09 --> Database Driver Class Initialized
INFO - 2019-07-21 10:18:09 --> Database Driver Class Initialized
INFO - 2019-07-21 10:18:09 --> Controller Class Initialized
INFO - 2019-07-21 10:18:09 --> Controller Class Initialized
INFO - 2019-07-21 10:18:09 --> Model "Product" initialized
INFO - 2019-07-21 10:18:09 --> Model "Product" initialized
INFO - 2019-07-21 10:18:09 --> Final output sent to browser
DEBUG - 2019-07-21 10:18:09 --> Total execution time: 0.2855
INFO - 2019-07-21 10:18:09 --> Final output sent to browser
DEBUG - 2019-07-21 10:18:09 --> Total execution time: 0.3097
INFO - 2019-07-21 10:23:01 --> Config Class Initialized
INFO - 2019-07-21 10:23:01 --> Hooks Class Initialized
INFO - 2019-07-21 10:23:01 --> Config Class Initialized
INFO - 2019-07-21 10:23:01 --> Hooks Class Initialized
DEBUG - 2019-07-21 10:23:01 --> UTF-8 Support Enabled
INFO - 2019-07-21 10:23:01 --> Utf8 Class Initialized
INFO - 2019-07-21 10:23:01 --> URI Class Initialized
DEBUG - 2019-07-21 10:23:01 --> UTF-8 Support Enabled
INFO - 2019-07-21 10:23:01 --> Utf8 Class Initialized
INFO - 2019-07-21 10:23:01 --> Router Class Initialized
INFO - 2019-07-21 10:23:01 --> URI Class Initialized
INFO - 2019-07-21 10:23:01 --> Output Class Initialized
INFO - 2019-07-21 10:23:01 --> Router Class Initialized
INFO - 2019-07-21 10:23:01 --> Security Class Initialized
DEBUG - 2019-07-21 10:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 10:23:01 --> Input Class Initialized
INFO - 2019-07-21 10:23:01 --> Language Class Initialized
INFO - 2019-07-21 10:23:01 --> Output Class Initialized
INFO - 2019-07-21 10:23:01 --> Loader Class Initialized
INFO - 2019-07-21 10:23:01 --> Security Class Initialized
DEBUG - 2019-07-21 10:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 10:23:01 --> Input Class Initialized
INFO - 2019-07-21 10:23:01 --> Language Class Initialized
INFO - 2019-07-21 10:23:01 --> Database Driver Class Initialized
INFO - 2019-07-21 10:23:01 --> Loader Class Initialized
INFO - 2019-07-21 10:23:01 --> Database Driver Class Initialized
INFO - 2019-07-21 10:23:01 --> Controller Class Initialized
INFO - 2019-07-21 10:23:01 --> Model "Product" initialized
INFO - 2019-07-21 10:23:01 --> Controller Class Initialized
INFO - 2019-07-21 10:23:01 --> Model "Product" initialized
INFO - 2019-07-21 10:23:01 --> Final output sent to browser
DEBUG - 2019-07-21 10:23:01 --> Total execution time: 0.0546
INFO - 2019-07-21 10:23:01 --> Final output sent to browser
DEBUG - 2019-07-21 10:23:01 --> Total execution time: 0.0551
INFO - 2019-07-21 10:23:22 --> Config Class Initialized
INFO - 2019-07-21 10:23:22 --> Hooks Class Initialized
DEBUG - 2019-07-21 10:23:22 --> UTF-8 Support Enabled
INFO - 2019-07-21 10:23:22 --> Utf8 Class Initialized
INFO - 2019-07-21 10:23:22 --> URI Class Initialized
INFO - 2019-07-21 10:23:22 --> Router Class Initialized
INFO - 2019-07-21 10:23:22 --> Output Class Initialized
INFO - 2019-07-21 10:23:22 --> Security Class Initialized
DEBUG - 2019-07-21 10:23:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 10:23:22 --> Input Class Initialized
INFO - 2019-07-21 10:23:22 --> Language Class Initialized
INFO - 2019-07-21 10:23:22 --> Loader Class Initialized
INFO - 2019-07-21 10:23:22 --> Database Driver Class Initialized
INFO - 2019-07-21 10:23:22 --> Controller Class Initialized
INFO - 2019-07-21 10:23:22 --> Model "Product" initialized
INFO - 2019-07-21 10:23:22 --> Final output sent to browser
DEBUG - 2019-07-21 10:23:22 --> Total execution time: 0.1137
INFO - 2019-07-21 10:23:22 --> Config Class Initialized
INFO - 2019-07-21 10:23:22 --> Hooks Class Initialized
DEBUG - 2019-07-21 10:23:22 --> UTF-8 Support Enabled
INFO - 2019-07-21 10:23:22 --> Utf8 Class Initialized
INFO - 2019-07-21 10:23:22 --> URI Class Initialized
INFO - 2019-07-21 10:23:22 --> Router Class Initialized
INFO - 2019-07-21 10:23:22 --> Output Class Initialized
INFO - 2019-07-21 10:23:22 --> Security Class Initialized
DEBUG - 2019-07-21 10:23:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 10:23:22 --> Input Class Initialized
INFO - 2019-07-21 10:23:22 --> Language Class Initialized
INFO - 2019-07-21 10:23:22 --> Loader Class Initialized
INFO - 2019-07-21 10:23:22 --> Database Driver Class Initialized
INFO - 2019-07-21 10:23:22 --> Controller Class Initialized
INFO - 2019-07-21 10:23:22 --> Model "Product" initialized
ERROR - 2019-07-21 10:23:22 --> Severity: 4096 --> Object of class stdClass could not be converted to string /opt/lampp/htdocs/mautic_ci_product/system/database/DB_query_builder.php 2442
ERROR - 2019-07-21 10:23:22 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '' at line 3 - Invalid query: SELECT *
FROM `prod_signup`
WHERE `id` = 
INFO - 2019-07-21 10:23:22 --> Language file loaded: language/english/db_lang.php
INFO - 2019-07-21 10:26:17 --> Config Class Initialized
INFO - 2019-07-21 10:26:17 --> Hooks Class Initialized
INFO - 2019-07-21 10:26:17 --> Config Class Initialized
INFO - 2019-07-21 10:26:17 --> Hooks Class Initialized
DEBUG - 2019-07-21 10:26:17 --> UTF-8 Support Enabled
INFO - 2019-07-21 10:26:17 --> Utf8 Class Initialized
INFO - 2019-07-21 10:26:17 --> URI Class Initialized
INFO - 2019-07-21 10:26:17 --> Router Class Initialized
DEBUG - 2019-07-21 10:26:17 --> UTF-8 Support Enabled
INFO - 2019-07-21 10:26:17 --> Utf8 Class Initialized
INFO - 2019-07-21 10:26:17 --> URI Class Initialized
INFO - 2019-07-21 10:26:17 --> Router Class Initialized
INFO - 2019-07-21 10:26:17 --> Output Class Initialized
INFO - 2019-07-21 10:26:17 --> Output Class Initialized
INFO - 2019-07-21 10:26:17 --> Security Class Initialized
INFO - 2019-07-21 10:26:17 --> Security Class Initialized
DEBUG - 2019-07-21 10:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 10:26:17 --> Input Class Initialized
DEBUG - 2019-07-21 10:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 10:26:17 --> Input Class Initialized
INFO - 2019-07-21 10:26:17 --> Language Class Initialized
INFO - 2019-07-21 10:26:17 --> Language Class Initialized
INFO - 2019-07-21 10:26:17 --> Loader Class Initialized
INFO - 2019-07-21 10:26:17 --> Loader Class Initialized
INFO - 2019-07-21 10:26:17 --> Database Driver Class Initialized
INFO - 2019-07-21 10:26:17 --> Controller Class Initialized
INFO - 2019-07-21 10:26:17 --> Model "Product" initialized
INFO - 2019-07-21 10:26:17 --> Final output sent to browser
DEBUG - 2019-07-21 10:26:17 --> Total execution time: 0.0676
INFO - 2019-07-21 10:26:17 --> Database Driver Class Initialized
INFO - 2019-07-21 10:26:17 --> Controller Class Initialized
INFO - 2019-07-21 10:26:17 --> Model "Product" initialized
INFO - 2019-07-21 10:26:17 --> Final output sent to browser
DEBUG - 2019-07-21 10:26:17 --> Total execution time: 0.0694
INFO - 2019-07-21 10:26:26 --> Config Class Initialized
INFO - 2019-07-21 10:26:26 --> Hooks Class Initialized
DEBUG - 2019-07-21 10:26:26 --> UTF-8 Support Enabled
INFO - 2019-07-21 10:26:26 --> Utf8 Class Initialized
INFO - 2019-07-21 10:26:26 --> URI Class Initialized
INFO - 2019-07-21 10:26:26 --> Router Class Initialized
INFO - 2019-07-21 10:26:26 --> Output Class Initialized
INFO - 2019-07-21 10:26:26 --> Security Class Initialized
DEBUG - 2019-07-21 10:26:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 10:26:26 --> Input Class Initialized
INFO - 2019-07-21 10:26:26 --> Language Class Initialized
ERROR - 2019-07-21 10:26:26 --> 404 Page Not Found: Welcome/updateuser
INFO - 2019-07-21 10:35:11 --> Config Class Initialized
INFO - 2019-07-21 10:35:11 --> Hooks Class Initialized
DEBUG - 2019-07-21 10:35:11 --> UTF-8 Support Enabled
INFO - 2019-07-21 10:35:11 --> Utf8 Class Initialized
INFO - 2019-07-21 10:35:11 --> URI Class Initialized
INFO - 2019-07-21 10:35:11 --> Router Class Initialized
INFO - 2019-07-21 10:35:11 --> Output Class Initialized
INFO - 2019-07-21 10:35:11 --> Security Class Initialized
DEBUG - 2019-07-21 10:35:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 10:35:11 --> Input Class Initialized
INFO - 2019-07-21 10:35:11 --> Language Class Initialized
INFO - 2019-07-21 10:35:11 --> Loader Class Initialized
INFO - 2019-07-21 10:35:11 --> Database Driver Class Initialized
INFO - 2019-07-21 10:35:11 --> Controller Class Initialized
INFO - 2019-07-21 10:35:11 --> Model "Product" initialized
INFO - 2019-07-21 10:35:11 --> Final output sent to browser
DEBUG - 2019-07-21 10:35:11 --> Total execution time: 0.1379
INFO - 2019-07-21 10:35:13 --> Config Class Initialized
INFO - 2019-07-21 10:35:13 --> Hooks Class Initialized
DEBUG - 2019-07-21 10:35:13 --> UTF-8 Support Enabled
INFO - 2019-07-21 10:35:13 --> Utf8 Class Initialized
INFO - 2019-07-21 10:35:13 --> URI Class Initialized
INFO - 2019-07-21 10:35:13 --> Router Class Initialized
INFO - 2019-07-21 10:35:13 --> Output Class Initialized
INFO - 2019-07-21 10:35:13 --> Security Class Initialized
DEBUG - 2019-07-21 10:35:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 10:35:13 --> Input Class Initialized
INFO - 2019-07-21 10:35:13 --> Language Class Initialized
INFO - 2019-07-21 10:35:13 --> Loader Class Initialized
INFO - 2019-07-21 10:35:13 --> Database Driver Class Initialized
INFO - 2019-07-21 10:35:13 --> Controller Class Initialized
INFO - 2019-07-21 10:35:13 --> Model "Product" initialized
INFO - 2019-07-21 10:35:13 --> Final output sent to browser
DEBUG - 2019-07-21 10:35:13 --> Total execution time: 0.0205
INFO - 2019-07-21 10:35:25 --> Config Class Initialized
INFO - 2019-07-21 10:35:25 --> Hooks Class Initialized
DEBUG - 2019-07-21 10:35:25 --> UTF-8 Support Enabled
INFO - 2019-07-21 10:35:25 --> Utf8 Class Initialized
INFO - 2019-07-21 10:35:25 --> URI Class Initialized
INFO - 2019-07-21 10:35:25 --> Router Class Initialized
INFO - 2019-07-21 10:35:25 --> Output Class Initialized
INFO - 2019-07-21 10:35:25 --> Security Class Initialized
DEBUG - 2019-07-21 10:35:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 10:35:25 --> Input Class Initialized
INFO - 2019-07-21 10:35:25 --> Language Class Initialized
INFO - 2019-07-21 10:35:25 --> Loader Class Initialized
INFO - 2019-07-21 10:35:25 --> Database Driver Class Initialized
INFO - 2019-07-21 10:35:25 --> Controller Class Initialized
INFO - 2019-07-21 10:35:25 --> Model "Product" initialized
INFO - 2019-07-21 10:35:25 --> Config Class Initialized
INFO - 2019-07-21 10:35:25 --> Hooks Class Initialized
DEBUG - 2019-07-21 10:35:25 --> UTF-8 Support Enabled
INFO - 2019-07-21 10:35:25 --> Utf8 Class Initialized
INFO - 2019-07-21 10:35:25 --> URI Class Initialized
INFO - 2019-07-21 10:35:25 --> Router Class Initialized
INFO - 2019-07-21 10:35:25 --> Output Class Initialized
INFO - 2019-07-21 10:35:25 --> Security Class Initialized
DEBUG - 2019-07-21 10:35:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 10:35:25 --> Input Class Initialized
INFO - 2019-07-21 10:35:25 --> Language Class Initialized
INFO - 2019-07-21 10:35:25 --> Loader Class Initialized
INFO - 2019-07-21 10:35:25 --> Database Driver Class Initialized
INFO - 2019-07-21 10:35:25 --> Controller Class Initialized
INFO - 2019-07-21 10:35:25 --> Model "Product" initialized
INFO - 2019-07-21 10:36:39 --> Config Class Initialized
INFO - 2019-07-21 10:36:39 --> Hooks Class Initialized
DEBUG - 2019-07-21 10:36:39 --> UTF-8 Support Enabled
INFO - 2019-07-21 10:36:39 --> Utf8 Class Initialized
INFO - 2019-07-21 10:36:39 --> URI Class Initialized
INFO - 2019-07-21 10:36:39 --> Router Class Initialized
INFO - 2019-07-21 10:36:39 --> Config Class Initialized
INFO - 2019-07-21 10:36:39 --> Hooks Class Initialized
DEBUG - 2019-07-21 10:36:39 --> UTF-8 Support Enabled
INFO - 2019-07-21 10:36:39 --> Utf8 Class Initialized
INFO - 2019-07-21 10:36:39 --> Output Class Initialized
INFO - 2019-07-21 10:36:39 --> URI Class Initialized
INFO - 2019-07-21 10:36:39 --> Router Class Initialized
INFO - 2019-07-21 10:36:39 --> Security Class Initialized
DEBUG - 2019-07-21 10:36:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 10:36:39 --> Input Class Initialized
INFO - 2019-07-21 10:36:39 --> Output Class Initialized
INFO - 2019-07-21 10:36:39 --> Language Class Initialized
INFO - 2019-07-21 10:36:39 --> Security Class Initialized
DEBUG - 2019-07-21 10:36:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 10:36:39 --> Input Class Initialized
INFO - 2019-07-21 10:36:39 --> Loader Class Initialized
INFO - 2019-07-21 10:36:39 --> Language Class Initialized
INFO - 2019-07-21 10:36:39 --> Loader Class Initialized
INFO - 2019-07-21 10:36:39 --> Database Driver Class Initialized
INFO - 2019-07-21 10:36:39 --> Controller Class Initialized
INFO - 2019-07-21 10:36:39 --> Model "Product" initialized
INFO - 2019-07-21 10:36:39 --> Final output sent to browser
DEBUG - 2019-07-21 10:36:39 --> Total execution time: 0.0456
INFO - 2019-07-21 10:36:39 --> Database Driver Class Initialized
INFO - 2019-07-21 10:36:39 --> Controller Class Initialized
INFO - 2019-07-21 10:36:39 --> Model "Product" initialized
INFO - 2019-07-21 10:36:39 --> Final output sent to browser
DEBUG - 2019-07-21 10:36:39 --> Total execution time: 0.0701
INFO - 2019-07-21 10:36:59 --> Config Class Initialized
INFO - 2019-07-21 10:36:59 --> Config Class Initialized
INFO - 2019-07-21 10:36:59 --> Hooks Class Initialized
INFO - 2019-07-21 10:36:59 --> Hooks Class Initialized
DEBUG - 2019-07-21 10:36:59 --> UTF-8 Support Enabled
DEBUG - 2019-07-21 10:36:59 --> UTF-8 Support Enabled
INFO - 2019-07-21 10:36:59 --> Utf8 Class Initialized
INFO - 2019-07-21 10:36:59 --> Utf8 Class Initialized
INFO - 2019-07-21 10:36:59 --> URI Class Initialized
INFO - 2019-07-21 10:36:59 --> URI Class Initialized
INFO - 2019-07-21 10:36:59 --> Router Class Initialized
INFO - 2019-07-21 10:36:59 --> Router Class Initialized
INFO - 2019-07-21 10:36:59 --> Output Class Initialized
INFO - 2019-07-21 10:36:59 --> Output Class Initialized
INFO - 2019-07-21 10:36:59 --> Security Class Initialized
INFO - 2019-07-21 10:36:59 --> Security Class Initialized
DEBUG - 2019-07-21 10:36:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 10:36:59 --> Input Class Initialized
DEBUG - 2019-07-21 10:36:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 10:36:59 --> Input Class Initialized
INFO - 2019-07-21 10:36:59 --> Language Class Initialized
INFO - 2019-07-21 10:36:59 --> Language Class Initialized
INFO - 2019-07-21 10:36:59 --> Loader Class Initialized
INFO - 2019-07-21 10:36:59 --> Loader Class Initialized
INFO - 2019-07-21 10:36:59 --> Database Driver Class Initialized
INFO - 2019-07-21 10:37:00 --> Database Driver Class Initialized
INFO - 2019-07-21 10:37:00 --> Controller Class Initialized
INFO - 2019-07-21 10:37:00 --> Controller Class Initialized
INFO - 2019-07-21 10:37:00 --> Model "Product" initialized
INFO - 2019-07-21 10:37:00 --> Model "Product" initialized
INFO - 2019-07-21 10:37:00 --> Final output sent to browser
INFO - 2019-07-21 10:37:00 --> Final output sent to browser
DEBUG - 2019-07-21 10:37:00 --> Total execution time: 0.8086
DEBUG - 2019-07-21 10:37:00 --> Total execution time: 0.8086
INFO - 2019-07-21 10:37:03 --> Config Class Initialized
INFO - 2019-07-21 10:37:03 --> Hooks Class Initialized
DEBUG - 2019-07-21 10:37:03 --> UTF-8 Support Enabled
INFO - 2019-07-21 10:37:03 --> Utf8 Class Initialized
INFO - 2019-07-21 10:37:03 --> URI Class Initialized
INFO - 2019-07-21 10:37:03 --> Router Class Initialized
INFO - 2019-07-21 10:37:03 --> Output Class Initialized
INFO - 2019-07-21 10:37:03 --> Security Class Initialized
DEBUG - 2019-07-21 10:37:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 10:37:03 --> Input Class Initialized
INFO - 2019-07-21 10:37:03 --> Language Class Initialized
INFO - 2019-07-21 10:37:03 --> Loader Class Initialized
INFO - 2019-07-21 10:37:03 --> Database Driver Class Initialized
INFO - 2019-07-21 10:37:03 --> Controller Class Initialized
INFO - 2019-07-21 10:37:03 --> Model "Product" initialized
INFO - 2019-07-21 10:37:03 --> Config Class Initialized
INFO - 2019-07-21 10:37:03 --> Hooks Class Initialized
DEBUG - 2019-07-21 10:37:03 --> UTF-8 Support Enabled
INFO - 2019-07-21 10:37:03 --> Utf8 Class Initialized
INFO - 2019-07-21 10:37:03 --> URI Class Initialized
INFO - 2019-07-21 10:37:03 --> Router Class Initialized
INFO - 2019-07-21 10:37:03 --> Output Class Initialized
INFO - 2019-07-21 10:37:03 --> Security Class Initialized
DEBUG - 2019-07-21 10:37:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 10:37:03 --> Input Class Initialized
INFO - 2019-07-21 10:37:03 --> Language Class Initialized
INFO - 2019-07-21 10:37:03 --> Loader Class Initialized
INFO - 2019-07-21 10:37:03 --> Database Driver Class Initialized
INFO - 2019-07-21 10:37:03 --> Controller Class Initialized
INFO - 2019-07-21 10:37:03 --> Model "Product" initialized
INFO - 2019-07-21 10:37:21 --> Config Class Initialized
INFO - 2019-07-21 10:37:21 --> Hooks Class Initialized
DEBUG - 2019-07-21 10:37:21 --> UTF-8 Support Enabled
INFO - 2019-07-21 10:37:21 --> Utf8 Class Initialized
INFO - 2019-07-21 10:37:21 --> URI Class Initialized
INFO - 2019-07-21 10:37:21 --> Router Class Initialized
INFO - 2019-07-21 10:37:21 --> Output Class Initialized
INFO - 2019-07-21 10:37:21 --> Security Class Initialized
DEBUG - 2019-07-21 10:37:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 10:37:21 --> Input Class Initialized
INFO - 2019-07-21 10:37:21 --> Language Class Initialized
INFO - 2019-07-21 10:37:21 --> Loader Class Initialized
INFO - 2019-07-21 10:37:21 --> Database Driver Class Initialized
INFO - 2019-07-21 10:37:21 --> Controller Class Initialized
INFO - 2019-07-21 10:37:21 --> Model "Product" initialized
INFO - 2019-07-21 10:37:21 --> Config Class Initialized
INFO - 2019-07-21 10:37:21 --> Hooks Class Initialized
DEBUG - 2019-07-21 10:37:21 --> UTF-8 Support Enabled
INFO - 2019-07-21 10:37:21 --> Utf8 Class Initialized
INFO - 2019-07-21 10:37:21 --> URI Class Initialized
INFO - 2019-07-21 10:37:21 --> Router Class Initialized
INFO - 2019-07-21 10:37:21 --> Output Class Initialized
INFO - 2019-07-21 10:37:21 --> Security Class Initialized
DEBUG - 2019-07-21 10:37:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 10:37:21 --> Input Class Initialized
INFO - 2019-07-21 10:37:21 --> Language Class Initialized
INFO - 2019-07-21 10:37:21 --> Loader Class Initialized
INFO - 2019-07-21 10:37:21 --> Database Driver Class Initialized
INFO - 2019-07-21 10:37:21 --> Controller Class Initialized
INFO - 2019-07-21 10:37:21 --> Model "Product" initialized
INFO - 2019-07-21 10:37:27 --> Config Class Initialized
INFO - 2019-07-21 10:37:27 --> Hooks Class Initialized
DEBUG - 2019-07-21 10:37:27 --> UTF-8 Support Enabled
INFO - 2019-07-21 10:37:27 --> Utf8 Class Initialized
INFO - 2019-07-21 10:37:27 --> URI Class Initialized
INFO - 2019-07-21 10:37:27 --> Router Class Initialized
INFO - 2019-07-21 10:37:27 --> Output Class Initialized
INFO - 2019-07-21 10:37:27 --> Security Class Initialized
DEBUG - 2019-07-21 10:37:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 10:37:27 --> Input Class Initialized
INFO - 2019-07-21 10:37:27 --> Language Class Initialized
INFO - 2019-07-21 10:37:27 --> Loader Class Initialized
INFO - 2019-07-21 10:37:27 --> Config Class Initialized
INFO - 2019-07-21 10:37:27 --> Hooks Class Initialized
DEBUG - 2019-07-21 10:37:27 --> UTF-8 Support Enabled
INFO - 2019-07-21 10:37:27 --> Utf8 Class Initialized
INFO - 2019-07-21 10:37:27 --> URI Class Initialized
INFO - 2019-07-21 10:37:27 --> Router Class Initialized
INFO - 2019-07-21 10:37:27 --> Output Class Initialized
INFO - 2019-07-21 10:37:27 --> Security Class Initialized
DEBUG - 2019-07-21 10:37:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 10:37:27 --> Input Class Initialized
INFO - 2019-07-21 10:37:27 --> Language Class Initialized
INFO - 2019-07-21 10:37:27 --> Loader Class Initialized
INFO - 2019-07-21 10:37:27 --> Database Driver Class Initialized
INFO - 2019-07-21 10:37:27 --> Controller Class Initialized
INFO - 2019-07-21 10:37:27 --> Model "Product" initialized
INFO - 2019-07-21 10:37:27 --> Final output sent to browser
DEBUG - 2019-07-21 10:37:27 --> Total execution time: 0.0308
INFO - 2019-07-21 10:37:27 --> Database Driver Class Initialized
INFO - 2019-07-21 10:37:27 --> Controller Class Initialized
INFO - 2019-07-21 10:37:27 --> Model "Product" initialized
INFO - 2019-07-21 10:37:27 --> Final output sent to browser
DEBUG - 2019-07-21 10:37:27 --> Total execution time: 0.1161
INFO - 2019-07-21 10:37:46 --> Config Class Initialized
INFO - 2019-07-21 10:37:46 --> Hooks Class Initialized
DEBUG - 2019-07-21 10:37:46 --> UTF-8 Support Enabled
INFO - 2019-07-21 10:37:46 --> Utf8 Class Initialized
INFO - 2019-07-21 10:37:46 --> URI Class Initialized
INFO - 2019-07-21 10:37:46 --> Router Class Initialized
INFO - 2019-07-21 10:37:46 --> Config Class Initialized
INFO - 2019-07-21 10:37:46 --> Hooks Class Initialized
DEBUG - 2019-07-21 10:37:46 --> UTF-8 Support Enabled
INFO - 2019-07-21 10:37:46 --> Utf8 Class Initialized
INFO - 2019-07-21 10:37:46 --> URI Class Initialized
INFO - 2019-07-21 10:37:46 --> Router Class Initialized
INFO - 2019-07-21 10:37:46 --> Output Class Initialized
INFO - 2019-07-21 10:37:46 --> Security Class Initialized
INFO - 2019-07-21 10:37:46 --> Output Class Initialized
INFO - 2019-07-21 10:37:46 --> Security Class Initialized
DEBUG - 2019-07-21 10:37:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 10:37:46 --> Input Class Initialized
INFO - 2019-07-21 10:37:46 --> Language Class Initialized
INFO - 2019-07-21 10:37:46 --> Loader Class Initialized
DEBUG - 2019-07-21 10:37:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 10:37:46 --> Input Class Initialized
INFO - 2019-07-21 10:37:46 --> Language Class Initialized
INFO - 2019-07-21 10:37:46 --> Loader Class Initialized
INFO - 2019-07-21 10:37:46 --> Database Driver Class Initialized
INFO - 2019-07-21 10:37:46 --> Controller Class Initialized
INFO - 2019-07-21 10:37:46 --> Model "Product" initialized
INFO - 2019-07-21 10:37:46 --> Final output sent to browser
DEBUG - 2019-07-21 10:37:46 --> Total execution time: 0.0481
INFO - 2019-07-21 10:37:46 --> Database Driver Class Initialized
INFO - 2019-07-21 10:37:46 --> Controller Class Initialized
INFO - 2019-07-21 10:37:46 --> Model "Product" initialized
INFO - 2019-07-21 10:37:46 --> Final output sent to browser
DEBUG - 2019-07-21 10:37:46 --> Total execution time: 0.0448
INFO - 2019-07-21 10:37:48 --> Config Class Initialized
INFO - 2019-07-21 10:37:48 --> Hooks Class Initialized
DEBUG - 2019-07-21 10:37:48 --> UTF-8 Support Enabled
INFO - 2019-07-21 10:37:48 --> Utf8 Class Initialized
INFO - 2019-07-21 10:37:48 --> URI Class Initialized
INFO - 2019-07-21 10:37:48 --> Router Class Initialized
INFO - 2019-07-21 10:37:48 --> Output Class Initialized
INFO - 2019-07-21 10:37:48 --> Security Class Initialized
DEBUG - 2019-07-21 10:37:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 10:37:48 --> Input Class Initialized
INFO - 2019-07-21 10:37:48 --> Language Class Initialized
INFO - 2019-07-21 10:37:48 --> Loader Class Initialized
INFO - 2019-07-21 10:37:48 --> Database Driver Class Initialized
INFO - 2019-07-21 10:37:48 --> Controller Class Initialized
INFO - 2019-07-21 10:37:48 --> Model "Product" initialized
INFO - 2019-07-21 10:37:48 --> Config Class Initialized
INFO - 2019-07-21 10:37:48 --> Hooks Class Initialized
DEBUG - 2019-07-21 10:37:48 --> UTF-8 Support Enabled
INFO - 2019-07-21 10:37:48 --> Utf8 Class Initialized
INFO - 2019-07-21 10:37:48 --> URI Class Initialized
INFO - 2019-07-21 10:37:48 --> Router Class Initialized
INFO - 2019-07-21 10:37:48 --> Output Class Initialized
INFO - 2019-07-21 10:37:48 --> Security Class Initialized
DEBUG - 2019-07-21 10:37:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 10:37:48 --> Input Class Initialized
INFO - 2019-07-21 10:37:48 --> Language Class Initialized
INFO - 2019-07-21 10:37:48 --> Loader Class Initialized
INFO - 2019-07-21 10:37:48 --> Database Driver Class Initialized
INFO - 2019-07-21 10:37:48 --> Controller Class Initialized
INFO - 2019-07-21 10:37:48 --> Model "Product" initialized
INFO - 2019-07-21 10:38:22 --> Config Class Initialized
INFO - 2019-07-21 10:38:22 --> Hooks Class Initialized
DEBUG - 2019-07-21 10:38:22 --> UTF-8 Support Enabled
INFO - 2019-07-21 10:38:22 --> Utf8 Class Initialized
INFO - 2019-07-21 10:38:22 --> URI Class Initialized
INFO - 2019-07-21 10:38:22 --> Router Class Initialized
INFO - 2019-07-21 10:38:22 --> Output Class Initialized
INFO - 2019-07-21 10:38:22 --> Config Class Initialized
INFO - 2019-07-21 10:38:22 --> Hooks Class Initialized
DEBUG - 2019-07-21 10:38:22 --> UTF-8 Support Enabled
INFO - 2019-07-21 10:38:22 --> Utf8 Class Initialized
INFO - 2019-07-21 10:38:22 --> URI Class Initialized
INFO - 2019-07-21 10:38:22 --> Router Class Initialized
INFO - 2019-07-21 10:38:22 --> Output Class Initialized
INFO - 2019-07-21 10:38:22 --> Security Class Initialized
DEBUG - 2019-07-21 10:38:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 10:38:22 --> Input Class Initialized
INFO - 2019-07-21 10:38:22 --> Language Class Initialized
INFO - 2019-07-21 10:38:22 --> Loader Class Initialized
INFO - 2019-07-21 10:38:22 --> Security Class Initialized
DEBUG - 2019-07-21 10:38:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 10:38:22 --> Input Class Initialized
INFO - 2019-07-21 10:38:22 --> Language Class Initialized
INFO - 2019-07-21 10:38:22 --> Loader Class Initialized
INFO - 2019-07-21 10:38:22 --> Database Driver Class Initialized
INFO - 2019-07-21 10:38:22 --> Database Driver Class Initialized
INFO - 2019-07-21 10:38:22 --> Controller Class Initialized
INFO - 2019-07-21 10:38:22 --> Controller Class Initialized
INFO - 2019-07-21 10:38:22 --> Model "Product" initialized
INFO - 2019-07-21 10:38:22 --> Model "Product" initialized
INFO - 2019-07-21 10:38:22 --> Final output sent to browser
INFO - 2019-07-21 10:38:22 --> Final output sent to browser
DEBUG - 2019-07-21 10:38:22 --> Total execution time: 0.0535
DEBUG - 2019-07-21 10:38:22 --> Total execution time: 0.0574
INFO - 2019-07-21 10:38:25 --> Config Class Initialized
INFO - 2019-07-21 10:38:25 --> Hooks Class Initialized
DEBUG - 2019-07-21 10:38:25 --> UTF-8 Support Enabled
INFO - 2019-07-21 10:38:25 --> Utf8 Class Initialized
INFO - 2019-07-21 10:38:25 --> URI Class Initialized
INFO - 2019-07-21 10:38:25 --> Router Class Initialized
INFO - 2019-07-21 10:38:25 --> Output Class Initialized
INFO - 2019-07-21 10:38:25 --> Security Class Initialized
DEBUG - 2019-07-21 10:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 10:38:25 --> Input Class Initialized
INFO - 2019-07-21 10:38:25 --> Language Class Initialized
INFO - 2019-07-21 10:38:25 --> Loader Class Initialized
INFO - 2019-07-21 10:38:25 --> Database Driver Class Initialized
INFO - 2019-07-21 10:38:25 --> Controller Class Initialized
INFO - 2019-07-21 10:38:25 --> Model "Product" initialized
INFO - 2019-07-21 10:38:25 --> Config Class Initialized
INFO - 2019-07-21 10:38:25 --> Hooks Class Initialized
DEBUG - 2019-07-21 10:38:25 --> UTF-8 Support Enabled
INFO - 2019-07-21 10:38:25 --> Utf8 Class Initialized
INFO - 2019-07-21 10:38:25 --> URI Class Initialized
INFO - 2019-07-21 10:38:25 --> Router Class Initialized
INFO - 2019-07-21 10:38:25 --> Output Class Initialized
INFO - 2019-07-21 10:38:25 --> Security Class Initialized
DEBUG - 2019-07-21 10:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 10:38:25 --> Input Class Initialized
INFO - 2019-07-21 10:38:25 --> Language Class Initialized
INFO - 2019-07-21 10:38:25 --> Loader Class Initialized
INFO - 2019-07-21 10:38:25 --> Database Driver Class Initialized
INFO - 2019-07-21 10:38:25 --> Controller Class Initialized
INFO - 2019-07-21 10:38:25 --> Model "Product" initialized
INFO - 2019-07-21 10:38:59 --> Config Class Initialized
INFO - 2019-07-21 10:38:59 --> Hooks Class Initialized
DEBUG - 2019-07-21 10:38:59 --> UTF-8 Support Enabled
INFO - 2019-07-21 10:38:59 --> Utf8 Class Initialized
INFO - 2019-07-21 10:38:59 --> URI Class Initialized
INFO - 2019-07-21 10:38:59 --> Router Class Initialized
INFO - 2019-07-21 10:38:59 --> Output Class Initialized
INFO - 2019-07-21 10:38:59 --> Security Class Initialized
DEBUG - 2019-07-21 10:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 10:38:59 --> Input Class Initialized
INFO - 2019-07-21 10:38:59 --> Language Class Initialized
INFO - 2019-07-21 10:38:59 --> Config Class Initialized
INFO - 2019-07-21 10:38:59 --> Hooks Class Initialized
DEBUG - 2019-07-21 10:38:59 --> UTF-8 Support Enabled
INFO - 2019-07-21 10:38:59 --> Utf8 Class Initialized
INFO - 2019-07-21 10:38:59 --> URI Class Initialized
INFO - 2019-07-21 10:38:59 --> Router Class Initialized
INFO - 2019-07-21 10:38:59 --> Loader Class Initialized
INFO - 2019-07-21 10:38:59 --> Output Class Initialized
INFO - 2019-07-21 10:38:59 --> Security Class Initialized
DEBUG - 2019-07-21 10:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 10:38:59 --> Input Class Initialized
INFO - 2019-07-21 10:38:59 --> Language Class Initialized
INFO - 2019-07-21 10:38:59 --> Database Driver Class Initialized
INFO - 2019-07-21 10:38:59 --> Loader Class Initialized
INFO - 2019-07-21 10:38:59 --> Controller Class Initialized
INFO - 2019-07-21 10:38:59 --> Model "Product" initialized
INFO - 2019-07-21 10:38:59 --> Final output sent to browser
DEBUG - 2019-07-21 10:38:59 --> Total execution time: 0.0518
INFO - 2019-07-21 10:38:59 --> Database Driver Class Initialized
INFO - 2019-07-21 10:38:59 --> Controller Class Initialized
INFO - 2019-07-21 10:38:59 --> Model "Product" initialized
INFO - 2019-07-21 10:39:00 --> Final output sent to browser
DEBUG - 2019-07-21 10:39:00 --> Total execution time: 0.0444
INFO - 2019-07-21 10:39:11 --> Config Class Initialized
INFO - 2019-07-21 10:39:11 --> Hooks Class Initialized
DEBUG - 2019-07-21 10:39:11 --> UTF-8 Support Enabled
INFO - 2019-07-21 10:39:11 --> Utf8 Class Initialized
INFO - 2019-07-21 10:39:11 --> URI Class Initialized
INFO - 2019-07-21 10:39:11 --> Router Class Initialized
INFO - 2019-07-21 10:39:11 --> Output Class Initialized
INFO - 2019-07-21 10:39:11 --> Security Class Initialized
DEBUG - 2019-07-21 10:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 10:39:11 --> Input Class Initialized
INFO - 2019-07-21 10:39:11 --> Language Class Initialized
INFO - 2019-07-21 10:39:11 --> Config Class Initialized
INFO - 2019-07-21 10:39:11 --> Hooks Class Initialized
INFO - 2019-07-21 10:39:11 --> Loader Class Initialized
DEBUG - 2019-07-21 10:39:11 --> UTF-8 Support Enabled
INFO - 2019-07-21 10:39:11 --> Utf8 Class Initialized
INFO - 2019-07-21 10:39:11 --> URI Class Initialized
INFO - 2019-07-21 10:39:11 --> Router Class Initialized
INFO - 2019-07-21 10:39:11 --> Database Driver Class Initialized
INFO - 2019-07-21 10:39:11 --> Output Class Initialized
INFO - 2019-07-21 10:39:11 --> Controller Class Initialized
INFO - 2019-07-21 10:39:11 --> Model "Product" initialized
INFO - 2019-07-21 10:39:11 --> Final output sent to browser
DEBUG - 2019-07-21 10:39:11 --> Total execution time: 0.0280
INFO - 2019-07-21 10:39:11 --> Security Class Initialized
DEBUG - 2019-07-21 10:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 10:39:11 --> Input Class Initialized
INFO - 2019-07-21 10:39:11 --> Language Class Initialized
INFO - 2019-07-21 10:39:11 --> Loader Class Initialized
INFO - 2019-07-21 10:39:11 --> Database Driver Class Initialized
INFO - 2019-07-21 10:39:11 --> Controller Class Initialized
INFO - 2019-07-21 10:39:11 --> Model "Product" initialized
INFO - 2019-07-21 10:39:11 --> Final output sent to browser
DEBUG - 2019-07-21 10:39:11 --> Total execution time: 0.0435
INFO - 2019-07-21 10:39:36 --> Config Class Initialized
INFO - 2019-07-21 10:39:36 --> Hooks Class Initialized
DEBUG - 2019-07-21 10:39:36 --> UTF-8 Support Enabled
INFO - 2019-07-21 10:39:36 --> Utf8 Class Initialized
INFO - 2019-07-21 10:39:36 --> URI Class Initialized
INFO - 2019-07-21 10:39:36 --> Router Class Initialized
INFO - 2019-07-21 10:39:36 --> Output Class Initialized
INFO - 2019-07-21 10:39:36 --> Security Class Initialized
INFO - 2019-07-21 10:39:36 --> Config Class Initialized
INFO - 2019-07-21 10:39:36 --> Hooks Class Initialized
DEBUG - 2019-07-21 10:39:36 --> UTF-8 Support Enabled
INFO - 2019-07-21 10:39:36 --> Utf8 Class Initialized
INFO - 2019-07-21 10:39:36 --> URI Class Initialized
INFO - 2019-07-21 10:39:36 --> Router Class Initialized
INFO - 2019-07-21 10:39:36 --> Output Class Initialized
INFO - 2019-07-21 10:39:36 --> Security Class Initialized
DEBUG - 2019-07-21 10:39:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-21 10:39:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 10:39:36 --> Input Class Initialized
INFO - 2019-07-21 10:39:36 --> Input Class Initialized
INFO - 2019-07-21 10:39:36 --> Language Class Initialized
INFO - 2019-07-21 10:39:36 --> Language Class Initialized
INFO - 2019-07-21 10:39:36 --> Loader Class Initialized
INFO - 2019-07-21 10:39:36 --> Loader Class Initialized
INFO - 2019-07-21 10:39:36 --> Database Driver Class Initialized
INFO - 2019-07-21 10:39:36 --> Controller Class Initialized
INFO - 2019-07-21 10:39:36 --> Model "Product" initialized
INFO - 2019-07-21 10:39:36 --> Final output sent to browser
DEBUG - 2019-07-21 10:39:36 --> Total execution time: 0.0417
INFO - 2019-07-21 10:39:36 --> Database Driver Class Initialized
INFO - 2019-07-21 10:39:36 --> Controller Class Initialized
INFO - 2019-07-21 10:39:36 --> Model "Product" initialized
INFO - 2019-07-21 10:39:36 --> Final output sent to browser
DEBUG - 2019-07-21 10:39:36 --> Total execution time: 0.0636
INFO - 2019-07-21 10:39:56 --> Config Class Initialized
INFO - 2019-07-21 10:39:56 --> Hooks Class Initialized
DEBUG - 2019-07-21 10:39:56 --> UTF-8 Support Enabled
INFO - 2019-07-21 10:39:56 --> Utf8 Class Initialized
INFO - 2019-07-21 10:39:56 --> Config Class Initialized
INFO - 2019-07-21 10:39:56 --> Hooks Class Initialized
INFO - 2019-07-21 10:39:56 --> URI Class Initialized
INFO - 2019-07-21 10:39:56 --> Router Class Initialized
DEBUG - 2019-07-21 10:39:56 --> UTF-8 Support Enabled
INFO - 2019-07-21 10:39:56 --> Utf8 Class Initialized
INFO - 2019-07-21 10:39:56 --> URI Class Initialized
INFO - 2019-07-21 10:39:56 --> Output Class Initialized
INFO - 2019-07-21 10:39:56 --> Router Class Initialized
INFO - 2019-07-21 10:39:56 --> Security Class Initialized
DEBUG - 2019-07-21 10:39:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 10:39:56 --> Input Class Initialized
INFO - 2019-07-21 10:39:56 --> Language Class Initialized
INFO - 2019-07-21 10:39:56 --> Loader Class Initialized
INFO - 2019-07-21 10:39:56 --> Output Class Initialized
INFO - 2019-07-21 10:39:56 --> Security Class Initialized
DEBUG - 2019-07-21 10:39:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 10:39:56 --> Input Class Initialized
INFO - 2019-07-21 10:39:56 --> Language Class Initialized
INFO - 2019-07-21 10:39:56 --> Loader Class Initialized
INFO - 2019-07-21 10:39:56 --> Database Driver Class Initialized
INFO - 2019-07-21 10:39:56 --> Controller Class Initialized
INFO - 2019-07-21 10:39:56 --> Model "Product" initialized
INFO - 2019-07-21 10:39:56 --> Final output sent to browser
DEBUG - 2019-07-21 10:39:56 --> Total execution time: 0.0240
INFO - 2019-07-21 10:39:56 --> Database Driver Class Initialized
INFO - 2019-07-21 10:39:56 --> Controller Class Initialized
INFO - 2019-07-21 10:39:56 --> Model "Product" initialized
INFO - 2019-07-21 10:39:56 --> Final output sent to browser
DEBUG - 2019-07-21 10:39:56 --> Total execution time: 0.0488
INFO - 2019-07-21 10:41:31 --> Config Class Initialized
INFO - 2019-07-21 10:41:31 --> Hooks Class Initialized
DEBUG - 2019-07-21 10:41:31 --> UTF-8 Support Enabled
INFO - 2019-07-21 10:41:31 --> Utf8 Class Initialized
INFO - 2019-07-21 10:41:31 --> URI Class Initialized
INFO - 2019-07-21 10:41:31 --> Router Class Initialized
INFO - 2019-07-21 10:41:31 --> Config Class Initialized
INFO - 2019-07-21 10:41:31 --> Hooks Class Initialized
INFO - 2019-07-21 10:41:31 --> Output Class Initialized
DEBUG - 2019-07-21 10:41:31 --> UTF-8 Support Enabled
INFO - 2019-07-21 10:41:31 --> Utf8 Class Initialized
INFO - 2019-07-21 10:41:31 --> Security Class Initialized
INFO - 2019-07-21 10:41:31 --> URI Class Initialized
DEBUG - 2019-07-21 10:41:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 10:41:31 --> Input Class Initialized
INFO - 2019-07-21 10:41:31 --> Router Class Initialized
INFO - 2019-07-21 10:41:31 --> Language Class Initialized
INFO - 2019-07-21 10:41:31 --> Output Class Initialized
INFO - 2019-07-21 10:41:31 --> Security Class Initialized
DEBUG - 2019-07-21 10:41:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 10:41:31 --> Input Class Initialized
INFO - 2019-07-21 10:41:31 --> Language Class Initialized
INFO - 2019-07-21 10:41:31 --> Loader Class Initialized
INFO - 2019-07-21 10:41:31 --> Loader Class Initialized
INFO - 2019-07-21 10:41:31 --> Database Driver Class Initialized
INFO - 2019-07-21 10:41:31 --> Database Driver Class Initialized
INFO - 2019-07-21 10:41:31 --> Controller Class Initialized
INFO - 2019-07-21 10:41:31 --> Controller Class Initialized
INFO - 2019-07-21 10:41:31 --> Model "Product" initialized
INFO - 2019-07-21 10:41:31 --> Model "Product" initialized
INFO - 2019-07-21 10:41:31 --> Final output sent to browser
DEBUG - 2019-07-21 10:41:31 --> Total execution time: 0.0416
INFO - 2019-07-21 10:41:31 --> Final output sent to browser
DEBUG - 2019-07-21 10:41:31 --> Total execution time: 0.0421
INFO - 2019-07-21 10:41:40 --> Config Class Initialized
INFO - 2019-07-21 10:41:40 --> Hooks Class Initialized
DEBUG - 2019-07-21 10:41:40 --> UTF-8 Support Enabled
INFO - 2019-07-21 10:41:40 --> Utf8 Class Initialized
INFO - 2019-07-21 10:41:40 --> URI Class Initialized
INFO - 2019-07-21 10:41:40 --> Router Class Initialized
INFO - 2019-07-21 10:41:40 --> Output Class Initialized
INFO - 2019-07-21 10:41:40 --> Security Class Initialized
DEBUG - 2019-07-21 10:41:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 10:41:40 --> Input Class Initialized
INFO - 2019-07-21 10:41:40 --> Language Class Initialized
INFO - 2019-07-21 10:41:40 --> Loader Class Initialized
INFO - 2019-07-21 10:41:40 --> Config Class Initialized
INFO - 2019-07-21 10:41:40 --> Hooks Class Initialized
INFO - 2019-07-21 10:41:40 --> Database Driver Class Initialized
INFO - 2019-07-21 10:41:40 --> Controller Class Initialized
INFO - 2019-07-21 10:41:40 --> Model "Product" initialized
DEBUG - 2019-07-21 10:41:40 --> UTF-8 Support Enabled
INFO - 2019-07-21 10:41:40 --> Utf8 Class Initialized
INFO - 2019-07-21 10:41:40 --> Final output sent to browser
DEBUG - 2019-07-21 10:41:40 --> Total execution time: 0.0284
INFO - 2019-07-21 10:41:40 --> URI Class Initialized
INFO - 2019-07-21 10:41:40 --> Router Class Initialized
INFO - 2019-07-21 10:41:40 --> Output Class Initialized
INFO - 2019-07-21 10:41:40 --> Security Class Initialized
DEBUG - 2019-07-21 10:41:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 10:41:40 --> Input Class Initialized
INFO - 2019-07-21 10:41:40 --> Language Class Initialized
INFO - 2019-07-21 10:41:40 --> Loader Class Initialized
INFO - 2019-07-21 10:41:40 --> Database Driver Class Initialized
INFO - 2019-07-21 10:41:40 --> Controller Class Initialized
INFO - 2019-07-21 10:41:40 --> Model "Product" initialized
INFO - 2019-07-21 10:41:40 --> Final output sent to browser
DEBUG - 2019-07-21 10:41:40 --> Total execution time: 0.0520
INFO - 2019-07-21 10:42:39 --> Config Class Initialized
INFO - 2019-07-21 10:42:39 --> Hooks Class Initialized
DEBUG - 2019-07-21 10:42:39 --> UTF-8 Support Enabled
INFO - 2019-07-21 10:42:39 --> Utf8 Class Initialized
INFO - 2019-07-21 10:42:39 --> URI Class Initialized
INFO - 2019-07-21 10:42:39 --> Router Class Initialized
INFO - 2019-07-21 10:42:39 --> Output Class Initialized
INFO - 2019-07-21 10:42:39 --> Config Class Initialized
INFO - 2019-07-21 10:42:39 --> Hooks Class Initialized
INFO - 2019-07-21 10:42:39 --> Security Class Initialized
DEBUG - 2019-07-21 10:42:39 --> UTF-8 Support Enabled
INFO - 2019-07-21 10:42:39 --> Utf8 Class Initialized
DEBUG - 2019-07-21 10:42:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 10:42:39 --> Input Class Initialized
INFO - 2019-07-21 10:42:39 --> Language Class Initialized
INFO - 2019-07-21 10:42:39 --> URI Class Initialized
INFO - 2019-07-21 10:42:39 --> Router Class Initialized
INFO - 2019-07-21 10:42:39 --> Loader Class Initialized
INFO - 2019-07-21 10:42:39 --> Output Class Initialized
INFO - 2019-07-21 10:42:39 --> Security Class Initialized
DEBUG - 2019-07-21 10:42:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 10:42:39 --> Input Class Initialized
INFO - 2019-07-21 10:42:39 --> Language Class Initialized
INFO - 2019-07-21 10:42:39 --> Database Driver Class Initialized
INFO - 2019-07-21 10:42:39 --> Controller Class Initialized
INFO - 2019-07-21 10:42:39 --> Model "Product" initialized
INFO - 2019-07-21 10:42:39 --> Loader Class Initialized
INFO - 2019-07-21 10:42:39 --> Final output sent to browser
DEBUG - 2019-07-21 10:42:39 --> Total execution time: 0.0216
INFO - 2019-07-21 10:42:39 --> Database Driver Class Initialized
INFO - 2019-07-21 10:42:39 --> Controller Class Initialized
INFO - 2019-07-21 10:42:39 --> Model "Product" initialized
INFO - 2019-07-21 10:42:39 --> Final output sent to browser
DEBUG - 2019-07-21 10:42:39 --> Total execution time: 0.0272
INFO - 2019-07-21 10:43:09 --> Config Class Initialized
INFO - 2019-07-21 10:43:09 --> Hooks Class Initialized
DEBUG - 2019-07-21 10:43:09 --> UTF-8 Support Enabled
INFO - 2019-07-21 10:43:09 --> Utf8 Class Initialized
INFO - 2019-07-21 10:43:09 --> URI Class Initialized
INFO - 2019-07-21 10:43:09 --> Router Class Initialized
INFO - 2019-07-21 10:43:09 --> Config Class Initialized
INFO - 2019-07-21 10:43:09 --> Hooks Class Initialized
INFO - 2019-07-21 10:43:09 --> Output Class Initialized
INFO - 2019-07-21 10:43:09 --> Security Class Initialized
DEBUG - 2019-07-21 10:43:09 --> UTF-8 Support Enabled
INFO - 2019-07-21 10:43:09 --> Utf8 Class Initialized
INFO - 2019-07-21 10:43:09 --> URI Class Initialized
DEBUG - 2019-07-21 10:43:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 10:43:09 --> Input Class Initialized
INFO - 2019-07-21 10:43:09 --> Language Class Initialized
INFO - 2019-07-21 10:43:09 --> Loader Class Initialized
INFO - 2019-07-21 10:43:09 --> Router Class Initialized
INFO - 2019-07-21 10:43:09 --> Output Class Initialized
INFO - 2019-07-21 10:43:09 --> Security Class Initialized
DEBUG - 2019-07-21 10:43:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 10:43:09 --> Input Class Initialized
INFO - 2019-07-21 10:43:09 --> Language Class Initialized
INFO - 2019-07-21 10:43:09 --> Loader Class Initialized
INFO - 2019-07-21 10:43:09 --> Database Driver Class Initialized
INFO - 2019-07-21 10:43:09 --> Controller Class Initialized
INFO - 2019-07-21 10:43:09 --> Model "Product" initialized
INFO - 2019-07-21 10:43:09 --> Final output sent to browser
DEBUG - 2019-07-21 10:43:09 --> Total execution time: 0.0351
INFO - 2019-07-21 10:43:09 --> Database Driver Class Initialized
INFO - 2019-07-21 10:43:09 --> Controller Class Initialized
INFO - 2019-07-21 10:43:09 --> Model "Product" initialized
INFO - 2019-07-21 10:43:09 --> Final output sent to browser
DEBUG - 2019-07-21 10:43:09 --> Total execution time: 0.0413
INFO - 2019-07-21 10:43:41 --> Config Class Initialized
INFO - 2019-07-21 10:43:41 --> Hooks Class Initialized
DEBUG - 2019-07-21 10:43:41 --> UTF-8 Support Enabled
INFO - 2019-07-21 10:43:41 --> Utf8 Class Initialized
INFO - 2019-07-21 10:43:41 --> URI Class Initialized
INFO - 2019-07-21 10:43:41 --> Router Class Initialized
INFO - 2019-07-21 10:43:41 --> Output Class Initialized
INFO - 2019-07-21 10:43:41 --> Security Class Initialized
DEBUG - 2019-07-21 10:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 10:43:41 --> Input Class Initialized
INFO - 2019-07-21 10:43:41 --> Language Class Initialized
INFO - 2019-07-21 10:43:41 --> Loader Class Initialized
INFO - 2019-07-21 10:43:41 --> Database Driver Class Initialized
INFO - 2019-07-21 10:43:41 --> Controller Class Initialized
INFO - 2019-07-21 10:43:41 --> Model "Product" initialized
INFO - 2019-07-21 10:43:41 --> Final output sent to browser
DEBUG - 2019-07-21 10:43:41 --> Total execution time: 0.0281
INFO - 2019-07-21 10:43:41 --> Config Class Initialized
INFO - 2019-07-21 10:43:41 --> Hooks Class Initialized
DEBUG - 2019-07-21 10:43:41 --> UTF-8 Support Enabled
INFO - 2019-07-21 10:43:41 --> Utf8 Class Initialized
INFO - 2019-07-21 10:43:41 --> URI Class Initialized
INFO - 2019-07-21 10:43:41 --> Router Class Initialized
INFO - 2019-07-21 10:43:41 --> Output Class Initialized
INFO - 2019-07-21 10:43:41 --> Security Class Initialized
DEBUG - 2019-07-21 10:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 10:43:41 --> Input Class Initialized
INFO - 2019-07-21 10:43:41 --> Language Class Initialized
INFO - 2019-07-21 10:43:41 --> Loader Class Initialized
INFO - 2019-07-21 10:43:41 --> Database Driver Class Initialized
INFO - 2019-07-21 10:43:41 --> Controller Class Initialized
INFO - 2019-07-21 10:43:41 --> Model "Product" initialized
INFO - 2019-07-21 10:43:41 --> Final output sent to browser
DEBUG - 2019-07-21 10:43:41 --> Total execution time: 0.0283
INFO - 2019-07-21 10:43:46 --> Config Class Initialized
INFO - 2019-07-21 10:43:46 --> Hooks Class Initialized
INFO - 2019-07-21 10:43:46 --> Config Class Initialized
INFO - 2019-07-21 10:43:46 --> Hooks Class Initialized
DEBUG - 2019-07-21 10:43:46 --> UTF-8 Support Enabled
INFO - 2019-07-21 10:43:46 --> Utf8 Class Initialized
INFO - 2019-07-21 10:43:46 --> URI Class Initialized
DEBUG - 2019-07-21 10:43:46 --> UTF-8 Support Enabled
INFO - 2019-07-21 10:43:46 --> Utf8 Class Initialized
INFO - 2019-07-21 10:43:46 --> Router Class Initialized
INFO - 2019-07-21 10:43:46 --> URI Class Initialized
INFO - 2019-07-21 10:43:46 --> Output Class Initialized
INFO - 2019-07-21 10:43:46 --> Router Class Initialized
INFO - 2019-07-21 10:43:46 --> Security Class Initialized
INFO - 2019-07-21 10:43:46 --> Output Class Initialized
INFO - 2019-07-21 10:43:46 --> Security Class Initialized
DEBUG - 2019-07-21 10:43:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 10:43:46 --> Input Class Initialized
INFO - 2019-07-21 10:43:46 --> Language Class Initialized
DEBUG - 2019-07-21 10:43:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 10:43:46 --> Input Class Initialized
INFO - 2019-07-21 10:43:46 --> Language Class Initialized
INFO - 2019-07-21 10:43:46 --> Loader Class Initialized
INFO - 2019-07-21 10:43:46 --> Loader Class Initialized
INFO - 2019-07-21 10:43:46 --> Database Driver Class Initialized
INFO - 2019-07-21 10:43:46 --> Controller Class Initialized
INFO - 2019-07-21 10:43:46 --> Model "Product" initialized
INFO - 2019-07-21 10:43:46 --> Final output sent to browser
DEBUG - 2019-07-21 10:43:46 --> Total execution time: 0.0317
INFO - 2019-07-21 10:43:46 --> Database Driver Class Initialized
INFO - 2019-07-21 10:43:46 --> Controller Class Initialized
INFO - 2019-07-21 10:43:46 --> Model "Product" initialized
INFO - 2019-07-21 10:43:46 --> Final output sent to browser
DEBUG - 2019-07-21 10:43:46 --> Total execution time: 0.0431
INFO - 2019-07-21 10:43:52 --> Config Class Initialized
INFO - 2019-07-21 10:43:52 --> Hooks Class Initialized
DEBUG - 2019-07-21 10:43:52 --> UTF-8 Support Enabled
INFO - 2019-07-21 10:43:52 --> Utf8 Class Initialized
INFO - 2019-07-21 10:43:52 --> URI Class Initialized
INFO - 2019-07-21 10:43:52 --> Router Class Initialized
INFO - 2019-07-21 10:43:52 --> Output Class Initialized
INFO - 2019-07-21 10:43:52 --> Security Class Initialized
DEBUG - 2019-07-21 10:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 10:43:52 --> Input Class Initialized
INFO - 2019-07-21 10:43:52 --> Language Class Initialized
INFO - 2019-07-21 10:43:52 --> Loader Class Initialized
INFO - 2019-07-21 10:43:52 --> Database Driver Class Initialized
INFO - 2019-07-21 10:43:52 --> Controller Class Initialized
INFO - 2019-07-21 10:43:52 --> Model "Product" initialized
INFO - 2019-07-21 10:43:52 --> Final output sent to browser
DEBUG - 2019-07-21 10:43:52 --> Total execution time: 0.0202
INFO - 2019-07-21 10:43:54 --> Config Class Initialized
INFO - 2019-07-21 10:43:54 --> Hooks Class Initialized
DEBUG - 2019-07-21 10:43:54 --> UTF-8 Support Enabled
INFO - 2019-07-21 10:43:54 --> Utf8 Class Initialized
INFO - 2019-07-21 10:43:54 --> URI Class Initialized
INFO - 2019-07-21 10:43:54 --> Router Class Initialized
INFO - 2019-07-21 10:43:54 --> Output Class Initialized
INFO - 2019-07-21 10:43:54 --> Security Class Initialized
DEBUG - 2019-07-21 10:43:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 10:43:54 --> Input Class Initialized
INFO - 2019-07-21 10:43:54 --> Language Class Initialized
INFO - 2019-07-21 10:43:54 --> Loader Class Initialized
INFO - 2019-07-21 10:43:54 --> Database Driver Class Initialized
INFO - 2019-07-21 10:43:54 --> Controller Class Initialized
INFO - 2019-07-21 10:43:54 --> Model "Product" initialized
INFO - 2019-07-21 10:43:54 --> Final output sent to browser
DEBUG - 2019-07-21 10:43:54 --> Total execution time: 0.0154
INFO - 2019-07-21 10:44:25 --> Config Class Initialized
INFO - 2019-07-21 10:44:25 --> Hooks Class Initialized
DEBUG - 2019-07-21 10:44:25 --> UTF-8 Support Enabled
INFO - 2019-07-21 10:44:25 --> Utf8 Class Initialized
INFO - 2019-07-21 10:44:25 --> URI Class Initialized
INFO - 2019-07-21 10:44:25 --> Router Class Initialized
INFO - 2019-07-21 10:44:25 --> Output Class Initialized
INFO - 2019-07-21 10:44:25 --> Config Class Initialized
INFO - 2019-07-21 10:44:25 --> Hooks Class Initialized
DEBUG - 2019-07-21 10:44:25 --> UTF-8 Support Enabled
INFO - 2019-07-21 10:44:25 --> Utf8 Class Initialized
INFO - 2019-07-21 10:44:25 --> Security Class Initialized
INFO - 2019-07-21 10:44:25 --> URI Class Initialized
INFO - 2019-07-21 10:44:25 --> Router Class Initialized
DEBUG - 2019-07-21 10:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 10:44:25 --> Input Class Initialized
INFO - 2019-07-21 10:44:25 --> Language Class Initialized
INFO - 2019-07-21 10:44:25 --> Output Class Initialized
INFO - 2019-07-21 10:44:25 --> Security Class Initialized
INFO - 2019-07-21 10:44:25 --> Loader Class Initialized
DEBUG - 2019-07-21 10:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 10:44:25 --> Input Class Initialized
INFO - 2019-07-21 10:44:25 --> Language Class Initialized
INFO - 2019-07-21 10:44:25 --> Loader Class Initialized
INFO - 2019-07-21 10:44:25 --> Database Driver Class Initialized
INFO - 2019-07-21 10:44:25 --> Controller Class Initialized
INFO - 2019-07-21 10:44:25 --> Model "Product" initialized
INFO - 2019-07-21 10:44:25 --> Final output sent to browser
DEBUG - 2019-07-21 10:44:25 --> Total execution time: 0.0516
INFO - 2019-07-21 10:44:25 --> Database Driver Class Initialized
INFO - 2019-07-21 10:44:25 --> Controller Class Initialized
INFO - 2019-07-21 10:44:25 --> Model "Product" initialized
INFO - 2019-07-21 10:44:25 --> Final output sent to browser
DEBUG - 2019-07-21 10:44:25 --> Total execution time: 0.0412
INFO - 2019-07-21 10:44:37 --> Config Class Initialized
INFO - 2019-07-21 10:44:37 --> Hooks Class Initialized
DEBUG - 2019-07-21 10:44:37 --> UTF-8 Support Enabled
INFO - 2019-07-21 10:44:37 --> Utf8 Class Initialized
INFO - 2019-07-21 10:44:37 --> URI Class Initialized
INFO - 2019-07-21 10:44:37 --> Router Class Initialized
INFO - 2019-07-21 10:44:37 --> Output Class Initialized
INFO - 2019-07-21 10:44:37 --> Security Class Initialized
DEBUG - 2019-07-21 10:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 10:44:37 --> Input Class Initialized
INFO - 2019-07-21 10:44:37 --> Language Class Initialized
INFO - 2019-07-21 10:44:37 --> Loader Class Initialized
INFO - 2019-07-21 10:44:37 --> Database Driver Class Initialized
INFO - 2019-07-21 10:44:37 --> Controller Class Initialized
INFO - 2019-07-21 10:44:37 --> Model "Product" initialized
INFO - 2019-07-21 10:44:37 --> Final output sent to browser
DEBUG - 2019-07-21 10:44:37 --> Total execution time: 0.0280
INFO - 2019-07-21 10:44:37 --> Config Class Initialized
INFO - 2019-07-21 10:44:37 --> Hooks Class Initialized
DEBUG - 2019-07-21 10:44:37 --> UTF-8 Support Enabled
INFO - 2019-07-21 10:44:37 --> Utf8 Class Initialized
INFO - 2019-07-21 10:44:37 --> URI Class Initialized
INFO - 2019-07-21 10:44:37 --> Router Class Initialized
INFO - 2019-07-21 10:44:37 --> Output Class Initialized
INFO - 2019-07-21 10:44:37 --> Security Class Initialized
DEBUG - 2019-07-21 10:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 10:44:37 --> Input Class Initialized
INFO - 2019-07-21 10:44:37 --> Language Class Initialized
INFO - 2019-07-21 10:44:37 --> Loader Class Initialized
INFO - 2019-07-21 10:44:37 --> Database Driver Class Initialized
INFO - 2019-07-21 10:44:37 --> Controller Class Initialized
INFO - 2019-07-21 10:44:37 --> Model "Product" initialized
INFO - 2019-07-21 10:44:37 --> Final output sent to browser
DEBUG - 2019-07-21 10:44:37 --> Total execution time: 0.0336
INFO - 2019-07-21 10:44:46 --> Config Class Initialized
INFO - 2019-07-21 10:44:46 --> Hooks Class Initialized
DEBUG - 2019-07-21 10:44:46 --> UTF-8 Support Enabled
INFO - 2019-07-21 10:44:46 --> Utf8 Class Initialized
INFO - 2019-07-21 10:44:46 --> URI Class Initialized
INFO - 2019-07-21 10:44:46 --> Router Class Initialized
INFO - 2019-07-21 10:44:46 --> Output Class Initialized
INFO - 2019-07-21 10:44:46 --> Security Class Initialized
DEBUG - 2019-07-21 10:44:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 10:44:46 --> Input Class Initialized
INFO - 2019-07-21 10:44:46 --> Language Class Initialized
INFO - 2019-07-21 10:44:46 --> Config Class Initialized
INFO - 2019-07-21 10:44:46 --> Hooks Class Initialized
DEBUG - 2019-07-21 10:44:46 --> UTF-8 Support Enabled
INFO - 2019-07-21 10:44:46 --> Utf8 Class Initialized
INFO - 2019-07-21 10:44:46 --> URI Class Initialized
INFO - 2019-07-21 10:44:46 --> Router Class Initialized
INFO - 2019-07-21 10:44:46 --> Output Class Initialized
INFO - 2019-07-21 10:44:46 --> Loader Class Initialized
INFO - 2019-07-21 10:44:46 --> Database Driver Class Initialized
INFO - 2019-07-21 10:44:46 --> Security Class Initialized
DEBUG - 2019-07-21 10:44:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 10:44:46 --> Input Class Initialized
INFO - 2019-07-21 10:44:46 --> Language Class Initialized
INFO - 2019-07-21 10:44:46 --> Loader Class Initialized
INFO - 2019-07-21 10:44:46 --> Controller Class Initialized
INFO - 2019-07-21 10:44:46 --> Model "Product" initialized
INFO - 2019-07-21 10:44:46 --> Final output sent to browser
DEBUG - 2019-07-21 10:44:46 --> Total execution time: 0.0622
INFO - 2019-07-21 10:44:46 --> Database Driver Class Initialized
INFO - 2019-07-21 10:44:46 --> Controller Class Initialized
INFO - 2019-07-21 10:44:46 --> Model "Product" initialized
INFO - 2019-07-21 10:44:46 --> Final output sent to browser
DEBUG - 2019-07-21 10:44:46 --> Total execution time: 0.0462
INFO - 2019-07-21 10:45:22 --> Config Class Initialized
INFO - 2019-07-21 10:45:23 --> Config Class Initialized
INFO - 2019-07-21 10:45:23 --> Hooks Class Initialized
INFO - 2019-07-21 10:45:23 --> Hooks Class Initialized
DEBUG - 2019-07-21 10:45:23 --> UTF-8 Support Enabled
DEBUG - 2019-07-21 10:45:23 --> UTF-8 Support Enabled
INFO - 2019-07-21 10:45:23 --> Utf8 Class Initialized
INFO - 2019-07-21 10:45:23 --> Utf8 Class Initialized
INFO - 2019-07-21 10:45:23 --> URI Class Initialized
INFO - 2019-07-21 10:45:23 --> URI Class Initialized
INFO - 2019-07-21 10:45:23 --> Router Class Initialized
INFO - 2019-07-21 10:45:23 --> Router Class Initialized
INFO - 2019-07-21 10:45:23 --> Output Class Initialized
INFO - 2019-07-21 10:45:23 --> Output Class Initialized
INFO - 2019-07-21 10:45:23 --> Security Class Initialized
INFO - 2019-07-21 10:45:23 --> Security Class Initialized
DEBUG - 2019-07-21 10:45:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-21 10:45:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 10:45:23 --> Input Class Initialized
INFO - 2019-07-21 10:45:23 --> Input Class Initialized
INFO - 2019-07-21 10:45:23 --> Language Class Initialized
INFO - 2019-07-21 10:45:23 --> Language Class Initialized
INFO - 2019-07-21 10:45:23 --> Loader Class Initialized
INFO - 2019-07-21 10:45:23 --> Loader Class Initialized
INFO - 2019-07-21 10:45:23 --> Database Driver Class Initialized
INFO - 2019-07-21 10:45:23 --> Database Driver Class Initialized
INFO - 2019-07-21 10:45:24 --> Controller Class Initialized
INFO - 2019-07-21 10:45:24 --> Controller Class Initialized
INFO - 2019-07-21 10:45:24 --> Model "Product" initialized
INFO - 2019-07-21 10:45:24 --> Model "Product" initialized
INFO - 2019-07-21 10:45:24 --> Final output sent to browser
INFO - 2019-07-21 10:45:24 --> Final output sent to browser
DEBUG - 2019-07-21 10:45:24 --> Total execution time: 1.3110
DEBUG - 2019-07-21 10:45:24 --> Total execution time: 1.3109
INFO - 2019-07-21 10:45:59 --> Config Class Initialized
INFO - 2019-07-21 10:45:59 --> Hooks Class Initialized
DEBUG - 2019-07-21 10:45:59 --> UTF-8 Support Enabled
INFO - 2019-07-21 10:45:59 --> Utf8 Class Initialized
INFO - 2019-07-21 10:45:59 --> URI Class Initialized
INFO - 2019-07-21 10:45:59 --> Router Class Initialized
INFO - 2019-07-21 10:45:59 --> Output Class Initialized
INFO - 2019-07-21 10:45:59 --> Config Class Initialized
INFO - 2019-07-21 10:45:59 --> Hooks Class Initialized
INFO - 2019-07-21 10:45:59 --> Security Class Initialized
DEBUG - 2019-07-21 10:45:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 10:45:59 --> Input Class Initialized
DEBUG - 2019-07-21 10:45:59 --> UTF-8 Support Enabled
INFO - 2019-07-21 10:45:59 --> Language Class Initialized
INFO - 2019-07-21 10:45:59 --> Utf8 Class Initialized
INFO - 2019-07-21 10:45:59 --> URI Class Initialized
INFO - 2019-07-21 10:45:59 --> Router Class Initialized
INFO - 2019-07-21 10:45:59 --> Output Class Initialized
INFO - 2019-07-21 10:45:59 --> Security Class Initialized
DEBUG - 2019-07-21 10:45:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 10:45:59 --> Input Class Initialized
INFO - 2019-07-21 10:45:59 --> Language Class Initialized
INFO - 2019-07-21 10:45:59 --> Loader Class Initialized
INFO - 2019-07-21 10:45:59 --> Loader Class Initialized
INFO - 2019-07-21 10:45:59 --> Database Driver Class Initialized
INFO - 2019-07-21 10:45:59 --> Database Driver Class Initialized
INFO - 2019-07-21 10:45:59 --> Controller Class Initialized
INFO - 2019-07-21 10:45:59 --> Model "Product" initialized
INFO - 2019-07-21 10:45:59 --> Controller Class Initialized
INFO - 2019-07-21 10:45:59 --> Model "Product" initialized
INFO - 2019-07-21 10:45:59 --> Final output sent to browser
DEBUG - 2019-07-21 10:45:59 --> Total execution time: 0.0681
INFO - 2019-07-21 10:45:59 --> Final output sent to browser
DEBUG - 2019-07-21 10:45:59 --> Total execution time: 0.0638
INFO - 2019-07-21 10:46:08 --> Config Class Initialized
INFO - 2019-07-21 10:46:08 --> Hooks Class Initialized
DEBUG - 2019-07-21 10:46:08 --> UTF-8 Support Enabled
INFO - 2019-07-21 10:46:08 --> Utf8 Class Initialized
INFO - 2019-07-21 10:46:08 --> URI Class Initialized
INFO - 2019-07-21 10:46:08 --> Router Class Initialized
INFO - 2019-07-21 10:46:08 --> Output Class Initialized
INFO - 2019-07-21 10:46:08 --> Config Class Initialized
INFO - 2019-07-21 10:46:08 --> Hooks Class Initialized
INFO - 2019-07-21 10:46:08 --> Security Class Initialized
DEBUG - 2019-07-21 10:46:08 --> UTF-8 Support Enabled
INFO - 2019-07-21 10:46:08 --> Utf8 Class Initialized
INFO - 2019-07-21 10:46:08 --> URI Class Initialized
DEBUG - 2019-07-21 10:46:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 10:46:08 --> Input Class Initialized
INFO - 2019-07-21 10:46:08 --> Language Class Initialized
INFO - 2019-07-21 10:46:08 --> Router Class Initialized
INFO - 2019-07-21 10:46:08 --> Output Class Initialized
INFO - 2019-07-21 10:46:08 --> Loader Class Initialized
INFO - 2019-07-21 10:46:08 --> Security Class Initialized
DEBUG - 2019-07-21 10:46:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 10:46:08 --> Input Class Initialized
INFO - 2019-07-21 10:46:08 --> Language Class Initialized
INFO - 2019-07-21 10:46:08 --> Loader Class Initialized
INFO - 2019-07-21 10:46:08 --> Database Driver Class Initialized
INFO - 2019-07-21 10:46:08 --> Controller Class Initialized
INFO - 2019-07-21 10:46:08 --> Model "Product" initialized
INFO - 2019-07-21 10:46:08 --> Final output sent to browser
DEBUG - 2019-07-21 10:46:08 --> Total execution time: 0.0469
INFO - 2019-07-21 10:46:08 --> Database Driver Class Initialized
INFO - 2019-07-21 10:46:08 --> Controller Class Initialized
INFO - 2019-07-21 10:46:08 --> Model "Product" initialized
INFO - 2019-07-21 10:46:08 --> Final output sent to browser
DEBUG - 2019-07-21 10:46:08 --> Total execution time: 0.0428
INFO - 2019-07-21 10:46:19 --> Config Class Initialized
INFO - 2019-07-21 10:46:19 --> Hooks Class Initialized
DEBUG - 2019-07-21 10:46:19 --> UTF-8 Support Enabled
INFO - 2019-07-21 10:46:19 --> Utf8 Class Initialized
INFO - 2019-07-21 10:46:19 --> URI Class Initialized
INFO - 2019-07-21 10:46:19 --> Router Class Initialized
INFO - 2019-07-21 10:46:19 --> Output Class Initialized
INFO - 2019-07-21 10:46:19 --> Config Class Initialized
INFO - 2019-07-21 10:46:19 --> Hooks Class Initialized
INFO - 2019-07-21 10:46:19 --> Security Class Initialized
DEBUG - 2019-07-21 10:46:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 10:46:19 --> Input Class Initialized
DEBUG - 2019-07-21 10:46:19 --> UTF-8 Support Enabled
INFO - 2019-07-21 10:46:19 --> Utf8 Class Initialized
INFO - 2019-07-21 10:46:19 --> Language Class Initialized
INFO - 2019-07-21 10:46:19 --> URI Class Initialized
INFO - 2019-07-21 10:46:19 --> Loader Class Initialized
INFO - 2019-07-21 10:46:19 --> Router Class Initialized
INFO - 2019-07-21 10:46:19 --> Output Class Initialized
INFO - 2019-07-21 10:46:19 --> Security Class Initialized
DEBUG - 2019-07-21 10:46:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 10:46:19 --> Input Class Initialized
INFO - 2019-07-21 10:46:19 --> Language Class Initialized
INFO - 2019-07-21 10:46:19 --> Database Driver Class Initialized
INFO - 2019-07-21 10:46:19 --> Loader Class Initialized
INFO - 2019-07-21 10:46:19 --> Controller Class Initialized
INFO - 2019-07-21 10:46:19 --> Model "Product" initialized
INFO - 2019-07-21 10:46:19 --> Database Driver Class Initialized
INFO - 2019-07-21 10:46:19 --> Controller Class Initialized
INFO - 2019-07-21 10:46:19 --> Model "Product" initialized
INFO - 2019-07-21 10:46:19 --> Final output sent to browser
DEBUG - 2019-07-21 10:46:19 --> Total execution time: 0.0257
INFO - 2019-07-21 10:46:19 --> Final output sent to browser
DEBUG - 2019-07-21 10:46:19 --> Total execution time: 0.0484
INFO - 2019-07-21 10:50:01 --> Config Class Initialized
INFO - 2019-07-21 10:50:01 --> Hooks Class Initialized
DEBUG - 2019-07-21 10:50:01 --> UTF-8 Support Enabled
INFO - 2019-07-21 10:50:01 --> Utf8 Class Initialized
INFO - 2019-07-21 10:50:01 --> URI Class Initialized
INFO - 2019-07-21 10:50:01 --> Router Class Initialized
INFO - 2019-07-21 10:50:01 --> Output Class Initialized
INFO - 2019-07-21 10:50:01 --> Security Class Initialized
DEBUG - 2019-07-21 10:50:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 10:50:01 --> Input Class Initialized
INFO - 2019-07-21 10:50:01 --> Language Class Initialized
INFO - 2019-07-21 10:50:01 --> Config Class Initialized
INFO - 2019-07-21 10:50:01 --> Hooks Class Initialized
DEBUG - 2019-07-21 10:50:01 --> UTF-8 Support Enabled
INFO - 2019-07-21 10:50:01 --> Utf8 Class Initialized
INFO - 2019-07-21 10:50:01 --> URI Class Initialized
INFO - 2019-07-21 10:50:01 --> Loader Class Initialized
INFO - 2019-07-21 10:50:01 --> Router Class Initialized
INFO - 2019-07-21 10:50:01 --> Output Class Initialized
INFO - 2019-07-21 10:50:01 --> Database Driver Class Initialized
INFO - 2019-07-21 10:50:01 --> Security Class Initialized
INFO - 2019-07-21 10:50:01 --> Controller Class Initialized
INFO - 2019-07-21 10:50:01 --> Model "Product" initialized
DEBUG - 2019-07-21 10:50:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 10:50:01 --> Input Class Initialized
INFO - 2019-07-21 10:50:01 --> Language Class Initialized
INFO - 2019-07-21 10:50:01 --> Final output sent to browser
DEBUG - 2019-07-21 10:50:01 --> Total execution time: 0.0329
INFO - 2019-07-21 10:50:01 --> Loader Class Initialized
INFO - 2019-07-21 10:50:01 --> Database Driver Class Initialized
INFO - 2019-07-21 10:50:01 --> Controller Class Initialized
INFO - 2019-07-21 10:50:01 --> Model "Product" initialized
INFO - 2019-07-21 10:50:01 --> Final output sent to browser
DEBUG - 2019-07-21 10:50:01 --> Total execution time: 0.0458
INFO - 2019-07-21 10:50:26 --> Config Class Initialized
INFO - 2019-07-21 10:50:26 --> Hooks Class Initialized
DEBUG - 2019-07-21 10:50:26 --> UTF-8 Support Enabled
INFO - 2019-07-21 10:50:26 --> Utf8 Class Initialized
INFO - 2019-07-21 10:50:26 --> URI Class Initialized
INFO - 2019-07-21 10:50:26 --> Router Class Initialized
INFO - 2019-07-21 10:50:26 --> Output Class Initialized
INFO - 2019-07-21 10:50:26 --> Security Class Initialized
DEBUG - 2019-07-21 10:50:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 10:50:26 --> Input Class Initialized
INFO - 2019-07-21 10:50:26 --> Language Class Initialized
INFO - 2019-07-21 10:50:26 --> Loader Class Initialized
INFO - 2019-07-21 10:50:26 --> Config Class Initialized
INFO - 2019-07-21 10:50:26 --> Hooks Class Initialized
DEBUG - 2019-07-21 10:50:26 --> UTF-8 Support Enabled
INFO - 2019-07-21 10:50:26 --> Utf8 Class Initialized
INFO - 2019-07-21 10:50:26 --> Database Driver Class Initialized
INFO - 2019-07-21 10:50:26 --> Controller Class Initialized
INFO - 2019-07-21 10:50:26 --> Model "Product" initialized
INFO - 2019-07-21 10:50:26 --> Final output sent to browser
DEBUG - 2019-07-21 10:50:26 --> Total execution time: 0.0279
INFO - 2019-07-21 10:50:26 --> URI Class Initialized
INFO - 2019-07-21 10:50:26 --> Router Class Initialized
INFO - 2019-07-21 10:50:26 --> Output Class Initialized
INFO - 2019-07-21 10:50:26 --> Security Class Initialized
DEBUG - 2019-07-21 10:50:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 10:50:26 --> Input Class Initialized
INFO - 2019-07-21 10:50:26 --> Language Class Initialized
INFO - 2019-07-21 10:50:26 --> Loader Class Initialized
INFO - 2019-07-21 10:50:26 --> Database Driver Class Initialized
INFO - 2019-07-21 10:50:26 --> Controller Class Initialized
INFO - 2019-07-21 10:50:26 --> Model "Product" initialized
INFO - 2019-07-21 10:50:26 --> Final output sent to browser
DEBUG - 2019-07-21 10:50:26 --> Total execution time: 0.0402
INFO - 2019-07-21 10:50:56 --> Config Class Initialized
INFO - 2019-07-21 10:50:56 --> Hooks Class Initialized
DEBUG - 2019-07-21 10:50:56 --> UTF-8 Support Enabled
INFO - 2019-07-21 10:50:56 --> Utf8 Class Initialized
INFO - 2019-07-21 10:50:56 --> URI Class Initialized
INFO - 2019-07-21 10:50:56 --> Router Class Initialized
INFO - 2019-07-21 10:50:56 --> Output Class Initialized
INFO - 2019-07-21 10:50:56 --> Config Class Initialized
INFO - 2019-07-21 10:50:56 --> Hooks Class Initialized
DEBUG - 2019-07-21 10:50:56 --> UTF-8 Support Enabled
INFO - 2019-07-21 10:50:56 --> Utf8 Class Initialized
INFO - 2019-07-21 10:50:56 --> URI Class Initialized
INFO - 2019-07-21 10:50:56 --> Router Class Initialized
INFO - 2019-07-21 10:50:56 --> Output Class Initialized
INFO - 2019-07-21 10:50:56 --> Security Class Initialized
INFO - 2019-07-21 10:50:56 --> Security Class Initialized
DEBUG - 2019-07-21 10:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 10:50:56 --> Input Class Initialized
INFO - 2019-07-21 10:50:56 --> Language Class Initialized
INFO - 2019-07-21 10:50:56 --> Loader Class Initialized
DEBUG - 2019-07-21 10:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 10:50:56 --> Input Class Initialized
INFO - 2019-07-21 10:50:56 --> Language Class Initialized
INFO - 2019-07-21 10:50:56 --> Loader Class Initialized
INFO - 2019-07-21 10:50:56 --> Database Driver Class Initialized
INFO - 2019-07-21 10:50:56 --> Database Driver Class Initialized
INFO - 2019-07-21 10:50:56 --> Controller Class Initialized
INFO - 2019-07-21 10:50:56 --> Controller Class Initialized
INFO - 2019-07-21 10:50:56 --> Model "Product" initialized
INFO - 2019-07-21 10:50:56 --> Model "Product" initialized
INFO - 2019-07-21 10:50:56 --> Final output sent to browser
DEBUG - 2019-07-21 10:50:56 --> Total execution time: 0.0428
INFO - 2019-07-21 10:50:56 --> Final output sent to browser
DEBUG - 2019-07-21 10:50:56 --> Total execution time: 0.0632
INFO - 2019-07-21 10:53:00 --> Config Class Initialized
INFO - 2019-07-21 10:53:00 --> Hooks Class Initialized
DEBUG - 2019-07-21 10:53:00 --> UTF-8 Support Enabled
INFO - 2019-07-21 10:53:00 --> Utf8 Class Initialized
INFO - 2019-07-21 10:53:00 --> URI Class Initialized
INFO - 2019-07-21 10:53:00 --> Router Class Initialized
INFO - 2019-07-21 10:53:00 --> Output Class Initialized
INFO - 2019-07-21 10:53:00 --> Security Class Initialized
INFO - 2019-07-21 10:53:00 --> Config Class Initialized
INFO - 2019-07-21 10:53:00 --> Hooks Class Initialized
DEBUG - 2019-07-21 10:53:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 10:53:00 --> Input Class Initialized
INFO - 2019-07-21 10:53:00 --> Language Class Initialized
INFO - 2019-07-21 10:53:00 --> Loader Class Initialized
DEBUG - 2019-07-21 10:53:00 --> UTF-8 Support Enabled
INFO - 2019-07-21 10:53:00 --> Utf8 Class Initialized
INFO - 2019-07-21 10:53:00 --> URI Class Initialized
INFO - 2019-07-21 10:53:00 --> Router Class Initialized
INFO - 2019-07-21 10:53:00 --> Output Class Initialized
INFO - 2019-07-21 10:53:00 --> Security Class Initialized
DEBUG - 2019-07-21 10:53:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 10:53:00 --> Input Class Initialized
INFO - 2019-07-21 10:53:00 --> Language Class Initialized
INFO - 2019-07-21 10:53:00 --> Database Driver Class Initialized
INFO - 2019-07-21 10:53:00 --> Controller Class Initialized
INFO - 2019-07-21 10:53:00 --> Model "Product" initialized
INFO - 2019-07-21 10:53:00 --> Loader Class Initialized
INFO - 2019-07-21 10:53:00 --> Final output sent to browser
DEBUG - 2019-07-21 10:53:00 --> Total execution time: 0.0912
INFO - 2019-07-21 10:53:00 --> Database Driver Class Initialized
INFO - 2019-07-21 10:53:00 --> Controller Class Initialized
INFO - 2019-07-21 10:53:00 --> Model "Product" initialized
INFO - 2019-07-21 10:53:00 --> Final output sent to browser
DEBUG - 2019-07-21 10:53:00 --> Total execution time: 0.1106
INFO - 2019-07-21 10:54:20 --> Config Class Initialized
INFO - 2019-07-21 10:54:20 --> Hooks Class Initialized
DEBUG - 2019-07-21 10:54:20 --> UTF-8 Support Enabled
INFO - 2019-07-21 10:54:20 --> Utf8 Class Initialized
INFO - 2019-07-21 10:54:20 --> URI Class Initialized
INFO - 2019-07-21 10:54:20 --> Router Class Initialized
INFO - 2019-07-21 10:54:20 --> Config Class Initialized
INFO - 2019-07-21 10:54:20 --> Hooks Class Initialized
INFO - 2019-07-21 10:54:20 --> Output Class Initialized
DEBUG - 2019-07-21 10:54:20 --> UTF-8 Support Enabled
INFO - 2019-07-21 10:54:20 --> Utf8 Class Initialized
INFO - 2019-07-21 10:54:20 --> URI Class Initialized
INFO - 2019-07-21 10:54:20 --> Security Class Initialized
INFO - 2019-07-21 10:54:20 --> Router Class Initialized
DEBUG - 2019-07-21 10:54:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 10:54:20 --> Input Class Initialized
INFO - 2019-07-21 10:54:20 --> Language Class Initialized
INFO - 2019-07-21 10:54:20 --> Output Class Initialized
INFO - 2019-07-21 10:54:20 --> Security Class Initialized
INFO - 2019-07-21 10:54:20 --> Loader Class Initialized
DEBUG - 2019-07-21 10:54:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 10:54:20 --> Input Class Initialized
INFO - 2019-07-21 10:54:20 --> Language Class Initialized
INFO - 2019-07-21 10:54:20 --> Loader Class Initialized
INFO - 2019-07-21 10:54:20 --> Database Driver Class Initialized
INFO - 2019-07-21 10:54:20 --> Controller Class Initialized
INFO - 2019-07-21 10:54:20 --> Model "Product" initialized
INFO - 2019-07-21 10:54:20 --> Final output sent to browser
DEBUG - 2019-07-21 10:54:20 --> Total execution time: 0.0240
INFO - 2019-07-21 10:54:20 --> Database Driver Class Initialized
INFO - 2019-07-21 10:54:20 --> Controller Class Initialized
INFO - 2019-07-21 10:54:20 --> Model "Product" initialized
INFO - 2019-07-21 10:54:20 --> Final output sent to browser
DEBUG - 2019-07-21 10:54:20 --> Total execution time: 0.0280
INFO - 2019-07-21 10:54:37 --> Config Class Initialized
INFO - 2019-07-21 10:54:37 --> Hooks Class Initialized
DEBUG - 2019-07-21 10:54:37 --> UTF-8 Support Enabled
INFO - 2019-07-21 10:54:37 --> Utf8 Class Initialized
INFO - 2019-07-21 10:54:37 --> URI Class Initialized
INFO - 2019-07-21 10:54:37 --> Router Class Initialized
INFO - 2019-07-21 10:54:37 --> Config Class Initialized
INFO - 2019-07-21 10:54:37 --> Hooks Class Initialized
INFO - 2019-07-21 10:54:37 --> Output Class Initialized
INFO - 2019-07-21 10:54:37 --> Security Class Initialized
DEBUG - 2019-07-21 10:54:37 --> UTF-8 Support Enabled
INFO - 2019-07-21 10:54:37 --> Utf8 Class Initialized
DEBUG - 2019-07-21 10:54:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 10:54:37 --> Input Class Initialized
INFO - 2019-07-21 10:54:37 --> Language Class Initialized
INFO - 2019-07-21 10:54:37 --> URI Class Initialized
INFO - 2019-07-21 10:54:37 --> Router Class Initialized
INFO - 2019-07-21 10:54:37 --> Loader Class Initialized
INFO - 2019-07-21 10:54:37 --> Output Class Initialized
INFO - 2019-07-21 10:54:37 --> Security Class Initialized
DEBUG - 2019-07-21 10:54:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 10:54:37 --> Input Class Initialized
INFO - 2019-07-21 10:54:37 --> Language Class Initialized
INFO - 2019-07-21 10:54:37 --> Loader Class Initialized
INFO - 2019-07-21 10:54:37 --> Database Driver Class Initialized
INFO - 2019-07-21 10:54:37 --> Controller Class Initialized
INFO - 2019-07-21 10:54:37 --> Model "Product" initialized
INFO - 2019-07-21 10:54:37 --> Final output sent to browser
DEBUG - 2019-07-21 10:54:37 --> Total execution time: 0.0232
INFO - 2019-07-21 10:54:37 --> Database Driver Class Initialized
INFO - 2019-07-21 10:54:37 --> Controller Class Initialized
INFO - 2019-07-21 10:54:37 --> Model "Product" initialized
INFO - 2019-07-21 10:54:37 --> Final output sent to browser
DEBUG - 2019-07-21 10:54:37 --> Total execution time: 0.0275
INFO - 2019-07-21 10:54:53 --> Config Class Initialized
INFO - 2019-07-21 10:54:53 --> Config Class Initialized
INFO - 2019-07-21 10:54:53 --> Hooks Class Initialized
INFO - 2019-07-21 10:54:53 --> Hooks Class Initialized
DEBUG - 2019-07-21 10:54:53 --> UTF-8 Support Enabled
INFO - 2019-07-21 10:54:53 --> Utf8 Class Initialized
INFO - 2019-07-21 10:54:53 --> URI Class Initialized
DEBUG - 2019-07-21 10:54:53 --> UTF-8 Support Enabled
INFO - 2019-07-21 10:54:53 --> Utf8 Class Initialized
INFO - 2019-07-21 10:54:53 --> Router Class Initialized
INFO - 2019-07-21 10:54:53 --> URI Class Initialized
INFO - 2019-07-21 10:54:53 --> Router Class Initialized
INFO - 2019-07-21 10:54:53 --> Output Class Initialized
INFO - 2019-07-21 10:54:53 --> Security Class Initialized
INFO - 2019-07-21 10:54:53 --> Output Class Initialized
INFO - 2019-07-21 10:54:53 --> Security Class Initialized
DEBUG - 2019-07-21 10:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 10:54:53 --> Input Class Initialized
DEBUG - 2019-07-21 10:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 10:54:53 --> Input Class Initialized
INFO - 2019-07-21 10:54:53 --> Language Class Initialized
INFO - 2019-07-21 10:54:53 --> Language Class Initialized
INFO - 2019-07-21 10:54:53 --> Loader Class Initialized
INFO - 2019-07-21 10:54:53 --> Loader Class Initialized
INFO - 2019-07-21 10:54:53 --> Database Driver Class Initialized
INFO - 2019-07-21 10:54:53 --> Database Driver Class Initialized
INFO - 2019-07-21 10:54:53 --> Controller Class Initialized
INFO - 2019-07-21 10:54:53 --> Controller Class Initialized
INFO - 2019-07-21 10:54:53 --> Model "Product" initialized
INFO - 2019-07-21 10:54:53 --> Model "Product" initialized
INFO - 2019-07-21 10:54:53 --> Final output sent to browser
DEBUG - 2019-07-21 10:54:53 --> Total execution time: 0.0334
INFO - 2019-07-21 10:54:53 --> Final output sent to browser
DEBUG - 2019-07-21 10:54:53 --> Total execution time: 0.0383
INFO - 2019-07-21 11:00:48 --> Config Class Initialized
INFO - 2019-07-21 11:00:48 --> Config Class Initialized
INFO - 2019-07-21 11:00:48 --> Hooks Class Initialized
INFO - 2019-07-21 11:00:48 --> Hooks Class Initialized
DEBUG - 2019-07-21 11:00:49 --> UTF-8 Support Enabled
INFO - 2019-07-21 11:00:49 --> Utf8 Class Initialized
DEBUG - 2019-07-21 11:00:49 --> UTF-8 Support Enabled
INFO - 2019-07-21 11:00:49 --> Utf8 Class Initialized
INFO - 2019-07-21 11:00:49 --> URI Class Initialized
INFO - 2019-07-21 11:00:49 --> URI Class Initialized
INFO - 2019-07-21 11:00:49 --> Router Class Initialized
INFO - 2019-07-21 11:00:49 --> Router Class Initialized
INFO - 2019-07-21 11:00:49 --> Output Class Initialized
INFO - 2019-07-21 11:00:49 --> Output Class Initialized
INFO - 2019-07-21 11:00:49 --> Security Class Initialized
INFO - 2019-07-21 11:00:49 --> Security Class Initialized
DEBUG - 2019-07-21 11:00:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-21 11:00:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 11:00:49 --> Input Class Initialized
INFO - 2019-07-21 11:00:49 --> Input Class Initialized
INFO - 2019-07-21 11:00:49 --> Language Class Initialized
INFO - 2019-07-21 11:00:49 --> Language Class Initialized
INFO - 2019-07-21 11:00:50 --> Loader Class Initialized
INFO - 2019-07-21 11:00:50 --> Loader Class Initialized
INFO - 2019-07-21 11:00:50 --> Database Driver Class Initialized
INFO - 2019-07-21 11:00:50 --> Database Driver Class Initialized
INFO - 2019-07-21 11:00:53 --> Controller Class Initialized
INFO - 2019-07-21 11:00:53 --> Controller Class Initialized
INFO - 2019-07-21 11:00:53 --> Model "Product" initialized
INFO - 2019-07-21 11:00:53 --> Model "Product" initialized
INFO - 2019-07-21 11:00:55 --> Final output sent to browser
DEBUG - 2019-07-21 11:00:55 --> Total execution time: 7.5377
INFO - 2019-07-21 11:00:55 --> Final output sent to browser
DEBUG - 2019-07-21 11:00:55 --> Total execution time: 7.5382
INFO - 2019-07-21 11:06:01 --> Config Class Initialized
INFO - 2019-07-21 11:06:01 --> Config Class Initialized
INFO - 2019-07-21 11:06:01 --> Hooks Class Initialized
INFO - 2019-07-21 11:06:01 --> Hooks Class Initialized
DEBUG - 2019-07-21 11:06:02 --> UTF-8 Support Enabled
INFO - 2019-07-21 11:06:02 --> Utf8 Class Initialized
DEBUG - 2019-07-21 11:06:02 --> UTF-8 Support Enabled
INFO - 2019-07-21 11:06:02 --> Utf8 Class Initialized
INFO - 2019-07-21 11:06:02 --> URI Class Initialized
INFO - 2019-07-21 11:06:02 --> URI Class Initialized
INFO - 2019-07-21 11:06:02 --> Router Class Initialized
INFO - 2019-07-21 11:06:02 --> Router Class Initialized
INFO - 2019-07-21 11:06:02 --> Output Class Initialized
INFO - 2019-07-21 11:06:02 --> Security Class Initialized
DEBUG - 2019-07-21 11:06:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 11:06:02 --> Input Class Initialized
INFO - 2019-07-21 11:06:02 --> Output Class Initialized
INFO - 2019-07-21 11:06:02 --> Language Class Initialized
INFO - 2019-07-21 11:06:03 --> Security Class Initialized
DEBUG - 2019-07-21 11:06:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 11:06:03 --> Input Class Initialized
INFO - 2019-07-21 11:06:03 --> Language Class Initialized
INFO - 2019-07-21 11:06:03 --> Loader Class Initialized
INFO - 2019-07-21 11:06:03 --> Loader Class Initialized
INFO - 2019-07-21 11:06:03 --> Database Driver Class Initialized
INFO - 2019-07-21 11:06:03 --> Database Driver Class Initialized
INFO - 2019-07-21 11:06:05 --> Controller Class Initialized
INFO - 2019-07-21 11:06:05 --> Controller Class Initialized
INFO - 2019-07-21 11:06:06 --> Model "Product" initialized
INFO - 2019-07-21 11:06:06 --> Model "Product" initialized
INFO - 2019-07-21 11:06:06 --> Final output sent to browser
DEBUG - 2019-07-21 11:06:06 --> Total execution time: 5.7548
INFO - 2019-07-21 11:06:06 --> Final output sent to browser
DEBUG - 2019-07-21 11:06:06 --> Total execution time: 6.5847
INFO - 2019-07-21 11:06:47 --> Config Class Initialized
INFO - 2019-07-21 11:06:47 --> Hooks Class Initialized
DEBUG - 2019-07-21 11:06:47 --> UTF-8 Support Enabled
INFO - 2019-07-21 11:06:47 --> Utf8 Class Initialized
INFO - 2019-07-21 11:06:47 --> URI Class Initialized
INFO - 2019-07-21 11:06:47 --> Router Class Initialized
INFO - 2019-07-21 11:06:47 --> Output Class Initialized
INFO - 2019-07-21 11:06:47 --> Security Class Initialized
DEBUG - 2019-07-21 11:06:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 11:06:47 --> Input Class Initialized
INFO - 2019-07-21 11:06:47 --> Language Class Initialized
INFO - 2019-07-21 11:06:47 --> Loader Class Initialized
INFO - 2019-07-21 11:06:47 --> Database Driver Class Initialized
INFO - 2019-07-21 11:06:47 --> Controller Class Initialized
INFO - 2019-07-21 11:06:47 --> Model "Product" initialized
INFO - 2019-07-21 11:06:48 --> Final output sent to browser
DEBUG - 2019-07-21 11:06:48 --> Total execution time: 0.1665
INFO - 2019-07-21 11:06:48 --> Config Class Initialized
INFO - 2019-07-21 11:06:48 --> Hooks Class Initialized
DEBUG - 2019-07-21 11:06:48 --> UTF-8 Support Enabled
INFO - 2019-07-21 11:06:48 --> Utf8 Class Initialized
INFO - 2019-07-21 11:06:48 --> URI Class Initialized
INFO - 2019-07-21 11:06:48 --> Router Class Initialized
INFO - 2019-07-21 11:06:48 --> Output Class Initialized
INFO - 2019-07-21 11:06:48 --> Security Class Initialized
DEBUG - 2019-07-21 11:06:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 11:06:48 --> Input Class Initialized
INFO - 2019-07-21 11:06:48 --> Language Class Initialized
INFO - 2019-07-21 11:06:48 --> Loader Class Initialized
INFO - 2019-07-21 11:06:48 --> Database Driver Class Initialized
INFO - 2019-07-21 11:06:48 --> Controller Class Initialized
INFO - 2019-07-21 11:06:48 --> Model "Product" initialized
INFO - 2019-07-21 11:06:48 --> Final output sent to browser
DEBUG - 2019-07-21 11:06:48 --> Total execution time: 0.8024
INFO - 2019-07-21 11:06:53 --> Config Class Initialized
INFO - 2019-07-21 11:06:53 --> Hooks Class Initialized
DEBUG - 2019-07-21 11:06:53 --> UTF-8 Support Enabled
INFO - 2019-07-21 11:06:53 --> Utf8 Class Initialized
INFO - 2019-07-21 11:06:53 --> URI Class Initialized
INFO - 2019-07-21 11:06:53 --> Router Class Initialized
INFO - 2019-07-21 11:06:53 --> Output Class Initialized
INFO - 2019-07-21 11:06:53 --> Security Class Initialized
DEBUG - 2019-07-21 11:06:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 11:06:53 --> Input Class Initialized
INFO - 2019-07-21 11:06:53 --> Language Class Initialized
INFO - 2019-07-21 11:06:53 --> Loader Class Initialized
INFO - 2019-07-21 11:06:53 --> Database Driver Class Initialized
INFO - 2019-07-21 11:06:53 --> Controller Class Initialized
INFO - 2019-07-21 11:06:53 --> Model "Product" initialized
INFO - 2019-07-21 11:06:53 --> Final output sent to browser
DEBUG - 2019-07-21 11:06:53 --> Total execution time: 0.0423
INFO - 2019-07-21 11:06:55 --> Config Class Initialized
INFO - 2019-07-21 11:06:55 --> Hooks Class Initialized
DEBUG - 2019-07-21 11:06:55 --> UTF-8 Support Enabled
INFO - 2019-07-21 11:06:55 --> Utf8 Class Initialized
INFO - 2019-07-21 11:06:55 --> URI Class Initialized
INFO - 2019-07-21 11:06:55 --> Router Class Initialized
INFO - 2019-07-21 11:06:55 --> Output Class Initialized
INFO - 2019-07-21 11:06:55 --> Security Class Initialized
DEBUG - 2019-07-21 11:06:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 11:06:55 --> Input Class Initialized
INFO - 2019-07-21 11:06:55 --> Language Class Initialized
INFO - 2019-07-21 11:06:55 --> Loader Class Initialized
INFO - 2019-07-21 11:06:55 --> Database Driver Class Initialized
INFO - 2019-07-21 11:06:55 --> Controller Class Initialized
INFO - 2019-07-21 11:06:55 --> Model "Product" initialized
INFO - 2019-07-21 11:06:55 --> Final output sent to browser
DEBUG - 2019-07-21 11:06:55 --> Total execution time: 0.0166
INFO - 2019-07-21 11:09:53 --> Config Class Initialized
INFO - 2019-07-21 11:09:53 --> Hooks Class Initialized
DEBUG - 2019-07-21 11:09:53 --> UTF-8 Support Enabled
INFO - 2019-07-21 11:09:53 --> Utf8 Class Initialized
INFO - 2019-07-21 11:09:53 --> URI Class Initialized
INFO - 2019-07-21 11:09:53 --> Router Class Initialized
INFO - 2019-07-21 11:09:53 --> Output Class Initialized
INFO - 2019-07-21 11:09:53 --> Security Class Initialized
DEBUG - 2019-07-21 11:09:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 11:09:53 --> Input Class Initialized
INFO - 2019-07-21 11:09:53 --> Language Class Initialized
INFO - 2019-07-21 11:09:53 --> Loader Class Initialized
INFO - 2019-07-21 11:09:53 --> Database Driver Class Initialized
INFO - 2019-07-21 11:09:53 --> Controller Class Initialized
INFO - 2019-07-21 11:09:53 --> Model "Product" initialized
INFO - 2019-07-21 11:09:53 --> Final output sent to browser
DEBUG - 2019-07-21 11:09:53 --> Total execution time: 0.0380
INFO - 2019-07-21 11:09:53 --> Config Class Initialized
INFO - 2019-07-21 11:09:53 --> Hooks Class Initialized
DEBUG - 2019-07-21 11:09:53 --> UTF-8 Support Enabled
INFO - 2019-07-21 11:09:53 --> Utf8 Class Initialized
INFO - 2019-07-21 11:09:53 --> URI Class Initialized
INFO - 2019-07-21 11:09:53 --> Router Class Initialized
INFO - 2019-07-21 11:09:53 --> Output Class Initialized
INFO - 2019-07-21 11:09:53 --> Security Class Initialized
DEBUG - 2019-07-21 11:09:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 11:09:53 --> Input Class Initialized
INFO - 2019-07-21 11:09:53 --> Language Class Initialized
INFO - 2019-07-21 11:09:53 --> Loader Class Initialized
INFO - 2019-07-21 11:09:53 --> Database Driver Class Initialized
INFO - 2019-07-21 11:09:53 --> Controller Class Initialized
INFO - 2019-07-21 11:09:53 --> Model "Product" initialized
INFO - 2019-07-21 11:09:53 --> Final output sent to browser
DEBUG - 2019-07-21 11:09:53 --> Total execution time: 0.3121
INFO - 2019-07-21 11:10:10 --> Config Class Initialized
INFO - 2019-07-21 11:10:10 --> Hooks Class Initialized
DEBUG - 2019-07-21 11:10:10 --> UTF-8 Support Enabled
INFO - 2019-07-21 11:10:10 --> Utf8 Class Initialized
INFO - 2019-07-21 11:10:10 --> URI Class Initialized
INFO - 2019-07-21 11:10:10 --> Router Class Initialized
INFO - 2019-07-21 11:10:10 --> Output Class Initialized
INFO - 2019-07-21 11:10:10 --> Security Class Initialized
DEBUG - 2019-07-21 11:10:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 11:10:10 --> Input Class Initialized
INFO - 2019-07-21 11:10:10 --> Config Class Initialized
INFO - 2019-07-21 11:10:10 --> Hooks Class Initialized
DEBUG - 2019-07-21 11:10:10 --> UTF-8 Support Enabled
INFO - 2019-07-21 11:10:10 --> Utf8 Class Initialized
INFO - 2019-07-21 11:10:10 --> URI Class Initialized
INFO - 2019-07-21 11:10:10 --> Router Class Initialized
INFO - 2019-07-21 11:10:10 --> Output Class Initialized
INFO - 2019-07-21 11:10:10 --> Security Class Initialized
INFO - 2019-07-21 11:10:10 --> Language Class Initialized
INFO - 2019-07-21 11:10:10 --> Loader Class Initialized
INFO - 2019-07-21 11:10:10 --> Database Driver Class Initialized
DEBUG - 2019-07-21 11:10:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 11:10:10 --> Input Class Initialized
INFO - 2019-07-21 11:10:10 --> Language Class Initialized
INFO - 2019-07-21 11:10:10 --> Controller Class Initialized
INFO - 2019-07-21 11:10:10 --> Model "Product" initialized
INFO - 2019-07-21 11:10:10 --> Loader Class Initialized
INFO - 2019-07-21 11:10:10 --> Final output sent to browser
DEBUG - 2019-07-21 11:10:10 --> Total execution time: 0.0403
INFO - 2019-07-21 11:10:10 --> Database Driver Class Initialized
INFO - 2019-07-21 11:10:10 --> Controller Class Initialized
INFO - 2019-07-21 11:10:10 --> Model "Product" initialized
INFO - 2019-07-21 11:10:10 --> Final output sent to browser
DEBUG - 2019-07-21 11:10:10 --> Total execution time: 0.0945
INFO - 2019-07-21 11:10:31 --> Config Class Initialized
INFO - 2019-07-21 11:10:31 --> Hooks Class Initialized
DEBUG - 2019-07-21 11:10:31 --> UTF-8 Support Enabled
INFO - 2019-07-21 11:10:31 --> Utf8 Class Initialized
INFO - 2019-07-21 11:10:31 --> URI Class Initialized
INFO - 2019-07-21 11:10:31 --> Router Class Initialized
INFO - 2019-07-21 11:10:31 --> Output Class Initialized
INFO - 2019-07-21 11:10:31 --> Security Class Initialized
DEBUG - 2019-07-21 11:10:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 11:10:31 --> Input Class Initialized
INFO - 2019-07-21 11:10:31 --> Language Class Initialized
INFO - 2019-07-21 11:10:31 --> Loader Class Initialized
INFO - 2019-07-21 11:10:31 --> Database Driver Class Initialized
INFO - 2019-07-21 11:10:31 --> Controller Class Initialized
INFO - 2019-07-21 11:10:31 --> Model "Product" initialized
INFO - 2019-07-21 11:10:31 --> Config Class Initialized
INFO - 2019-07-21 11:10:31 --> Hooks Class Initialized
DEBUG - 2019-07-21 11:10:31 --> UTF-8 Support Enabled
INFO - 2019-07-21 11:10:31 --> Utf8 Class Initialized
INFO - 2019-07-21 11:10:31 --> URI Class Initialized
INFO - 2019-07-21 11:10:31 --> Router Class Initialized
INFO - 2019-07-21 11:10:31 --> Output Class Initialized
INFO - 2019-07-21 11:10:31 --> Security Class Initialized
DEBUG - 2019-07-21 11:10:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 11:10:31 --> Input Class Initialized
INFO - 2019-07-21 11:10:31 --> Language Class Initialized
INFO - 2019-07-21 11:10:31 --> Loader Class Initialized
INFO - 2019-07-21 11:10:31 --> Database Driver Class Initialized
INFO - 2019-07-21 11:10:31 --> Controller Class Initialized
INFO - 2019-07-21 11:10:31 --> Model "Product" initialized
INFO - 2019-07-21 11:12:04 --> Config Class Initialized
INFO - 2019-07-21 11:12:04 --> Hooks Class Initialized
DEBUG - 2019-07-21 11:12:04 --> UTF-8 Support Enabled
INFO - 2019-07-21 11:12:04 --> Utf8 Class Initialized
INFO - 2019-07-21 11:12:04 --> URI Class Initialized
INFO - 2019-07-21 11:12:04 --> Router Class Initialized
INFO - 2019-07-21 11:12:04 --> Output Class Initialized
INFO - 2019-07-21 11:12:04 --> Security Class Initialized
DEBUG - 2019-07-21 11:12:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 11:12:04 --> Input Class Initialized
INFO - 2019-07-21 11:12:04 --> Language Class Initialized
INFO - 2019-07-21 11:12:04 --> Loader Class Initialized
INFO - 2019-07-21 11:12:04 --> Config Class Initialized
INFO - 2019-07-21 11:12:04 --> Hooks Class Initialized
DEBUG - 2019-07-21 11:12:04 --> UTF-8 Support Enabled
INFO - 2019-07-21 11:12:04 --> Utf8 Class Initialized
INFO - 2019-07-21 11:12:04 --> URI Class Initialized
INFO - 2019-07-21 11:12:04 --> Router Class Initialized
INFO - 2019-07-21 11:12:04 --> Output Class Initialized
INFO - 2019-07-21 11:12:04 --> Security Class Initialized
DEBUG - 2019-07-21 11:12:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 11:12:04 --> Input Class Initialized
INFO - 2019-07-21 11:12:04 --> Language Class Initialized
INFO - 2019-07-21 11:12:04 --> Loader Class Initialized
INFO - 2019-07-21 11:12:04 --> Database Driver Class Initialized
INFO - 2019-07-21 11:12:04 --> Controller Class Initialized
INFO - 2019-07-21 11:12:04 --> Model "Product" initialized
INFO - 2019-07-21 11:12:04 --> Final output sent to browser
DEBUG - 2019-07-21 11:12:04 --> Total execution time: 0.0325
INFO - 2019-07-21 11:12:04 --> Database Driver Class Initialized
INFO - 2019-07-21 11:12:04 --> Controller Class Initialized
INFO - 2019-07-21 11:12:04 --> Model "Product" initialized
INFO - 2019-07-21 11:12:04 --> Final output sent to browser
DEBUG - 2019-07-21 11:12:04 --> Total execution time: 0.0234
INFO - 2019-07-21 11:12:08 --> Config Class Initialized
INFO - 2019-07-21 11:12:08 --> Hooks Class Initialized
DEBUG - 2019-07-21 11:12:08 --> UTF-8 Support Enabled
INFO - 2019-07-21 11:12:08 --> Utf8 Class Initialized
INFO - 2019-07-21 11:12:08 --> URI Class Initialized
INFO - 2019-07-21 11:12:08 --> Router Class Initialized
INFO - 2019-07-21 11:12:08 --> Output Class Initialized
INFO - 2019-07-21 11:12:08 --> Security Class Initialized
DEBUG - 2019-07-21 11:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 11:12:08 --> Input Class Initialized
INFO - 2019-07-21 11:12:08 --> Language Class Initialized
INFO - 2019-07-21 11:12:08 --> Loader Class Initialized
INFO - 2019-07-21 11:12:08 --> Database Driver Class Initialized
INFO - 2019-07-21 11:12:08 --> Controller Class Initialized
INFO - 2019-07-21 11:12:08 --> Model "Product" initialized
INFO - 2019-07-21 11:12:08 --> Final output sent to browser
DEBUG - 2019-07-21 11:12:08 --> Total execution time: 0.0177
INFO - 2019-07-21 11:12:19 --> Config Class Initialized
INFO - 2019-07-21 11:12:19 --> Hooks Class Initialized
DEBUG - 2019-07-21 11:12:19 --> UTF-8 Support Enabled
INFO - 2019-07-21 11:12:19 --> Utf8 Class Initialized
INFO - 2019-07-21 11:12:19 --> URI Class Initialized
INFO - 2019-07-21 11:12:19 --> Router Class Initialized
INFO - 2019-07-21 11:12:19 --> Output Class Initialized
INFO - 2019-07-21 11:12:19 --> Security Class Initialized
DEBUG - 2019-07-21 11:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 11:12:19 --> Input Class Initialized
INFO - 2019-07-21 11:12:19 --> Language Class Initialized
INFO - 2019-07-21 11:12:19 --> Loader Class Initialized
INFO - 2019-07-21 11:12:19 --> Database Driver Class Initialized
INFO - 2019-07-21 11:12:19 --> Controller Class Initialized
INFO - 2019-07-21 11:12:19 --> Model "Product" initialized
INFO - 2019-07-21 11:12:19 --> Final output sent to browser
DEBUG - 2019-07-21 11:12:19 --> Total execution time: 0.0199
INFO - 2019-07-21 11:12:19 --> Config Class Initialized
INFO - 2019-07-21 11:12:19 --> Hooks Class Initialized
DEBUG - 2019-07-21 11:12:19 --> UTF-8 Support Enabled
INFO - 2019-07-21 11:12:19 --> Utf8 Class Initialized
INFO - 2019-07-21 11:12:19 --> URI Class Initialized
INFO - 2019-07-21 11:12:19 --> Router Class Initialized
INFO - 2019-07-21 11:12:19 --> Output Class Initialized
INFO - 2019-07-21 11:12:19 --> Security Class Initialized
DEBUG - 2019-07-21 11:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 11:12:19 --> Input Class Initialized
INFO - 2019-07-21 11:12:19 --> Language Class Initialized
INFO - 2019-07-21 11:12:19 --> Loader Class Initialized
INFO - 2019-07-21 11:12:19 --> Database Driver Class Initialized
INFO - 2019-07-21 11:12:19 --> Controller Class Initialized
INFO - 2019-07-21 11:12:19 --> Model "Product" initialized
ERROR - 2019-07-21 11:12:20 --> Severity: Notice --> Undefined variable: result /opt/lampp/htdocs/mautic_ci_product/application/models/Product.php 54
INFO - 2019-07-21 11:12:20 --> Final output sent to browser
DEBUG - 2019-07-21 11:12:20 --> Total execution time: 1.1421
INFO - 2019-07-21 12:51:54 --> Config Class Initialized
INFO - 2019-07-21 12:51:54 --> Hooks Class Initialized
DEBUG - 2019-07-21 12:51:54 --> UTF-8 Support Enabled
INFO - 2019-07-21 12:51:54 --> Utf8 Class Initialized
INFO - 2019-07-21 12:51:54 --> URI Class Initialized
INFO - 2019-07-21 12:51:54 --> Router Class Initialized
INFO - 2019-07-21 12:51:54 --> Output Class Initialized
INFO - 2019-07-21 12:51:54 --> Security Class Initialized
DEBUG - 2019-07-21 12:51:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 12:51:54 --> Input Class Initialized
INFO - 2019-07-21 12:51:54 --> Language Class Initialized
INFO - 2019-07-21 12:51:54 --> Loader Class Initialized
INFO - 2019-07-21 12:51:55 --> Database Driver Class Initialized
INFO - 2019-07-21 12:51:55 --> Controller Class Initialized
INFO - 2019-07-21 12:51:55 --> Model "Product" initialized
INFO - 2019-07-21 12:51:56 --> Final output sent to browser
DEBUG - 2019-07-21 12:51:56 --> Total execution time: 2.1002
INFO - 2019-07-21 12:52:04 --> Config Class Initialized
INFO - 2019-07-21 12:52:04 --> Hooks Class Initialized
DEBUG - 2019-07-21 12:52:04 --> UTF-8 Support Enabled
INFO - 2019-07-21 12:52:04 --> Utf8 Class Initialized
INFO - 2019-07-21 12:52:04 --> URI Class Initialized
INFO - 2019-07-21 12:52:04 --> Router Class Initialized
INFO - 2019-07-21 12:52:04 --> Output Class Initialized
INFO - 2019-07-21 12:52:04 --> Security Class Initialized
DEBUG - 2019-07-21 12:52:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 12:52:04 --> Input Class Initialized
INFO - 2019-07-21 12:52:04 --> Language Class Initialized
INFO - 2019-07-21 12:52:04 --> Loader Class Initialized
INFO - 2019-07-21 12:52:04 --> Database Driver Class Initialized
INFO - 2019-07-21 12:52:04 --> Controller Class Initialized
INFO - 2019-07-21 12:52:04 --> Model "Product" initialized
INFO - 2019-07-21 12:52:04 --> Final output sent to browser
DEBUG - 2019-07-21 12:52:04 --> Total execution time: 0.0194
INFO - 2019-07-21 12:52:06 --> Config Class Initialized
INFO - 2019-07-21 12:52:06 --> Hooks Class Initialized
DEBUG - 2019-07-21 12:52:06 --> UTF-8 Support Enabled
INFO - 2019-07-21 12:52:06 --> Utf8 Class Initialized
INFO - 2019-07-21 12:52:06 --> URI Class Initialized
INFO - 2019-07-21 12:52:06 --> Router Class Initialized
INFO - 2019-07-21 12:52:06 --> Output Class Initialized
INFO - 2019-07-21 12:52:06 --> Security Class Initialized
DEBUG - 2019-07-21 12:52:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 12:52:06 --> Input Class Initialized
INFO - 2019-07-21 12:52:06 --> Language Class Initialized
INFO - 2019-07-21 12:52:06 --> Loader Class Initialized
INFO - 2019-07-21 12:52:06 --> Database Driver Class Initialized
INFO - 2019-07-21 12:52:06 --> Controller Class Initialized
INFO - 2019-07-21 12:52:06 --> Model "Product" initialized
INFO - 2019-07-21 12:52:06 --> Final output sent to browser
DEBUG - 2019-07-21 12:52:06 --> Total execution time: 0.0181
INFO - 2019-07-21 12:52:08 --> Config Class Initialized
INFO - 2019-07-21 12:52:08 --> Hooks Class Initialized
DEBUG - 2019-07-21 12:52:08 --> UTF-8 Support Enabled
INFO - 2019-07-21 12:52:08 --> Utf8 Class Initialized
INFO - 2019-07-21 12:52:08 --> URI Class Initialized
INFO - 2019-07-21 12:52:08 --> Router Class Initialized
INFO - 2019-07-21 12:52:08 --> Output Class Initialized
INFO - 2019-07-21 12:52:08 --> Security Class Initialized
DEBUG - 2019-07-21 12:52:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 12:52:08 --> Input Class Initialized
INFO - 2019-07-21 12:52:08 --> Language Class Initialized
INFO - 2019-07-21 12:52:08 --> Loader Class Initialized
INFO - 2019-07-21 12:52:08 --> Database Driver Class Initialized
INFO - 2019-07-21 12:52:08 --> Controller Class Initialized
INFO - 2019-07-21 12:52:08 --> Model "Product" initialized
INFO - 2019-07-21 12:52:08 --> Final output sent to browser
DEBUG - 2019-07-21 12:52:08 --> Total execution time: 0.0211
INFO - 2019-07-21 12:52:09 --> Config Class Initialized
INFO - 2019-07-21 12:52:09 --> Hooks Class Initialized
DEBUG - 2019-07-21 12:52:09 --> UTF-8 Support Enabled
INFO - 2019-07-21 12:52:09 --> Utf8 Class Initialized
INFO - 2019-07-21 12:52:09 --> URI Class Initialized
INFO - 2019-07-21 12:52:09 --> Router Class Initialized
INFO - 2019-07-21 12:52:09 --> Output Class Initialized
INFO - 2019-07-21 12:52:09 --> Security Class Initialized
DEBUG - 2019-07-21 12:52:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 12:52:09 --> Input Class Initialized
INFO - 2019-07-21 12:52:09 --> Language Class Initialized
INFO - 2019-07-21 12:52:09 --> Loader Class Initialized
INFO - 2019-07-21 12:52:09 --> Database Driver Class Initialized
INFO - 2019-07-21 12:52:09 --> Controller Class Initialized
INFO - 2019-07-21 12:52:09 --> Model "Product" initialized
INFO - 2019-07-21 12:52:09 --> Final output sent to browser
DEBUG - 2019-07-21 12:52:09 --> Total execution time: 0.0208
INFO - 2019-07-21 12:53:38 --> Config Class Initialized
INFO - 2019-07-21 12:53:38 --> Hooks Class Initialized
DEBUG - 2019-07-21 12:53:38 --> UTF-8 Support Enabled
INFO - 2019-07-21 12:53:38 --> Utf8 Class Initialized
INFO - 2019-07-21 12:53:38 --> URI Class Initialized
INFO - 2019-07-21 12:53:38 --> Router Class Initialized
INFO - 2019-07-21 12:53:38 --> Output Class Initialized
INFO - 2019-07-21 12:53:38 --> Security Class Initialized
DEBUG - 2019-07-21 12:53:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 12:53:38 --> Input Class Initialized
INFO - 2019-07-21 12:53:38 --> Language Class Initialized
INFO - 2019-07-21 12:53:38 --> Loader Class Initialized
INFO - 2019-07-21 12:53:38 --> Database Driver Class Initialized
INFO - 2019-07-21 12:53:38 --> Controller Class Initialized
INFO - 2019-07-21 12:53:38 --> Model "Product" initialized
INFO - 2019-07-21 12:53:38 --> Final output sent to browser
DEBUG - 2019-07-21 12:53:38 --> Total execution time: 0.0184
INFO - 2019-07-21 12:53:38 --> Config Class Initialized
INFO - 2019-07-21 12:53:38 --> Hooks Class Initialized
DEBUG - 2019-07-21 12:53:38 --> UTF-8 Support Enabled
INFO - 2019-07-21 12:53:38 --> Utf8 Class Initialized
INFO - 2019-07-21 12:53:38 --> URI Class Initialized
INFO - 2019-07-21 12:53:38 --> Router Class Initialized
INFO - 2019-07-21 12:53:38 --> Output Class Initialized
INFO - 2019-07-21 12:53:38 --> Security Class Initialized
DEBUG - 2019-07-21 12:53:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 12:53:38 --> Input Class Initialized
INFO - 2019-07-21 12:53:38 --> Language Class Initialized
INFO - 2019-07-21 12:53:38 --> Loader Class Initialized
INFO - 2019-07-21 12:53:38 --> Database Driver Class Initialized
INFO - 2019-07-21 12:53:38 --> Controller Class Initialized
INFO - 2019-07-21 12:53:38 --> Model "Product" initialized
ERROR - 2019-07-21 12:53:38 --> Severity: Notice --> Undefined variable: result /opt/lampp/htdocs/mautic_ci_product/application/models/Product.php 54
INFO - 2019-07-21 12:53:38 --> Final output sent to browser
DEBUG - 2019-07-21 12:53:38 --> Total execution time: 0.1378
INFO - 2019-07-21 12:54:20 --> Config Class Initialized
INFO - 2019-07-21 12:54:20 --> Hooks Class Initialized
DEBUG - 2019-07-21 12:54:20 --> UTF-8 Support Enabled
INFO - 2019-07-21 12:54:20 --> Utf8 Class Initialized
INFO - 2019-07-21 12:54:20 --> URI Class Initialized
INFO - 2019-07-21 12:54:20 --> Config Class Initialized
INFO - 2019-07-21 12:54:20 --> Hooks Class Initialized
INFO - 2019-07-21 12:54:20 --> Router Class Initialized
DEBUG - 2019-07-21 12:54:20 --> UTF-8 Support Enabled
INFO - 2019-07-21 12:54:20 --> Utf8 Class Initialized
INFO - 2019-07-21 12:54:20 --> Output Class Initialized
INFO - 2019-07-21 12:54:20 --> URI Class Initialized
INFO - 2019-07-21 12:54:20 --> Security Class Initialized
INFO - 2019-07-21 12:54:20 --> Router Class Initialized
DEBUG - 2019-07-21 12:54:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 12:54:20 --> Input Class Initialized
INFO - 2019-07-21 12:54:20 --> Language Class Initialized
INFO - 2019-07-21 12:54:20 --> Output Class Initialized
INFO - 2019-07-21 12:54:20 --> Security Class Initialized
INFO - 2019-07-21 12:54:20 --> Loader Class Initialized
DEBUG - 2019-07-21 12:54:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 12:54:20 --> Input Class Initialized
INFO - 2019-07-21 12:54:20 --> Language Class Initialized
INFO - 2019-07-21 12:54:20 --> Loader Class Initialized
INFO - 2019-07-21 12:54:20 --> Database Driver Class Initialized
INFO - 2019-07-21 12:54:20 --> Controller Class Initialized
INFO - 2019-07-21 12:54:20 --> Model "Product" initialized
INFO - 2019-07-21 12:54:20 --> Final output sent to browser
DEBUG - 2019-07-21 12:54:20 --> Total execution time: 0.0343
INFO - 2019-07-21 12:54:20 --> Database Driver Class Initialized
INFO - 2019-07-21 12:54:20 --> Controller Class Initialized
INFO - 2019-07-21 12:54:20 --> Model "Product" initialized
INFO - 2019-07-21 12:54:20 --> Final output sent to browser
DEBUG - 2019-07-21 12:54:20 --> Total execution time: 0.0440
INFO - 2019-07-21 12:55:12 --> Config Class Initialized
INFO - 2019-07-21 12:55:12 --> Hooks Class Initialized
INFO - 2019-07-21 12:55:12 --> Config Class Initialized
INFO - 2019-07-21 12:55:12 --> Hooks Class Initialized
DEBUG - 2019-07-21 12:55:12 --> UTF-8 Support Enabled
INFO - 2019-07-21 12:55:12 --> Utf8 Class Initialized
INFO - 2019-07-21 12:55:12 --> URI Class Initialized
DEBUG - 2019-07-21 12:55:12 --> UTF-8 Support Enabled
INFO - 2019-07-21 12:55:12 --> Utf8 Class Initialized
INFO - 2019-07-21 12:55:12 --> Router Class Initialized
INFO - 2019-07-21 12:55:12 --> URI Class Initialized
INFO - 2019-07-21 12:55:12 --> Router Class Initialized
INFO - 2019-07-21 12:55:12 --> Output Class Initialized
INFO - 2019-07-21 12:55:12 --> Output Class Initialized
INFO - 2019-07-21 12:55:12 --> Security Class Initialized
INFO - 2019-07-21 12:55:12 --> Security Class Initialized
DEBUG - 2019-07-21 12:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 12:55:12 --> Input Class Initialized
INFO - 2019-07-21 12:55:12 --> Language Class Initialized
DEBUG - 2019-07-21 12:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 12:55:12 --> Input Class Initialized
INFO - 2019-07-21 12:55:12 --> Language Class Initialized
INFO - 2019-07-21 12:55:12 --> Loader Class Initialized
INFO - 2019-07-21 12:55:12 --> Loader Class Initialized
INFO - 2019-07-21 12:55:12 --> Database Driver Class Initialized
INFO - 2019-07-21 12:55:12 --> Controller Class Initialized
INFO - 2019-07-21 12:55:12 --> Model "Product" initialized
INFO - 2019-07-21 12:55:12 --> Final output sent to browser
DEBUG - 2019-07-21 12:55:12 --> Total execution time: 0.0255
INFO - 2019-07-21 12:55:12 --> Database Driver Class Initialized
INFO - 2019-07-21 12:55:12 --> Controller Class Initialized
INFO - 2019-07-21 12:55:12 --> Model "Product" initialized
INFO - 2019-07-21 12:55:12 --> Final output sent to browser
DEBUG - 2019-07-21 12:55:12 --> Total execution time: 0.0320
INFO - 2019-07-21 12:55:20 --> Config Class Initialized
INFO - 2019-07-21 12:55:20 --> Hooks Class Initialized
DEBUG - 2019-07-21 12:55:20 --> UTF-8 Support Enabled
INFO - 2019-07-21 12:55:20 --> Utf8 Class Initialized
INFO - 2019-07-21 12:55:20 --> URI Class Initialized
INFO - 2019-07-21 12:55:20 --> Router Class Initialized
INFO - 2019-07-21 12:55:20 --> Config Class Initialized
INFO - 2019-07-21 12:55:20 --> Hooks Class Initialized
DEBUG - 2019-07-21 12:55:20 --> UTF-8 Support Enabled
INFO - 2019-07-21 12:55:20 --> Utf8 Class Initialized
INFO - 2019-07-21 12:55:20 --> Output Class Initialized
INFO - 2019-07-21 12:55:20 --> URI Class Initialized
INFO - 2019-07-21 12:55:20 --> Security Class Initialized
INFO - 2019-07-21 12:55:20 --> Router Class Initialized
DEBUG - 2019-07-21 12:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 12:55:20 --> Input Class Initialized
INFO - 2019-07-21 12:55:20 --> Language Class Initialized
INFO - 2019-07-21 12:55:20 --> Output Class Initialized
INFO - 2019-07-21 12:55:20 --> Loader Class Initialized
INFO - 2019-07-21 12:55:20 --> Security Class Initialized
DEBUG - 2019-07-21 12:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 12:55:20 --> Input Class Initialized
INFO - 2019-07-21 12:55:20 --> Language Class Initialized
INFO - 2019-07-21 12:55:20 --> Loader Class Initialized
INFO - 2019-07-21 12:55:20 --> Database Driver Class Initialized
INFO - 2019-07-21 12:55:20 --> Database Driver Class Initialized
INFO - 2019-07-21 12:55:20 --> Controller Class Initialized
INFO - 2019-07-21 12:55:20 --> Model "Product" initialized
INFO - 2019-07-21 12:55:20 --> Controller Class Initialized
INFO - 2019-07-21 12:55:20 --> Model "Product" initialized
INFO - 2019-07-21 12:55:20 --> Final output sent to browser
DEBUG - 2019-07-21 12:55:20 --> Total execution time: 0.0276
INFO - 2019-07-21 12:55:20 --> Final output sent to browser
DEBUG - 2019-07-21 12:55:20 --> Total execution time: 0.0340
INFO - 2019-07-21 12:55:26 --> Config Class Initialized
INFO - 2019-07-21 12:55:26 --> Hooks Class Initialized
DEBUG - 2019-07-21 12:55:26 --> UTF-8 Support Enabled
INFO - 2019-07-21 12:55:26 --> Utf8 Class Initialized
INFO - 2019-07-21 12:55:26 --> URI Class Initialized
INFO - 2019-07-21 12:55:26 --> Router Class Initialized
INFO - 2019-07-21 12:55:26 --> Output Class Initialized
INFO - 2019-07-21 12:55:26 --> Security Class Initialized
DEBUG - 2019-07-21 12:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 12:55:26 --> Input Class Initialized
INFO - 2019-07-21 12:55:26 --> Language Class Initialized
INFO - 2019-07-21 12:55:26 --> Loader Class Initialized
INFO - 2019-07-21 12:55:26 --> Database Driver Class Initialized
INFO - 2019-07-21 12:55:26 --> Controller Class Initialized
INFO - 2019-07-21 12:55:26 --> Model "Product" initialized
INFO - 2019-07-21 12:55:26 --> Final output sent to browser
DEBUG - 2019-07-21 12:55:26 --> Total execution time: 0.0141
INFO - 2019-07-21 12:55:26 --> Config Class Initialized
INFO - 2019-07-21 12:55:26 --> Hooks Class Initialized
DEBUG - 2019-07-21 12:55:26 --> UTF-8 Support Enabled
INFO - 2019-07-21 12:55:26 --> Utf8 Class Initialized
INFO - 2019-07-21 12:55:26 --> URI Class Initialized
INFO - 2019-07-21 12:55:26 --> Router Class Initialized
INFO - 2019-07-21 12:55:26 --> Output Class Initialized
INFO - 2019-07-21 12:55:26 --> Security Class Initialized
DEBUG - 2019-07-21 12:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 12:55:26 --> Input Class Initialized
INFO - 2019-07-21 12:55:26 --> Language Class Initialized
INFO - 2019-07-21 12:55:26 --> Loader Class Initialized
INFO - 2019-07-21 12:55:26 --> Database Driver Class Initialized
INFO - 2019-07-21 12:55:26 --> Controller Class Initialized
INFO - 2019-07-21 12:55:26 --> Model "Product" initialized
ERROR - 2019-07-21 12:55:27 --> Severity: Notice --> Undefined variable: result /opt/lampp/htdocs/mautic_ci_product/application/models/Product.php 54
INFO - 2019-07-21 12:55:27 --> Final output sent to browser
DEBUG - 2019-07-21 12:55:27 --> Total execution time: 0.5215
INFO - 2019-07-21 12:55:37 --> Config Class Initialized
INFO - 2019-07-21 12:55:37 --> Hooks Class Initialized
DEBUG - 2019-07-21 12:55:37 --> UTF-8 Support Enabled
INFO - 2019-07-21 12:55:37 --> Utf8 Class Initialized
INFO - 2019-07-21 12:55:37 --> URI Class Initialized
INFO - 2019-07-21 12:55:37 --> Router Class Initialized
INFO - 2019-07-21 12:55:37 --> Output Class Initialized
INFO - 2019-07-21 12:55:37 --> Security Class Initialized
DEBUG - 2019-07-21 12:55:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 12:55:37 --> Input Class Initialized
INFO - 2019-07-21 12:55:37 --> Language Class Initialized
INFO - 2019-07-21 12:55:37 --> Loader Class Initialized
INFO - 2019-07-21 12:55:37 --> Database Driver Class Initialized
INFO - 2019-07-21 12:55:37 --> Controller Class Initialized
INFO - 2019-07-21 12:55:37 --> Model "Product" initialized
INFO - 2019-07-21 12:55:37 --> Final output sent to browser
DEBUG - 2019-07-21 12:55:37 --> Total execution time: 0.0202
INFO - 2019-07-21 12:55:38 --> Config Class Initialized
INFO - 2019-07-21 12:55:38 --> Hooks Class Initialized
DEBUG - 2019-07-21 12:55:38 --> UTF-8 Support Enabled
INFO - 2019-07-21 12:55:38 --> Utf8 Class Initialized
INFO - 2019-07-21 12:55:38 --> URI Class Initialized
INFO - 2019-07-21 12:55:38 --> Router Class Initialized
INFO - 2019-07-21 12:55:38 --> Output Class Initialized
INFO - 2019-07-21 12:55:38 --> Security Class Initialized
DEBUG - 2019-07-21 12:55:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 12:55:38 --> Input Class Initialized
INFO - 2019-07-21 12:55:38 --> Language Class Initialized
INFO - 2019-07-21 12:55:38 --> Loader Class Initialized
INFO - 2019-07-21 12:55:38 --> Database Driver Class Initialized
INFO - 2019-07-21 12:55:38 --> Controller Class Initialized
INFO - 2019-07-21 12:55:38 --> Model "Product" initialized
INFO - 2019-07-21 12:55:38 --> Final output sent to browser
DEBUG - 2019-07-21 12:55:38 --> Total execution time: 0.0163
INFO - 2019-07-21 12:55:38 --> Config Class Initialized
INFO - 2019-07-21 12:55:38 --> Hooks Class Initialized
DEBUG - 2019-07-21 12:55:38 --> UTF-8 Support Enabled
INFO - 2019-07-21 12:55:38 --> Utf8 Class Initialized
INFO - 2019-07-21 12:55:38 --> URI Class Initialized
INFO - 2019-07-21 12:55:38 --> Router Class Initialized
INFO - 2019-07-21 12:55:38 --> Output Class Initialized
INFO - 2019-07-21 12:55:38 --> Security Class Initialized
DEBUG - 2019-07-21 12:55:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 12:55:38 --> Input Class Initialized
INFO - 2019-07-21 12:55:38 --> Language Class Initialized
INFO - 2019-07-21 12:55:38 --> Loader Class Initialized
INFO - 2019-07-21 12:55:38 --> Database Driver Class Initialized
INFO - 2019-07-21 12:55:38 --> Controller Class Initialized
INFO - 2019-07-21 12:55:38 --> Model "Product" initialized
ERROR - 2019-07-21 12:55:38 --> Severity: Notice --> Undefined variable: result /opt/lampp/htdocs/mautic_ci_product/application/models/Product.php 54
INFO - 2019-07-21 12:55:38 --> Final output sent to browser
DEBUG - 2019-07-21 12:55:38 --> Total execution time: 0.0237
INFO - 2019-07-21 12:55:58 --> Config Class Initialized
INFO - 2019-07-21 12:55:58 --> Hooks Class Initialized
DEBUG - 2019-07-21 12:55:58 --> UTF-8 Support Enabled
INFO - 2019-07-21 12:55:58 --> Utf8 Class Initialized
INFO - 2019-07-21 12:55:58 --> URI Class Initialized
INFO - 2019-07-21 12:55:58 --> Config Class Initialized
INFO - 2019-07-21 12:55:58 --> Hooks Class Initialized
INFO - 2019-07-21 12:55:58 --> Router Class Initialized
DEBUG - 2019-07-21 12:55:58 --> UTF-8 Support Enabled
INFO - 2019-07-21 12:55:58 --> Utf8 Class Initialized
INFO - 2019-07-21 12:55:58 --> Output Class Initialized
INFO - 2019-07-21 12:55:58 --> URI Class Initialized
INFO - 2019-07-21 12:55:58 --> Router Class Initialized
INFO - 2019-07-21 12:55:58 --> Security Class Initialized
DEBUG - 2019-07-21 12:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 12:55:58 --> Input Class Initialized
INFO - 2019-07-21 12:55:58 --> Language Class Initialized
INFO - 2019-07-21 12:55:58 --> Loader Class Initialized
INFO - 2019-07-21 12:55:58 --> Output Class Initialized
INFO - 2019-07-21 12:55:58 --> Security Class Initialized
DEBUG - 2019-07-21 12:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 12:55:58 --> Input Class Initialized
INFO - 2019-07-21 12:55:58 --> Language Class Initialized
INFO - 2019-07-21 12:55:58 --> Loader Class Initialized
INFO - 2019-07-21 12:55:58 --> Database Driver Class Initialized
INFO - 2019-07-21 12:55:58 --> Controller Class Initialized
INFO - 2019-07-21 12:55:58 --> Model "Product" initialized
INFO - 2019-07-21 12:55:58 --> Database Driver Class Initialized
INFO - 2019-07-21 12:55:58 --> Final output sent to browser
DEBUG - 2019-07-21 12:55:58 --> Total execution time: 0.0394
INFO - 2019-07-21 12:55:58 --> Controller Class Initialized
INFO - 2019-07-21 12:55:58 --> Model "Product" initialized
INFO - 2019-07-21 12:55:58 --> Final output sent to browser
DEBUG - 2019-07-21 12:55:58 --> Total execution time: 0.0395
INFO - 2019-07-21 12:56:10 --> Config Class Initialized
INFO - 2019-07-21 12:56:10 --> Hooks Class Initialized
DEBUG - 2019-07-21 12:56:10 --> UTF-8 Support Enabled
INFO - 2019-07-21 12:56:10 --> Utf8 Class Initialized
INFO - 2019-07-21 12:56:10 --> URI Class Initialized
INFO - 2019-07-21 12:56:10 --> Router Class Initialized
INFO - 2019-07-21 12:56:10 --> Output Class Initialized
INFO - 2019-07-21 12:56:10 --> Security Class Initialized
DEBUG - 2019-07-21 12:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 12:56:10 --> Input Class Initialized
INFO - 2019-07-21 12:56:10 --> Language Class Initialized
INFO - 2019-07-21 12:56:10 --> Loader Class Initialized
INFO - 2019-07-21 12:56:10 --> Database Driver Class Initialized
INFO - 2019-07-21 12:56:10 --> Controller Class Initialized
INFO - 2019-07-21 12:56:10 --> Model "Product" initialized
INFO - 2019-07-21 12:56:10 --> Final output sent to browser
DEBUG - 2019-07-21 12:56:10 --> Total execution time: 0.0156
INFO - 2019-07-21 12:56:10 --> Config Class Initialized
INFO - 2019-07-21 12:56:10 --> Hooks Class Initialized
DEBUG - 2019-07-21 12:56:10 --> UTF-8 Support Enabled
INFO - 2019-07-21 12:56:10 --> Utf8 Class Initialized
INFO - 2019-07-21 12:56:10 --> URI Class Initialized
INFO - 2019-07-21 12:56:10 --> Router Class Initialized
INFO - 2019-07-21 12:56:10 --> Output Class Initialized
INFO - 2019-07-21 12:56:10 --> Security Class Initialized
DEBUG - 2019-07-21 12:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 12:56:10 --> Input Class Initialized
INFO - 2019-07-21 12:56:10 --> Language Class Initialized
INFO - 2019-07-21 12:56:10 --> Loader Class Initialized
INFO - 2019-07-21 12:56:10 --> Database Driver Class Initialized
INFO - 2019-07-21 12:56:10 --> Controller Class Initialized
INFO - 2019-07-21 12:56:10 --> Model "Product" initialized
ERROR - 2019-07-21 12:56:10 --> Severity: Notice --> Undefined variable: result /opt/lampp/htdocs/mautic_ci_product/application/models/Product.php 54
INFO - 2019-07-21 12:56:10 --> Final output sent to browser
DEBUG - 2019-07-21 12:56:10 --> Total execution time: 0.0155
INFO - 2019-07-21 12:57:03 --> Config Class Initialized
INFO - 2019-07-21 12:57:03 --> Hooks Class Initialized
DEBUG - 2019-07-21 12:57:03 --> UTF-8 Support Enabled
INFO - 2019-07-21 12:57:03 --> Utf8 Class Initialized
INFO - 2019-07-21 12:57:03 --> URI Class Initialized
INFO - 2019-07-21 12:57:03 --> Router Class Initialized
INFO - 2019-07-21 12:57:03 --> Output Class Initialized
INFO - 2019-07-21 12:57:03 --> Security Class Initialized
INFO - 2019-07-21 12:57:03 --> Config Class Initialized
INFO - 2019-07-21 12:57:03 --> Hooks Class Initialized
DEBUG - 2019-07-21 12:57:03 --> UTF-8 Support Enabled
INFO - 2019-07-21 12:57:03 --> Utf8 Class Initialized
INFO - 2019-07-21 12:57:03 --> URI Class Initialized
DEBUG - 2019-07-21 12:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 12:57:03 --> Input Class Initialized
INFO - 2019-07-21 12:57:03 --> Router Class Initialized
INFO - 2019-07-21 12:57:03 --> Language Class Initialized
INFO - 2019-07-21 12:57:03 --> Output Class Initialized
INFO - 2019-07-21 12:57:03 --> Loader Class Initialized
INFO - 2019-07-21 12:57:03 --> Security Class Initialized
DEBUG - 2019-07-21 12:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 12:57:03 --> Input Class Initialized
INFO - 2019-07-21 12:57:03 --> Language Class Initialized
INFO - 2019-07-21 12:57:03 --> Loader Class Initialized
INFO - 2019-07-21 12:57:03 --> Database Driver Class Initialized
INFO - 2019-07-21 12:57:03 --> Controller Class Initialized
INFO - 2019-07-21 12:57:03 --> Model "Product" initialized
INFO - 2019-07-21 12:57:03 --> Final output sent to browser
DEBUG - 2019-07-21 12:57:03 --> Total execution time: 0.0352
INFO - 2019-07-21 12:57:03 --> Database Driver Class Initialized
INFO - 2019-07-21 12:57:03 --> Controller Class Initialized
INFO - 2019-07-21 12:57:03 --> Model "Product" initialized
INFO - 2019-07-21 12:57:03 --> Final output sent to browser
DEBUG - 2019-07-21 12:57:03 --> Total execution time: 0.0740
INFO - 2019-07-21 12:57:20 --> Config Class Initialized
INFO - 2019-07-21 12:57:20 --> Hooks Class Initialized
DEBUG - 2019-07-21 12:57:20 --> UTF-8 Support Enabled
INFO - 2019-07-21 12:57:20 --> Utf8 Class Initialized
INFO - 2019-07-21 12:57:20 --> URI Class Initialized
INFO - 2019-07-21 12:57:20 --> Router Class Initialized
INFO - 2019-07-21 12:57:20 --> Output Class Initialized
INFO - 2019-07-21 12:57:20 --> Security Class Initialized
DEBUG - 2019-07-21 12:57:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 12:57:20 --> Input Class Initialized
INFO - 2019-07-21 12:57:20 --> Language Class Initialized
INFO - 2019-07-21 12:57:20 --> Loader Class Initialized
INFO - 2019-07-21 12:57:20 --> Database Driver Class Initialized
INFO - 2019-07-21 12:57:20 --> Controller Class Initialized
INFO - 2019-07-21 12:57:20 --> Model "Product" initialized
INFO - 2019-07-21 12:57:20 --> Final output sent to browser
DEBUG - 2019-07-21 12:57:20 --> Total execution time: 0.0238
INFO - 2019-07-21 12:57:20 --> Config Class Initialized
INFO - 2019-07-21 12:57:20 --> Hooks Class Initialized
DEBUG - 2019-07-21 12:57:20 --> UTF-8 Support Enabled
INFO - 2019-07-21 12:57:20 --> Utf8 Class Initialized
INFO - 2019-07-21 12:57:20 --> URI Class Initialized
INFO - 2019-07-21 12:57:20 --> Router Class Initialized
INFO - 2019-07-21 12:57:20 --> Output Class Initialized
INFO - 2019-07-21 12:57:20 --> Security Class Initialized
DEBUG - 2019-07-21 12:57:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 12:57:20 --> Input Class Initialized
INFO - 2019-07-21 12:57:20 --> Language Class Initialized
INFO - 2019-07-21 12:57:20 --> Loader Class Initialized
INFO - 2019-07-21 12:57:20 --> Database Driver Class Initialized
INFO - 2019-07-21 12:57:20 --> Controller Class Initialized
INFO - 2019-07-21 12:57:20 --> Model "Product" initialized
INFO - 2019-07-21 12:57:20 --> Final output sent to browser
DEBUG - 2019-07-21 12:57:20 --> Total execution time: 0.3181
INFO - 2019-07-21 12:57:38 --> Config Class Initialized
INFO - 2019-07-21 12:57:38 --> Hooks Class Initialized
DEBUG - 2019-07-21 12:57:38 --> UTF-8 Support Enabled
INFO - 2019-07-21 12:57:38 --> Utf8 Class Initialized
INFO - 2019-07-21 12:57:38 --> URI Class Initialized
INFO - 2019-07-21 12:57:38 --> Router Class Initialized
INFO - 2019-07-21 12:57:38 --> Output Class Initialized
INFO - 2019-07-21 12:57:38 --> Security Class Initialized
DEBUG - 2019-07-21 12:57:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 12:57:38 --> Input Class Initialized
INFO - 2019-07-21 12:57:38 --> Language Class Initialized
INFO - 2019-07-21 12:57:38 --> Loader Class Initialized
INFO - 2019-07-21 12:57:38 --> Database Driver Class Initialized
INFO - 2019-07-21 12:57:38 --> Controller Class Initialized
INFO - 2019-07-21 12:57:38 --> Model "Product" initialized
INFO - 2019-07-21 12:57:38 --> Final output sent to browser
DEBUG - 2019-07-21 12:57:38 --> Total execution time: 0.0257
INFO - 2019-07-21 12:57:41 --> Config Class Initialized
INFO - 2019-07-21 12:57:41 --> Hooks Class Initialized
DEBUG - 2019-07-21 12:57:41 --> UTF-8 Support Enabled
INFO - 2019-07-21 12:57:41 --> Utf8 Class Initialized
INFO - 2019-07-21 12:57:41 --> URI Class Initialized
INFO - 2019-07-21 12:57:41 --> Router Class Initialized
INFO - 2019-07-21 12:57:41 --> Output Class Initialized
INFO - 2019-07-21 12:57:41 --> Security Class Initialized
DEBUG - 2019-07-21 12:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 12:57:41 --> Input Class Initialized
INFO - 2019-07-21 12:57:41 --> Language Class Initialized
INFO - 2019-07-21 12:57:41 --> Loader Class Initialized
INFO - 2019-07-21 12:57:41 --> Database Driver Class Initialized
INFO - 2019-07-21 12:57:41 --> Controller Class Initialized
INFO - 2019-07-21 12:57:41 --> Model "Product" initialized
INFO - 2019-07-21 12:57:41 --> Final output sent to browser
DEBUG - 2019-07-21 12:57:41 --> Total execution time: 0.0217
INFO - 2019-07-21 12:57:43 --> Config Class Initialized
INFO - 2019-07-21 12:57:43 --> Hooks Class Initialized
DEBUG - 2019-07-21 12:57:43 --> UTF-8 Support Enabled
INFO - 2019-07-21 12:57:43 --> Utf8 Class Initialized
INFO - 2019-07-21 12:57:43 --> URI Class Initialized
INFO - 2019-07-21 12:57:43 --> Router Class Initialized
INFO - 2019-07-21 12:57:43 --> Output Class Initialized
INFO - 2019-07-21 12:57:43 --> Security Class Initialized
DEBUG - 2019-07-21 12:57:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 12:57:43 --> Input Class Initialized
INFO - 2019-07-21 12:57:43 --> Language Class Initialized
INFO - 2019-07-21 12:57:43 --> Loader Class Initialized
INFO - 2019-07-21 12:57:43 --> Database Driver Class Initialized
INFO - 2019-07-21 12:57:43 --> Controller Class Initialized
INFO - 2019-07-21 12:57:43 --> Model "Product" initialized
INFO - 2019-07-21 12:57:43 --> Final output sent to browser
DEBUG - 2019-07-21 12:57:43 --> Total execution time: 0.0154
INFO - 2019-07-21 12:57:43 --> Config Class Initialized
INFO - 2019-07-21 12:57:43 --> Hooks Class Initialized
DEBUG - 2019-07-21 12:57:43 --> UTF-8 Support Enabled
INFO - 2019-07-21 12:57:43 --> Utf8 Class Initialized
INFO - 2019-07-21 12:57:43 --> URI Class Initialized
INFO - 2019-07-21 12:57:43 --> Router Class Initialized
INFO - 2019-07-21 12:57:43 --> Output Class Initialized
INFO - 2019-07-21 12:57:43 --> Security Class Initialized
DEBUG - 2019-07-21 12:57:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 12:57:43 --> Input Class Initialized
INFO - 2019-07-21 12:57:43 --> Language Class Initialized
INFO - 2019-07-21 12:57:43 --> Loader Class Initialized
INFO - 2019-07-21 12:57:43 --> Database Driver Class Initialized
INFO - 2019-07-21 12:57:43 --> Controller Class Initialized
INFO - 2019-07-21 12:57:43 --> Model "Product" initialized
INFO - 2019-07-21 12:57:43 --> Final output sent to browser
DEBUG - 2019-07-21 12:57:43 --> Total execution time: 0.0161
INFO - 2019-07-21 12:59:25 --> Config Class Initialized
INFO - 2019-07-21 12:59:25 --> Hooks Class Initialized
DEBUG - 2019-07-21 12:59:25 --> UTF-8 Support Enabled
INFO - 2019-07-21 12:59:25 --> Utf8 Class Initialized
INFO - 2019-07-21 12:59:25 --> URI Class Initialized
INFO - 2019-07-21 12:59:25 --> Router Class Initialized
INFO - 2019-07-21 12:59:25 --> Output Class Initialized
INFO - 2019-07-21 12:59:25 --> Security Class Initialized
DEBUG - 2019-07-21 12:59:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 12:59:25 --> Input Class Initialized
INFO - 2019-07-21 12:59:25 --> Language Class Initialized
INFO - 2019-07-21 12:59:25 --> Loader Class Initialized
INFO - 2019-07-21 12:59:25 --> Database Driver Class Initialized
INFO - 2019-07-21 12:59:25 --> Controller Class Initialized
INFO - 2019-07-21 12:59:25 --> Model "Product" initialized
INFO - 2019-07-21 12:59:25 --> Final output sent to browser
DEBUG - 2019-07-21 12:59:25 --> Total execution time: 0.0298
INFO - 2019-07-21 13:00:40 --> Config Class Initialized
INFO - 2019-07-21 13:00:40 --> Hooks Class Initialized
DEBUG - 2019-07-21 13:00:40 --> UTF-8 Support Enabled
INFO - 2019-07-21 13:00:40 --> Utf8 Class Initialized
INFO - 2019-07-21 13:00:40 --> URI Class Initialized
INFO - 2019-07-21 13:00:40 --> Router Class Initialized
INFO - 2019-07-21 13:00:40 --> Output Class Initialized
INFO - 2019-07-21 13:00:40 --> Security Class Initialized
DEBUG - 2019-07-21 13:00:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 13:00:40 --> Input Class Initialized
INFO - 2019-07-21 13:00:40 --> Language Class Initialized
INFO - 2019-07-21 13:00:40 --> Loader Class Initialized
INFO - 2019-07-21 13:00:41 --> Database Driver Class Initialized
INFO - 2019-07-21 13:00:41 --> Controller Class Initialized
INFO - 2019-07-21 13:00:41 --> Model "Product" initialized
INFO - 2019-07-21 13:00:42 --> Final output sent to browser
DEBUG - 2019-07-21 13:00:42 --> Total execution time: 1.4026
INFO - 2019-07-21 13:01:13 --> Config Class Initialized
INFO - 2019-07-21 13:01:13 --> Hooks Class Initialized
DEBUG - 2019-07-21 13:01:13 --> UTF-8 Support Enabled
INFO - 2019-07-21 13:01:13 --> Utf8 Class Initialized
INFO - 2019-07-21 13:01:13 --> URI Class Initialized
INFO - 2019-07-21 13:01:13 --> Router Class Initialized
INFO - 2019-07-21 13:01:13 --> Output Class Initialized
INFO - 2019-07-21 13:01:13 --> Security Class Initialized
DEBUG - 2019-07-21 13:01:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 13:01:13 --> Input Class Initialized
INFO - 2019-07-21 13:01:13 --> Language Class Initialized
INFO - 2019-07-21 13:01:13 --> Loader Class Initialized
INFO - 2019-07-21 13:01:13 --> Database Driver Class Initialized
INFO - 2019-07-21 13:01:13 --> Controller Class Initialized
INFO - 2019-07-21 13:01:13 --> Model "Product" initialized
INFO - 2019-07-21 13:01:13 --> Final output sent to browser
DEBUG - 2019-07-21 13:01:13 --> Total execution time: 0.0218
INFO - 2019-07-21 13:01:21 --> Config Class Initialized
INFO - 2019-07-21 13:01:21 --> Hooks Class Initialized
DEBUG - 2019-07-21 13:01:21 --> UTF-8 Support Enabled
INFO - 2019-07-21 13:01:21 --> Utf8 Class Initialized
INFO - 2019-07-21 13:01:21 --> URI Class Initialized
INFO - 2019-07-21 13:01:21 --> Router Class Initialized
INFO - 2019-07-21 13:01:21 --> Output Class Initialized
INFO - 2019-07-21 13:01:21 --> Security Class Initialized
DEBUG - 2019-07-21 13:01:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 13:01:21 --> Input Class Initialized
INFO - 2019-07-21 13:01:21 --> Language Class Initialized
INFO - 2019-07-21 13:01:21 --> Loader Class Initialized
INFO - 2019-07-21 13:01:21 --> Database Driver Class Initialized
INFO - 2019-07-21 13:01:21 --> Controller Class Initialized
INFO - 2019-07-21 13:01:21 --> Model "Product" initialized
INFO - 2019-07-21 13:01:21 --> Final output sent to browser
DEBUG - 2019-07-21 13:01:21 --> Total execution time: 0.0280
INFO - 2019-07-21 13:01:27 --> Config Class Initialized
INFO - 2019-07-21 13:01:27 --> Hooks Class Initialized
DEBUG - 2019-07-21 13:01:27 --> UTF-8 Support Enabled
INFO - 2019-07-21 13:01:27 --> Utf8 Class Initialized
INFO - 2019-07-21 13:01:27 --> URI Class Initialized
INFO - 2019-07-21 13:01:27 --> Router Class Initialized
INFO - 2019-07-21 13:01:27 --> Output Class Initialized
INFO - 2019-07-21 13:01:27 --> Security Class Initialized
DEBUG - 2019-07-21 13:01:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 13:01:27 --> Input Class Initialized
INFO - 2019-07-21 13:01:27 --> Language Class Initialized
INFO - 2019-07-21 13:01:27 --> Loader Class Initialized
INFO - 2019-07-21 13:01:27 --> Database Driver Class Initialized
INFO - 2019-07-21 13:01:27 --> Controller Class Initialized
INFO - 2019-07-21 13:01:27 --> Model "Product" initialized
INFO - 2019-07-21 13:01:27 --> Final output sent to browser
DEBUG - 2019-07-21 13:01:27 --> Total execution time: 0.1036
INFO - 2019-07-21 13:01:33 --> Config Class Initialized
INFO - 2019-07-21 13:01:33 --> Hooks Class Initialized
DEBUG - 2019-07-21 13:01:33 --> UTF-8 Support Enabled
INFO - 2019-07-21 13:01:33 --> Utf8 Class Initialized
INFO - 2019-07-21 13:01:33 --> URI Class Initialized
INFO - 2019-07-21 13:01:33 --> Router Class Initialized
INFO - 2019-07-21 13:01:33 --> Output Class Initialized
INFO - 2019-07-21 13:01:33 --> Security Class Initialized
DEBUG - 2019-07-21 13:01:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 13:01:33 --> Input Class Initialized
INFO - 2019-07-21 13:01:33 --> Language Class Initialized
INFO - 2019-07-21 13:01:33 --> Loader Class Initialized
INFO - 2019-07-21 13:01:33 --> Database Driver Class Initialized
INFO - 2019-07-21 13:01:33 --> Controller Class Initialized
INFO - 2019-07-21 13:01:33 --> Model "Product" initialized
INFO - 2019-07-21 13:01:33 --> Final output sent to browser
DEBUG - 2019-07-21 13:01:33 --> Total execution time: 0.0224
INFO - 2019-07-21 13:01:33 --> Config Class Initialized
INFO - 2019-07-21 13:01:33 --> Hooks Class Initialized
DEBUG - 2019-07-21 13:01:33 --> UTF-8 Support Enabled
INFO - 2019-07-21 13:01:33 --> Utf8 Class Initialized
INFO - 2019-07-21 13:01:33 --> URI Class Initialized
INFO - 2019-07-21 13:01:33 --> Router Class Initialized
INFO - 2019-07-21 13:01:33 --> Output Class Initialized
INFO - 2019-07-21 13:01:33 --> Security Class Initialized
DEBUG - 2019-07-21 13:01:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 13:01:33 --> Input Class Initialized
INFO - 2019-07-21 13:01:33 --> Language Class Initialized
INFO - 2019-07-21 13:01:33 --> Loader Class Initialized
INFO - 2019-07-21 13:01:33 --> Database Driver Class Initialized
INFO - 2019-07-21 13:01:33 --> Controller Class Initialized
INFO - 2019-07-21 13:01:33 --> Model "Product" initialized
INFO - 2019-07-21 13:01:33 --> Final output sent to browser
DEBUG - 2019-07-21 13:01:33 --> Total execution time: 0.1409
INFO - 2019-07-21 13:01:33 --> Config Class Initialized
INFO - 2019-07-21 13:01:33 --> Hooks Class Initialized
DEBUG - 2019-07-21 13:01:33 --> UTF-8 Support Enabled
INFO - 2019-07-21 13:01:33 --> Utf8 Class Initialized
INFO - 2019-07-21 13:01:33 --> URI Class Initialized
INFO - 2019-07-21 13:01:33 --> Router Class Initialized
INFO - 2019-07-21 13:01:33 --> Output Class Initialized
INFO - 2019-07-21 13:01:33 --> Security Class Initialized
DEBUG - 2019-07-21 13:01:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 13:01:33 --> Input Class Initialized
INFO - 2019-07-21 13:01:33 --> Language Class Initialized
INFO - 2019-07-21 13:01:33 --> Loader Class Initialized
INFO - 2019-07-21 13:01:33 --> Database Driver Class Initialized
INFO - 2019-07-21 13:01:33 --> Controller Class Initialized
INFO - 2019-07-21 13:01:33 --> Model "Product" initialized
INFO - 2019-07-21 13:01:33 --> Final output sent to browser
DEBUG - 2019-07-21 13:01:33 --> Total execution time: 0.0208
INFO - 2019-07-21 13:01:42 --> Config Class Initialized
INFO - 2019-07-21 13:01:42 --> Hooks Class Initialized
DEBUG - 2019-07-21 13:01:42 --> UTF-8 Support Enabled
INFO - 2019-07-21 13:01:42 --> Utf8 Class Initialized
INFO - 2019-07-21 13:01:42 --> URI Class Initialized
INFO - 2019-07-21 13:01:42 --> Router Class Initialized
INFO - 2019-07-21 13:01:42 --> Output Class Initialized
INFO - 2019-07-21 13:01:42 --> Security Class Initialized
DEBUG - 2019-07-21 13:01:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 13:01:42 --> Input Class Initialized
INFO - 2019-07-21 13:01:42 --> Language Class Initialized
INFO - 2019-07-21 13:01:42 --> Loader Class Initialized
INFO - 2019-07-21 13:01:42 --> Database Driver Class Initialized
INFO - 2019-07-21 13:01:42 --> Controller Class Initialized
INFO - 2019-07-21 13:01:42 --> Model "Product" initialized
INFO - 2019-07-21 13:01:42 --> Final output sent to browser
DEBUG - 2019-07-21 13:01:42 --> Total execution time: 0.0252
INFO - 2019-07-21 13:02:36 --> Config Class Initialized
INFO - 2019-07-21 13:02:36 --> Hooks Class Initialized
DEBUG - 2019-07-21 13:02:36 --> UTF-8 Support Enabled
INFO - 2019-07-21 13:02:36 --> Utf8 Class Initialized
INFO - 2019-07-21 13:02:36 --> URI Class Initialized
INFO - 2019-07-21 13:02:36 --> Router Class Initialized
INFO - 2019-07-21 13:02:36 --> Output Class Initialized
INFO - 2019-07-21 13:02:36 --> Security Class Initialized
DEBUG - 2019-07-21 13:02:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 13:02:36 --> Input Class Initialized
INFO - 2019-07-21 13:02:36 --> Language Class Initialized
INFO - 2019-07-21 13:02:36 --> Loader Class Initialized
INFO - 2019-07-21 13:02:36 --> Database Driver Class Initialized
INFO - 2019-07-21 13:02:36 --> Controller Class Initialized
INFO - 2019-07-21 13:02:36 --> Model "Product" initialized
INFO - 2019-07-21 13:02:36 --> Final output sent to browser
DEBUG - 2019-07-21 13:02:36 --> Total execution time: 0.0206
INFO - 2019-07-21 13:02:41 --> Config Class Initialized
INFO - 2019-07-21 13:02:41 --> Hooks Class Initialized
DEBUG - 2019-07-21 13:02:41 --> UTF-8 Support Enabled
INFO - 2019-07-21 13:02:41 --> Utf8 Class Initialized
INFO - 2019-07-21 13:02:41 --> URI Class Initialized
INFO - 2019-07-21 13:02:41 --> Router Class Initialized
INFO - 2019-07-21 13:02:41 --> Output Class Initialized
INFO - 2019-07-21 13:02:41 --> Security Class Initialized
DEBUG - 2019-07-21 13:02:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 13:02:41 --> Input Class Initialized
INFO - 2019-07-21 13:02:41 --> Language Class Initialized
INFO - 2019-07-21 13:02:41 --> Loader Class Initialized
INFO - 2019-07-21 13:02:41 --> Database Driver Class Initialized
INFO - 2019-07-21 13:02:41 --> Controller Class Initialized
INFO - 2019-07-21 13:02:41 --> Model "Product" initialized
INFO - 2019-07-21 13:02:41 --> Final output sent to browser
DEBUG - 2019-07-21 13:02:41 --> Total execution time: 0.0163
INFO - 2019-07-21 13:02:41 --> Config Class Initialized
INFO - 2019-07-21 13:02:41 --> Hooks Class Initialized
DEBUG - 2019-07-21 13:02:41 --> UTF-8 Support Enabled
INFO - 2019-07-21 13:02:41 --> Utf8 Class Initialized
INFO - 2019-07-21 13:02:41 --> URI Class Initialized
INFO - 2019-07-21 13:02:41 --> Router Class Initialized
INFO - 2019-07-21 13:02:41 --> Output Class Initialized
INFO - 2019-07-21 13:02:41 --> Security Class Initialized
DEBUG - 2019-07-21 13:02:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 13:02:41 --> Input Class Initialized
INFO - 2019-07-21 13:02:41 --> Language Class Initialized
INFO - 2019-07-21 13:02:41 --> Loader Class Initialized
INFO - 2019-07-21 13:02:41 --> Database Driver Class Initialized
INFO - 2019-07-21 13:02:42 --> Controller Class Initialized
INFO - 2019-07-21 13:02:42 --> Model "Product" initialized
INFO - 2019-07-21 13:02:42 --> Final output sent to browser
DEBUG - 2019-07-21 13:02:42 --> Total execution time: 0.0152
INFO - 2019-07-21 13:02:42 --> Config Class Initialized
INFO - 2019-07-21 13:02:42 --> Hooks Class Initialized
DEBUG - 2019-07-21 13:02:42 --> UTF-8 Support Enabled
INFO - 2019-07-21 13:02:42 --> Utf8 Class Initialized
INFO - 2019-07-21 13:02:42 --> URI Class Initialized
INFO - 2019-07-21 13:02:42 --> Router Class Initialized
INFO - 2019-07-21 13:02:42 --> Output Class Initialized
INFO - 2019-07-21 13:02:42 --> Security Class Initialized
DEBUG - 2019-07-21 13:02:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 13:02:42 --> Input Class Initialized
INFO - 2019-07-21 13:02:42 --> Language Class Initialized
INFO - 2019-07-21 13:02:42 --> Loader Class Initialized
INFO - 2019-07-21 13:02:42 --> Database Driver Class Initialized
INFO - 2019-07-21 13:02:42 --> Controller Class Initialized
INFO - 2019-07-21 13:02:42 --> Model "Product" initialized
INFO - 2019-07-21 13:02:42 --> Final output sent to browser
DEBUG - 2019-07-21 13:02:42 --> Total execution time: 0.0200
INFO - 2019-07-21 13:02:44 --> Config Class Initialized
INFO - 2019-07-21 13:02:44 --> Hooks Class Initialized
DEBUG - 2019-07-21 13:02:44 --> UTF-8 Support Enabled
INFO - 2019-07-21 13:02:44 --> Utf8 Class Initialized
INFO - 2019-07-21 13:02:44 --> URI Class Initialized
INFO - 2019-07-21 13:02:44 --> Router Class Initialized
INFO - 2019-07-21 13:02:44 --> Output Class Initialized
INFO - 2019-07-21 13:02:44 --> Security Class Initialized
DEBUG - 2019-07-21 13:02:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 13:02:44 --> Input Class Initialized
INFO - 2019-07-21 13:02:44 --> Language Class Initialized
INFO - 2019-07-21 13:02:44 --> Loader Class Initialized
INFO - 2019-07-21 13:02:44 --> Database Driver Class Initialized
INFO - 2019-07-21 13:02:44 --> Controller Class Initialized
INFO - 2019-07-21 13:02:44 --> Model "Product" initialized
INFO - 2019-07-21 13:02:44 --> Final output sent to browser
DEBUG - 2019-07-21 13:02:44 --> Total execution time: 0.0244
INFO - 2019-07-21 13:02:46 --> Config Class Initialized
INFO - 2019-07-21 13:02:46 --> Hooks Class Initialized
DEBUG - 2019-07-21 13:02:46 --> UTF-8 Support Enabled
INFO - 2019-07-21 13:02:46 --> Utf8 Class Initialized
INFO - 2019-07-21 13:02:46 --> URI Class Initialized
INFO - 2019-07-21 13:02:46 --> Router Class Initialized
INFO - 2019-07-21 13:02:46 --> Output Class Initialized
INFO - 2019-07-21 13:02:46 --> Security Class Initialized
DEBUG - 2019-07-21 13:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 13:02:46 --> Input Class Initialized
INFO - 2019-07-21 13:02:46 --> Language Class Initialized
INFO - 2019-07-21 13:02:46 --> Loader Class Initialized
INFO - 2019-07-21 13:02:46 --> Database Driver Class Initialized
INFO - 2019-07-21 13:02:46 --> Controller Class Initialized
INFO - 2019-07-21 13:02:46 --> Model "Product" initialized
INFO - 2019-07-21 13:02:46 --> Final output sent to browser
DEBUG - 2019-07-21 13:02:46 --> Total execution time: 0.0172
INFO - 2019-07-21 13:02:46 --> Config Class Initialized
INFO - 2019-07-21 13:02:46 --> Hooks Class Initialized
DEBUG - 2019-07-21 13:02:46 --> UTF-8 Support Enabled
INFO - 2019-07-21 13:02:46 --> Utf8 Class Initialized
INFO - 2019-07-21 13:02:46 --> URI Class Initialized
INFO - 2019-07-21 13:02:46 --> Router Class Initialized
INFO - 2019-07-21 13:02:46 --> Output Class Initialized
INFO - 2019-07-21 13:02:46 --> Security Class Initialized
DEBUG - 2019-07-21 13:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 13:02:46 --> Input Class Initialized
INFO - 2019-07-21 13:02:46 --> Language Class Initialized
INFO - 2019-07-21 13:02:46 --> Loader Class Initialized
INFO - 2019-07-21 13:02:46 --> Database Driver Class Initialized
INFO - 2019-07-21 13:02:46 --> Controller Class Initialized
INFO - 2019-07-21 13:02:46 --> Model "Product" initialized
INFO - 2019-07-21 13:02:46 --> Final output sent to browser
DEBUG - 2019-07-21 13:02:46 --> Total execution time: 0.0177
INFO - 2019-07-21 13:04:12 --> Config Class Initialized
INFO - 2019-07-21 13:04:12 --> Hooks Class Initialized
DEBUG - 2019-07-21 13:04:12 --> UTF-8 Support Enabled
INFO - 2019-07-21 13:04:12 --> Utf8 Class Initialized
INFO - 2019-07-21 13:04:12 --> URI Class Initialized
INFO - 2019-07-21 13:04:12 --> Router Class Initialized
INFO - 2019-07-21 13:04:12 --> Output Class Initialized
INFO - 2019-07-21 13:04:12 --> Security Class Initialized
DEBUG - 2019-07-21 13:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 13:04:12 --> Input Class Initialized
INFO - 2019-07-21 13:04:12 --> Language Class Initialized
INFO - 2019-07-21 13:04:12 --> Loader Class Initialized
INFO - 2019-07-21 13:04:12 --> Database Driver Class Initialized
INFO - 2019-07-21 13:04:12 --> Controller Class Initialized
INFO - 2019-07-21 13:04:12 --> Model "Product" initialized
INFO - 2019-07-21 13:04:12 --> Final output sent to browser
DEBUG - 2019-07-21 13:04:12 --> Total execution time: 0.0234
INFO - 2019-07-21 13:04:22 --> Config Class Initialized
INFO - 2019-07-21 13:04:22 --> Hooks Class Initialized
DEBUG - 2019-07-21 13:04:22 --> UTF-8 Support Enabled
INFO - 2019-07-21 13:04:22 --> Utf8 Class Initialized
INFO - 2019-07-21 13:04:22 --> URI Class Initialized
INFO - 2019-07-21 13:04:22 --> Router Class Initialized
INFO - 2019-07-21 13:04:22 --> Output Class Initialized
INFO - 2019-07-21 13:04:22 --> Security Class Initialized
DEBUG - 2019-07-21 13:04:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 13:04:22 --> Input Class Initialized
INFO - 2019-07-21 13:04:22 --> Language Class Initialized
INFO - 2019-07-21 13:04:22 --> Loader Class Initialized
INFO - 2019-07-21 13:04:22 --> Database Driver Class Initialized
INFO - 2019-07-21 13:04:22 --> Controller Class Initialized
INFO - 2019-07-21 13:04:22 --> Model "Product" initialized
INFO - 2019-07-21 13:04:22 --> Final output sent to browser
DEBUG - 2019-07-21 13:04:22 --> Total execution time: 0.0274
INFO - 2019-07-21 13:04:28 --> Config Class Initialized
INFO - 2019-07-21 13:04:28 --> Hooks Class Initialized
DEBUG - 2019-07-21 13:04:28 --> UTF-8 Support Enabled
INFO - 2019-07-21 13:04:28 --> Utf8 Class Initialized
INFO - 2019-07-21 13:04:28 --> URI Class Initialized
INFO - 2019-07-21 13:04:28 --> Router Class Initialized
INFO - 2019-07-21 13:04:28 --> Output Class Initialized
INFO - 2019-07-21 13:04:28 --> Security Class Initialized
DEBUG - 2019-07-21 13:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 13:04:28 --> Input Class Initialized
INFO - 2019-07-21 13:04:28 --> Language Class Initialized
INFO - 2019-07-21 13:04:28 --> Loader Class Initialized
INFO - 2019-07-21 13:04:28 --> Database Driver Class Initialized
INFO - 2019-07-21 13:04:28 --> Controller Class Initialized
INFO - 2019-07-21 13:04:28 --> Model "Product" initialized
INFO - 2019-07-21 13:04:28 --> Final output sent to browser
DEBUG - 2019-07-21 13:04:28 --> Total execution time: 0.0216
INFO - 2019-07-21 13:04:29 --> Config Class Initialized
INFO - 2019-07-21 13:04:29 --> Hooks Class Initialized
DEBUG - 2019-07-21 13:04:29 --> UTF-8 Support Enabled
INFO - 2019-07-21 13:04:29 --> Utf8 Class Initialized
INFO - 2019-07-21 13:04:29 --> URI Class Initialized
INFO - 2019-07-21 13:04:29 --> Router Class Initialized
INFO - 2019-07-21 13:04:29 --> Output Class Initialized
INFO - 2019-07-21 13:04:29 --> Security Class Initialized
DEBUG - 2019-07-21 13:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 13:04:29 --> Input Class Initialized
INFO - 2019-07-21 13:04:29 --> Language Class Initialized
INFO - 2019-07-21 13:04:29 --> Loader Class Initialized
INFO - 2019-07-21 13:04:29 --> Database Driver Class Initialized
INFO - 2019-07-21 13:04:29 --> Controller Class Initialized
INFO - 2019-07-21 13:04:29 --> Model "Product" initialized
INFO - 2019-07-21 13:04:29 --> Final output sent to browser
DEBUG - 2019-07-21 13:04:29 --> Total execution time: 0.0161
INFO - 2019-07-21 13:04:29 --> Config Class Initialized
INFO - 2019-07-21 13:04:29 --> Hooks Class Initialized
DEBUG - 2019-07-21 13:04:29 --> UTF-8 Support Enabled
INFO - 2019-07-21 13:04:29 --> Utf8 Class Initialized
INFO - 2019-07-21 13:04:29 --> URI Class Initialized
INFO - 2019-07-21 13:04:29 --> Router Class Initialized
INFO - 2019-07-21 13:04:29 --> Output Class Initialized
INFO - 2019-07-21 13:04:29 --> Security Class Initialized
DEBUG - 2019-07-21 13:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 13:04:29 --> Input Class Initialized
INFO - 2019-07-21 13:04:29 --> Language Class Initialized
INFO - 2019-07-21 13:04:29 --> Loader Class Initialized
INFO - 2019-07-21 13:04:29 --> Database Driver Class Initialized
INFO - 2019-07-21 13:04:29 --> Controller Class Initialized
INFO - 2019-07-21 13:04:29 --> Model "Product" initialized
INFO - 2019-07-21 13:04:29 --> Final output sent to browser
DEBUG - 2019-07-21 13:04:29 --> Total execution time: 0.0209
INFO - 2019-07-21 13:04:29 --> Config Class Initialized
INFO - 2019-07-21 13:04:29 --> Hooks Class Initialized
DEBUG - 2019-07-21 13:04:29 --> UTF-8 Support Enabled
INFO - 2019-07-21 13:04:29 --> Utf8 Class Initialized
INFO - 2019-07-21 13:04:29 --> URI Class Initialized
INFO - 2019-07-21 13:04:29 --> Router Class Initialized
INFO - 2019-07-21 13:04:29 --> Output Class Initialized
INFO - 2019-07-21 13:04:29 --> Security Class Initialized
DEBUG - 2019-07-21 13:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 13:04:29 --> Input Class Initialized
INFO - 2019-07-21 13:04:29 --> Language Class Initialized
INFO - 2019-07-21 13:04:29 --> Loader Class Initialized
INFO - 2019-07-21 13:04:29 --> Database Driver Class Initialized
INFO - 2019-07-21 13:04:29 --> Controller Class Initialized
INFO - 2019-07-21 13:04:29 --> Model "Product" initialized
INFO - 2019-07-21 13:04:29 --> Final output sent to browser
DEBUG - 2019-07-21 13:04:29 --> Total execution time: 0.0226
INFO - 2019-07-21 13:04:53 --> Config Class Initialized
INFO - 2019-07-21 13:04:53 --> Hooks Class Initialized
DEBUG - 2019-07-21 13:04:54 --> UTF-8 Support Enabled
INFO - 2019-07-21 13:04:54 --> Utf8 Class Initialized
INFO - 2019-07-21 13:04:54 --> URI Class Initialized
INFO - 2019-07-21 13:04:54 --> Router Class Initialized
INFO - 2019-07-21 13:04:54 --> Output Class Initialized
INFO - 2019-07-21 13:04:54 --> Security Class Initialized
DEBUG - 2019-07-21 13:04:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 13:04:54 --> Input Class Initialized
INFO - 2019-07-21 13:04:54 --> Language Class Initialized
INFO - 2019-07-21 13:04:54 --> Loader Class Initialized
INFO - 2019-07-21 13:04:54 --> Database Driver Class Initialized
INFO - 2019-07-21 13:04:54 --> Controller Class Initialized
INFO - 2019-07-21 13:04:54 --> Model "Product" initialized
INFO - 2019-07-21 13:04:54 --> Final output sent to browser
DEBUG - 2019-07-21 13:04:54 --> Total execution time: 0.0343
INFO - 2019-07-21 13:05:17 --> Config Class Initialized
INFO - 2019-07-21 13:05:17 --> Hooks Class Initialized
DEBUG - 2019-07-21 13:05:17 --> UTF-8 Support Enabled
INFO - 2019-07-21 13:05:17 --> Utf8 Class Initialized
INFO - 2019-07-21 13:05:17 --> URI Class Initialized
INFO - 2019-07-21 13:05:17 --> Router Class Initialized
INFO - 2019-07-21 13:05:17 --> Output Class Initialized
INFO - 2019-07-21 13:05:17 --> Security Class Initialized
DEBUG - 2019-07-21 13:05:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 13:05:17 --> Input Class Initialized
INFO - 2019-07-21 13:05:17 --> Language Class Initialized
INFO - 2019-07-21 13:05:17 --> Loader Class Initialized
INFO - 2019-07-21 13:05:17 --> Database Driver Class Initialized
INFO - 2019-07-21 13:05:17 --> Controller Class Initialized
INFO - 2019-07-21 13:05:17 --> Model "Product" initialized
INFO - 2019-07-21 13:05:17 --> Final output sent to browser
DEBUG - 2019-07-21 13:05:17 --> Total execution time: 0.0294
INFO - 2019-07-21 13:05:20 --> Config Class Initialized
INFO - 2019-07-21 13:05:20 --> Hooks Class Initialized
DEBUG - 2019-07-21 13:05:20 --> UTF-8 Support Enabled
INFO - 2019-07-21 13:05:20 --> Utf8 Class Initialized
INFO - 2019-07-21 13:05:20 --> URI Class Initialized
INFO - 2019-07-21 13:05:20 --> Router Class Initialized
INFO - 2019-07-21 13:05:20 --> Output Class Initialized
INFO - 2019-07-21 13:05:20 --> Security Class Initialized
DEBUG - 2019-07-21 13:05:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 13:05:20 --> Input Class Initialized
INFO - 2019-07-21 13:05:20 --> Language Class Initialized
INFO - 2019-07-21 13:05:20 --> Loader Class Initialized
INFO - 2019-07-21 13:05:20 --> Database Driver Class Initialized
INFO - 2019-07-21 13:05:20 --> Controller Class Initialized
INFO - 2019-07-21 13:05:20 --> Model "Product" initialized
INFO - 2019-07-21 13:05:20 --> Final output sent to browser
DEBUG - 2019-07-21 13:05:20 --> Total execution time: 0.0220
INFO - 2019-07-21 13:05:21 --> Config Class Initialized
INFO - 2019-07-21 13:05:21 --> Hooks Class Initialized
DEBUG - 2019-07-21 13:05:21 --> UTF-8 Support Enabled
INFO - 2019-07-21 13:05:21 --> Utf8 Class Initialized
INFO - 2019-07-21 13:05:21 --> URI Class Initialized
INFO - 2019-07-21 13:05:21 --> Router Class Initialized
INFO - 2019-07-21 13:05:21 --> Output Class Initialized
INFO - 2019-07-21 13:05:21 --> Security Class Initialized
DEBUG - 2019-07-21 13:05:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 13:05:21 --> Input Class Initialized
INFO - 2019-07-21 13:05:21 --> Language Class Initialized
INFO - 2019-07-21 13:05:21 --> Loader Class Initialized
INFO - 2019-07-21 13:05:21 --> Database Driver Class Initialized
INFO - 2019-07-21 13:05:21 --> Controller Class Initialized
INFO - 2019-07-21 13:05:21 --> Model "Product" initialized
INFO - 2019-07-21 13:05:21 --> Final output sent to browser
DEBUG - 2019-07-21 13:05:21 --> Total execution time: 0.0193
INFO - 2019-07-21 13:05:21 --> Config Class Initialized
INFO - 2019-07-21 13:05:21 --> Hooks Class Initialized
DEBUG - 2019-07-21 13:05:21 --> UTF-8 Support Enabled
INFO - 2019-07-21 13:05:21 --> Utf8 Class Initialized
INFO - 2019-07-21 13:05:21 --> URI Class Initialized
INFO - 2019-07-21 13:05:21 --> Router Class Initialized
INFO - 2019-07-21 13:05:21 --> Output Class Initialized
INFO - 2019-07-21 13:05:21 --> Security Class Initialized
DEBUG - 2019-07-21 13:05:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 13:05:21 --> Input Class Initialized
INFO - 2019-07-21 13:05:21 --> Language Class Initialized
INFO - 2019-07-21 13:05:21 --> Loader Class Initialized
INFO - 2019-07-21 13:05:21 --> Database Driver Class Initialized
INFO - 2019-07-21 13:05:21 --> Controller Class Initialized
INFO - 2019-07-21 13:05:21 --> Model "Product" initialized
INFO - 2019-07-21 13:05:21 --> Final output sent to browser
DEBUG - 2019-07-21 13:05:21 --> Total execution time: 0.0326
INFO - 2019-07-21 13:05:21 --> Config Class Initialized
INFO - 2019-07-21 13:05:21 --> Hooks Class Initialized
DEBUG - 2019-07-21 13:05:21 --> UTF-8 Support Enabled
INFO - 2019-07-21 13:05:21 --> Utf8 Class Initialized
INFO - 2019-07-21 13:05:21 --> URI Class Initialized
INFO - 2019-07-21 13:05:21 --> Router Class Initialized
INFO - 2019-07-21 13:05:21 --> Output Class Initialized
INFO - 2019-07-21 13:05:21 --> Security Class Initialized
DEBUG - 2019-07-21 13:05:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 13:05:21 --> Input Class Initialized
INFO - 2019-07-21 13:05:21 --> Language Class Initialized
INFO - 2019-07-21 13:05:21 --> Loader Class Initialized
INFO - 2019-07-21 13:05:21 --> Database Driver Class Initialized
INFO - 2019-07-21 13:05:21 --> Controller Class Initialized
INFO - 2019-07-21 13:05:21 --> Model "Product" initialized
INFO - 2019-07-21 13:05:21 --> Final output sent to browser
DEBUG - 2019-07-21 13:05:21 --> Total execution time: 0.0223
INFO - 2019-07-21 13:07:10 --> Config Class Initialized
INFO - 2019-07-21 13:07:10 --> Hooks Class Initialized
DEBUG - 2019-07-21 13:07:10 --> UTF-8 Support Enabled
INFO - 2019-07-21 13:07:10 --> Utf8 Class Initialized
INFO - 2019-07-21 13:07:10 --> URI Class Initialized
INFO - 2019-07-21 13:07:10 --> Router Class Initialized
INFO - 2019-07-21 13:07:10 --> Output Class Initialized
INFO - 2019-07-21 13:07:10 --> Security Class Initialized
DEBUG - 2019-07-21 13:07:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 13:07:10 --> Input Class Initialized
INFO - 2019-07-21 13:07:10 --> Language Class Initialized
INFO - 2019-07-21 13:07:10 --> Loader Class Initialized
INFO - 2019-07-21 13:07:10 --> Database Driver Class Initialized
INFO - 2019-07-21 13:07:10 --> Controller Class Initialized
INFO - 2019-07-21 13:07:10 --> Model "Product" initialized
INFO - 2019-07-21 13:07:10 --> Final output sent to browser
DEBUG - 2019-07-21 13:07:10 --> Total execution time: 0.0210
INFO - 2019-07-21 13:07:33 --> Config Class Initialized
INFO - 2019-07-21 13:07:33 --> Hooks Class Initialized
DEBUG - 2019-07-21 13:07:33 --> UTF-8 Support Enabled
INFO - 2019-07-21 13:07:33 --> Utf8 Class Initialized
INFO - 2019-07-21 13:07:33 --> URI Class Initialized
INFO - 2019-07-21 13:07:33 --> Router Class Initialized
INFO - 2019-07-21 13:07:33 --> Output Class Initialized
INFO - 2019-07-21 13:07:33 --> Security Class Initialized
DEBUG - 2019-07-21 13:07:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 13:07:33 --> Input Class Initialized
INFO - 2019-07-21 13:07:33 --> Language Class Initialized
INFO - 2019-07-21 13:07:33 --> Loader Class Initialized
INFO - 2019-07-21 13:07:33 --> Database Driver Class Initialized
INFO - 2019-07-21 13:07:33 --> Controller Class Initialized
INFO - 2019-07-21 13:07:33 --> Model "Product" initialized
INFO - 2019-07-21 13:07:33 --> Final output sent to browser
DEBUG - 2019-07-21 13:07:33 --> Total execution time: 0.0245
INFO - 2019-07-21 13:07:37 --> Config Class Initialized
INFO - 2019-07-21 13:07:37 --> Hooks Class Initialized
DEBUG - 2019-07-21 13:07:37 --> UTF-8 Support Enabled
INFO - 2019-07-21 13:07:37 --> Utf8 Class Initialized
INFO - 2019-07-21 13:07:37 --> URI Class Initialized
INFO - 2019-07-21 13:07:37 --> Router Class Initialized
INFO - 2019-07-21 13:07:37 --> Output Class Initialized
INFO - 2019-07-21 13:07:37 --> Security Class Initialized
DEBUG - 2019-07-21 13:07:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 13:07:37 --> Input Class Initialized
INFO - 2019-07-21 13:07:37 --> Language Class Initialized
INFO - 2019-07-21 13:07:37 --> Loader Class Initialized
INFO - 2019-07-21 13:07:37 --> Database Driver Class Initialized
INFO - 2019-07-21 13:07:37 --> Controller Class Initialized
INFO - 2019-07-21 13:07:37 --> Model "Product" initialized
INFO - 2019-07-21 13:07:37 --> Final output sent to browser
DEBUG - 2019-07-21 13:07:37 --> Total execution time: 0.0195
INFO - 2019-07-21 13:07:44 --> Config Class Initialized
INFO - 2019-07-21 13:07:44 --> Hooks Class Initialized
DEBUG - 2019-07-21 13:07:44 --> UTF-8 Support Enabled
INFO - 2019-07-21 13:07:44 --> Utf8 Class Initialized
INFO - 2019-07-21 13:07:44 --> URI Class Initialized
INFO - 2019-07-21 13:07:44 --> Router Class Initialized
INFO - 2019-07-21 13:07:44 --> Output Class Initialized
INFO - 2019-07-21 13:07:44 --> Security Class Initialized
DEBUG - 2019-07-21 13:07:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 13:07:44 --> Input Class Initialized
INFO - 2019-07-21 13:07:44 --> Language Class Initialized
INFO - 2019-07-21 13:07:44 --> Loader Class Initialized
INFO - 2019-07-21 13:07:44 --> Database Driver Class Initialized
INFO - 2019-07-21 13:07:44 --> Controller Class Initialized
INFO - 2019-07-21 13:07:44 --> Model "Product" initialized
INFO - 2019-07-21 13:07:44 --> Final output sent to browser
DEBUG - 2019-07-21 13:07:44 --> Total execution time: 0.0202
INFO - 2019-07-21 13:07:44 --> Config Class Initialized
INFO - 2019-07-21 13:07:44 --> Hooks Class Initialized
DEBUG - 2019-07-21 13:07:44 --> UTF-8 Support Enabled
INFO - 2019-07-21 13:07:44 --> Utf8 Class Initialized
INFO - 2019-07-21 13:07:44 --> URI Class Initialized
INFO - 2019-07-21 13:07:44 --> Router Class Initialized
INFO - 2019-07-21 13:07:44 --> Output Class Initialized
INFO - 2019-07-21 13:07:44 --> Security Class Initialized
DEBUG - 2019-07-21 13:07:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 13:07:44 --> Input Class Initialized
INFO - 2019-07-21 13:07:44 --> Language Class Initialized
INFO - 2019-07-21 13:07:44 --> Loader Class Initialized
INFO - 2019-07-21 13:07:44 --> Database Driver Class Initialized
INFO - 2019-07-21 13:07:44 --> Controller Class Initialized
INFO - 2019-07-21 13:07:44 --> Model "Product" initialized
INFO - 2019-07-21 13:07:44 --> Final output sent to browser
DEBUG - 2019-07-21 13:07:44 --> Total execution time: 0.1518
INFO - 2019-07-21 13:08:30 --> Config Class Initialized
INFO - 2019-07-21 13:08:30 --> Hooks Class Initialized
DEBUG - 2019-07-21 13:08:30 --> UTF-8 Support Enabled
INFO - 2019-07-21 13:08:30 --> Utf8 Class Initialized
INFO - 2019-07-21 13:08:30 --> URI Class Initialized
INFO - 2019-07-21 13:08:30 --> Router Class Initialized
INFO - 2019-07-21 13:08:30 --> Output Class Initialized
INFO - 2019-07-21 13:08:30 --> Security Class Initialized
DEBUG - 2019-07-21 13:08:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 13:08:30 --> Input Class Initialized
INFO - 2019-07-21 13:08:30 --> Language Class Initialized
INFO - 2019-07-21 13:08:30 --> Loader Class Initialized
INFO - 2019-07-21 13:08:30 --> Database Driver Class Initialized
INFO - 2019-07-21 13:08:30 --> Controller Class Initialized
INFO - 2019-07-21 13:08:30 --> Model "Product" initialized
INFO - 2019-07-21 13:08:30 --> Final output sent to browser
DEBUG - 2019-07-21 13:08:30 --> Total execution time: 0.0321
INFO - 2019-07-21 13:08:40 --> Config Class Initialized
INFO - 2019-07-21 13:08:40 --> Hooks Class Initialized
DEBUG - 2019-07-21 13:08:40 --> UTF-8 Support Enabled
INFO - 2019-07-21 13:08:40 --> Utf8 Class Initialized
INFO - 2019-07-21 13:08:40 --> URI Class Initialized
INFO - 2019-07-21 13:08:40 --> Router Class Initialized
INFO - 2019-07-21 13:08:40 --> Output Class Initialized
INFO - 2019-07-21 13:08:40 --> Security Class Initialized
DEBUG - 2019-07-21 13:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 13:08:40 --> Input Class Initialized
INFO - 2019-07-21 13:08:40 --> Language Class Initialized
INFO - 2019-07-21 13:08:40 --> Loader Class Initialized
INFO - 2019-07-21 13:08:40 --> Database Driver Class Initialized
INFO - 2019-07-21 13:08:40 --> Controller Class Initialized
INFO - 2019-07-21 13:08:40 --> Model "Product" initialized
INFO - 2019-07-21 13:08:40 --> Final output sent to browser
DEBUG - 2019-07-21 13:08:40 --> Total execution time: 0.0195
INFO - 2019-07-21 13:08:53 --> Config Class Initialized
INFO - 2019-07-21 13:08:53 --> Hooks Class Initialized
DEBUG - 2019-07-21 13:08:53 --> UTF-8 Support Enabled
INFO - 2019-07-21 13:08:53 --> Utf8 Class Initialized
INFO - 2019-07-21 13:08:53 --> URI Class Initialized
INFO - 2019-07-21 13:08:53 --> Router Class Initialized
INFO - 2019-07-21 13:08:53 --> Output Class Initialized
INFO - 2019-07-21 13:08:53 --> Security Class Initialized
DEBUG - 2019-07-21 13:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 13:08:53 --> Input Class Initialized
INFO - 2019-07-21 13:08:53 --> Language Class Initialized
INFO - 2019-07-21 13:08:53 --> Loader Class Initialized
INFO - 2019-07-21 13:08:53 --> Database Driver Class Initialized
INFO - 2019-07-21 13:08:53 --> Controller Class Initialized
INFO - 2019-07-21 13:08:53 --> Model "Product" initialized
INFO - 2019-07-21 13:08:53 --> Final output sent to browser
DEBUG - 2019-07-21 13:08:53 --> Total execution time: 0.0206
INFO - 2019-07-21 13:08:54 --> Config Class Initialized
INFO - 2019-07-21 13:08:54 --> Hooks Class Initialized
DEBUG - 2019-07-21 13:08:54 --> UTF-8 Support Enabled
INFO - 2019-07-21 13:08:54 --> Utf8 Class Initialized
INFO - 2019-07-21 13:08:54 --> URI Class Initialized
INFO - 2019-07-21 13:08:54 --> Router Class Initialized
INFO - 2019-07-21 13:08:54 --> Output Class Initialized
INFO - 2019-07-21 13:08:54 --> Security Class Initialized
DEBUG - 2019-07-21 13:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 13:08:54 --> Input Class Initialized
INFO - 2019-07-21 13:08:54 --> Language Class Initialized
INFO - 2019-07-21 13:08:54 --> Loader Class Initialized
INFO - 2019-07-21 13:08:54 --> Database Driver Class Initialized
INFO - 2019-07-21 13:08:54 --> Controller Class Initialized
INFO - 2019-07-21 13:08:54 --> Model "Product" initialized
INFO - 2019-07-21 13:08:54 --> Final output sent to browser
DEBUG - 2019-07-21 13:08:54 --> Total execution time: 0.0162
INFO - 2019-07-21 13:08:54 --> Config Class Initialized
INFO - 2019-07-21 13:08:54 --> Hooks Class Initialized
DEBUG - 2019-07-21 13:08:54 --> UTF-8 Support Enabled
INFO - 2019-07-21 13:08:54 --> Utf8 Class Initialized
INFO - 2019-07-21 13:08:54 --> URI Class Initialized
INFO - 2019-07-21 13:08:54 --> Router Class Initialized
INFO - 2019-07-21 13:08:54 --> Output Class Initialized
INFO - 2019-07-21 13:08:54 --> Security Class Initialized
DEBUG - 2019-07-21 13:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 13:08:54 --> Input Class Initialized
INFO - 2019-07-21 13:08:54 --> Language Class Initialized
INFO - 2019-07-21 13:08:54 --> Loader Class Initialized
INFO - 2019-07-21 13:08:54 --> Database Driver Class Initialized
INFO - 2019-07-21 13:08:54 --> Controller Class Initialized
INFO - 2019-07-21 13:08:54 --> Model "Product" initialized
INFO - 2019-07-21 13:08:54 --> Final output sent to browser
DEBUG - 2019-07-21 13:08:54 --> Total execution time: 0.0179
INFO - 2019-07-21 13:08:56 --> Config Class Initialized
INFO - 2019-07-21 13:08:56 --> Hooks Class Initialized
DEBUG - 2019-07-21 13:08:56 --> UTF-8 Support Enabled
INFO - 2019-07-21 13:08:56 --> Utf8 Class Initialized
INFO - 2019-07-21 13:08:56 --> URI Class Initialized
INFO - 2019-07-21 13:08:56 --> Router Class Initialized
INFO - 2019-07-21 13:08:56 --> Output Class Initialized
INFO - 2019-07-21 13:08:56 --> Security Class Initialized
DEBUG - 2019-07-21 13:08:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 13:08:56 --> Input Class Initialized
INFO - 2019-07-21 13:08:56 --> Language Class Initialized
INFO - 2019-07-21 13:08:56 --> Loader Class Initialized
INFO - 2019-07-21 13:08:56 --> Database Driver Class Initialized
INFO - 2019-07-21 13:08:56 --> Controller Class Initialized
INFO - 2019-07-21 13:08:56 --> Model "Product" initialized
INFO - 2019-07-21 13:08:56 --> Final output sent to browser
DEBUG - 2019-07-21 13:08:56 --> Total execution time: 0.0208
INFO - 2019-07-21 13:08:57 --> Config Class Initialized
INFO - 2019-07-21 13:08:57 --> Hooks Class Initialized
DEBUG - 2019-07-21 13:08:57 --> UTF-8 Support Enabled
INFO - 2019-07-21 13:08:57 --> Utf8 Class Initialized
INFO - 2019-07-21 13:08:57 --> URI Class Initialized
INFO - 2019-07-21 13:08:57 --> Router Class Initialized
INFO - 2019-07-21 13:08:57 --> Output Class Initialized
INFO - 2019-07-21 13:08:57 --> Security Class Initialized
DEBUG - 2019-07-21 13:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 13:08:57 --> Input Class Initialized
INFO - 2019-07-21 13:08:57 --> Language Class Initialized
INFO - 2019-07-21 13:08:57 --> Loader Class Initialized
INFO - 2019-07-21 13:08:57 --> Database Driver Class Initialized
INFO - 2019-07-21 13:08:57 --> Controller Class Initialized
INFO - 2019-07-21 13:08:57 --> Model "Product" initialized
INFO - 2019-07-21 13:08:57 --> Final output sent to browser
DEBUG - 2019-07-21 13:08:57 --> Total execution time: 0.0170
INFO - 2019-07-21 13:08:58 --> Config Class Initialized
INFO - 2019-07-21 13:08:58 --> Hooks Class Initialized
DEBUG - 2019-07-21 13:08:58 --> UTF-8 Support Enabled
INFO - 2019-07-21 13:08:58 --> Utf8 Class Initialized
INFO - 2019-07-21 13:08:58 --> URI Class Initialized
INFO - 2019-07-21 13:08:58 --> Router Class Initialized
INFO - 2019-07-21 13:08:58 --> Output Class Initialized
INFO - 2019-07-21 13:08:58 --> Security Class Initialized
DEBUG - 2019-07-21 13:08:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 13:08:58 --> Input Class Initialized
INFO - 2019-07-21 13:08:58 --> Language Class Initialized
INFO - 2019-07-21 13:08:58 --> Loader Class Initialized
INFO - 2019-07-21 13:08:58 --> Database Driver Class Initialized
INFO - 2019-07-21 13:08:58 --> Controller Class Initialized
INFO - 2019-07-21 13:08:58 --> Model "Product" initialized
INFO - 2019-07-21 13:08:58 --> Final output sent to browser
DEBUG - 2019-07-21 13:08:58 --> Total execution time: 0.0206
INFO - 2019-07-21 13:09:00 --> Config Class Initialized
INFO - 2019-07-21 13:09:00 --> Hooks Class Initialized
DEBUG - 2019-07-21 13:09:00 --> UTF-8 Support Enabled
INFO - 2019-07-21 13:09:00 --> Utf8 Class Initialized
INFO - 2019-07-21 13:09:00 --> URI Class Initialized
INFO - 2019-07-21 13:09:00 --> Router Class Initialized
INFO - 2019-07-21 13:09:00 --> Output Class Initialized
INFO - 2019-07-21 13:09:00 --> Security Class Initialized
DEBUG - 2019-07-21 13:09:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 13:09:00 --> Input Class Initialized
INFO - 2019-07-21 13:09:00 --> Language Class Initialized
INFO - 2019-07-21 13:09:00 --> Loader Class Initialized
INFO - 2019-07-21 13:09:00 --> Database Driver Class Initialized
INFO - 2019-07-21 13:09:00 --> Controller Class Initialized
INFO - 2019-07-21 13:09:00 --> Model "Product" initialized
INFO - 2019-07-21 13:09:00 --> Final output sent to browser
DEBUG - 2019-07-21 13:09:00 --> Total execution time: 0.0190
INFO - 2019-07-21 13:09:02 --> Config Class Initialized
INFO - 2019-07-21 13:09:02 --> Hooks Class Initialized
DEBUG - 2019-07-21 13:09:02 --> UTF-8 Support Enabled
INFO - 2019-07-21 13:09:02 --> Utf8 Class Initialized
INFO - 2019-07-21 13:09:02 --> URI Class Initialized
INFO - 2019-07-21 13:09:02 --> Router Class Initialized
INFO - 2019-07-21 13:09:02 --> Output Class Initialized
INFO - 2019-07-21 13:09:02 --> Security Class Initialized
DEBUG - 2019-07-21 13:09:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 13:09:02 --> Input Class Initialized
INFO - 2019-07-21 13:09:02 --> Language Class Initialized
INFO - 2019-07-21 13:09:02 --> Loader Class Initialized
INFO - 2019-07-21 13:09:02 --> Database Driver Class Initialized
INFO - 2019-07-21 13:09:02 --> Controller Class Initialized
INFO - 2019-07-21 13:09:02 --> Model "Product" initialized
INFO - 2019-07-21 13:09:02 --> Final output sent to browser
DEBUG - 2019-07-21 13:09:02 --> Total execution time: 0.0196
INFO - 2019-07-21 13:09:19 --> Config Class Initialized
INFO - 2019-07-21 13:09:19 --> Hooks Class Initialized
DEBUG - 2019-07-21 13:09:19 --> UTF-8 Support Enabled
INFO - 2019-07-21 13:09:19 --> Utf8 Class Initialized
INFO - 2019-07-21 13:09:19 --> URI Class Initialized
INFO - 2019-07-21 13:09:19 --> Config Class Initialized
INFO - 2019-07-21 13:09:19 --> Hooks Class Initialized
INFO - 2019-07-21 13:09:19 --> Router Class Initialized
DEBUG - 2019-07-21 13:09:19 --> UTF-8 Support Enabled
INFO - 2019-07-21 13:09:19 --> Utf8 Class Initialized
INFO - 2019-07-21 13:09:19 --> Output Class Initialized
INFO - 2019-07-21 13:09:19 --> URI Class Initialized
INFO - 2019-07-21 13:09:19 --> Router Class Initialized
INFO - 2019-07-21 13:09:19 --> Security Class Initialized
DEBUG - 2019-07-21 13:09:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 13:09:19 --> Input Class Initialized
INFO - 2019-07-21 13:09:19 --> Language Class Initialized
INFO - 2019-07-21 13:09:19 --> Output Class Initialized
INFO - 2019-07-21 13:09:19 --> Security Class Initialized
INFO - 2019-07-21 13:09:19 --> Loader Class Initialized
DEBUG - 2019-07-21 13:09:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 13:09:19 --> Input Class Initialized
INFO - 2019-07-21 13:09:19 --> Language Class Initialized
INFO - 2019-07-21 13:09:19 --> Loader Class Initialized
INFO - 2019-07-21 13:09:19 --> Database Driver Class Initialized
INFO - 2019-07-21 13:09:19 --> Controller Class Initialized
INFO - 2019-07-21 13:09:19 --> Model "Product" initialized
INFO - 2019-07-21 13:09:19 --> Final output sent to browser
DEBUG - 2019-07-21 13:09:19 --> Total execution time: 0.0264
INFO - 2019-07-21 13:09:19 --> Database Driver Class Initialized
INFO - 2019-07-21 13:09:19 --> Controller Class Initialized
INFO - 2019-07-21 13:09:19 --> Model "Product" initialized
INFO - 2019-07-21 13:09:19 --> Final output sent to browser
DEBUG - 2019-07-21 13:09:19 --> Total execution time: 0.0403
INFO - 2019-07-21 13:09:20 --> Config Class Initialized
INFO - 2019-07-21 13:09:20 --> Hooks Class Initialized
DEBUG - 2019-07-21 13:09:20 --> UTF-8 Support Enabled
INFO - 2019-07-21 13:09:20 --> Utf8 Class Initialized
INFO - 2019-07-21 13:09:20 --> URI Class Initialized
INFO - 2019-07-21 13:09:20 --> Router Class Initialized
INFO - 2019-07-21 13:09:20 --> Output Class Initialized
INFO - 2019-07-21 13:09:20 --> Security Class Initialized
DEBUG - 2019-07-21 13:09:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 13:09:20 --> Input Class Initialized
INFO - 2019-07-21 13:09:20 --> Language Class Initialized
INFO - 2019-07-21 13:09:20 --> Loader Class Initialized
INFO - 2019-07-21 13:09:20 --> Database Driver Class Initialized
INFO - 2019-07-21 13:09:20 --> Controller Class Initialized
INFO - 2019-07-21 13:09:20 --> Model "Product" initialized
INFO - 2019-07-21 13:09:20 --> Final output sent to browser
DEBUG - 2019-07-21 13:09:20 --> Total execution time: 0.0216
INFO - 2019-07-21 13:09:20 --> Config Class Initialized
INFO - 2019-07-21 13:09:20 --> Hooks Class Initialized
DEBUG - 2019-07-21 13:09:20 --> UTF-8 Support Enabled
INFO - 2019-07-21 13:09:20 --> Utf8 Class Initialized
INFO - 2019-07-21 13:09:20 --> URI Class Initialized
INFO - 2019-07-21 13:09:20 --> Router Class Initialized
INFO - 2019-07-21 13:09:20 --> Output Class Initialized
INFO - 2019-07-21 13:09:20 --> Security Class Initialized
DEBUG - 2019-07-21 13:09:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 13:09:20 --> Input Class Initialized
INFO - 2019-07-21 13:09:20 --> Language Class Initialized
INFO - 2019-07-21 13:09:20 --> Loader Class Initialized
INFO - 2019-07-21 13:09:20 --> Database Driver Class Initialized
INFO - 2019-07-21 13:09:20 --> Controller Class Initialized
INFO - 2019-07-21 13:09:20 --> Model "Product" initialized
INFO - 2019-07-21 13:09:20 --> Final output sent to browser
DEBUG - 2019-07-21 13:09:20 --> Total execution time: 0.0159
INFO - 2019-07-21 13:09:28 --> Config Class Initialized
INFO - 2019-07-21 13:09:28 --> Hooks Class Initialized
DEBUG - 2019-07-21 13:09:28 --> UTF-8 Support Enabled
INFO - 2019-07-21 13:09:28 --> Utf8 Class Initialized
INFO - 2019-07-21 13:09:28 --> URI Class Initialized
INFO - 2019-07-21 13:09:28 --> Router Class Initialized
INFO - 2019-07-21 13:09:28 --> Output Class Initialized
INFO - 2019-07-21 13:09:28 --> Security Class Initialized
DEBUG - 2019-07-21 13:09:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 13:09:28 --> Input Class Initialized
INFO - 2019-07-21 13:09:28 --> Language Class Initialized
INFO - 2019-07-21 13:09:28 --> Loader Class Initialized
INFO - 2019-07-21 13:09:28 --> Database Driver Class Initialized
INFO - 2019-07-21 13:09:28 --> Controller Class Initialized
INFO - 2019-07-21 13:09:28 --> Model "Product" initialized
INFO - 2019-07-21 13:09:28 --> Final output sent to browser
DEBUG - 2019-07-21 13:09:28 --> Total execution time: 0.0192
INFO - 2019-07-21 13:09:33 --> Config Class Initialized
INFO - 2019-07-21 13:09:33 --> Hooks Class Initialized
DEBUG - 2019-07-21 13:09:33 --> UTF-8 Support Enabled
INFO - 2019-07-21 13:09:33 --> Utf8 Class Initialized
INFO - 2019-07-21 13:09:33 --> URI Class Initialized
INFO - 2019-07-21 13:09:33 --> Router Class Initialized
INFO - 2019-07-21 13:09:33 --> Output Class Initialized
INFO - 2019-07-21 13:09:33 --> Security Class Initialized
DEBUG - 2019-07-21 13:09:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 13:09:33 --> Input Class Initialized
INFO - 2019-07-21 13:09:33 --> Language Class Initialized
INFO - 2019-07-21 13:09:33 --> Loader Class Initialized
INFO - 2019-07-21 13:09:33 --> Database Driver Class Initialized
INFO - 2019-07-21 13:09:33 --> Controller Class Initialized
INFO - 2019-07-21 13:09:33 --> Model "Product" initialized
INFO - 2019-07-21 13:09:33 --> Final output sent to browser
DEBUG - 2019-07-21 13:09:33 --> Total execution time: 0.0191
INFO - 2019-07-21 13:09:34 --> Config Class Initialized
INFO - 2019-07-21 13:09:34 --> Hooks Class Initialized
DEBUG - 2019-07-21 13:09:34 --> UTF-8 Support Enabled
INFO - 2019-07-21 13:09:34 --> Utf8 Class Initialized
INFO - 2019-07-21 13:09:34 --> URI Class Initialized
INFO - 2019-07-21 13:09:34 --> Router Class Initialized
INFO - 2019-07-21 13:09:34 --> Output Class Initialized
INFO - 2019-07-21 13:09:34 --> Security Class Initialized
DEBUG - 2019-07-21 13:09:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 13:09:34 --> Input Class Initialized
INFO - 2019-07-21 13:09:34 --> Language Class Initialized
INFO - 2019-07-21 13:09:34 --> Loader Class Initialized
INFO - 2019-07-21 13:09:34 --> Database Driver Class Initialized
INFO - 2019-07-21 13:09:34 --> Controller Class Initialized
INFO - 2019-07-21 13:09:34 --> Model "Product" initialized
INFO - 2019-07-21 13:09:34 --> Final output sent to browser
DEBUG - 2019-07-21 13:09:34 --> Total execution time: 0.0177
INFO - 2019-07-21 13:09:34 --> Config Class Initialized
INFO - 2019-07-21 13:09:34 --> Hooks Class Initialized
DEBUG - 2019-07-21 13:09:34 --> UTF-8 Support Enabled
INFO - 2019-07-21 13:09:34 --> Utf8 Class Initialized
INFO - 2019-07-21 13:09:34 --> URI Class Initialized
INFO - 2019-07-21 13:09:34 --> Router Class Initialized
INFO - 2019-07-21 13:09:34 --> Output Class Initialized
INFO - 2019-07-21 13:09:34 --> Security Class Initialized
DEBUG - 2019-07-21 13:09:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 13:09:34 --> Input Class Initialized
INFO - 2019-07-21 13:09:34 --> Language Class Initialized
INFO - 2019-07-21 13:09:34 --> Loader Class Initialized
INFO - 2019-07-21 13:09:34 --> Database Driver Class Initialized
INFO - 2019-07-21 13:09:34 --> Controller Class Initialized
INFO - 2019-07-21 13:09:34 --> Model "Product" initialized
INFO - 2019-07-21 13:09:34 --> Final output sent to browser
DEBUG - 2019-07-21 13:09:34 --> Total execution time: 0.0150
INFO - 2019-07-21 13:09:37 --> Config Class Initialized
INFO - 2019-07-21 13:09:37 --> Hooks Class Initialized
DEBUG - 2019-07-21 13:09:37 --> UTF-8 Support Enabled
INFO - 2019-07-21 13:09:37 --> Utf8 Class Initialized
INFO - 2019-07-21 13:09:37 --> URI Class Initialized
INFO - 2019-07-21 13:09:37 --> Router Class Initialized
INFO - 2019-07-21 13:09:37 --> Output Class Initialized
INFO - 2019-07-21 13:09:37 --> Security Class Initialized
DEBUG - 2019-07-21 13:09:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 13:09:37 --> Input Class Initialized
INFO - 2019-07-21 13:09:37 --> Language Class Initialized
INFO - 2019-07-21 13:09:37 --> Loader Class Initialized
INFO - 2019-07-21 13:09:37 --> Database Driver Class Initialized
INFO - 2019-07-21 13:09:37 --> Controller Class Initialized
INFO - 2019-07-21 13:09:37 --> Model "Product" initialized
INFO - 2019-07-21 13:09:37 --> Final output sent to browser
DEBUG - 2019-07-21 13:09:37 --> Total execution time: 0.0194
INFO - 2019-07-21 13:11:29 --> Config Class Initialized
INFO - 2019-07-21 13:11:29 --> Hooks Class Initialized
DEBUG - 2019-07-21 13:11:29 --> UTF-8 Support Enabled
INFO - 2019-07-21 13:11:29 --> Utf8 Class Initialized
INFO - 2019-07-21 13:11:29 --> URI Class Initialized
INFO - 2019-07-21 13:11:29 --> Router Class Initialized
INFO - 2019-07-21 13:11:29 --> Output Class Initialized
INFO - 2019-07-21 13:11:29 --> Security Class Initialized
DEBUG - 2019-07-21 13:11:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 13:11:29 --> Input Class Initialized
INFO - 2019-07-21 13:11:29 --> Language Class Initialized
INFO - 2019-07-21 13:11:29 --> Loader Class Initialized
INFO - 2019-07-21 13:11:29 --> Database Driver Class Initialized
INFO - 2019-07-21 13:11:29 --> Controller Class Initialized
INFO - 2019-07-21 13:11:29 --> Model "Product" initialized
INFO - 2019-07-21 13:11:29 --> Final output sent to browser
DEBUG - 2019-07-21 13:11:29 --> Total execution time: 0.0151
INFO - 2019-07-21 13:11:29 --> Config Class Initialized
INFO - 2019-07-21 13:11:29 --> Hooks Class Initialized
DEBUG - 2019-07-21 13:11:29 --> UTF-8 Support Enabled
INFO - 2019-07-21 13:11:29 --> Utf8 Class Initialized
INFO - 2019-07-21 13:11:29 --> URI Class Initialized
INFO - 2019-07-21 13:11:29 --> Router Class Initialized
INFO - 2019-07-21 13:11:29 --> Output Class Initialized
INFO - 2019-07-21 13:11:29 --> Security Class Initialized
DEBUG - 2019-07-21 13:11:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 13:11:29 --> Input Class Initialized
INFO - 2019-07-21 13:11:29 --> Language Class Initialized
INFO - 2019-07-21 13:11:29 --> Loader Class Initialized
INFO - 2019-07-21 13:11:29 --> Database Driver Class Initialized
INFO - 2019-07-21 13:11:29 --> Controller Class Initialized
INFO - 2019-07-21 13:11:29 --> Model "Product" initialized
INFO - 2019-07-21 13:11:29 --> Final output sent to browser
DEBUG - 2019-07-21 13:11:29 --> Total execution time: 0.2085
INFO - 2019-07-21 13:11:35 --> Config Class Initialized
INFO - 2019-07-21 13:11:35 --> Hooks Class Initialized
DEBUG - 2019-07-21 13:11:35 --> UTF-8 Support Enabled
INFO - 2019-07-21 13:11:35 --> Utf8 Class Initialized
INFO - 2019-07-21 13:11:35 --> URI Class Initialized
INFO - 2019-07-21 13:11:35 --> Router Class Initialized
INFO - 2019-07-21 13:11:35 --> Output Class Initialized
INFO - 2019-07-21 13:11:35 --> Security Class Initialized
DEBUG - 2019-07-21 13:11:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 13:11:35 --> Input Class Initialized
INFO - 2019-07-21 13:11:35 --> Language Class Initialized
INFO - 2019-07-21 13:11:35 --> Loader Class Initialized
INFO - 2019-07-21 13:11:35 --> Database Driver Class Initialized
INFO - 2019-07-21 13:11:35 --> Controller Class Initialized
INFO - 2019-07-21 13:11:35 --> Model "Product" initialized
INFO - 2019-07-21 13:11:35 --> Final output sent to browser
DEBUG - 2019-07-21 13:11:35 --> Total execution time: 0.0162
INFO - 2019-07-21 13:11:35 --> Config Class Initialized
INFO - 2019-07-21 13:11:35 --> Hooks Class Initialized
DEBUG - 2019-07-21 13:11:35 --> UTF-8 Support Enabled
INFO - 2019-07-21 13:11:35 --> Utf8 Class Initialized
INFO - 2019-07-21 13:11:35 --> URI Class Initialized
INFO - 2019-07-21 13:11:35 --> Router Class Initialized
INFO - 2019-07-21 13:11:35 --> Output Class Initialized
INFO - 2019-07-21 13:11:35 --> Security Class Initialized
DEBUG - 2019-07-21 13:11:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 13:11:35 --> Input Class Initialized
INFO - 2019-07-21 13:11:35 --> Language Class Initialized
INFO - 2019-07-21 13:11:35 --> Loader Class Initialized
INFO - 2019-07-21 13:11:35 --> Database Driver Class Initialized
INFO - 2019-07-21 13:11:35 --> Controller Class Initialized
INFO - 2019-07-21 13:11:35 --> Model "Product" initialized
INFO - 2019-07-21 13:11:35 --> Final output sent to browser
DEBUG - 2019-07-21 13:11:35 --> Total execution time: 0.0646
INFO - 2019-07-21 13:11:36 --> Config Class Initialized
INFO - 2019-07-21 13:11:36 --> Hooks Class Initialized
DEBUG - 2019-07-21 13:11:36 --> UTF-8 Support Enabled
INFO - 2019-07-21 13:11:36 --> Utf8 Class Initialized
INFO - 2019-07-21 13:11:36 --> URI Class Initialized
INFO - 2019-07-21 13:11:36 --> Router Class Initialized
INFO - 2019-07-21 13:11:36 --> Output Class Initialized
INFO - 2019-07-21 13:11:36 --> Security Class Initialized
DEBUG - 2019-07-21 13:11:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 13:11:36 --> Input Class Initialized
INFO - 2019-07-21 13:11:36 --> Language Class Initialized
INFO - 2019-07-21 13:11:36 --> Loader Class Initialized
INFO - 2019-07-21 13:11:36 --> Database Driver Class Initialized
INFO - 2019-07-21 13:11:36 --> Controller Class Initialized
INFO - 2019-07-21 13:11:36 --> Model "Product" initialized
INFO - 2019-07-21 13:11:36 --> Final output sent to browser
DEBUG - 2019-07-21 13:11:36 --> Total execution time: 0.0210
INFO - 2019-07-21 15:56:02 --> Config Class Initialized
INFO - 2019-07-21 15:56:02 --> Hooks Class Initialized
DEBUG - 2019-07-21 15:56:02 --> UTF-8 Support Enabled
INFO - 2019-07-21 15:56:02 --> Utf8 Class Initialized
INFO - 2019-07-21 15:56:02 --> URI Class Initialized
INFO - 2019-07-21 15:56:02 --> Router Class Initialized
INFO - 2019-07-21 15:56:02 --> Output Class Initialized
INFO - 2019-07-21 15:56:02 --> Security Class Initialized
DEBUG - 2019-07-21 15:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 15:56:02 --> Input Class Initialized
INFO - 2019-07-21 15:56:02 --> Language Class Initialized
INFO - 2019-07-21 15:56:02 --> Loader Class Initialized
INFO - 2019-07-21 15:56:02 --> Database Driver Class Initialized
INFO - 2019-07-21 15:56:02 --> Controller Class Initialized
INFO - 2019-07-21 15:56:02 --> Model "Product" initialized
INFO - 2019-07-21 15:56:02 --> Final output sent to browser
DEBUG - 2019-07-21 15:56:02 --> Total execution time: 0.1835
INFO - 2019-07-21 15:56:03 --> Config Class Initialized
INFO - 2019-07-21 15:56:03 --> Hooks Class Initialized
DEBUG - 2019-07-21 15:56:03 --> UTF-8 Support Enabled
INFO - 2019-07-21 15:56:03 --> Utf8 Class Initialized
INFO - 2019-07-21 15:56:03 --> URI Class Initialized
INFO - 2019-07-21 15:56:03 --> Router Class Initialized
INFO - 2019-07-21 15:56:03 --> Output Class Initialized
INFO - 2019-07-21 15:56:03 --> Security Class Initialized
DEBUG - 2019-07-21 15:56:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 15:56:03 --> Input Class Initialized
INFO - 2019-07-21 15:56:03 --> Language Class Initialized
INFO - 2019-07-21 15:56:03 --> Loader Class Initialized
INFO - 2019-07-21 15:56:03 --> Database Driver Class Initialized
INFO - 2019-07-21 15:56:03 --> Controller Class Initialized
INFO - 2019-07-21 15:56:03 --> Model "Product" initialized
INFO - 2019-07-21 15:56:03 --> Final output sent to browser
DEBUG - 2019-07-21 15:56:03 --> Total execution time: 0.0196
INFO - 2019-07-21 15:56:06 --> Config Class Initialized
INFO - 2019-07-21 15:56:06 --> Hooks Class Initialized
DEBUG - 2019-07-21 15:56:06 --> UTF-8 Support Enabled
INFO - 2019-07-21 15:56:06 --> Utf8 Class Initialized
INFO - 2019-07-21 15:56:06 --> URI Class Initialized
INFO - 2019-07-21 15:56:06 --> Router Class Initialized
INFO - 2019-07-21 15:56:06 --> Output Class Initialized
INFO - 2019-07-21 15:56:06 --> Security Class Initialized
DEBUG - 2019-07-21 15:56:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 15:56:06 --> Input Class Initialized
INFO - 2019-07-21 15:56:06 --> Language Class Initialized
INFO - 2019-07-21 15:56:06 --> Loader Class Initialized
INFO - 2019-07-21 15:56:06 --> Database Driver Class Initialized
INFO - 2019-07-21 15:56:06 --> Controller Class Initialized
INFO - 2019-07-21 15:56:06 --> Model "Product" initialized
INFO - 2019-07-21 15:56:06 --> Final output sent to browser
DEBUG - 2019-07-21 15:56:06 --> Total execution time: 0.0456
INFO - 2019-07-21 15:56:13 --> Config Class Initialized
INFO - 2019-07-21 15:56:13 --> Hooks Class Initialized
DEBUG - 2019-07-21 15:56:13 --> UTF-8 Support Enabled
INFO - 2019-07-21 15:56:13 --> Utf8 Class Initialized
INFO - 2019-07-21 15:56:13 --> URI Class Initialized
INFO - 2019-07-21 15:56:13 --> Router Class Initialized
INFO - 2019-07-21 15:56:13 --> Output Class Initialized
INFO - 2019-07-21 15:56:13 --> Security Class Initialized
DEBUG - 2019-07-21 15:56:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 15:56:13 --> Input Class Initialized
INFO - 2019-07-21 15:56:13 --> Language Class Initialized
INFO - 2019-07-21 15:56:13 --> Loader Class Initialized
INFO - 2019-07-21 15:56:13 --> Database Driver Class Initialized
INFO - 2019-07-21 15:56:13 --> Controller Class Initialized
INFO - 2019-07-21 15:56:13 --> Model "Product" initialized
INFO - 2019-07-21 15:56:13 --> Final output sent to browser
DEBUG - 2019-07-21 15:56:13 --> Total execution time: 0.0186
INFO - 2019-07-21 16:19:38 --> Config Class Initialized
INFO - 2019-07-21 16:19:38 --> Hooks Class Initialized
DEBUG - 2019-07-21 16:19:39 --> UTF-8 Support Enabled
INFO - 2019-07-21 16:19:39 --> Utf8 Class Initialized
INFO - 2019-07-21 16:19:39 --> URI Class Initialized
INFO - 2019-07-21 16:19:39 --> Router Class Initialized
INFO - 2019-07-21 16:19:39 --> Output Class Initialized
INFO - 2019-07-21 16:19:39 --> Security Class Initialized
DEBUG - 2019-07-21 16:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 16:19:39 --> Input Class Initialized
INFO - 2019-07-21 16:19:39 --> Language Class Initialized
INFO - 2019-07-21 16:19:39 --> Loader Class Initialized
INFO - 2019-07-21 16:19:39 --> Database Driver Class Initialized
INFO - 2019-07-21 16:19:40 --> Controller Class Initialized
INFO - 2019-07-21 16:19:40 --> Model "Product" initialized
INFO - 2019-07-21 16:19:41 --> Final output sent to browser
DEBUG - 2019-07-21 16:19:41 --> Total execution time: 2.1156
INFO - 2019-07-21 16:19:41 --> Config Class Initialized
INFO - 2019-07-21 16:19:41 --> Hooks Class Initialized
DEBUG - 2019-07-21 16:19:41 --> UTF-8 Support Enabled
INFO - 2019-07-21 16:19:41 --> Utf8 Class Initialized
INFO - 2019-07-21 16:19:41 --> URI Class Initialized
INFO - 2019-07-21 16:19:41 --> Router Class Initialized
INFO - 2019-07-21 16:19:41 --> Output Class Initialized
INFO - 2019-07-21 16:19:41 --> Security Class Initialized
DEBUG - 2019-07-21 16:19:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 16:19:41 --> Input Class Initialized
INFO - 2019-07-21 16:19:41 --> Language Class Initialized
INFO - 2019-07-21 16:19:41 --> Loader Class Initialized
INFO - 2019-07-21 16:19:41 --> Database Driver Class Initialized
INFO - 2019-07-21 16:19:41 --> Controller Class Initialized
INFO - 2019-07-21 16:19:41 --> Model "Product" initialized
INFO - 2019-07-21 16:19:42 --> Final output sent to browser
DEBUG - 2019-07-21 16:19:42 --> Total execution time: 1.1293
INFO - 2019-07-21 16:20:38 --> Config Class Initialized
INFO - 2019-07-21 16:20:38 --> Hooks Class Initialized
DEBUG - 2019-07-21 16:20:38 --> UTF-8 Support Enabled
INFO - 2019-07-21 16:20:38 --> Utf8 Class Initialized
INFO - 2019-07-21 16:20:38 --> URI Class Initialized
INFO - 2019-07-21 16:20:38 --> Router Class Initialized
INFO - 2019-07-21 16:20:38 --> Output Class Initialized
INFO - 2019-07-21 16:20:38 --> Security Class Initialized
DEBUG - 2019-07-21 16:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 16:20:38 --> Input Class Initialized
INFO - 2019-07-21 16:20:38 --> Language Class Initialized
INFO - 2019-07-21 16:20:38 --> Loader Class Initialized
INFO - 2019-07-21 16:20:38 --> Database Driver Class Initialized
INFO - 2019-07-21 16:20:38 --> Controller Class Initialized
INFO - 2019-07-21 16:20:38 --> Model "Product" initialized
INFO - 2019-07-21 16:20:38 --> Final output sent to browser
DEBUG - 2019-07-21 16:20:38 --> Total execution time: 0.0304
INFO - 2019-07-21 16:20:38 --> Config Class Initialized
INFO - 2019-07-21 16:20:38 --> Hooks Class Initialized
DEBUG - 2019-07-21 16:20:38 --> UTF-8 Support Enabled
INFO - 2019-07-21 16:20:38 --> Utf8 Class Initialized
INFO - 2019-07-21 16:20:38 --> URI Class Initialized
INFO - 2019-07-21 16:20:38 --> Router Class Initialized
INFO - 2019-07-21 16:20:38 --> Output Class Initialized
INFO - 2019-07-21 16:20:38 --> Security Class Initialized
DEBUG - 2019-07-21 16:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 16:20:38 --> Input Class Initialized
INFO - 2019-07-21 16:20:38 --> Language Class Initialized
INFO - 2019-07-21 16:20:38 --> Loader Class Initialized
INFO - 2019-07-21 16:20:38 --> Database Driver Class Initialized
INFO - 2019-07-21 16:20:38 --> Controller Class Initialized
INFO - 2019-07-21 16:20:38 --> Model "Product" initialized
INFO - 2019-07-21 16:20:38 --> Final output sent to browser
DEBUG - 2019-07-21 16:20:38 --> Total execution time: 0.1777
INFO - 2019-07-21 16:20:57 --> Config Class Initialized
INFO - 2019-07-21 16:20:57 --> Hooks Class Initialized
DEBUG - 2019-07-21 16:20:57 --> UTF-8 Support Enabled
INFO - 2019-07-21 16:20:57 --> Utf8 Class Initialized
INFO - 2019-07-21 16:20:57 --> URI Class Initialized
INFO - 2019-07-21 16:20:57 --> Router Class Initialized
INFO - 2019-07-21 16:20:57 --> Output Class Initialized
INFO - 2019-07-21 16:20:57 --> Security Class Initialized
DEBUG - 2019-07-21 16:20:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 16:20:57 --> Input Class Initialized
INFO - 2019-07-21 16:20:57 --> Language Class Initialized
INFO - 2019-07-21 16:20:57 --> Loader Class Initialized
INFO - 2019-07-21 16:20:57 --> Database Driver Class Initialized
INFO - 2019-07-21 16:20:57 --> Controller Class Initialized
INFO - 2019-07-21 16:20:57 --> Model "Product" initialized
INFO - 2019-07-21 16:20:57 --> Final output sent to browser
DEBUG - 2019-07-21 16:20:57 --> Total execution time: 0.0493
INFO - 2019-07-21 16:20:57 --> Config Class Initialized
INFO - 2019-07-21 16:20:57 --> Hooks Class Initialized
DEBUG - 2019-07-21 16:20:57 --> UTF-8 Support Enabled
INFO - 2019-07-21 16:20:57 --> Utf8 Class Initialized
INFO - 2019-07-21 16:20:57 --> URI Class Initialized
INFO - 2019-07-21 16:20:57 --> Router Class Initialized
INFO - 2019-07-21 16:20:57 --> Output Class Initialized
INFO - 2019-07-21 16:20:57 --> Security Class Initialized
DEBUG - 2019-07-21 16:20:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 16:20:57 --> Input Class Initialized
INFO - 2019-07-21 16:20:57 --> Language Class Initialized
INFO - 2019-07-21 16:20:57 --> Loader Class Initialized
INFO - 2019-07-21 16:20:57 --> Database Driver Class Initialized
INFO - 2019-07-21 16:20:57 --> Controller Class Initialized
INFO - 2019-07-21 16:20:57 --> Model "Product" initialized
INFO - 2019-07-21 16:20:58 --> Final output sent to browser
DEBUG - 2019-07-21 16:20:58 --> Total execution time: 0.1820
INFO - 2019-07-21 16:32:34 --> Config Class Initialized
INFO - 2019-07-21 16:32:34 --> Hooks Class Initialized
DEBUG - 2019-07-21 16:32:34 --> UTF-8 Support Enabled
INFO - 2019-07-21 16:32:34 --> Utf8 Class Initialized
INFO - 2019-07-21 16:32:34 --> URI Class Initialized
INFO - 2019-07-21 16:32:34 --> Router Class Initialized
INFO - 2019-07-21 16:32:34 --> Output Class Initialized
INFO - 2019-07-21 16:32:34 --> Security Class Initialized
DEBUG - 2019-07-21 16:32:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 16:32:34 --> Input Class Initialized
INFO - 2019-07-21 16:32:34 --> Language Class Initialized
INFO - 2019-07-21 16:32:34 --> Loader Class Initialized
INFO - 2019-07-21 16:32:34 --> Database Driver Class Initialized
INFO - 2019-07-21 16:32:35 --> Controller Class Initialized
INFO - 2019-07-21 16:32:35 --> Model "Product" initialized
INFO - 2019-07-21 16:32:35 --> Final output sent to browser
DEBUG - 2019-07-21 16:32:35 --> Total execution time: 1.8657
INFO - 2019-07-21 16:32:36 --> Config Class Initialized
INFO - 2019-07-21 16:32:36 --> Hooks Class Initialized
DEBUG - 2019-07-21 16:32:36 --> UTF-8 Support Enabled
INFO - 2019-07-21 16:32:36 --> Utf8 Class Initialized
INFO - 2019-07-21 16:32:36 --> URI Class Initialized
INFO - 2019-07-21 16:32:36 --> Router Class Initialized
INFO - 2019-07-21 16:32:36 --> Output Class Initialized
INFO - 2019-07-21 16:32:36 --> Security Class Initialized
DEBUG - 2019-07-21 16:32:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 16:32:36 --> Input Class Initialized
INFO - 2019-07-21 16:32:36 --> Language Class Initialized
INFO - 2019-07-21 16:32:36 --> Loader Class Initialized
INFO - 2019-07-21 16:32:36 --> Database Driver Class Initialized
INFO - 2019-07-21 16:32:36 --> Controller Class Initialized
INFO - 2019-07-21 16:32:36 --> Model "Product" initialized
INFO - 2019-07-21 16:32:36 --> Final output sent to browser
DEBUG - 2019-07-21 16:32:36 --> Total execution time: 0.5350
INFO - 2019-07-21 16:32:52 --> Config Class Initialized
INFO - 2019-07-21 16:32:52 --> Hooks Class Initialized
DEBUG - 2019-07-21 16:32:52 --> UTF-8 Support Enabled
INFO - 2019-07-21 16:32:52 --> Utf8 Class Initialized
INFO - 2019-07-21 16:32:52 --> URI Class Initialized
INFO - 2019-07-21 16:32:52 --> Router Class Initialized
INFO - 2019-07-21 16:32:52 --> Output Class Initialized
INFO - 2019-07-21 16:32:52 --> Security Class Initialized
DEBUG - 2019-07-21 16:32:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 16:32:52 --> Input Class Initialized
INFO - 2019-07-21 16:32:52 --> Language Class Initialized
INFO - 2019-07-21 16:32:52 --> Loader Class Initialized
INFO - 2019-07-21 16:32:52 --> Database Driver Class Initialized
INFO - 2019-07-21 16:32:52 --> Controller Class Initialized
INFO - 2019-07-21 16:32:52 --> Model "Product" initialized
INFO - 2019-07-21 16:32:52 --> Final output sent to browser
DEBUG - 2019-07-21 16:32:52 --> Total execution time: 0.1055
INFO - 2019-07-21 16:32:52 --> Config Class Initialized
INFO - 2019-07-21 16:32:52 --> Hooks Class Initialized
DEBUG - 2019-07-21 16:32:52 --> UTF-8 Support Enabled
INFO - 2019-07-21 16:32:52 --> Utf8 Class Initialized
INFO - 2019-07-21 16:32:52 --> URI Class Initialized
INFO - 2019-07-21 16:32:52 --> Router Class Initialized
INFO - 2019-07-21 16:32:52 --> Output Class Initialized
INFO - 2019-07-21 16:32:52 --> Security Class Initialized
DEBUG - 2019-07-21 16:32:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 16:32:52 --> Input Class Initialized
INFO - 2019-07-21 16:32:52 --> Language Class Initialized
INFO - 2019-07-21 16:32:52 --> Loader Class Initialized
INFO - 2019-07-21 16:32:52 --> Database Driver Class Initialized
INFO - 2019-07-21 16:32:52 --> Controller Class Initialized
INFO - 2019-07-21 16:32:52 --> Model "Product" initialized
INFO - 2019-07-21 16:32:52 --> Final output sent to browser
DEBUG - 2019-07-21 16:32:52 --> Total execution time: 0.1145
INFO - 2019-07-21 16:34:12 --> Config Class Initialized
INFO - 2019-07-21 16:34:12 --> Hooks Class Initialized
DEBUG - 2019-07-21 16:34:12 --> UTF-8 Support Enabled
INFO - 2019-07-21 16:34:12 --> Utf8 Class Initialized
INFO - 2019-07-21 16:34:12 --> URI Class Initialized
INFO - 2019-07-21 16:34:12 --> Router Class Initialized
INFO - 2019-07-21 16:34:12 --> Output Class Initialized
INFO - 2019-07-21 16:34:12 --> Security Class Initialized
DEBUG - 2019-07-21 16:34:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 16:34:12 --> Input Class Initialized
INFO - 2019-07-21 16:34:12 --> Language Class Initialized
INFO - 2019-07-21 16:34:12 --> Loader Class Initialized
INFO - 2019-07-21 16:34:13 --> Database Driver Class Initialized
INFO - 2019-07-21 16:34:13 --> Controller Class Initialized
INFO - 2019-07-21 16:34:13 --> Model "Product" initialized
INFO - 2019-07-21 16:34:13 --> Final output sent to browser
DEBUG - 2019-07-21 16:34:13 --> Total execution time: 1.4299
INFO - 2019-07-21 16:34:13 --> Config Class Initialized
INFO - 2019-07-21 16:34:13 --> Hooks Class Initialized
DEBUG - 2019-07-21 16:34:13 --> UTF-8 Support Enabled
INFO - 2019-07-21 16:34:13 --> Utf8 Class Initialized
INFO - 2019-07-21 16:34:13 --> URI Class Initialized
INFO - 2019-07-21 16:34:13 --> Router Class Initialized
INFO - 2019-07-21 16:34:13 --> Output Class Initialized
INFO - 2019-07-21 16:34:13 --> Security Class Initialized
DEBUG - 2019-07-21 16:34:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 16:34:13 --> Input Class Initialized
INFO - 2019-07-21 16:34:13 --> Language Class Initialized
INFO - 2019-07-21 16:34:13 --> Loader Class Initialized
INFO - 2019-07-21 16:34:13 --> Database Driver Class Initialized
INFO - 2019-07-21 16:34:13 --> Controller Class Initialized
INFO - 2019-07-21 16:34:13 --> Model "Product" initialized
INFO - 2019-07-21 16:34:14 --> Final output sent to browser
DEBUG - 2019-07-21 16:34:14 --> Total execution time: 0.3249
INFO - 2019-07-21 16:34:23 --> Config Class Initialized
INFO - 2019-07-21 16:34:23 --> Hooks Class Initialized
DEBUG - 2019-07-21 16:34:23 --> UTF-8 Support Enabled
INFO - 2019-07-21 16:34:23 --> Utf8 Class Initialized
INFO - 2019-07-21 16:34:23 --> URI Class Initialized
INFO - 2019-07-21 16:34:23 --> Router Class Initialized
INFO - 2019-07-21 16:34:23 --> Output Class Initialized
INFO - 2019-07-21 16:34:23 --> Security Class Initialized
DEBUG - 2019-07-21 16:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 16:34:23 --> Input Class Initialized
INFO - 2019-07-21 16:34:23 --> Language Class Initialized
INFO - 2019-07-21 16:34:23 --> Loader Class Initialized
INFO - 2019-07-21 16:34:23 --> Database Driver Class Initialized
INFO - 2019-07-21 16:34:23 --> Controller Class Initialized
INFO - 2019-07-21 16:34:23 --> Model "Product" initialized
INFO - 2019-07-21 16:34:23 --> Final output sent to browser
DEBUG - 2019-07-21 16:34:23 --> Total execution time: 0.0946
INFO - 2019-07-21 16:34:23 --> Config Class Initialized
INFO - 2019-07-21 16:34:23 --> Hooks Class Initialized
DEBUG - 2019-07-21 16:34:23 --> UTF-8 Support Enabled
INFO - 2019-07-21 16:34:23 --> Utf8 Class Initialized
INFO - 2019-07-21 16:34:23 --> URI Class Initialized
INFO - 2019-07-21 16:34:23 --> Router Class Initialized
INFO - 2019-07-21 16:34:23 --> Output Class Initialized
INFO - 2019-07-21 16:34:23 --> Security Class Initialized
DEBUG - 2019-07-21 16:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 16:34:23 --> Input Class Initialized
INFO - 2019-07-21 16:34:23 --> Language Class Initialized
INFO - 2019-07-21 16:34:23 --> Loader Class Initialized
INFO - 2019-07-21 16:34:23 --> Database Driver Class Initialized
INFO - 2019-07-21 16:34:23 --> Controller Class Initialized
INFO - 2019-07-21 16:34:23 --> Model "Product" initialized
INFO - 2019-07-21 16:34:23 --> Final output sent to browser
DEBUG - 2019-07-21 16:34:23 --> Total execution time: 0.2088
INFO - 2019-07-21 16:35:06 --> Config Class Initialized
INFO - 2019-07-21 16:35:06 --> Hooks Class Initialized
DEBUG - 2019-07-21 16:35:06 --> UTF-8 Support Enabled
INFO - 2019-07-21 16:35:06 --> Utf8 Class Initialized
INFO - 2019-07-21 16:35:06 --> URI Class Initialized
INFO - 2019-07-21 16:35:07 --> Router Class Initialized
INFO - 2019-07-21 16:35:07 --> Output Class Initialized
INFO - 2019-07-21 16:35:07 --> Security Class Initialized
DEBUG - 2019-07-21 16:35:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 16:35:07 --> Input Class Initialized
INFO - 2019-07-21 16:35:07 --> Language Class Initialized
INFO - 2019-07-21 16:35:07 --> Loader Class Initialized
INFO - 2019-07-21 16:35:07 --> Database Driver Class Initialized
INFO - 2019-07-21 16:35:07 --> Controller Class Initialized
INFO - 2019-07-21 16:35:07 --> Model "Product" initialized
INFO - 2019-07-21 16:35:07 --> Final output sent to browser
DEBUG - 2019-07-21 16:35:07 --> Total execution time: 0.0764
INFO - 2019-07-21 16:35:07 --> Config Class Initialized
INFO - 2019-07-21 16:35:07 --> Hooks Class Initialized
DEBUG - 2019-07-21 16:35:07 --> UTF-8 Support Enabled
INFO - 2019-07-21 16:35:07 --> Utf8 Class Initialized
INFO - 2019-07-21 16:35:07 --> URI Class Initialized
INFO - 2019-07-21 16:35:07 --> Router Class Initialized
INFO - 2019-07-21 16:35:07 --> Output Class Initialized
INFO - 2019-07-21 16:35:07 --> Security Class Initialized
DEBUG - 2019-07-21 16:35:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 16:35:07 --> Input Class Initialized
INFO - 2019-07-21 16:35:07 --> Language Class Initialized
INFO - 2019-07-21 16:35:07 --> Loader Class Initialized
INFO - 2019-07-21 16:35:07 --> Database Driver Class Initialized
INFO - 2019-07-21 16:35:07 --> Controller Class Initialized
INFO - 2019-07-21 16:35:07 --> Model "Product" initialized
INFO - 2019-07-21 16:35:07 --> Final output sent to browser
DEBUG - 2019-07-21 16:35:07 --> Total execution time: 0.1095
INFO - 2019-07-21 16:36:06 --> Config Class Initialized
INFO - 2019-07-21 16:36:06 --> Hooks Class Initialized
DEBUG - 2019-07-21 16:36:06 --> UTF-8 Support Enabled
INFO - 2019-07-21 16:36:06 --> Utf8 Class Initialized
INFO - 2019-07-21 16:36:06 --> URI Class Initialized
INFO - 2019-07-21 16:36:06 --> Router Class Initialized
INFO - 2019-07-21 16:36:06 --> Output Class Initialized
INFO - 2019-07-21 16:36:06 --> Security Class Initialized
DEBUG - 2019-07-21 16:36:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 16:36:06 --> Input Class Initialized
INFO - 2019-07-21 16:36:06 --> Language Class Initialized
INFO - 2019-07-21 16:36:06 --> Loader Class Initialized
INFO - 2019-07-21 16:36:06 --> Database Driver Class Initialized
INFO - 2019-07-21 16:36:06 --> Controller Class Initialized
INFO - 2019-07-21 16:36:06 --> Model "Product" initialized
INFO - 2019-07-21 16:36:06 --> Final output sent to browser
DEBUG - 2019-07-21 16:36:06 --> Total execution time: 0.0171
INFO - 2019-07-21 16:36:06 --> Config Class Initialized
INFO - 2019-07-21 16:36:06 --> Hooks Class Initialized
DEBUG - 2019-07-21 16:36:06 --> UTF-8 Support Enabled
INFO - 2019-07-21 16:36:06 --> Utf8 Class Initialized
INFO - 2019-07-21 16:36:06 --> URI Class Initialized
INFO - 2019-07-21 16:36:06 --> Router Class Initialized
INFO - 2019-07-21 16:36:06 --> Output Class Initialized
INFO - 2019-07-21 16:36:06 --> Security Class Initialized
DEBUG - 2019-07-21 16:36:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 16:36:06 --> Input Class Initialized
INFO - 2019-07-21 16:36:06 --> Language Class Initialized
INFO - 2019-07-21 16:36:06 --> Loader Class Initialized
INFO - 2019-07-21 16:36:06 --> Database Driver Class Initialized
INFO - 2019-07-21 16:36:06 --> Controller Class Initialized
INFO - 2019-07-21 16:36:06 --> Model "Product" initialized
INFO - 2019-07-21 16:36:07 --> Final output sent to browser
DEBUG - 2019-07-21 16:36:07 --> Total execution time: 0.1370
INFO - 2019-07-21 16:36:14 --> Config Class Initialized
INFO - 2019-07-21 16:36:14 --> Hooks Class Initialized
DEBUG - 2019-07-21 16:36:14 --> UTF-8 Support Enabled
INFO - 2019-07-21 16:36:14 --> Utf8 Class Initialized
INFO - 2019-07-21 16:36:14 --> URI Class Initialized
INFO - 2019-07-21 16:36:14 --> Router Class Initialized
INFO - 2019-07-21 16:36:14 --> Output Class Initialized
INFO - 2019-07-21 16:36:14 --> Security Class Initialized
DEBUG - 2019-07-21 16:36:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 16:36:14 --> Input Class Initialized
INFO - 2019-07-21 16:36:14 --> Language Class Initialized
INFO - 2019-07-21 16:36:14 --> Loader Class Initialized
INFO - 2019-07-21 16:36:14 --> Database Driver Class Initialized
INFO - 2019-07-21 16:36:14 --> Controller Class Initialized
INFO - 2019-07-21 16:36:14 --> Model "Product" initialized
INFO - 2019-07-21 16:36:14 --> Final output sent to browser
DEBUG - 2019-07-21 16:36:14 --> Total execution time: 0.0719
INFO - 2019-07-21 16:36:14 --> Config Class Initialized
INFO - 2019-07-21 16:36:14 --> Hooks Class Initialized
DEBUG - 2019-07-21 16:36:14 --> UTF-8 Support Enabled
INFO - 2019-07-21 16:36:14 --> Utf8 Class Initialized
INFO - 2019-07-21 16:36:14 --> URI Class Initialized
INFO - 2019-07-21 16:36:14 --> Router Class Initialized
INFO - 2019-07-21 16:36:14 --> Output Class Initialized
INFO - 2019-07-21 16:36:14 --> Security Class Initialized
DEBUG - 2019-07-21 16:36:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 16:36:14 --> Input Class Initialized
INFO - 2019-07-21 16:36:14 --> Language Class Initialized
INFO - 2019-07-21 16:36:14 --> Loader Class Initialized
INFO - 2019-07-21 16:36:14 --> Database Driver Class Initialized
INFO - 2019-07-21 16:36:14 --> Controller Class Initialized
INFO - 2019-07-21 16:36:14 --> Model "Product" initialized
INFO - 2019-07-21 16:36:15 --> Final output sent to browser
DEBUG - 2019-07-21 16:36:15 --> Total execution time: 0.1925
INFO - 2019-07-21 16:39:28 --> Config Class Initialized
INFO - 2019-07-21 16:39:28 --> Hooks Class Initialized
DEBUG - 2019-07-21 16:39:28 --> UTF-8 Support Enabled
INFO - 2019-07-21 16:39:28 --> Utf8 Class Initialized
INFO - 2019-07-21 16:39:28 --> URI Class Initialized
INFO - 2019-07-21 16:39:28 --> Router Class Initialized
INFO - 2019-07-21 16:39:28 --> Output Class Initialized
INFO - 2019-07-21 16:39:28 --> Security Class Initialized
DEBUG - 2019-07-21 16:39:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 16:39:28 --> Input Class Initialized
INFO - 2019-07-21 16:39:28 --> Language Class Initialized
INFO - 2019-07-21 16:39:28 --> Loader Class Initialized
INFO - 2019-07-21 16:39:28 --> Database Driver Class Initialized
INFO - 2019-07-21 16:39:28 --> Controller Class Initialized
INFO - 2019-07-21 16:39:28 --> Model "Product" initialized
INFO - 2019-07-21 16:39:28 --> Final output sent to browser
DEBUG - 2019-07-21 16:39:28 --> Total execution time: 0.0142
INFO - 2019-07-21 16:39:28 --> Config Class Initialized
INFO - 2019-07-21 16:39:28 --> Hooks Class Initialized
DEBUG - 2019-07-21 16:39:28 --> UTF-8 Support Enabled
INFO - 2019-07-21 16:39:28 --> Utf8 Class Initialized
INFO - 2019-07-21 16:39:28 --> URI Class Initialized
INFO - 2019-07-21 16:39:28 --> Router Class Initialized
INFO - 2019-07-21 16:39:28 --> Output Class Initialized
INFO - 2019-07-21 16:39:28 --> Security Class Initialized
DEBUG - 2019-07-21 16:39:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 16:39:28 --> Input Class Initialized
INFO - 2019-07-21 16:39:28 --> Language Class Initialized
INFO - 2019-07-21 16:39:28 --> Loader Class Initialized
INFO - 2019-07-21 16:39:28 --> Database Driver Class Initialized
INFO - 2019-07-21 16:39:28 --> Controller Class Initialized
INFO - 2019-07-21 16:39:28 --> Model "Product" initialized
INFO - 2019-07-21 16:39:29 --> Final output sent to browser
DEBUG - 2019-07-21 16:39:29 --> Total execution time: 0.5451
INFO - 2019-07-21 16:43:41 --> Config Class Initialized
INFO - 2019-07-21 16:43:41 --> Hooks Class Initialized
DEBUG - 2019-07-21 16:43:41 --> UTF-8 Support Enabled
INFO - 2019-07-21 16:43:41 --> Utf8 Class Initialized
INFO - 2019-07-21 16:43:41 --> URI Class Initialized
INFO - 2019-07-21 16:43:41 --> Router Class Initialized
INFO - 2019-07-21 16:43:41 --> Output Class Initialized
INFO - 2019-07-21 16:43:41 --> Security Class Initialized
DEBUG - 2019-07-21 16:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 16:43:41 --> Input Class Initialized
INFO - 2019-07-21 16:43:41 --> Language Class Initialized
INFO - 2019-07-21 16:43:41 --> Loader Class Initialized
INFO - 2019-07-21 16:43:41 --> Database Driver Class Initialized
INFO - 2019-07-21 16:43:41 --> Controller Class Initialized
INFO - 2019-07-21 16:43:41 --> Model "Product" initialized
INFO - 2019-07-21 16:43:41 --> Final output sent to browser
DEBUG - 2019-07-21 16:43:41 --> Total execution time: 0.0216
INFO - 2019-07-21 16:43:41 --> Config Class Initialized
INFO - 2019-07-21 16:43:41 --> Hooks Class Initialized
DEBUG - 2019-07-21 16:43:41 --> UTF-8 Support Enabled
INFO - 2019-07-21 16:43:41 --> Utf8 Class Initialized
INFO - 2019-07-21 16:43:41 --> URI Class Initialized
INFO - 2019-07-21 16:43:41 --> Router Class Initialized
INFO - 2019-07-21 16:43:41 --> Output Class Initialized
INFO - 2019-07-21 16:43:41 --> Security Class Initialized
DEBUG - 2019-07-21 16:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 16:43:41 --> Input Class Initialized
INFO - 2019-07-21 16:43:41 --> Language Class Initialized
INFO - 2019-07-21 16:43:41 --> Loader Class Initialized
INFO - 2019-07-21 16:43:41 --> Database Driver Class Initialized
INFO - 2019-07-21 16:43:41 --> Controller Class Initialized
INFO - 2019-07-21 16:43:41 --> Model "Product" initialized
INFO - 2019-07-21 16:43:41 --> Final output sent to browser
DEBUG - 2019-07-21 16:43:41 --> Total execution time: 0.1263
INFO - 2019-07-21 16:48:08 --> Config Class Initialized
INFO - 2019-07-21 16:48:08 --> Hooks Class Initialized
DEBUG - 2019-07-21 16:48:08 --> UTF-8 Support Enabled
INFO - 2019-07-21 16:48:08 --> Utf8 Class Initialized
INFO - 2019-07-21 16:48:08 --> URI Class Initialized
INFO - 2019-07-21 16:48:08 --> Router Class Initialized
INFO - 2019-07-21 16:48:08 --> Output Class Initialized
INFO - 2019-07-21 16:48:08 --> Security Class Initialized
DEBUG - 2019-07-21 16:48:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 16:48:08 --> Input Class Initialized
INFO - 2019-07-21 16:48:08 --> Language Class Initialized
INFO - 2019-07-21 16:48:08 --> Loader Class Initialized
INFO - 2019-07-21 16:48:09 --> Database Driver Class Initialized
INFO - 2019-07-21 16:48:09 --> Controller Class Initialized
INFO - 2019-07-21 16:48:09 --> Model "Product" initialized
INFO - 2019-07-21 16:48:09 --> Final output sent to browser
DEBUG - 2019-07-21 16:48:09 --> Total execution time: 0.2760
INFO - 2019-07-21 16:48:09 --> Config Class Initialized
INFO - 2019-07-21 16:48:09 --> Hooks Class Initialized
DEBUG - 2019-07-21 16:48:09 --> UTF-8 Support Enabled
INFO - 2019-07-21 16:48:09 --> Utf8 Class Initialized
INFO - 2019-07-21 16:48:09 --> URI Class Initialized
INFO - 2019-07-21 16:48:09 --> Router Class Initialized
INFO - 2019-07-21 16:48:09 --> Output Class Initialized
INFO - 2019-07-21 16:48:09 --> Security Class Initialized
DEBUG - 2019-07-21 16:48:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 16:48:09 --> Input Class Initialized
INFO - 2019-07-21 16:48:09 --> Language Class Initialized
INFO - 2019-07-21 16:48:09 --> Loader Class Initialized
INFO - 2019-07-21 16:48:09 --> Database Driver Class Initialized
INFO - 2019-07-21 16:48:09 --> Controller Class Initialized
INFO - 2019-07-21 16:48:09 --> Model "Product" initialized
INFO - 2019-07-21 16:48:09 --> Final output sent to browser
DEBUG - 2019-07-21 16:48:09 --> Total execution time: 0.1561
INFO - 2019-07-21 16:52:11 --> Config Class Initialized
INFO - 2019-07-21 16:52:11 --> Hooks Class Initialized
DEBUG - 2019-07-21 16:52:11 --> UTF-8 Support Enabled
INFO - 2019-07-21 16:52:11 --> Utf8 Class Initialized
INFO - 2019-07-21 16:52:11 --> URI Class Initialized
INFO - 2019-07-21 16:52:11 --> Router Class Initialized
INFO - 2019-07-21 16:52:11 --> Output Class Initialized
INFO - 2019-07-21 16:52:11 --> Security Class Initialized
DEBUG - 2019-07-21 16:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 16:52:11 --> Input Class Initialized
INFO - 2019-07-21 16:52:11 --> Language Class Initialized
INFO - 2019-07-21 16:52:11 --> Loader Class Initialized
INFO - 2019-07-21 16:52:11 --> Database Driver Class Initialized
INFO - 2019-07-21 16:52:11 --> Controller Class Initialized
INFO - 2019-07-21 16:52:11 --> Model "Product" initialized
INFO - 2019-07-21 16:52:11 --> Final output sent to browser
DEBUG - 2019-07-21 16:52:11 --> Total execution time: 0.0248
INFO - 2019-07-21 16:52:11 --> Config Class Initialized
INFO - 2019-07-21 16:52:11 --> Hooks Class Initialized
DEBUG - 2019-07-21 16:52:11 --> UTF-8 Support Enabled
INFO - 2019-07-21 16:52:11 --> Utf8 Class Initialized
INFO - 2019-07-21 16:52:11 --> URI Class Initialized
INFO - 2019-07-21 16:52:11 --> Router Class Initialized
INFO - 2019-07-21 16:52:11 --> Output Class Initialized
INFO - 2019-07-21 16:52:11 --> Security Class Initialized
DEBUG - 2019-07-21 16:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 16:52:11 --> Input Class Initialized
INFO - 2019-07-21 16:52:11 --> Language Class Initialized
INFO - 2019-07-21 16:52:11 --> Loader Class Initialized
INFO - 2019-07-21 16:52:11 --> Database Driver Class Initialized
INFO - 2019-07-21 16:52:11 --> Controller Class Initialized
INFO - 2019-07-21 16:52:11 --> Model "Product" initialized
INFO - 2019-07-21 16:52:11 --> Final output sent to browser
DEBUG - 2019-07-21 16:52:11 --> Total execution time: 0.1843
INFO - 2019-07-21 16:52:19 --> Config Class Initialized
INFO - 2019-07-21 16:52:19 --> Hooks Class Initialized
DEBUG - 2019-07-21 16:52:19 --> UTF-8 Support Enabled
INFO - 2019-07-21 16:52:19 --> Utf8 Class Initialized
INFO - 2019-07-21 16:52:19 --> URI Class Initialized
INFO - 2019-07-21 16:52:19 --> Router Class Initialized
INFO - 2019-07-21 16:52:19 --> Output Class Initialized
INFO - 2019-07-21 16:52:19 --> Security Class Initialized
DEBUG - 2019-07-21 16:52:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 16:52:19 --> Input Class Initialized
INFO - 2019-07-21 16:52:19 --> Language Class Initialized
INFO - 2019-07-21 16:52:19 --> Loader Class Initialized
INFO - 2019-07-21 16:52:19 --> Database Driver Class Initialized
INFO - 2019-07-21 16:52:19 --> Controller Class Initialized
INFO - 2019-07-21 16:52:19 --> Model "Product" initialized
INFO - 2019-07-21 16:52:19 --> Final output sent to browser
DEBUG - 2019-07-21 16:52:19 --> Total execution time: 0.0168
INFO - 2019-07-21 16:52:19 --> Config Class Initialized
INFO - 2019-07-21 16:52:19 --> Hooks Class Initialized
DEBUG - 2019-07-21 16:52:19 --> UTF-8 Support Enabled
INFO - 2019-07-21 16:52:19 --> Utf8 Class Initialized
INFO - 2019-07-21 16:52:19 --> URI Class Initialized
INFO - 2019-07-21 16:52:19 --> Router Class Initialized
INFO - 2019-07-21 16:52:19 --> Output Class Initialized
INFO - 2019-07-21 16:52:19 --> Security Class Initialized
DEBUG - 2019-07-21 16:52:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 16:52:19 --> Input Class Initialized
INFO - 2019-07-21 16:52:19 --> Language Class Initialized
INFO - 2019-07-21 16:52:19 --> Loader Class Initialized
INFO - 2019-07-21 16:52:19 --> Database Driver Class Initialized
INFO - 2019-07-21 16:52:19 --> Controller Class Initialized
INFO - 2019-07-21 16:52:19 --> Model "Product" initialized
INFO - 2019-07-21 16:52:20 --> Final output sent to browser
DEBUG - 2019-07-21 16:52:20 --> Total execution time: 0.2071
INFO - 2019-07-21 16:58:42 --> Config Class Initialized
INFO - 2019-07-21 16:58:42 --> Hooks Class Initialized
DEBUG - 2019-07-21 16:58:42 --> UTF-8 Support Enabled
INFO - 2019-07-21 16:58:42 --> Utf8 Class Initialized
INFO - 2019-07-21 16:58:42 --> URI Class Initialized
INFO - 2019-07-21 16:58:42 --> Router Class Initialized
INFO - 2019-07-21 16:58:42 --> Output Class Initialized
INFO - 2019-07-21 16:58:42 --> Security Class Initialized
DEBUG - 2019-07-21 16:58:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 16:58:42 --> Input Class Initialized
INFO - 2019-07-21 16:58:42 --> Language Class Initialized
INFO - 2019-07-21 16:58:42 --> Loader Class Initialized
INFO - 2019-07-21 16:58:42 --> Database Driver Class Initialized
INFO - 2019-07-21 16:58:42 --> Controller Class Initialized
INFO - 2019-07-21 16:58:42 --> Model "Product" initialized
INFO - 2019-07-21 16:58:42 --> Final output sent to browser
DEBUG - 2019-07-21 16:58:42 --> Total execution time: 0.3201
INFO - 2019-07-21 16:58:42 --> Config Class Initialized
INFO - 2019-07-21 16:58:42 --> Hooks Class Initialized
DEBUG - 2019-07-21 16:58:42 --> UTF-8 Support Enabled
INFO - 2019-07-21 16:58:42 --> Utf8 Class Initialized
INFO - 2019-07-21 16:58:42 --> URI Class Initialized
INFO - 2019-07-21 16:58:42 --> Router Class Initialized
INFO - 2019-07-21 16:58:42 --> Output Class Initialized
INFO - 2019-07-21 16:58:42 --> Security Class Initialized
DEBUG - 2019-07-21 16:58:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 16:58:42 --> Input Class Initialized
INFO - 2019-07-21 16:58:42 --> Language Class Initialized
INFO - 2019-07-21 16:58:42 --> Loader Class Initialized
INFO - 2019-07-21 16:58:42 --> Database Driver Class Initialized
INFO - 2019-07-21 16:58:42 --> Controller Class Initialized
INFO - 2019-07-21 16:58:42 --> Model "Product" initialized
INFO - 2019-07-21 16:58:42 --> Final output sent to browser
DEBUG - 2019-07-21 16:58:42 --> Total execution time: 0.1729
INFO - 2019-07-21 17:00:42 --> Config Class Initialized
INFO - 2019-07-21 17:00:42 --> Hooks Class Initialized
DEBUG - 2019-07-21 17:00:42 --> UTF-8 Support Enabled
INFO - 2019-07-21 17:00:42 --> Utf8 Class Initialized
INFO - 2019-07-21 17:00:42 --> URI Class Initialized
INFO - 2019-07-21 17:00:42 --> Router Class Initialized
INFO - 2019-07-21 17:00:42 --> Output Class Initialized
INFO - 2019-07-21 17:00:42 --> Security Class Initialized
DEBUG - 2019-07-21 17:00:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 17:00:42 --> Input Class Initialized
INFO - 2019-07-21 17:00:42 --> Language Class Initialized
INFO - 2019-07-21 17:00:42 --> Loader Class Initialized
INFO - 2019-07-21 17:00:42 --> Database Driver Class Initialized
INFO - 2019-07-21 17:00:42 --> Controller Class Initialized
INFO - 2019-07-21 17:00:42 --> Model "Product" initialized
INFO - 2019-07-21 17:00:42 --> Final output sent to browser
DEBUG - 2019-07-21 17:00:42 --> Total execution time: 0.0416
INFO - 2019-07-21 17:00:42 --> Config Class Initialized
INFO - 2019-07-21 17:00:42 --> Hooks Class Initialized
DEBUG - 2019-07-21 17:00:42 --> UTF-8 Support Enabled
INFO - 2019-07-21 17:00:42 --> Utf8 Class Initialized
INFO - 2019-07-21 17:00:42 --> URI Class Initialized
INFO - 2019-07-21 17:00:42 --> Router Class Initialized
INFO - 2019-07-21 17:00:42 --> Output Class Initialized
INFO - 2019-07-21 17:00:42 --> Security Class Initialized
DEBUG - 2019-07-21 17:00:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 17:00:42 --> Input Class Initialized
INFO - 2019-07-21 17:00:42 --> Language Class Initialized
INFO - 2019-07-21 17:00:42 --> Loader Class Initialized
INFO - 2019-07-21 17:00:42 --> Database Driver Class Initialized
INFO - 2019-07-21 17:00:42 --> Controller Class Initialized
INFO - 2019-07-21 17:00:42 --> Model "Product" initialized
INFO - 2019-07-21 17:00:42 --> Final output sent to browser
DEBUG - 2019-07-21 17:00:42 --> Total execution time: 0.1349
INFO - 2019-07-21 17:01:28 --> Config Class Initialized
INFO - 2019-07-21 17:01:28 --> Hooks Class Initialized
DEBUG - 2019-07-21 17:01:28 --> UTF-8 Support Enabled
INFO - 2019-07-21 17:01:28 --> Utf8 Class Initialized
INFO - 2019-07-21 17:01:28 --> URI Class Initialized
INFO - 2019-07-21 17:01:28 --> Router Class Initialized
INFO - 2019-07-21 17:01:28 --> Output Class Initialized
INFO - 2019-07-21 17:01:28 --> Security Class Initialized
DEBUG - 2019-07-21 17:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 17:01:28 --> Input Class Initialized
INFO - 2019-07-21 17:01:28 --> Language Class Initialized
INFO - 2019-07-21 17:01:28 --> Loader Class Initialized
INFO - 2019-07-21 17:01:28 --> Database Driver Class Initialized
INFO - 2019-07-21 17:01:28 --> Controller Class Initialized
INFO - 2019-07-21 17:01:28 --> Model "Product" initialized
INFO - 2019-07-21 17:01:28 --> Final output sent to browser
DEBUG - 2019-07-21 17:01:28 --> Total execution time: 0.0211
INFO - 2019-07-21 17:01:28 --> Config Class Initialized
INFO - 2019-07-21 17:01:28 --> Hooks Class Initialized
DEBUG - 2019-07-21 17:01:28 --> UTF-8 Support Enabled
INFO - 2019-07-21 17:01:28 --> Utf8 Class Initialized
INFO - 2019-07-21 17:01:28 --> URI Class Initialized
INFO - 2019-07-21 17:01:28 --> Router Class Initialized
INFO - 2019-07-21 17:01:28 --> Output Class Initialized
INFO - 2019-07-21 17:01:28 --> Security Class Initialized
DEBUG - 2019-07-21 17:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 17:01:28 --> Input Class Initialized
INFO - 2019-07-21 17:01:28 --> Language Class Initialized
INFO - 2019-07-21 17:01:28 --> Loader Class Initialized
INFO - 2019-07-21 17:01:28 --> Database Driver Class Initialized
INFO - 2019-07-21 17:01:28 --> Controller Class Initialized
INFO - 2019-07-21 17:01:28 --> Model "Product" initialized
INFO - 2019-07-21 17:01:28 --> Final output sent to browser
DEBUG - 2019-07-21 17:01:28 --> Total execution time: 0.0982
INFO - 2019-07-21 17:03:14 --> Config Class Initialized
INFO - 2019-07-21 17:03:14 --> Hooks Class Initialized
DEBUG - 2019-07-21 17:03:14 --> UTF-8 Support Enabled
INFO - 2019-07-21 17:03:14 --> Utf8 Class Initialized
INFO - 2019-07-21 17:03:14 --> URI Class Initialized
INFO - 2019-07-21 17:03:14 --> Router Class Initialized
INFO - 2019-07-21 17:03:14 --> Output Class Initialized
INFO - 2019-07-21 17:03:14 --> Security Class Initialized
DEBUG - 2019-07-21 17:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 17:03:14 --> Input Class Initialized
INFO - 2019-07-21 17:03:14 --> Language Class Initialized
INFO - 2019-07-21 17:03:14 --> Loader Class Initialized
INFO - 2019-07-21 17:03:14 --> Database Driver Class Initialized
INFO - 2019-07-21 17:03:14 --> Controller Class Initialized
INFO - 2019-07-21 17:03:14 --> Model "Product" initialized
INFO - 2019-07-21 17:03:14 --> Final output sent to browser
DEBUG - 2019-07-21 17:03:14 --> Total execution time: 0.0228
INFO - 2019-07-21 17:03:14 --> Config Class Initialized
INFO - 2019-07-21 17:03:14 --> Hooks Class Initialized
DEBUG - 2019-07-21 17:03:14 --> UTF-8 Support Enabled
INFO - 2019-07-21 17:03:14 --> Utf8 Class Initialized
INFO - 2019-07-21 17:03:14 --> URI Class Initialized
INFO - 2019-07-21 17:03:14 --> Router Class Initialized
INFO - 2019-07-21 17:03:14 --> Output Class Initialized
INFO - 2019-07-21 17:03:14 --> Security Class Initialized
DEBUG - 2019-07-21 17:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 17:03:14 --> Input Class Initialized
INFO - 2019-07-21 17:03:14 --> Language Class Initialized
INFO - 2019-07-21 17:03:14 --> Loader Class Initialized
INFO - 2019-07-21 17:03:14 --> Database Driver Class Initialized
INFO - 2019-07-21 17:03:14 --> Controller Class Initialized
INFO - 2019-07-21 17:03:14 --> Model "Product" initialized
INFO - 2019-07-21 17:03:14 --> Final output sent to browser
DEBUG - 2019-07-21 17:03:14 --> Total execution time: 0.1555
INFO - 2019-07-21 17:03:27 --> Config Class Initialized
INFO - 2019-07-21 17:03:27 --> Hooks Class Initialized
DEBUG - 2019-07-21 17:03:27 --> UTF-8 Support Enabled
INFO - 2019-07-21 17:03:27 --> Utf8 Class Initialized
INFO - 2019-07-21 17:03:27 --> URI Class Initialized
INFO - 2019-07-21 17:03:27 --> Router Class Initialized
INFO - 2019-07-21 17:03:27 --> Output Class Initialized
INFO - 2019-07-21 17:03:27 --> Security Class Initialized
DEBUG - 2019-07-21 17:03:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 17:03:27 --> Input Class Initialized
INFO - 2019-07-21 17:03:27 --> Language Class Initialized
INFO - 2019-07-21 17:03:27 --> Loader Class Initialized
INFO - 2019-07-21 17:03:27 --> Database Driver Class Initialized
INFO - 2019-07-21 17:03:27 --> Controller Class Initialized
INFO - 2019-07-21 17:03:27 --> Model "Product" initialized
INFO - 2019-07-21 17:03:27 --> Final output sent to browser
DEBUG - 2019-07-21 17:03:27 --> Total execution time: 0.0192
INFO - 2019-07-21 17:03:27 --> Config Class Initialized
INFO - 2019-07-21 17:03:27 --> Hooks Class Initialized
DEBUG - 2019-07-21 17:03:27 --> UTF-8 Support Enabled
INFO - 2019-07-21 17:03:27 --> Utf8 Class Initialized
INFO - 2019-07-21 17:03:27 --> URI Class Initialized
INFO - 2019-07-21 17:03:27 --> Router Class Initialized
INFO - 2019-07-21 17:03:27 --> Output Class Initialized
INFO - 2019-07-21 17:03:27 --> Security Class Initialized
DEBUG - 2019-07-21 17:03:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 17:03:27 --> Input Class Initialized
INFO - 2019-07-21 17:03:27 --> Language Class Initialized
INFO - 2019-07-21 17:03:27 --> Loader Class Initialized
INFO - 2019-07-21 17:03:27 --> Database Driver Class Initialized
INFO - 2019-07-21 17:03:27 --> Controller Class Initialized
INFO - 2019-07-21 17:03:27 --> Model "Product" initialized
INFO - 2019-07-21 17:03:27 --> Final output sent to browser
DEBUG - 2019-07-21 17:03:27 --> Total execution time: 0.2213
INFO - 2019-07-21 17:03:40 --> Config Class Initialized
INFO - 2019-07-21 17:03:40 --> Hooks Class Initialized
DEBUG - 2019-07-21 17:03:40 --> UTF-8 Support Enabled
INFO - 2019-07-21 17:03:40 --> Utf8 Class Initialized
INFO - 2019-07-21 17:03:40 --> URI Class Initialized
INFO - 2019-07-21 17:03:40 --> Router Class Initialized
INFO - 2019-07-21 17:03:40 --> Output Class Initialized
INFO - 2019-07-21 17:03:40 --> Security Class Initialized
DEBUG - 2019-07-21 17:03:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 17:03:40 --> Input Class Initialized
INFO - 2019-07-21 17:03:40 --> Language Class Initialized
INFO - 2019-07-21 17:03:40 --> Loader Class Initialized
INFO - 2019-07-21 17:03:40 --> Database Driver Class Initialized
INFO - 2019-07-21 17:03:40 --> Controller Class Initialized
INFO - 2019-07-21 17:03:40 --> Model "Product" initialized
INFO - 2019-07-21 17:03:40 --> Final output sent to browser
DEBUG - 2019-07-21 17:03:40 --> Total execution time: 0.0182
INFO - 2019-07-21 17:03:40 --> Config Class Initialized
INFO - 2019-07-21 17:03:40 --> Hooks Class Initialized
DEBUG - 2019-07-21 17:03:40 --> UTF-8 Support Enabled
INFO - 2019-07-21 17:03:40 --> Utf8 Class Initialized
INFO - 2019-07-21 17:03:40 --> URI Class Initialized
INFO - 2019-07-21 17:03:40 --> Router Class Initialized
INFO - 2019-07-21 17:03:40 --> Output Class Initialized
INFO - 2019-07-21 17:03:40 --> Security Class Initialized
DEBUG - 2019-07-21 17:03:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 17:03:40 --> Input Class Initialized
INFO - 2019-07-21 17:03:40 --> Language Class Initialized
INFO - 2019-07-21 17:03:40 --> Loader Class Initialized
INFO - 2019-07-21 17:03:40 --> Database Driver Class Initialized
INFO - 2019-07-21 17:03:40 --> Controller Class Initialized
INFO - 2019-07-21 17:03:40 --> Model "Product" initialized
INFO - 2019-07-21 17:03:40 --> Final output sent to browser
DEBUG - 2019-07-21 17:03:40 --> Total execution time: 0.2085
INFO - 2019-07-21 17:04:07 --> Config Class Initialized
INFO - 2019-07-21 17:04:07 --> Hooks Class Initialized
DEBUG - 2019-07-21 17:04:07 --> UTF-8 Support Enabled
INFO - 2019-07-21 17:04:07 --> Utf8 Class Initialized
INFO - 2019-07-21 17:04:07 --> URI Class Initialized
INFO - 2019-07-21 17:04:07 --> Router Class Initialized
INFO - 2019-07-21 17:04:07 --> Output Class Initialized
INFO - 2019-07-21 17:04:07 --> Security Class Initialized
DEBUG - 2019-07-21 17:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 17:04:07 --> Input Class Initialized
INFO - 2019-07-21 17:04:07 --> Language Class Initialized
INFO - 2019-07-21 17:04:07 --> Loader Class Initialized
INFO - 2019-07-21 17:04:07 --> Database Driver Class Initialized
INFO - 2019-07-21 17:04:07 --> Controller Class Initialized
INFO - 2019-07-21 17:04:07 --> Model "Product" initialized
INFO - 2019-07-21 17:04:07 --> Final output sent to browser
DEBUG - 2019-07-21 17:04:07 --> Total execution time: 0.0181
INFO - 2019-07-21 17:04:07 --> Config Class Initialized
INFO - 2019-07-21 17:04:07 --> Hooks Class Initialized
DEBUG - 2019-07-21 17:04:07 --> UTF-8 Support Enabled
INFO - 2019-07-21 17:04:07 --> Utf8 Class Initialized
INFO - 2019-07-21 17:04:07 --> URI Class Initialized
INFO - 2019-07-21 17:04:07 --> Router Class Initialized
INFO - 2019-07-21 17:04:07 --> Output Class Initialized
INFO - 2019-07-21 17:04:07 --> Security Class Initialized
DEBUG - 2019-07-21 17:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 17:04:07 --> Input Class Initialized
INFO - 2019-07-21 17:04:07 --> Language Class Initialized
INFO - 2019-07-21 17:04:07 --> Loader Class Initialized
INFO - 2019-07-21 17:04:07 --> Database Driver Class Initialized
INFO - 2019-07-21 17:04:07 --> Controller Class Initialized
INFO - 2019-07-21 17:04:07 --> Model "Product" initialized
INFO - 2019-07-21 17:04:07 --> Final output sent to browser
DEBUG - 2019-07-21 17:04:07 --> Total execution time: 0.1463
INFO - 2019-07-21 17:04:51 --> Config Class Initialized
INFO - 2019-07-21 17:04:51 --> Hooks Class Initialized
DEBUG - 2019-07-21 17:04:51 --> UTF-8 Support Enabled
INFO - 2019-07-21 17:04:51 --> Utf8 Class Initialized
INFO - 2019-07-21 17:04:51 --> URI Class Initialized
INFO - 2019-07-21 17:04:51 --> Router Class Initialized
INFO - 2019-07-21 17:04:51 --> Output Class Initialized
INFO - 2019-07-21 17:04:51 --> Security Class Initialized
DEBUG - 2019-07-21 17:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 17:04:51 --> Input Class Initialized
INFO - 2019-07-21 17:04:51 --> Language Class Initialized
INFO - 2019-07-21 17:04:51 --> Loader Class Initialized
INFO - 2019-07-21 17:04:51 --> Database Driver Class Initialized
INFO - 2019-07-21 17:04:51 --> Controller Class Initialized
INFO - 2019-07-21 17:04:51 --> Model "Product" initialized
INFO - 2019-07-21 17:04:51 --> Final output sent to browser
DEBUG - 2019-07-21 17:04:51 --> Total execution time: 0.0219
INFO - 2019-07-21 17:04:51 --> Config Class Initialized
INFO - 2019-07-21 17:04:51 --> Hooks Class Initialized
DEBUG - 2019-07-21 17:04:51 --> UTF-8 Support Enabled
INFO - 2019-07-21 17:04:51 --> Utf8 Class Initialized
INFO - 2019-07-21 17:04:51 --> URI Class Initialized
INFO - 2019-07-21 17:04:51 --> Router Class Initialized
INFO - 2019-07-21 17:04:51 --> Output Class Initialized
INFO - 2019-07-21 17:04:51 --> Security Class Initialized
DEBUG - 2019-07-21 17:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 17:04:51 --> Input Class Initialized
INFO - 2019-07-21 17:04:51 --> Language Class Initialized
INFO - 2019-07-21 17:04:51 --> Loader Class Initialized
INFO - 2019-07-21 17:04:51 --> Database Driver Class Initialized
INFO - 2019-07-21 17:04:51 --> Controller Class Initialized
INFO - 2019-07-21 17:04:51 --> Model "Product" initialized
INFO - 2019-07-21 17:04:51 --> Final output sent to browser
DEBUG - 2019-07-21 17:04:51 --> Total execution time: 0.1358
INFO - 2019-07-21 17:06:44 --> Config Class Initialized
INFO - 2019-07-21 17:06:44 --> Hooks Class Initialized
DEBUG - 2019-07-21 17:06:44 --> UTF-8 Support Enabled
INFO - 2019-07-21 17:06:44 --> Utf8 Class Initialized
INFO - 2019-07-21 17:06:44 --> URI Class Initialized
INFO - 2019-07-21 17:06:44 --> Router Class Initialized
INFO - 2019-07-21 17:06:44 --> Output Class Initialized
INFO - 2019-07-21 17:06:44 --> Security Class Initialized
DEBUG - 2019-07-21 17:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 17:06:44 --> Input Class Initialized
INFO - 2019-07-21 17:06:44 --> Language Class Initialized
INFO - 2019-07-21 17:06:44 --> Loader Class Initialized
INFO - 2019-07-21 17:06:44 --> Database Driver Class Initialized
INFO - 2019-07-21 17:06:45 --> Controller Class Initialized
INFO - 2019-07-21 17:06:45 --> Model "Product" initialized
INFO - 2019-07-21 17:06:45 --> Final output sent to browser
DEBUG - 2019-07-21 17:06:45 --> Total execution time: 0.5857
INFO - 2019-07-21 17:06:45 --> Config Class Initialized
INFO - 2019-07-21 17:06:45 --> Hooks Class Initialized
DEBUG - 2019-07-21 17:06:45 --> UTF-8 Support Enabled
INFO - 2019-07-21 17:06:45 --> Utf8 Class Initialized
INFO - 2019-07-21 17:06:45 --> URI Class Initialized
INFO - 2019-07-21 17:06:45 --> Router Class Initialized
INFO - 2019-07-21 17:06:45 --> Output Class Initialized
INFO - 2019-07-21 17:06:45 --> Security Class Initialized
DEBUG - 2019-07-21 17:06:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 17:06:45 --> Input Class Initialized
INFO - 2019-07-21 17:06:45 --> Language Class Initialized
INFO - 2019-07-21 17:06:45 --> Loader Class Initialized
INFO - 2019-07-21 17:06:45 --> Database Driver Class Initialized
INFO - 2019-07-21 17:06:45 --> Controller Class Initialized
INFO - 2019-07-21 17:06:45 --> Model "Product" initialized
INFO - 2019-07-21 17:06:45 --> Final output sent to browser
DEBUG - 2019-07-21 17:06:45 --> Total execution time: 0.1514
INFO - 2019-07-21 17:07:32 --> Config Class Initialized
INFO - 2019-07-21 17:07:32 --> Hooks Class Initialized
DEBUG - 2019-07-21 17:07:32 --> UTF-8 Support Enabled
INFO - 2019-07-21 17:07:32 --> Utf8 Class Initialized
INFO - 2019-07-21 17:07:32 --> URI Class Initialized
INFO - 2019-07-21 17:07:32 --> Router Class Initialized
INFO - 2019-07-21 17:07:32 --> Output Class Initialized
INFO - 2019-07-21 17:07:32 --> Security Class Initialized
DEBUG - 2019-07-21 17:07:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 17:07:32 --> Input Class Initialized
INFO - 2019-07-21 17:07:32 --> Language Class Initialized
INFO - 2019-07-21 17:07:32 --> Loader Class Initialized
INFO - 2019-07-21 17:07:32 --> Database Driver Class Initialized
INFO - 2019-07-21 17:07:32 --> Controller Class Initialized
INFO - 2019-07-21 17:07:32 --> Model "Product" initialized
INFO - 2019-07-21 17:07:32 --> Final output sent to browser
DEBUG - 2019-07-21 17:07:32 --> Total execution time: 0.0181
INFO - 2019-07-21 17:07:32 --> Config Class Initialized
INFO - 2019-07-21 17:07:32 --> Hooks Class Initialized
DEBUG - 2019-07-21 17:07:32 --> UTF-8 Support Enabled
INFO - 2019-07-21 17:07:32 --> Utf8 Class Initialized
INFO - 2019-07-21 17:07:32 --> URI Class Initialized
INFO - 2019-07-21 17:07:32 --> Router Class Initialized
INFO - 2019-07-21 17:07:32 --> Output Class Initialized
INFO - 2019-07-21 17:07:32 --> Security Class Initialized
DEBUG - 2019-07-21 17:07:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 17:07:32 --> Input Class Initialized
INFO - 2019-07-21 17:07:32 --> Language Class Initialized
INFO - 2019-07-21 17:07:32 --> Loader Class Initialized
INFO - 2019-07-21 17:07:32 --> Database Driver Class Initialized
INFO - 2019-07-21 17:07:32 --> Controller Class Initialized
INFO - 2019-07-21 17:07:32 --> Model "Product" initialized
INFO - 2019-07-21 17:07:32 --> Final output sent to browser
DEBUG - 2019-07-21 17:07:32 --> Total execution time: 0.0972
INFO - 2019-07-21 17:16:13 --> Config Class Initialized
INFO - 2019-07-21 17:16:13 --> Hooks Class Initialized
DEBUG - 2019-07-21 17:16:13 --> UTF-8 Support Enabled
INFO - 2019-07-21 17:16:13 --> Utf8 Class Initialized
INFO - 2019-07-21 17:16:13 --> URI Class Initialized
INFO - 2019-07-21 17:16:13 --> Router Class Initialized
INFO - 2019-07-21 17:16:13 --> Output Class Initialized
INFO - 2019-07-21 17:16:13 --> Security Class Initialized
DEBUG - 2019-07-21 17:16:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 17:16:13 --> Input Class Initialized
INFO - 2019-07-21 17:16:13 --> Language Class Initialized
INFO - 2019-07-21 17:16:13 --> Loader Class Initialized
INFO - 2019-07-21 17:16:13 --> Database Driver Class Initialized
INFO - 2019-07-21 17:16:13 --> Controller Class Initialized
INFO - 2019-07-21 17:16:13 --> Model "Product" initialized
INFO - 2019-07-21 17:16:13 --> Final output sent to browser
DEBUG - 2019-07-21 17:16:13 --> Total execution time: 0.3315
INFO - 2019-07-21 17:16:13 --> Config Class Initialized
INFO - 2019-07-21 17:16:13 --> Hooks Class Initialized
DEBUG - 2019-07-21 17:16:13 --> UTF-8 Support Enabled
INFO - 2019-07-21 17:16:13 --> Utf8 Class Initialized
INFO - 2019-07-21 17:16:13 --> URI Class Initialized
INFO - 2019-07-21 17:16:13 --> Router Class Initialized
INFO - 2019-07-21 17:16:13 --> Output Class Initialized
INFO - 2019-07-21 17:16:13 --> Security Class Initialized
DEBUG - 2019-07-21 17:16:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 17:16:13 --> Input Class Initialized
INFO - 2019-07-21 17:16:13 --> Language Class Initialized
INFO - 2019-07-21 17:16:13 --> Loader Class Initialized
INFO - 2019-07-21 17:16:13 --> Database Driver Class Initialized
INFO - 2019-07-21 17:16:13 --> Controller Class Initialized
INFO - 2019-07-21 17:16:13 --> Model "Product" initialized
INFO - 2019-07-21 17:16:14 --> Final output sent to browser
DEBUG - 2019-07-21 17:16:14 --> Total execution time: 0.3039
INFO - 2019-07-21 17:16:17 --> Config Class Initialized
INFO - 2019-07-21 17:16:17 --> Hooks Class Initialized
DEBUG - 2019-07-21 17:16:17 --> UTF-8 Support Enabled
INFO - 2019-07-21 17:16:17 --> Utf8 Class Initialized
INFO - 2019-07-21 17:16:17 --> URI Class Initialized
INFO - 2019-07-21 17:16:17 --> Router Class Initialized
INFO - 2019-07-21 17:16:17 --> Output Class Initialized
INFO - 2019-07-21 17:16:17 --> Security Class Initialized
DEBUG - 2019-07-21 17:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 17:16:17 --> Input Class Initialized
INFO - 2019-07-21 17:16:17 --> Language Class Initialized
INFO - 2019-07-21 17:16:17 --> Loader Class Initialized
INFO - 2019-07-21 17:16:17 --> Database Driver Class Initialized
INFO - 2019-07-21 17:16:17 --> Controller Class Initialized
INFO - 2019-07-21 17:16:17 --> Model "Product" initialized
INFO - 2019-07-21 17:16:17 --> Final output sent to browser
DEBUG - 2019-07-21 17:16:17 --> Total execution time: 0.1155
INFO - 2019-07-21 17:16:22 --> Config Class Initialized
INFO - 2019-07-21 17:16:22 --> Hooks Class Initialized
DEBUG - 2019-07-21 17:16:22 --> UTF-8 Support Enabled
INFO - 2019-07-21 17:16:22 --> Utf8 Class Initialized
INFO - 2019-07-21 17:16:22 --> URI Class Initialized
INFO - 2019-07-21 17:16:22 --> Router Class Initialized
INFO - 2019-07-21 17:16:22 --> Output Class Initialized
INFO - 2019-07-21 17:16:22 --> Security Class Initialized
DEBUG - 2019-07-21 17:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 17:16:22 --> Input Class Initialized
INFO - 2019-07-21 17:16:22 --> Language Class Initialized
INFO - 2019-07-21 17:16:22 --> Loader Class Initialized
INFO - 2019-07-21 17:16:22 --> Database Driver Class Initialized
INFO - 2019-07-21 17:16:22 --> Controller Class Initialized
INFO - 2019-07-21 17:16:22 --> Model "Product" initialized
INFO - 2019-07-21 17:16:22 --> Final output sent to browser
DEBUG - 2019-07-21 17:16:22 --> Total execution time: 0.1327
INFO - 2019-07-21 17:16:22 --> Config Class Initialized
INFO - 2019-07-21 17:16:22 --> Hooks Class Initialized
DEBUG - 2019-07-21 17:16:22 --> UTF-8 Support Enabled
INFO - 2019-07-21 17:16:22 --> Utf8 Class Initialized
INFO - 2019-07-21 17:16:22 --> URI Class Initialized
INFO - 2019-07-21 17:16:22 --> Router Class Initialized
INFO - 2019-07-21 17:16:22 --> Output Class Initialized
INFO - 2019-07-21 17:16:22 --> Security Class Initialized
DEBUG - 2019-07-21 17:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 17:16:22 --> Input Class Initialized
INFO - 2019-07-21 17:16:22 --> Language Class Initialized
INFO - 2019-07-21 17:16:22 --> Loader Class Initialized
INFO - 2019-07-21 17:16:22 --> Database Driver Class Initialized
INFO - 2019-07-21 17:16:22 --> Controller Class Initialized
INFO - 2019-07-21 17:16:22 --> Model "Product" initialized
INFO - 2019-07-21 17:16:22 --> Final output sent to browser
DEBUG - 2019-07-21 17:16:22 --> Total execution time: 0.1390
INFO - 2019-07-21 17:22:50 --> Config Class Initialized
INFO - 2019-07-21 17:22:50 --> Hooks Class Initialized
DEBUG - 2019-07-21 17:22:50 --> UTF-8 Support Enabled
INFO - 2019-07-21 17:22:50 --> Utf8 Class Initialized
INFO - 2019-07-21 17:22:50 --> URI Class Initialized
INFO - 2019-07-21 17:22:51 --> Router Class Initialized
INFO - 2019-07-21 17:22:51 --> Output Class Initialized
INFO - 2019-07-21 17:22:51 --> Security Class Initialized
DEBUG - 2019-07-21 17:22:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 17:22:51 --> Input Class Initialized
INFO - 2019-07-21 17:22:51 --> Language Class Initialized
INFO - 2019-07-21 17:22:52 --> Loader Class Initialized
INFO - 2019-07-21 17:22:52 --> Database Driver Class Initialized
INFO - 2019-07-21 17:22:52 --> Controller Class Initialized
INFO - 2019-07-21 17:22:53 --> Model "Product" initialized
INFO - 2019-07-21 17:22:53 --> Final output sent to browser
DEBUG - 2019-07-21 17:22:53 --> Total execution time: 2.7057
INFO - 2019-07-21 17:22:53 --> Config Class Initialized
INFO - 2019-07-21 17:22:53 --> Hooks Class Initialized
DEBUG - 2019-07-21 17:22:53 --> UTF-8 Support Enabled
INFO - 2019-07-21 17:22:53 --> Utf8 Class Initialized
INFO - 2019-07-21 17:22:53 --> URI Class Initialized
INFO - 2019-07-21 17:22:53 --> Router Class Initialized
INFO - 2019-07-21 17:22:53 --> Output Class Initialized
INFO - 2019-07-21 17:22:53 --> Security Class Initialized
DEBUG - 2019-07-21 17:22:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 17:22:53 --> Input Class Initialized
INFO - 2019-07-21 17:22:53 --> Language Class Initialized
INFO - 2019-07-21 17:22:53 --> Loader Class Initialized
INFO - 2019-07-21 17:22:53 --> Database Driver Class Initialized
INFO - 2019-07-21 17:22:53 --> Controller Class Initialized
INFO - 2019-07-21 17:22:53 --> Model "Product" initialized
INFO - 2019-07-21 17:22:53 --> Final output sent to browser
DEBUG - 2019-07-21 17:22:53 --> Total execution time: 0.3742
INFO - 2019-07-21 17:23:00 --> Config Class Initialized
INFO - 2019-07-21 17:23:00 --> Hooks Class Initialized
DEBUG - 2019-07-21 17:23:00 --> UTF-8 Support Enabled
INFO - 2019-07-21 17:23:00 --> Utf8 Class Initialized
INFO - 2019-07-21 17:23:00 --> URI Class Initialized
INFO - 2019-07-21 17:23:00 --> Router Class Initialized
INFO - 2019-07-21 17:23:00 --> Output Class Initialized
INFO - 2019-07-21 17:23:00 --> Security Class Initialized
DEBUG - 2019-07-21 17:23:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 17:23:00 --> Input Class Initialized
INFO - 2019-07-21 17:23:00 --> Language Class Initialized
INFO - 2019-07-21 17:23:00 --> Loader Class Initialized
INFO - 2019-07-21 17:23:00 --> Database Driver Class Initialized
INFO - 2019-07-21 17:23:00 --> Controller Class Initialized
INFO - 2019-07-21 17:23:00 --> Model "Product" initialized
INFO - 2019-07-21 17:23:00 --> Final output sent to browser
DEBUG - 2019-07-21 17:23:00 --> Total execution time: 0.1424
INFO - 2019-07-21 17:23:00 --> Config Class Initialized
INFO - 2019-07-21 17:23:00 --> Hooks Class Initialized
DEBUG - 2019-07-21 17:23:00 --> UTF-8 Support Enabled
INFO - 2019-07-21 17:23:00 --> Utf8 Class Initialized
INFO - 2019-07-21 17:23:00 --> URI Class Initialized
INFO - 2019-07-21 17:23:00 --> Router Class Initialized
INFO - 2019-07-21 17:23:00 --> Output Class Initialized
INFO - 2019-07-21 17:23:00 --> Security Class Initialized
DEBUG - 2019-07-21 17:23:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 17:23:00 --> Input Class Initialized
INFO - 2019-07-21 17:23:00 --> Language Class Initialized
INFO - 2019-07-21 17:23:00 --> Loader Class Initialized
INFO - 2019-07-21 17:23:00 --> Database Driver Class Initialized
INFO - 2019-07-21 17:23:00 --> Controller Class Initialized
INFO - 2019-07-21 17:23:00 --> Model "Product" initialized
INFO - 2019-07-21 17:23:00 --> Final output sent to browser
DEBUG - 2019-07-21 17:23:00 --> Total execution time: 0.1039
INFO - 2019-07-21 17:24:49 --> Config Class Initialized
INFO - 2019-07-21 17:24:49 --> Hooks Class Initialized
DEBUG - 2019-07-21 17:24:49 --> UTF-8 Support Enabled
INFO - 2019-07-21 17:24:49 --> Utf8 Class Initialized
INFO - 2019-07-21 17:24:49 --> URI Class Initialized
INFO - 2019-07-21 17:24:49 --> Router Class Initialized
INFO - 2019-07-21 17:24:49 --> Output Class Initialized
INFO - 2019-07-21 17:24:49 --> Security Class Initialized
DEBUG - 2019-07-21 17:24:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 17:24:49 --> Input Class Initialized
INFO - 2019-07-21 17:24:49 --> Language Class Initialized
INFO - 2019-07-21 17:24:49 --> Loader Class Initialized
INFO - 2019-07-21 17:24:49 --> Database Driver Class Initialized
INFO - 2019-07-21 17:24:49 --> Controller Class Initialized
INFO - 2019-07-21 17:24:49 --> Model "Product" initialized
INFO - 2019-07-21 17:24:49 --> Final output sent to browser
DEBUG - 2019-07-21 17:24:49 --> Total execution time: 0.0194
INFO - 2019-07-21 17:24:49 --> Config Class Initialized
INFO - 2019-07-21 17:24:49 --> Hooks Class Initialized
DEBUG - 2019-07-21 17:24:49 --> UTF-8 Support Enabled
INFO - 2019-07-21 17:24:49 --> Utf8 Class Initialized
INFO - 2019-07-21 17:24:49 --> URI Class Initialized
INFO - 2019-07-21 17:24:49 --> Router Class Initialized
INFO - 2019-07-21 17:24:49 --> Output Class Initialized
INFO - 2019-07-21 17:24:49 --> Security Class Initialized
DEBUG - 2019-07-21 17:24:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 17:24:49 --> Input Class Initialized
INFO - 2019-07-21 17:24:49 --> Language Class Initialized
INFO - 2019-07-21 17:24:49 --> Loader Class Initialized
INFO - 2019-07-21 17:24:49 --> Database Driver Class Initialized
INFO - 2019-07-21 17:24:49 --> Controller Class Initialized
INFO - 2019-07-21 17:24:49 --> Model "Product" initialized
INFO - 2019-07-21 17:24:49 --> Final output sent to browser
DEBUG - 2019-07-21 17:24:49 --> Total execution time: 0.0883
INFO - 2019-07-21 17:25:55 --> Config Class Initialized
INFO - 2019-07-21 17:25:55 --> Hooks Class Initialized
DEBUG - 2019-07-21 17:25:55 --> UTF-8 Support Enabled
INFO - 2019-07-21 17:25:55 --> Utf8 Class Initialized
INFO - 2019-07-21 17:25:55 --> URI Class Initialized
INFO - 2019-07-21 17:25:55 --> Router Class Initialized
INFO - 2019-07-21 17:25:55 --> Output Class Initialized
INFO - 2019-07-21 17:25:55 --> Security Class Initialized
DEBUG - 2019-07-21 17:25:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 17:25:55 --> Input Class Initialized
INFO - 2019-07-21 17:25:55 --> Language Class Initialized
INFO - 2019-07-21 17:25:55 --> Loader Class Initialized
INFO - 2019-07-21 17:25:55 --> Database Driver Class Initialized
INFO - 2019-07-21 17:25:55 --> Controller Class Initialized
INFO - 2019-07-21 17:25:56 --> Model "Product" initialized
INFO - 2019-07-21 17:25:56 --> Final output sent to browser
DEBUG - 2019-07-21 17:25:56 --> Total execution time: 0.8043
INFO - 2019-07-21 17:25:56 --> Config Class Initialized
INFO - 2019-07-21 17:25:56 --> Hooks Class Initialized
DEBUG - 2019-07-21 17:25:56 --> UTF-8 Support Enabled
INFO - 2019-07-21 17:25:56 --> Utf8 Class Initialized
INFO - 2019-07-21 17:25:56 --> URI Class Initialized
INFO - 2019-07-21 17:25:56 --> Router Class Initialized
INFO - 2019-07-21 17:25:56 --> Output Class Initialized
INFO - 2019-07-21 17:25:56 --> Security Class Initialized
DEBUG - 2019-07-21 17:25:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 17:25:56 --> Input Class Initialized
INFO - 2019-07-21 17:25:56 --> Language Class Initialized
INFO - 2019-07-21 17:25:56 --> Loader Class Initialized
INFO - 2019-07-21 17:25:56 --> Database Driver Class Initialized
INFO - 2019-07-21 17:25:56 --> Controller Class Initialized
INFO - 2019-07-21 17:25:56 --> Model "Product" initialized
INFO - 2019-07-21 17:25:56 --> Final output sent to browser
DEBUG - 2019-07-21 17:25:56 --> Total execution time: 0.0900
INFO - 2019-07-21 17:26:28 --> Config Class Initialized
INFO - 2019-07-21 17:26:28 --> Hooks Class Initialized
DEBUG - 2019-07-21 17:26:28 --> UTF-8 Support Enabled
INFO - 2019-07-21 17:26:28 --> Utf8 Class Initialized
INFO - 2019-07-21 17:26:28 --> URI Class Initialized
INFO - 2019-07-21 17:26:28 --> Router Class Initialized
INFO - 2019-07-21 17:26:28 --> Output Class Initialized
INFO - 2019-07-21 17:26:28 --> Security Class Initialized
DEBUG - 2019-07-21 17:26:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 17:26:28 --> Input Class Initialized
INFO - 2019-07-21 17:26:28 --> Language Class Initialized
INFO - 2019-07-21 17:26:28 --> Loader Class Initialized
INFO - 2019-07-21 17:26:28 --> Database Driver Class Initialized
INFO - 2019-07-21 17:26:28 --> Controller Class Initialized
INFO - 2019-07-21 17:26:28 --> Model "Product" initialized
INFO - 2019-07-21 17:26:28 --> Final output sent to browser
DEBUG - 2019-07-21 17:26:28 --> Total execution time: 0.0180
INFO - 2019-07-21 17:26:28 --> Config Class Initialized
INFO - 2019-07-21 17:26:28 --> Hooks Class Initialized
DEBUG - 2019-07-21 17:26:28 --> UTF-8 Support Enabled
INFO - 2019-07-21 17:26:28 --> Utf8 Class Initialized
INFO - 2019-07-21 17:26:28 --> URI Class Initialized
INFO - 2019-07-21 17:26:28 --> Router Class Initialized
INFO - 2019-07-21 17:26:28 --> Output Class Initialized
INFO - 2019-07-21 17:26:28 --> Security Class Initialized
DEBUG - 2019-07-21 17:26:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 17:26:28 --> Input Class Initialized
INFO - 2019-07-21 17:26:28 --> Language Class Initialized
INFO - 2019-07-21 17:26:28 --> Loader Class Initialized
INFO - 2019-07-21 17:26:28 --> Database Driver Class Initialized
INFO - 2019-07-21 17:26:28 --> Controller Class Initialized
INFO - 2019-07-21 17:26:28 --> Model "Product" initialized
INFO - 2019-07-21 17:26:28 --> Final output sent to browser
DEBUG - 2019-07-21 17:26:28 --> Total execution time: 0.1505
INFO - 2019-07-21 17:26:47 --> Config Class Initialized
INFO - 2019-07-21 17:26:47 --> Hooks Class Initialized
DEBUG - 2019-07-21 17:26:47 --> UTF-8 Support Enabled
INFO - 2019-07-21 17:26:47 --> Utf8 Class Initialized
INFO - 2019-07-21 17:26:47 --> URI Class Initialized
INFO - 2019-07-21 17:26:47 --> Router Class Initialized
INFO - 2019-07-21 17:26:47 --> Output Class Initialized
INFO - 2019-07-21 17:26:47 --> Security Class Initialized
DEBUG - 2019-07-21 17:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 17:26:47 --> Input Class Initialized
INFO - 2019-07-21 17:26:47 --> Language Class Initialized
INFO - 2019-07-21 17:26:47 --> Loader Class Initialized
INFO - 2019-07-21 17:26:47 --> Database Driver Class Initialized
INFO - 2019-07-21 17:26:47 --> Controller Class Initialized
INFO - 2019-07-21 17:26:47 --> Model "Product" initialized
INFO - 2019-07-21 17:26:47 --> Final output sent to browser
DEBUG - 2019-07-21 17:26:47 --> Total execution time: 0.0194
INFO - 2019-07-21 17:26:47 --> Config Class Initialized
INFO - 2019-07-21 17:26:47 --> Hooks Class Initialized
DEBUG - 2019-07-21 17:26:47 --> UTF-8 Support Enabled
INFO - 2019-07-21 17:26:47 --> Utf8 Class Initialized
INFO - 2019-07-21 17:26:47 --> URI Class Initialized
INFO - 2019-07-21 17:26:47 --> Router Class Initialized
INFO - 2019-07-21 17:26:47 --> Output Class Initialized
INFO - 2019-07-21 17:26:47 --> Security Class Initialized
DEBUG - 2019-07-21 17:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 17:26:47 --> Input Class Initialized
INFO - 2019-07-21 17:26:47 --> Language Class Initialized
INFO - 2019-07-21 17:26:47 --> Loader Class Initialized
INFO - 2019-07-21 17:26:47 --> Database Driver Class Initialized
INFO - 2019-07-21 17:26:47 --> Controller Class Initialized
INFO - 2019-07-21 17:26:47 --> Model "Product" initialized
INFO - 2019-07-21 17:26:47 --> Final output sent to browser
DEBUG - 2019-07-21 17:26:47 --> Total execution time: 0.0999
INFO - 2019-07-21 17:28:14 --> Config Class Initialized
INFO - 2019-07-21 17:28:14 --> Hooks Class Initialized
DEBUG - 2019-07-21 17:28:14 --> UTF-8 Support Enabled
INFO - 2019-07-21 17:28:14 --> Utf8 Class Initialized
INFO - 2019-07-21 17:28:14 --> URI Class Initialized
INFO - 2019-07-21 17:28:14 --> Router Class Initialized
INFO - 2019-07-21 17:28:14 --> Output Class Initialized
INFO - 2019-07-21 17:28:14 --> Security Class Initialized
DEBUG - 2019-07-21 17:28:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 17:28:14 --> Input Class Initialized
INFO - 2019-07-21 17:28:14 --> Language Class Initialized
INFO - 2019-07-21 17:28:14 --> Loader Class Initialized
INFO - 2019-07-21 17:28:14 --> Database Driver Class Initialized
INFO - 2019-07-21 17:28:14 --> Controller Class Initialized
INFO - 2019-07-21 17:28:14 --> Model "Product" initialized
INFO - 2019-07-21 17:28:14 --> Final output sent to browser
DEBUG - 2019-07-21 17:28:14 --> Total execution time: 0.0884
INFO - 2019-07-21 17:28:14 --> Config Class Initialized
INFO - 2019-07-21 17:28:14 --> Hooks Class Initialized
DEBUG - 2019-07-21 17:28:14 --> UTF-8 Support Enabled
INFO - 2019-07-21 17:28:14 --> Utf8 Class Initialized
INFO - 2019-07-21 17:28:14 --> URI Class Initialized
INFO - 2019-07-21 17:28:14 --> Router Class Initialized
INFO - 2019-07-21 17:28:14 --> Output Class Initialized
INFO - 2019-07-21 17:28:14 --> Security Class Initialized
DEBUG - 2019-07-21 17:28:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 17:28:14 --> Input Class Initialized
INFO - 2019-07-21 17:28:14 --> Language Class Initialized
INFO - 2019-07-21 17:28:14 --> Loader Class Initialized
INFO - 2019-07-21 17:28:14 --> Database Driver Class Initialized
INFO - 2019-07-21 17:28:14 --> Controller Class Initialized
INFO - 2019-07-21 17:28:14 --> Model "Product" initialized
INFO - 2019-07-21 17:28:14 --> Final output sent to browser
DEBUG - 2019-07-21 17:28:14 --> Total execution time: 0.1148
INFO - 2019-07-21 17:28:40 --> Config Class Initialized
INFO - 2019-07-21 17:28:40 --> Hooks Class Initialized
DEBUG - 2019-07-21 17:28:40 --> UTF-8 Support Enabled
INFO - 2019-07-21 17:28:40 --> Utf8 Class Initialized
INFO - 2019-07-21 17:28:40 --> URI Class Initialized
INFO - 2019-07-21 17:28:40 --> Router Class Initialized
INFO - 2019-07-21 17:28:40 --> Output Class Initialized
INFO - 2019-07-21 17:28:40 --> Security Class Initialized
DEBUG - 2019-07-21 17:28:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 17:28:40 --> Input Class Initialized
INFO - 2019-07-21 17:28:40 --> Language Class Initialized
INFO - 2019-07-21 17:28:40 --> Loader Class Initialized
INFO - 2019-07-21 17:28:40 --> Database Driver Class Initialized
INFO - 2019-07-21 17:28:40 --> Controller Class Initialized
INFO - 2019-07-21 17:28:40 --> Model "Product" initialized
INFO - 2019-07-21 17:28:40 --> Final output sent to browser
DEBUG - 2019-07-21 17:28:40 --> Total execution time: 0.0775
INFO - 2019-07-21 17:28:40 --> Config Class Initialized
INFO - 2019-07-21 17:28:40 --> Hooks Class Initialized
DEBUG - 2019-07-21 17:28:40 --> UTF-8 Support Enabled
INFO - 2019-07-21 17:28:40 --> Utf8 Class Initialized
INFO - 2019-07-21 17:28:40 --> URI Class Initialized
INFO - 2019-07-21 17:28:40 --> Router Class Initialized
INFO - 2019-07-21 17:28:40 --> Output Class Initialized
INFO - 2019-07-21 17:28:40 --> Security Class Initialized
DEBUG - 2019-07-21 17:28:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 17:28:40 --> Input Class Initialized
INFO - 2019-07-21 17:28:40 --> Language Class Initialized
INFO - 2019-07-21 17:28:40 --> Loader Class Initialized
INFO - 2019-07-21 17:28:40 --> Database Driver Class Initialized
INFO - 2019-07-21 17:28:40 --> Controller Class Initialized
INFO - 2019-07-21 17:28:40 --> Model "Product" initialized
INFO - 2019-07-21 17:28:41 --> Final output sent to browser
DEBUG - 2019-07-21 17:28:41 --> Total execution time: 0.2941
INFO - 2019-07-21 17:28:51 --> Config Class Initialized
INFO - 2019-07-21 17:28:51 --> Hooks Class Initialized
DEBUG - 2019-07-21 17:28:51 --> UTF-8 Support Enabled
INFO - 2019-07-21 17:28:51 --> Utf8 Class Initialized
INFO - 2019-07-21 17:28:51 --> URI Class Initialized
INFO - 2019-07-21 17:28:51 --> Router Class Initialized
INFO - 2019-07-21 17:28:51 --> Output Class Initialized
INFO - 2019-07-21 17:28:51 --> Security Class Initialized
DEBUG - 2019-07-21 17:28:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 17:28:51 --> Input Class Initialized
INFO - 2019-07-21 17:28:51 --> Language Class Initialized
INFO - 2019-07-21 17:28:51 --> Loader Class Initialized
INFO - 2019-07-21 17:28:51 --> Database Driver Class Initialized
INFO - 2019-07-21 17:28:51 --> Controller Class Initialized
INFO - 2019-07-21 17:28:51 --> Model "Product" initialized
INFO - 2019-07-21 17:28:51 --> Final output sent to browser
DEBUG - 2019-07-21 17:28:51 --> Total execution time: 0.0143
INFO - 2019-07-21 17:28:51 --> Config Class Initialized
INFO - 2019-07-21 17:28:51 --> Hooks Class Initialized
DEBUG - 2019-07-21 17:28:51 --> UTF-8 Support Enabled
INFO - 2019-07-21 17:28:51 --> Utf8 Class Initialized
INFO - 2019-07-21 17:28:51 --> URI Class Initialized
INFO - 2019-07-21 17:28:51 --> Router Class Initialized
INFO - 2019-07-21 17:28:51 --> Output Class Initialized
INFO - 2019-07-21 17:28:51 --> Security Class Initialized
DEBUG - 2019-07-21 17:28:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 17:28:51 --> Input Class Initialized
INFO - 2019-07-21 17:28:51 --> Language Class Initialized
INFO - 2019-07-21 17:28:51 --> Loader Class Initialized
INFO - 2019-07-21 17:28:51 --> Database Driver Class Initialized
INFO - 2019-07-21 17:28:51 --> Controller Class Initialized
INFO - 2019-07-21 17:28:51 --> Model "Product" initialized
INFO - 2019-07-21 17:28:51 --> Final output sent to browser
DEBUG - 2019-07-21 17:28:51 --> Total execution time: 0.1900
INFO - 2019-07-21 17:29:05 --> Config Class Initialized
INFO - 2019-07-21 17:29:05 --> Hooks Class Initialized
DEBUG - 2019-07-21 17:29:05 --> UTF-8 Support Enabled
INFO - 2019-07-21 17:29:05 --> Utf8 Class Initialized
INFO - 2019-07-21 17:29:05 --> URI Class Initialized
INFO - 2019-07-21 17:29:05 --> Router Class Initialized
INFO - 2019-07-21 17:29:05 --> Output Class Initialized
INFO - 2019-07-21 17:29:05 --> Security Class Initialized
DEBUG - 2019-07-21 17:29:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 17:29:05 --> Input Class Initialized
INFO - 2019-07-21 17:29:05 --> Language Class Initialized
INFO - 2019-07-21 17:29:06 --> Loader Class Initialized
INFO - 2019-07-21 17:29:06 --> Database Driver Class Initialized
INFO - 2019-07-21 17:29:06 --> Controller Class Initialized
INFO - 2019-07-21 17:29:06 --> Model "Product" initialized
INFO - 2019-07-21 17:29:06 --> Final output sent to browser
DEBUG - 2019-07-21 17:29:06 --> Total execution time: 0.1241
INFO - 2019-07-21 17:29:06 --> Config Class Initialized
INFO - 2019-07-21 17:29:06 --> Hooks Class Initialized
DEBUG - 2019-07-21 17:29:06 --> UTF-8 Support Enabled
INFO - 2019-07-21 17:29:06 --> Utf8 Class Initialized
INFO - 2019-07-21 17:29:06 --> URI Class Initialized
INFO - 2019-07-21 17:29:06 --> Router Class Initialized
INFO - 2019-07-21 17:29:06 --> Output Class Initialized
INFO - 2019-07-21 17:29:06 --> Security Class Initialized
DEBUG - 2019-07-21 17:29:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 17:29:06 --> Input Class Initialized
INFO - 2019-07-21 17:29:06 --> Language Class Initialized
INFO - 2019-07-21 17:29:06 --> Loader Class Initialized
INFO - 2019-07-21 17:29:06 --> Database Driver Class Initialized
INFO - 2019-07-21 17:29:06 --> Controller Class Initialized
INFO - 2019-07-21 17:29:06 --> Model "Product" initialized
INFO - 2019-07-21 17:29:06 --> Final output sent to browser
DEBUG - 2019-07-21 17:29:06 --> Total execution time: 0.2325
INFO - 2019-07-21 17:33:53 --> Config Class Initialized
INFO - 2019-07-21 17:33:53 --> Hooks Class Initialized
DEBUG - 2019-07-21 17:33:53 --> UTF-8 Support Enabled
INFO - 2019-07-21 17:33:53 --> Utf8 Class Initialized
INFO - 2019-07-21 17:33:53 --> URI Class Initialized
INFO - 2019-07-21 17:33:53 --> Router Class Initialized
INFO - 2019-07-21 17:33:53 --> Output Class Initialized
INFO - 2019-07-21 17:33:53 --> Security Class Initialized
DEBUG - 2019-07-21 17:33:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 17:33:53 --> Input Class Initialized
INFO - 2019-07-21 17:33:53 --> Language Class Initialized
INFO - 2019-07-21 17:33:53 --> Loader Class Initialized
INFO - 2019-07-21 17:33:53 --> Database Driver Class Initialized
INFO - 2019-07-21 17:33:53 --> Controller Class Initialized
INFO - 2019-07-21 17:33:53 --> Model "Product" initialized
INFO - 2019-07-21 17:33:53 --> Final output sent to browser
DEBUG - 2019-07-21 17:33:53 --> Total execution time: 0.8785
INFO - 2019-07-21 17:33:53 --> Config Class Initialized
INFO - 2019-07-21 17:33:53 --> Hooks Class Initialized
DEBUG - 2019-07-21 17:33:53 --> UTF-8 Support Enabled
INFO - 2019-07-21 17:33:53 --> Utf8 Class Initialized
INFO - 2019-07-21 17:33:53 --> URI Class Initialized
INFO - 2019-07-21 17:33:53 --> Router Class Initialized
INFO - 2019-07-21 17:33:53 --> Output Class Initialized
INFO - 2019-07-21 17:33:53 --> Security Class Initialized
DEBUG - 2019-07-21 17:33:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 17:33:53 --> Input Class Initialized
INFO - 2019-07-21 17:33:53 --> Language Class Initialized
INFO - 2019-07-21 17:33:53 --> Loader Class Initialized
INFO - 2019-07-21 17:33:54 --> Database Driver Class Initialized
INFO - 2019-07-21 17:33:54 --> Controller Class Initialized
INFO - 2019-07-21 17:33:54 --> Model "Product" initialized
INFO - 2019-07-21 17:33:54 --> Final output sent to browser
DEBUG - 2019-07-21 17:33:54 --> Total execution time: 0.4153
INFO - 2019-07-21 17:34:00 --> Config Class Initialized
INFO - 2019-07-21 17:34:00 --> Hooks Class Initialized
DEBUG - 2019-07-21 17:34:00 --> UTF-8 Support Enabled
INFO - 2019-07-21 17:34:00 --> Utf8 Class Initialized
INFO - 2019-07-21 17:34:00 --> URI Class Initialized
INFO - 2019-07-21 17:34:00 --> Router Class Initialized
INFO - 2019-07-21 17:34:00 --> Output Class Initialized
INFO - 2019-07-21 17:34:00 --> Security Class Initialized
DEBUG - 2019-07-21 17:34:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 17:34:00 --> Input Class Initialized
INFO - 2019-07-21 17:34:00 --> Language Class Initialized
INFO - 2019-07-21 17:34:00 --> Loader Class Initialized
INFO - 2019-07-21 17:34:00 --> Database Driver Class Initialized
INFO - 2019-07-21 17:34:00 --> Controller Class Initialized
INFO - 2019-07-21 17:34:00 --> Model "Product" initialized
INFO - 2019-07-21 17:34:00 --> Final output sent to browser
DEBUG - 2019-07-21 17:34:00 --> Total execution time: 0.0176
INFO - 2019-07-21 17:34:00 --> Config Class Initialized
INFO - 2019-07-21 17:34:00 --> Hooks Class Initialized
DEBUG - 2019-07-21 17:34:00 --> UTF-8 Support Enabled
INFO - 2019-07-21 17:34:00 --> Utf8 Class Initialized
INFO - 2019-07-21 17:34:00 --> URI Class Initialized
INFO - 2019-07-21 17:34:00 --> Router Class Initialized
INFO - 2019-07-21 17:34:00 --> Output Class Initialized
INFO - 2019-07-21 17:34:00 --> Security Class Initialized
DEBUG - 2019-07-21 17:34:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 17:34:00 --> Input Class Initialized
INFO - 2019-07-21 17:34:00 --> Language Class Initialized
INFO - 2019-07-21 17:34:01 --> Loader Class Initialized
INFO - 2019-07-21 17:34:01 --> Database Driver Class Initialized
INFO - 2019-07-21 17:34:01 --> Controller Class Initialized
INFO - 2019-07-21 17:34:01 --> Model "Product" initialized
INFO - 2019-07-21 17:34:01 --> Final output sent to browser
DEBUG - 2019-07-21 17:34:01 --> Total execution time: 0.1095
INFO - 2019-07-21 17:34:21 --> Config Class Initialized
INFO - 2019-07-21 17:34:21 --> Hooks Class Initialized
DEBUG - 2019-07-21 17:34:21 --> UTF-8 Support Enabled
INFO - 2019-07-21 17:34:21 --> Utf8 Class Initialized
INFO - 2019-07-21 17:34:21 --> URI Class Initialized
INFO - 2019-07-21 17:34:21 --> Router Class Initialized
INFO - 2019-07-21 17:34:21 --> Output Class Initialized
INFO - 2019-07-21 17:34:21 --> Security Class Initialized
DEBUG - 2019-07-21 17:34:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 17:34:21 --> Input Class Initialized
INFO - 2019-07-21 17:34:21 --> Language Class Initialized
INFO - 2019-07-21 17:34:21 --> Loader Class Initialized
INFO - 2019-07-21 17:34:21 --> Database Driver Class Initialized
INFO - 2019-07-21 17:34:21 --> Controller Class Initialized
INFO - 2019-07-21 17:34:21 --> Model "Product" initialized
INFO - 2019-07-21 17:34:21 --> Final output sent to browser
DEBUG - 2019-07-21 17:34:21 --> Total execution time: 0.0154
INFO - 2019-07-21 17:34:21 --> Config Class Initialized
INFO - 2019-07-21 17:34:21 --> Hooks Class Initialized
DEBUG - 2019-07-21 17:34:21 --> UTF-8 Support Enabled
INFO - 2019-07-21 17:34:21 --> Utf8 Class Initialized
INFO - 2019-07-21 17:34:21 --> URI Class Initialized
INFO - 2019-07-21 17:34:21 --> Router Class Initialized
INFO - 2019-07-21 17:34:21 --> Output Class Initialized
INFO - 2019-07-21 17:34:21 --> Security Class Initialized
DEBUG - 2019-07-21 17:34:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 17:34:21 --> Input Class Initialized
INFO - 2019-07-21 17:34:21 --> Language Class Initialized
INFO - 2019-07-21 17:34:21 --> Loader Class Initialized
INFO - 2019-07-21 17:34:21 --> Database Driver Class Initialized
INFO - 2019-07-21 17:34:21 --> Controller Class Initialized
INFO - 2019-07-21 17:34:21 --> Model "Product" initialized
INFO - 2019-07-21 17:34:21 --> Final output sent to browser
DEBUG - 2019-07-21 17:34:21 --> Total execution time: 0.1171
INFO - 2019-07-21 17:37:57 --> Config Class Initialized
INFO - 2019-07-21 17:37:58 --> Hooks Class Initialized
DEBUG - 2019-07-21 17:37:58 --> UTF-8 Support Enabled
INFO - 2019-07-21 17:37:58 --> Utf8 Class Initialized
INFO - 2019-07-21 17:37:58 --> URI Class Initialized
INFO - 2019-07-21 17:37:58 --> Router Class Initialized
INFO - 2019-07-21 17:37:58 --> Output Class Initialized
INFO - 2019-07-21 17:37:58 --> Security Class Initialized
DEBUG - 2019-07-21 17:37:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 17:37:58 --> Input Class Initialized
INFO - 2019-07-21 17:37:58 --> Language Class Initialized
INFO - 2019-07-21 17:37:58 --> Loader Class Initialized
INFO - 2019-07-21 17:37:58 --> Database Driver Class Initialized
INFO - 2019-07-21 17:37:58 --> Controller Class Initialized
INFO - 2019-07-21 17:37:58 --> Model "Product" initialized
INFO - 2019-07-21 17:37:58 --> Final output sent to browser
DEBUG - 2019-07-21 17:37:58 --> Total execution time: 0.2939
INFO - 2019-07-21 17:37:58 --> Config Class Initialized
INFO - 2019-07-21 17:37:58 --> Hooks Class Initialized
DEBUG - 2019-07-21 17:37:58 --> UTF-8 Support Enabled
INFO - 2019-07-21 17:37:58 --> Utf8 Class Initialized
INFO - 2019-07-21 17:37:58 --> URI Class Initialized
INFO - 2019-07-21 17:37:58 --> Router Class Initialized
INFO - 2019-07-21 17:37:58 --> Output Class Initialized
INFO - 2019-07-21 17:37:58 --> Security Class Initialized
DEBUG - 2019-07-21 17:37:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 17:37:58 --> Input Class Initialized
INFO - 2019-07-21 17:37:58 --> Language Class Initialized
INFO - 2019-07-21 17:37:58 --> Loader Class Initialized
INFO - 2019-07-21 17:37:58 --> Database Driver Class Initialized
INFO - 2019-07-21 17:37:58 --> Controller Class Initialized
INFO - 2019-07-21 17:37:58 --> Model "Product" initialized
INFO - 2019-07-21 17:37:58 --> Final output sent to browser
DEBUG - 2019-07-21 17:37:58 --> Total execution time: 0.1157
INFO - 2019-07-21 17:38:23 --> Config Class Initialized
INFO - 2019-07-21 17:38:23 --> Hooks Class Initialized
DEBUG - 2019-07-21 17:38:23 --> UTF-8 Support Enabled
INFO - 2019-07-21 17:38:23 --> Utf8 Class Initialized
INFO - 2019-07-21 17:38:23 --> URI Class Initialized
INFO - 2019-07-21 17:38:23 --> Router Class Initialized
INFO - 2019-07-21 17:38:23 --> Output Class Initialized
INFO - 2019-07-21 17:38:23 --> Security Class Initialized
DEBUG - 2019-07-21 17:38:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 17:38:23 --> Input Class Initialized
INFO - 2019-07-21 17:38:23 --> Language Class Initialized
INFO - 2019-07-21 17:38:23 --> Loader Class Initialized
INFO - 2019-07-21 17:38:23 --> Database Driver Class Initialized
INFO - 2019-07-21 17:38:23 --> Controller Class Initialized
INFO - 2019-07-21 17:38:23 --> Model "Product" initialized
INFO - 2019-07-21 17:38:23 --> Final output sent to browser
DEBUG - 2019-07-21 17:38:23 --> Total execution time: 0.0289
INFO - 2019-07-21 17:38:23 --> Config Class Initialized
INFO - 2019-07-21 17:38:23 --> Hooks Class Initialized
DEBUG - 2019-07-21 17:38:23 --> UTF-8 Support Enabled
INFO - 2019-07-21 17:38:23 --> Utf8 Class Initialized
INFO - 2019-07-21 17:38:23 --> URI Class Initialized
INFO - 2019-07-21 17:38:23 --> Router Class Initialized
INFO - 2019-07-21 17:38:23 --> Output Class Initialized
INFO - 2019-07-21 17:38:23 --> Security Class Initialized
DEBUG - 2019-07-21 17:38:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 17:38:23 --> Input Class Initialized
INFO - 2019-07-21 17:38:23 --> Language Class Initialized
INFO - 2019-07-21 17:38:23 --> Loader Class Initialized
INFO - 2019-07-21 17:38:23 --> Database Driver Class Initialized
INFO - 2019-07-21 17:38:23 --> Controller Class Initialized
INFO - 2019-07-21 17:38:23 --> Model "Product" initialized
INFO - 2019-07-21 17:38:23 --> Final output sent to browser
DEBUG - 2019-07-21 17:38:23 --> Total execution time: 0.1036
INFO - 2019-07-21 17:40:32 --> Config Class Initialized
INFO - 2019-07-21 17:40:32 --> Hooks Class Initialized
DEBUG - 2019-07-21 17:40:32 --> UTF-8 Support Enabled
INFO - 2019-07-21 17:40:32 --> Utf8 Class Initialized
INFO - 2019-07-21 17:40:32 --> URI Class Initialized
INFO - 2019-07-21 17:40:32 --> Router Class Initialized
INFO - 2019-07-21 17:40:32 --> Output Class Initialized
INFO - 2019-07-21 17:40:32 --> Security Class Initialized
DEBUG - 2019-07-21 17:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 17:40:32 --> Input Class Initialized
INFO - 2019-07-21 17:40:32 --> Language Class Initialized
INFO - 2019-07-21 17:40:32 --> Loader Class Initialized
INFO - 2019-07-21 17:40:32 --> Database Driver Class Initialized
INFO - 2019-07-21 17:40:32 --> Controller Class Initialized
INFO - 2019-07-21 17:40:32 --> Model "Product" initialized
INFO - 2019-07-21 17:40:32 --> Final output sent to browser
DEBUG - 2019-07-21 17:40:32 --> Total execution time: 0.0152
INFO - 2019-07-21 17:40:32 --> Config Class Initialized
INFO - 2019-07-21 17:40:32 --> Hooks Class Initialized
DEBUG - 2019-07-21 17:40:32 --> UTF-8 Support Enabled
INFO - 2019-07-21 17:40:32 --> Utf8 Class Initialized
INFO - 2019-07-21 17:40:32 --> URI Class Initialized
INFO - 2019-07-21 17:40:32 --> Router Class Initialized
INFO - 2019-07-21 17:40:32 --> Output Class Initialized
INFO - 2019-07-21 17:40:32 --> Security Class Initialized
DEBUG - 2019-07-21 17:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 17:40:32 --> Input Class Initialized
INFO - 2019-07-21 17:40:32 --> Language Class Initialized
INFO - 2019-07-21 17:40:32 --> Loader Class Initialized
INFO - 2019-07-21 17:40:32 --> Database Driver Class Initialized
INFO - 2019-07-21 17:40:32 --> Controller Class Initialized
INFO - 2019-07-21 17:40:32 --> Model "Product" initialized
INFO - 2019-07-21 17:40:32 --> Final output sent to browser
DEBUG - 2019-07-21 17:40:32 --> Total execution time: 0.0866
INFO - 2019-07-21 17:40:33 --> Config Class Initialized
INFO - 2019-07-21 17:40:33 --> Hooks Class Initialized
DEBUG - 2019-07-21 17:40:33 --> UTF-8 Support Enabled
INFO - 2019-07-21 17:40:33 --> Utf8 Class Initialized
INFO - 2019-07-21 17:40:33 --> URI Class Initialized
INFO - 2019-07-21 17:40:33 --> Router Class Initialized
INFO - 2019-07-21 17:40:33 --> Output Class Initialized
INFO - 2019-07-21 17:40:33 --> Security Class Initialized
DEBUG - 2019-07-21 17:40:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 17:40:33 --> Input Class Initialized
INFO - 2019-07-21 17:40:33 --> Language Class Initialized
INFO - 2019-07-21 17:40:33 --> Loader Class Initialized
INFO - 2019-07-21 17:40:33 --> Database Driver Class Initialized
INFO - 2019-07-21 17:40:33 --> Controller Class Initialized
INFO - 2019-07-21 17:40:33 --> Model "Product" initialized
INFO - 2019-07-21 17:40:33 --> Final output sent to browser
DEBUG - 2019-07-21 17:40:33 --> Total execution time: 0.0186
INFO - 2019-07-21 17:43:56 --> Config Class Initialized
INFO - 2019-07-21 17:43:56 --> Hooks Class Initialized
DEBUG - 2019-07-21 17:43:56 --> UTF-8 Support Enabled
INFO - 2019-07-21 17:43:56 --> Utf8 Class Initialized
INFO - 2019-07-21 17:43:56 --> URI Class Initialized
INFO - 2019-07-21 17:43:56 --> Router Class Initialized
INFO - 2019-07-21 17:43:56 --> Output Class Initialized
INFO - 2019-07-21 17:43:56 --> Security Class Initialized
DEBUG - 2019-07-21 17:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 17:43:56 --> Input Class Initialized
INFO - 2019-07-21 17:43:56 --> Language Class Initialized
INFO - 2019-07-21 17:43:56 --> Loader Class Initialized
INFO - 2019-07-21 17:43:56 --> Database Driver Class Initialized
INFO - 2019-07-21 17:43:56 --> Controller Class Initialized
INFO - 2019-07-21 17:43:56 --> Model "Product" initialized
INFO - 2019-07-21 17:43:56 --> Final output sent to browser
DEBUG - 2019-07-21 17:43:56 --> Total execution time: 0.0298
INFO - 2019-07-21 17:43:59 --> Config Class Initialized
INFO - 2019-07-21 17:43:59 --> Hooks Class Initialized
DEBUG - 2019-07-21 17:43:59 --> UTF-8 Support Enabled
INFO - 2019-07-21 17:43:59 --> Utf8 Class Initialized
INFO - 2019-07-21 17:43:59 --> URI Class Initialized
INFO - 2019-07-21 17:43:59 --> Router Class Initialized
INFO - 2019-07-21 17:43:59 --> Output Class Initialized
INFO - 2019-07-21 17:43:59 --> Security Class Initialized
DEBUG - 2019-07-21 17:43:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 17:43:59 --> Input Class Initialized
INFO - 2019-07-21 17:43:59 --> Language Class Initialized
INFO - 2019-07-21 17:43:59 --> Loader Class Initialized
INFO - 2019-07-21 17:43:59 --> Database Driver Class Initialized
INFO - 2019-07-21 17:43:59 --> Controller Class Initialized
INFO - 2019-07-21 17:43:59 --> Model "Product" initialized
INFO - 2019-07-21 17:43:59 --> Final output sent to browser
DEBUG - 2019-07-21 17:43:59 --> Total execution time: 0.0215
INFO - 2019-07-21 17:57:34 --> Config Class Initialized
INFO - 2019-07-21 17:57:34 --> Hooks Class Initialized
DEBUG - 2019-07-21 17:57:34 --> UTF-8 Support Enabled
INFO - 2019-07-21 17:57:34 --> Utf8 Class Initialized
INFO - 2019-07-21 17:57:35 --> URI Class Initialized
INFO - 2019-07-21 17:57:35 --> Router Class Initialized
INFO - 2019-07-21 17:57:35 --> Output Class Initialized
INFO - 2019-07-21 17:57:35 --> Security Class Initialized
DEBUG - 2019-07-21 17:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 17:57:35 --> Input Class Initialized
INFO - 2019-07-21 17:57:35 --> Language Class Initialized
INFO - 2019-07-21 17:57:35 --> Loader Class Initialized
INFO - 2019-07-21 17:57:35 --> Database Driver Class Initialized
INFO - 2019-07-21 17:57:35 --> Controller Class Initialized
INFO - 2019-07-21 17:57:35 --> Model "Product" initialized
INFO - 2019-07-21 17:57:35 --> Final output sent to browser
DEBUG - 2019-07-21 17:57:35 --> Total execution time: 0.1565
INFO - 2019-07-21 17:57:37 --> Config Class Initialized
INFO - 2019-07-21 17:57:37 --> Hooks Class Initialized
DEBUG - 2019-07-21 17:57:37 --> UTF-8 Support Enabled
INFO - 2019-07-21 17:57:37 --> Utf8 Class Initialized
INFO - 2019-07-21 17:57:37 --> URI Class Initialized
INFO - 2019-07-21 17:57:37 --> Router Class Initialized
INFO - 2019-07-21 17:57:37 --> Output Class Initialized
INFO - 2019-07-21 17:57:37 --> Security Class Initialized
DEBUG - 2019-07-21 17:57:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 17:57:37 --> Input Class Initialized
INFO - 2019-07-21 17:57:37 --> Language Class Initialized
INFO - 2019-07-21 17:57:37 --> Loader Class Initialized
INFO - 2019-07-21 17:57:37 --> Database Driver Class Initialized
INFO - 2019-07-21 17:57:37 --> Controller Class Initialized
INFO - 2019-07-21 17:57:37 --> Model "Product" initialized
INFO - 2019-07-21 17:57:37 --> Final output sent to browser
DEBUG - 2019-07-21 17:57:37 --> Total execution time: 0.0486
INFO - 2019-07-21 17:57:45 --> Config Class Initialized
INFO - 2019-07-21 17:57:45 --> Hooks Class Initialized
DEBUG - 2019-07-21 17:57:45 --> UTF-8 Support Enabled
INFO - 2019-07-21 17:57:45 --> Utf8 Class Initialized
INFO - 2019-07-21 17:57:45 --> URI Class Initialized
INFO - 2019-07-21 17:57:45 --> Router Class Initialized
INFO - 2019-07-21 17:57:45 --> Output Class Initialized
INFO - 2019-07-21 17:57:45 --> Security Class Initialized
DEBUG - 2019-07-21 17:57:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 17:57:45 --> Input Class Initialized
INFO - 2019-07-21 17:57:45 --> Language Class Initialized
INFO - 2019-07-21 17:57:45 --> Loader Class Initialized
INFO - 2019-07-21 17:57:45 --> Database Driver Class Initialized
INFO - 2019-07-21 17:57:45 --> Controller Class Initialized
INFO - 2019-07-21 17:57:45 --> Model "Product" initialized
INFO - 2019-07-21 17:57:45 --> Final output sent to browser
DEBUG - 2019-07-21 17:57:45 --> Total execution time: 0.0684
INFO - 2019-07-21 17:57:47 --> Config Class Initialized
INFO - 2019-07-21 17:57:47 --> Hooks Class Initialized
DEBUG - 2019-07-21 17:57:47 --> UTF-8 Support Enabled
INFO - 2019-07-21 17:57:47 --> Utf8 Class Initialized
INFO - 2019-07-21 17:57:47 --> URI Class Initialized
INFO - 2019-07-21 17:57:47 --> Router Class Initialized
INFO - 2019-07-21 17:57:47 --> Output Class Initialized
INFO - 2019-07-21 17:57:47 --> Security Class Initialized
DEBUG - 2019-07-21 17:57:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 17:57:47 --> Input Class Initialized
INFO - 2019-07-21 17:57:47 --> Language Class Initialized
INFO - 2019-07-21 17:57:47 --> Loader Class Initialized
INFO - 2019-07-21 17:57:47 --> Database Driver Class Initialized
INFO - 2019-07-21 17:57:47 --> Controller Class Initialized
INFO - 2019-07-21 17:57:47 --> Model "Product" initialized
INFO - 2019-07-21 17:57:47 --> Final output sent to browser
DEBUG - 2019-07-21 17:57:47 --> Total execution time: 0.0167
INFO - 2019-07-21 17:57:49 --> Config Class Initialized
INFO - 2019-07-21 17:57:49 --> Hooks Class Initialized
DEBUG - 2019-07-21 17:57:49 --> UTF-8 Support Enabled
INFO - 2019-07-21 17:57:49 --> Utf8 Class Initialized
INFO - 2019-07-21 17:57:49 --> URI Class Initialized
INFO - 2019-07-21 17:57:49 --> Router Class Initialized
INFO - 2019-07-21 17:57:49 --> Output Class Initialized
INFO - 2019-07-21 17:57:49 --> Security Class Initialized
DEBUG - 2019-07-21 17:57:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 17:57:49 --> Input Class Initialized
INFO - 2019-07-21 17:57:49 --> Language Class Initialized
INFO - 2019-07-21 17:57:49 --> Loader Class Initialized
INFO - 2019-07-21 17:57:49 --> Database Driver Class Initialized
INFO - 2019-07-21 17:57:49 --> Controller Class Initialized
INFO - 2019-07-21 17:57:49 --> Model "Product" initialized
INFO - 2019-07-21 17:57:49 --> Final output sent to browser
DEBUG - 2019-07-21 17:57:49 --> Total execution time: 0.0192
INFO - 2019-07-21 17:58:13 --> Config Class Initialized
INFO - 2019-07-21 17:58:13 --> Hooks Class Initialized
DEBUG - 2019-07-21 17:58:13 --> UTF-8 Support Enabled
INFO - 2019-07-21 17:58:13 --> Utf8 Class Initialized
INFO - 2019-07-21 17:58:13 --> URI Class Initialized
INFO - 2019-07-21 17:58:13 --> Router Class Initialized
INFO - 2019-07-21 17:58:13 --> Output Class Initialized
INFO - 2019-07-21 17:58:13 --> Config Class Initialized
INFO - 2019-07-21 17:58:13 --> Hooks Class Initialized
DEBUG - 2019-07-21 17:58:13 --> UTF-8 Support Enabled
INFO - 2019-07-21 17:58:13 --> Utf8 Class Initialized
INFO - 2019-07-21 17:58:13 --> URI Class Initialized
INFO - 2019-07-21 17:58:13 --> Security Class Initialized
DEBUG - 2019-07-21 17:58:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 17:58:13 --> Input Class Initialized
INFO - 2019-07-21 17:58:13 --> Language Class Initialized
INFO - 2019-07-21 17:58:13 --> Loader Class Initialized
INFO - 2019-07-21 17:58:13 --> Router Class Initialized
INFO - 2019-07-21 17:58:13 --> Output Class Initialized
INFO - 2019-07-21 17:58:13 --> Security Class Initialized
DEBUG - 2019-07-21 17:58:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 17:58:13 --> Input Class Initialized
INFO - 2019-07-21 17:58:13 --> Language Class Initialized
INFO - 2019-07-21 17:58:13 --> Loader Class Initialized
INFO - 2019-07-21 17:58:13 --> Database Driver Class Initialized
INFO - 2019-07-21 17:58:13 --> Controller Class Initialized
INFO - 2019-07-21 17:58:13 --> Model "Product" initialized
INFO - 2019-07-21 17:58:13 --> Final output sent to browser
DEBUG - 2019-07-21 17:58:13 --> Total execution time: 0.0640
INFO - 2019-07-21 17:58:13 --> Database Driver Class Initialized
INFO - 2019-07-21 17:58:13 --> Controller Class Initialized
INFO - 2019-07-21 17:58:13 --> Model "Product" initialized
INFO - 2019-07-21 17:58:13 --> Final output sent to browser
DEBUG - 2019-07-21 17:58:13 --> Total execution time: 0.0543
INFO - 2019-07-21 17:58:31 --> Config Class Initialized
INFO - 2019-07-21 17:58:31 --> Hooks Class Initialized
DEBUG - 2019-07-21 17:58:31 --> UTF-8 Support Enabled
INFO - 2019-07-21 17:58:31 --> Utf8 Class Initialized
INFO - 2019-07-21 17:58:31 --> URI Class Initialized
INFO - 2019-07-21 17:58:31 --> Router Class Initialized
INFO - 2019-07-21 17:58:31 --> Output Class Initialized
INFO - 2019-07-21 17:58:31 --> Security Class Initialized
DEBUG - 2019-07-21 17:58:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 17:58:31 --> Input Class Initialized
INFO - 2019-07-21 17:58:31 --> Language Class Initialized
INFO - 2019-07-21 17:58:31 --> Loader Class Initialized
INFO - 2019-07-21 17:58:31 --> Database Driver Class Initialized
INFO - 2019-07-21 17:58:31 --> Controller Class Initialized
INFO - 2019-07-21 17:58:31 --> Model "Product" initialized
INFO - 2019-07-21 17:58:31 --> Final output sent to browser
DEBUG - 2019-07-21 17:58:31 --> Total execution time: 0.0200
INFO - 2019-07-21 17:58:33 --> Config Class Initialized
INFO - 2019-07-21 17:58:33 --> Hooks Class Initialized
DEBUG - 2019-07-21 17:58:33 --> UTF-8 Support Enabled
INFO - 2019-07-21 17:58:33 --> Utf8 Class Initialized
INFO - 2019-07-21 17:58:33 --> URI Class Initialized
INFO - 2019-07-21 17:58:33 --> Router Class Initialized
INFO - 2019-07-21 17:58:33 --> Output Class Initialized
INFO - 2019-07-21 17:58:33 --> Security Class Initialized
DEBUG - 2019-07-21 17:58:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 17:58:33 --> Input Class Initialized
INFO - 2019-07-21 17:58:33 --> Language Class Initialized
INFO - 2019-07-21 17:58:33 --> Loader Class Initialized
INFO - 2019-07-21 17:58:33 --> Database Driver Class Initialized
INFO - 2019-07-21 17:58:33 --> Controller Class Initialized
INFO - 2019-07-21 17:58:33 --> Model "Product" initialized
INFO - 2019-07-21 17:58:33 --> Final output sent to browser
DEBUG - 2019-07-21 17:58:33 --> Total execution time: 0.0498
INFO - 2019-07-21 17:58:48 --> Config Class Initialized
INFO - 2019-07-21 17:58:48 --> Hooks Class Initialized
DEBUG - 2019-07-21 17:58:48 --> UTF-8 Support Enabled
INFO - 2019-07-21 17:58:48 --> Utf8 Class Initialized
INFO - 2019-07-21 17:58:48 --> URI Class Initialized
INFO - 2019-07-21 17:58:48 --> Router Class Initialized
INFO - 2019-07-21 17:58:48 --> Output Class Initialized
INFO - 2019-07-21 17:58:48 --> Security Class Initialized
DEBUG - 2019-07-21 17:58:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 17:58:48 --> Input Class Initialized
INFO - 2019-07-21 17:58:48 --> Language Class Initialized
INFO - 2019-07-21 17:58:48 --> Config Class Initialized
INFO - 2019-07-21 17:58:48 --> Hooks Class Initialized
DEBUG - 2019-07-21 17:58:48 --> UTF-8 Support Enabled
INFO - 2019-07-21 17:58:48 --> Utf8 Class Initialized
INFO - 2019-07-21 17:58:48 --> URI Class Initialized
INFO - 2019-07-21 17:58:48 --> Router Class Initialized
INFO - 2019-07-21 17:58:48 --> Output Class Initialized
INFO - 2019-07-21 17:58:48 --> Security Class Initialized
DEBUG - 2019-07-21 17:58:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 17:58:48 --> Input Class Initialized
INFO - 2019-07-21 17:58:48 --> Language Class Initialized
INFO - 2019-07-21 17:58:48 --> Loader Class Initialized
INFO - 2019-07-21 17:58:48 --> Loader Class Initialized
INFO - 2019-07-21 17:58:48 --> Database Driver Class Initialized
INFO - 2019-07-21 17:58:48 --> Controller Class Initialized
INFO - 2019-07-21 17:58:48 --> Model "Product" initialized
INFO - 2019-07-21 17:58:48 --> Final output sent to browser
DEBUG - 2019-07-21 17:58:48 --> Total execution time: 0.0581
INFO - 2019-07-21 17:58:48 --> Database Driver Class Initialized
INFO - 2019-07-21 17:58:48 --> Controller Class Initialized
INFO - 2019-07-21 17:58:48 --> Model "Product" initialized
INFO - 2019-07-21 17:58:48 --> Final output sent to browser
DEBUG - 2019-07-21 17:58:48 --> Total execution time: 0.0559
INFO - 2019-07-21 17:58:59 --> Config Class Initialized
INFO - 2019-07-21 17:58:59 --> Hooks Class Initialized
DEBUG - 2019-07-21 17:58:59 --> UTF-8 Support Enabled
INFO - 2019-07-21 17:58:59 --> Utf8 Class Initialized
INFO - 2019-07-21 17:58:59 --> URI Class Initialized
INFO - 2019-07-21 17:58:59 --> Router Class Initialized
INFO - 2019-07-21 17:58:59 --> Output Class Initialized
INFO - 2019-07-21 17:58:59 --> Security Class Initialized
DEBUG - 2019-07-21 17:58:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 17:58:59 --> Input Class Initialized
INFO - 2019-07-21 17:58:59 --> Language Class Initialized
INFO - 2019-07-21 17:58:59 --> Loader Class Initialized
INFO - 2019-07-21 17:58:59 --> Config Class Initialized
INFO - 2019-07-21 17:58:59 --> Hooks Class Initialized
DEBUG - 2019-07-21 17:58:59 --> UTF-8 Support Enabled
INFO - 2019-07-21 17:58:59 --> Utf8 Class Initialized
INFO - 2019-07-21 17:58:59 --> URI Class Initialized
INFO - 2019-07-21 17:58:59 --> Router Class Initialized
INFO - 2019-07-21 17:58:59 --> Output Class Initialized
INFO - 2019-07-21 17:58:59 --> Security Class Initialized
INFO - 2019-07-21 17:58:59 --> Database Driver Class Initialized
INFO - 2019-07-21 17:58:59 --> Controller Class Initialized
INFO - 2019-07-21 17:58:59 --> Model "Product" initialized
DEBUG - 2019-07-21 17:58:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 17:58:59 --> Input Class Initialized
INFO - 2019-07-21 17:58:59 --> Language Class Initialized
INFO - 2019-07-21 17:58:59 --> Final output sent to browser
DEBUG - 2019-07-21 17:58:59 --> Total execution time: 0.0387
INFO - 2019-07-21 17:58:59 --> Loader Class Initialized
INFO - 2019-07-21 17:58:59 --> Database Driver Class Initialized
INFO - 2019-07-21 17:58:59 --> Controller Class Initialized
INFO - 2019-07-21 17:58:59 --> Model "Product" initialized
INFO - 2019-07-21 17:58:59 --> Final output sent to browser
DEBUG - 2019-07-21 17:58:59 --> Total execution time: 0.0254
INFO - 2019-07-21 17:59:14 --> Config Class Initialized
INFO - 2019-07-21 17:59:14 --> Hooks Class Initialized
DEBUG - 2019-07-21 17:59:14 --> UTF-8 Support Enabled
INFO - 2019-07-21 17:59:14 --> Utf8 Class Initialized
INFO - 2019-07-21 17:59:14 --> Config Class Initialized
INFO - 2019-07-21 17:59:14 --> Hooks Class Initialized
DEBUG - 2019-07-21 17:59:14 --> UTF-8 Support Enabled
INFO - 2019-07-21 17:59:14 --> Utf8 Class Initialized
INFO - 2019-07-21 17:59:14 --> URI Class Initialized
INFO - 2019-07-21 17:59:14 --> Router Class Initialized
INFO - 2019-07-21 17:59:14 --> Output Class Initialized
INFO - 2019-07-21 17:59:14 --> Security Class Initialized
DEBUG - 2019-07-21 17:59:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 17:59:14 --> Input Class Initialized
INFO - 2019-07-21 17:59:14 --> Language Class Initialized
INFO - 2019-07-21 17:59:14 --> URI Class Initialized
INFO - 2019-07-21 17:59:14 --> Router Class Initialized
INFO - 2019-07-21 17:59:14 --> Output Class Initialized
INFO - 2019-07-21 17:59:14 --> Security Class Initialized
DEBUG - 2019-07-21 17:59:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 17:59:14 --> Input Class Initialized
INFO - 2019-07-21 17:59:14 --> Language Class Initialized
INFO - 2019-07-21 17:59:14 --> Loader Class Initialized
INFO - 2019-07-21 17:59:14 --> Loader Class Initialized
INFO - 2019-07-21 17:59:14 --> Database Driver Class Initialized
INFO - 2019-07-21 17:59:14 --> Database Driver Class Initialized
INFO - 2019-07-21 17:59:14 --> Controller Class Initialized
INFO - 2019-07-21 17:59:14 --> Model "Product" initialized
INFO - 2019-07-21 17:59:14 --> Final output sent to browser
DEBUG - 2019-07-21 17:59:14 --> Total execution time: 0.0616
INFO - 2019-07-21 17:59:14 --> Controller Class Initialized
INFO - 2019-07-21 17:59:14 --> Model "Product" initialized
INFO - 2019-07-21 17:59:14 --> Final output sent to browser
DEBUG - 2019-07-21 17:59:14 --> Total execution time: 0.0806
INFO - 2019-07-21 18:01:07 --> Config Class Initialized
INFO - 2019-07-21 18:01:07 --> Hooks Class Initialized
DEBUG - 2019-07-21 18:01:07 --> UTF-8 Support Enabled
INFO - 2019-07-21 18:01:07 --> Utf8 Class Initialized
INFO - 2019-07-21 18:01:07 --> URI Class Initialized
INFO - 2019-07-21 18:01:07 --> Router Class Initialized
INFO - 2019-07-21 18:01:07 --> Output Class Initialized
INFO - 2019-07-21 18:01:07 --> Security Class Initialized
DEBUG - 2019-07-21 18:01:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 18:01:07 --> Input Class Initialized
INFO - 2019-07-21 18:01:07 --> Language Class Initialized
INFO - 2019-07-21 18:01:07 --> Loader Class Initialized
INFO - 2019-07-21 18:01:07 --> Config Class Initialized
INFO - 2019-07-21 18:01:07 --> Hooks Class Initialized
DEBUG - 2019-07-21 18:01:07 --> UTF-8 Support Enabled
INFO - 2019-07-21 18:01:07 --> Utf8 Class Initialized
INFO - 2019-07-21 18:01:07 --> URI Class Initialized
INFO - 2019-07-21 18:01:07 --> Router Class Initialized
INFO - 2019-07-21 18:01:07 --> Database Driver Class Initialized
INFO - 2019-07-21 18:01:07 --> Controller Class Initialized
INFO - 2019-07-21 18:01:07 --> Model "Product" initialized
INFO - 2019-07-21 18:01:07 --> Output Class Initialized
INFO - 2019-07-21 18:01:07 --> Final output sent to browser
DEBUG - 2019-07-21 18:01:07 --> Total execution time: 0.0408
INFO - 2019-07-21 18:01:07 --> Security Class Initialized
DEBUG - 2019-07-21 18:01:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 18:01:07 --> Input Class Initialized
INFO - 2019-07-21 18:01:07 --> Language Class Initialized
INFO - 2019-07-21 18:01:07 --> Loader Class Initialized
INFO - 2019-07-21 18:01:07 --> Database Driver Class Initialized
INFO - 2019-07-21 18:01:07 --> Controller Class Initialized
INFO - 2019-07-21 18:01:07 --> Model "Product" initialized
INFO - 2019-07-21 18:01:07 --> Final output sent to browser
DEBUG - 2019-07-21 18:01:07 --> Total execution time: 0.0365
INFO - 2019-07-21 18:02:13 --> Config Class Initialized
INFO - 2019-07-21 18:02:13 --> Hooks Class Initialized
DEBUG - 2019-07-21 18:02:13 --> UTF-8 Support Enabled
INFO - 2019-07-21 18:02:13 --> Utf8 Class Initialized
INFO - 2019-07-21 18:02:13 --> URI Class Initialized
INFO - 2019-07-21 18:02:13 --> Router Class Initialized
INFO - 2019-07-21 18:02:13 --> Config Class Initialized
INFO - 2019-07-21 18:02:13 --> Hooks Class Initialized
INFO - 2019-07-21 18:02:13 --> Output Class Initialized
DEBUG - 2019-07-21 18:02:13 --> UTF-8 Support Enabled
INFO - 2019-07-21 18:02:13 --> Utf8 Class Initialized
INFO - 2019-07-21 18:02:13 --> URI Class Initialized
INFO - 2019-07-21 18:02:13 --> Security Class Initialized
INFO - 2019-07-21 18:02:13 --> Router Class Initialized
DEBUG - 2019-07-21 18:02:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 18:02:13 --> Input Class Initialized
INFO - 2019-07-21 18:02:13 --> Language Class Initialized
INFO - 2019-07-21 18:02:13 --> Output Class Initialized
INFO - 2019-07-21 18:02:13 --> Security Class Initialized
INFO - 2019-07-21 18:02:13 --> Loader Class Initialized
DEBUG - 2019-07-21 18:02:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 18:02:13 --> Input Class Initialized
INFO - 2019-07-21 18:02:13 --> Language Class Initialized
INFO - 2019-07-21 18:02:13 --> Loader Class Initialized
INFO - 2019-07-21 18:02:13 --> Database Driver Class Initialized
INFO - 2019-07-21 18:02:13 --> Controller Class Initialized
INFO - 2019-07-21 18:02:13 --> Model "Product" initialized
INFO - 2019-07-21 18:02:13 --> Database Driver Class Initialized
INFO - 2019-07-21 18:02:13 --> Controller Class Initialized
INFO - 2019-07-21 18:02:13 --> Model "Product" initialized
INFO - 2019-07-21 18:02:13 --> Final output sent to browser
DEBUG - 2019-07-21 18:02:13 --> Total execution time: 0.0456
INFO - 2019-07-21 18:02:13 --> Final output sent to browser
DEBUG - 2019-07-21 18:02:13 --> Total execution time: 0.0896
INFO - 2019-07-21 18:03:10 --> Config Class Initialized
INFO - 2019-07-21 18:03:10 --> Hooks Class Initialized
DEBUG - 2019-07-21 18:03:10 --> UTF-8 Support Enabled
INFO - 2019-07-21 18:03:10 --> Utf8 Class Initialized
INFO - 2019-07-21 18:03:10 --> URI Class Initialized
INFO - 2019-07-21 18:03:10 --> Router Class Initialized
INFO - 2019-07-21 18:03:10 --> Output Class Initialized
INFO - 2019-07-21 18:03:10 --> Security Class Initialized
DEBUG - 2019-07-21 18:03:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 18:03:10 --> Input Class Initialized
INFO - 2019-07-21 18:03:10 --> Language Class Initialized
INFO - 2019-07-21 18:03:10 --> Loader Class Initialized
INFO - 2019-07-21 18:03:10 --> Config Class Initialized
INFO - 2019-07-21 18:03:10 --> Hooks Class Initialized
INFO - 2019-07-21 18:03:10 --> Database Driver Class Initialized
DEBUG - 2019-07-21 18:03:10 --> UTF-8 Support Enabled
INFO - 2019-07-21 18:03:10 --> Utf8 Class Initialized
INFO - 2019-07-21 18:03:10 --> Controller Class Initialized
INFO - 2019-07-21 18:03:10 --> Model "Product" initialized
INFO - 2019-07-21 18:03:10 --> URI Class Initialized
INFO - 2019-07-21 18:03:10 --> Final output sent to browser
DEBUG - 2019-07-21 18:03:10 --> Total execution time: 0.0244
INFO - 2019-07-21 18:03:10 --> Router Class Initialized
INFO - 2019-07-21 18:03:10 --> Output Class Initialized
INFO - 2019-07-21 18:03:10 --> Security Class Initialized
DEBUG - 2019-07-21 18:03:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 18:03:10 --> Input Class Initialized
INFO - 2019-07-21 18:03:10 --> Language Class Initialized
INFO - 2019-07-21 18:03:10 --> Loader Class Initialized
INFO - 2019-07-21 18:03:10 --> Database Driver Class Initialized
INFO - 2019-07-21 18:03:10 --> Controller Class Initialized
INFO - 2019-07-21 18:03:10 --> Model "Product" initialized
INFO - 2019-07-21 18:03:10 --> Final output sent to browser
DEBUG - 2019-07-21 18:03:10 --> Total execution time: 0.0357
INFO - 2019-07-21 18:03:17 --> Config Class Initialized
INFO - 2019-07-21 18:03:17 --> Hooks Class Initialized
DEBUG - 2019-07-21 18:03:17 --> UTF-8 Support Enabled
INFO - 2019-07-21 18:03:17 --> Utf8 Class Initialized
INFO - 2019-07-21 18:03:17 --> URI Class Initialized
INFO - 2019-07-21 18:03:17 --> Router Class Initialized
INFO - 2019-07-21 18:03:17 --> Output Class Initialized
INFO - 2019-07-21 18:03:17 --> Security Class Initialized
DEBUG - 2019-07-21 18:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 18:03:17 --> Input Class Initialized
INFO - 2019-07-21 18:03:17 --> Language Class Initialized
INFO - 2019-07-21 18:03:17 --> Loader Class Initialized
INFO - 2019-07-21 18:03:17 --> Database Driver Class Initialized
INFO - 2019-07-21 18:03:17 --> Controller Class Initialized
INFO - 2019-07-21 18:03:17 --> Model "Product" initialized
INFO - 2019-07-21 18:03:17 --> Final output sent to browser
DEBUG - 2019-07-21 18:03:17 --> Total execution time: 0.0172
INFO - 2019-07-21 18:03:20 --> Config Class Initialized
INFO - 2019-07-21 18:03:20 --> Hooks Class Initialized
DEBUG - 2019-07-21 18:03:20 --> UTF-8 Support Enabled
INFO - 2019-07-21 18:03:20 --> Utf8 Class Initialized
INFO - 2019-07-21 18:03:20 --> URI Class Initialized
INFO - 2019-07-21 18:03:20 --> Router Class Initialized
INFO - 2019-07-21 18:03:20 --> Output Class Initialized
INFO - 2019-07-21 18:03:20 --> Security Class Initialized
DEBUG - 2019-07-21 18:03:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 18:03:20 --> Input Class Initialized
INFO - 2019-07-21 18:03:20 --> Language Class Initialized
INFO - 2019-07-21 18:03:20 --> Loader Class Initialized
INFO - 2019-07-21 18:03:20 --> Database Driver Class Initialized
INFO - 2019-07-21 18:03:20 --> Controller Class Initialized
INFO - 2019-07-21 18:03:20 --> Model "Product" initialized
INFO - 2019-07-21 18:03:20 --> Final output sent to browser
DEBUG - 2019-07-21 18:03:20 --> Total execution time: 0.0227
INFO - 2019-07-21 18:03:21 --> Config Class Initialized
INFO - 2019-07-21 18:03:21 --> Hooks Class Initialized
DEBUG - 2019-07-21 18:03:21 --> UTF-8 Support Enabled
INFO - 2019-07-21 18:03:21 --> Utf8 Class Initialized
INFO - 2019-07-21 18:03:21 --> URI Class Initialized
INFO - 2019-07-21 18:03:21 --> Router Class Initialized
INFO - 2019-07-21 18:03:21 --> Output Class Initialized
INFO - 2019-07-21 18:03:21 --> Security Class Initialized
DEBUG - 2019-07-21 18:03:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 18:03:21 --> Input Class Initialized
INFO - 2019-07-21 18:03:21 --> Language Class Initialized
INFO - 2019-07-21 18:03:21 --> Loader Class Initialized
INFO - 2019-07-21 18:03:21 --> Database Driver Class Initialized
INFO - 2019-07-21 18:03:21 --> Controller Class Initialized
INFO - 2019-07-21 18:03:21 --> Model "Product" initialized
INFO - 2019-07-21 18:03:21 --> Final output sent to browser
DEBUG - 2019-07-21 18:03:21 --> Total execution time: 0.0184
INFO - 2019-07-21 18:03:23 --> Config Class Initialized
INFO - 2019-07-21 18:03:23 --> Hooks Class Initialized
DEBUG - 2019-07-21 18:03:23 --> UTF-8 Support Enabled
INFO - 2019-07-21 18:03:23 --> Utf8 Class Initialized
INFO - 2019-07-21 18:03:23 --> URI Class Initialized
INFO - 2019-07-21 18:03:23 --> Router Class Initialized
INFO - 2019-07-21 18:03:23 --> Output Class Initialized
INFO - 2019-07-21 18:03:23 --> Security Class Initialized
DEBUG - 2019-07-21 18:03:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 18:03:23 --> Input Class Initialized
INFO - 2019-07-21 18:03:23 --> Language Class Initialized
INFO - 2019-07-21 18:03:23 --> Loader Class Initialized
INFO - 2019-07-21 18:03:23 --> Database Driver Class Initialized
INFO - 2019-07-21 18:03:23 --> Controller Class Initialized
INFO - 2019-07-21 18:03:23 --> Model "Product" initialized
INFO - 2019-07-21 18:03:23 --> Final output sent to browser
DEBUG - 2019-07-21 18:03:23 --> Total execution time: 0.0274
INFO - 2019-07-21 18:05:19 --> Config Class Initialized
INFO - 2019-07-21 18:05:19 --> Hooks Class Initialized
DEBUG - 2019-07-21 18:05:19 --> UTF-8 Support Enabled
INFO - 2019-07-21 18:05:19 --> Utf8 Class Initialized
INFO - 2019-07-21 18:05:19 --> URI Class Initialized
INFO - 2019-07-21 18:05:19 --> Router Class Initialized
INFO - 2019-07-21 18:05:19 --> Output Class Initialized
INFO - 2019-07-21 18:05:19 --> Security Class Initialized
INFO - 2019-07-21 18:05:19 --> Config Class Initialized
INFO - 2019-07-21 18:05:19 --> Hooks Class Initialized
DEBUG - 2019-07-21 18:05:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 18:05:19 --> Input Class Initialized
INFO - 2019-07-21 18:05:19 --> Language Class Initialized
DEBUG - 2019-07-21 18:05:19 --> UTF-8 Support Enabled
INFO - 2019-07-21 18:05:19 --> Utf8 Class Initialized
INFO - 2019-07-21 18:05:19 --> URI Class Initialized
INFO - 2019-07-21 18:05:19 --> Loader Class Initialized
INFO - 2019-07-21 18:05:19 --> Router Class Initialized
INFO - 2019-07-21 18:05:19 --> Output Class Initialized
INFO - 2019-07-21 18:05:19 --> Security Class Initialized
DEBUG - 2019-07-21 18:05:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 18:05:19 --> Input Class Initialized
INFO - 2019-07-21 18:05:19 --> Language Class Initialized
INFO - 2019-07-21 18:05:19 --> Database Driver Class Initialized
INFO - 2019-07-21 18:05:19 --> Loader Class Initialized
INFO - 2019-07-21 18:05:19 --> Controller Class Initialized
INFO - 2019-07-21 18:05:19 --> Model "Product" initialized
INFO - 2019-07-21 18:05:19 --> Final output sent to browser
DEBUG - 2019-07-21 18:05:19 --> Total execution time: 0.0320
INFO - 2019-07-21 18:05:19 --> Database Driver Class Initialized
INFO - 2019-07-21 18:05:19 --> Controller Class Initialized
INFO - 2019-07-21 18:05:19 --> Model "Product" initialized
INFO - 2019-07-21 18:05:19 --> Final output sent to browser
DEBUG - 2019-07-21 18:05:19 --> Total execution time: 0.0311
INFO - 2019-07-21 18:05:23 --> Config Class Initialized
INFO - 2019-07-21 18:05:23 --> Hooks Class Initialized
DEBUG - 2019-07-21 18:05:23 --> UTF-8 Support Enabled
INFO - 2019-07-21 18:05:23 --> Utf8 Class Initialized
INFO - 2019-07-21 18:05:23 --> URI Class Initialized
INFO - 2019-07-21 18:05:23 --> Router Class Initialized
INFO - 2019-07-21 18:05:23 --> Output Class Initialized
INFO - 2019-07-21 18:05:23 --> Security Class Initialized
DEBUG - 2019-07-21 18:05:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 18:05:23 --> Input Class Initialized
INFO - 2019-07-21 18:05:23 --> Language Class Initialized
INFO - 2019-07-21 18:05:23 --> Loader Class Initialized
INFO - 2019-07-21 18:05:23 --> Database Driver Class Initialized
INFO - 2019-07-21 18:05:23 --> Controller Class Initialized
INFO - 2019-07-21 18:05:23 --> Model "Product" initialized
INFO - 2019-07-21 18:05:23 --> Final output sent to browser
DEBUG - 2019-07-21 18:05:23 --> Total execution time: 0.0173
INFO - 2019-07-21 18:05:25 --> Config Class Initialized
INFO - 2019-07-21 18:05:25 --> Hooks Class Initialized
DEBUG - 2019-07-21 18:05:25 --> UTF-8 Support Enabled
INFO - 2019-07-21 18:05:25 --> Utf8 Class Initialized
INFO - 2019-07-21 18:05:25 --> URI Class Initialized
INFO - 2019-07-21 18:05:25 --> Router Class Initialized
INFO - 2019-07-21 18:05:25 --> Output Class Initialized
INFO - 2019-07-21 18:05:25 --> Security Class Initialized
DEBUG - 2019-07-21 18:05:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 18:05:25 --> Input Class Initialized
INFO - 2019-07-21 18:05:25 --> Language Class Initialized
INFO - 2019-07-21 18:05:25 --> Loader Class Initialized
INFO - 2019-07-21 18:05:25 --> Database Driver Class Initialized
INFO - 2019-07-21 18:05:25 --> Controller Class Initialized
INFO - 2019-07-21 18:05:25 --> Model "Product" initialized
INFO - 2019-07-21 18:05:25 --> Final output sent to browser
DEBUG - 2019-07-21 18:05:25 --> Total execution time: 0.0204
INFO - 2019-07-21 18:05:29 --> Config Class Initialized
INFO - 2019-07-21 18:05:29 --> Hooks Class Initialized
DEBUG - 2019-07-21 18:05:29 --> UTF-8 Support Enabled
INFO - 2019-07-21 18:05:29 --> Utf8 Class Initialized
INFO - 2019-07-21 18:05:29 --> URI Class Initialized
INFO - 2019-07-21 18:05:29 --> Router Class Initialized
INFO - 2019-07-21 18:05:29 --> Config Class Initialized
INFO - 2019-07-21 18:05:29 --> Hooks Class Initialized
INFO - 2019-07-21 18:05:29 --> Output Class Initialized
DEBUG - 2019-07-21 18:05:29 --> UTF-8 Support Enabled
INFO - 2019-07-21 18:05:29 --> Utf8 Class Initialized
INFO - 2019-07-21 18:05:29 --> Security Class Initialized
INFO - 2019-07-21 18:05:29 --> URI Class Initialized
DEBUG - 2019-07-21 18:05:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 18:05:29 --> Input Class Initialized
INFO - 2019-07-21 18:05:29 --> Language Class Initialized
INFO - 2019-07-21 18:05:29 --> Router Class Initialized
INFO - 2019-07-21 18:05:29 --> Output Class Initialized
INFO - 2019-07-21 18:05:29 --> Loader Class Initialized
INFO - 2019-07-21 18:05:29 --> Security Class Initialized
DEBUG - 2019-07-21 18:05:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 18:05:29 --> Input Class Initialized
INFO - 2019-07-21 18:05:29 --> Language Class Initialized
INFO - 2019-07-21 18:05:29 --> Loader Class Initialized
INFO - 2019-07-21 18:05:29 --> Database Driver Class Initialized
INFO - 2019-07-21 18:05:29 --> Controller Class Initialized
INFO - 2019-07-21 18:05:29 --> Model "Product" initialized
INFO - 2019-07-21 18:05:29 --> Database Driver Class Initialized
INFO - 2019-07-21 18:05:29 --> Final output sent to browser
DEBUG - 2019-07-21 18:05:29 --> Total execution time: 0.0306
INFO - 2019-07-21 18:05:29 --> Controller Class Initialized
INFO - 2019-07-21 18:05:29 --> Model "Product" initialized
INFO - 2019-07-21 18:05:29 --> Final output sent to browser
DEBUG - 2019-07-21 18:05:29 --> Total execution time: 0.0324
INFO - 2019-07-21 18:05:31 --> Config Class Initialized
INFO - 2019-07-21 18:05:31 --> Hooks Class Initialized
DEBUG - 2019-07-21 18:05:31 --> UTF-8 Support Enabled
INFO - 2019-07-21 18:05:31 --> Utf8 Class Initialized
INFO - 2019-07-21 18:05:31 --> URI Class Initialized
INFO - 2019-07-21 18:05:31 --> Router Class Initialized
INFO - 2019-07-21 18:05:31 --> Output Class Initialized
INFO - 2019-07-21 18:05:31 --> Security Class Initialized
DEBUG - 2019-07-21 18:05:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 18:05:31 --> Input Class Initialized
INFO - 2019-07-21 18:05:31 --> Language Class Initialized
INFO - 2019-07-21 18:05:31 --> Loader Class Initialized
INFO - 2019-07-21 18:05:31 --> Database Driver Class Initialized
INFO - 2019-07-21 18:05:31 --> Controller Class Initialized
INFO - 2019-07-21 18:05:31 --> Model "Product" initialized
INFO - 2019-07-21 18:05:31 --> Final output sent to browser
DEBUG - 2019-07-21 18:05:31 --> Total execution time: 0.0177
INFO - 2019-07-21 18:05:33 --> Config Class Initialized
INFO - 2019-07-21 18:05:33 --> Hooks Class Initialized
DEBUG - 2019-07-21 18:05:33 --> UTF-8 Support Enabled
INFO - 2019-07-21 18:05:33 --> Utf8 Class Initialized
INFO - 2019-07-21 18:05:33 --> URI Class Initialized
INFO - 2019-07-21 18:05:33 --> Router Class Initialized
INFO - 2019-07-21 18:05:33 --> Output Class Initialized
INFO - 2019-07-21 18:05:33 --> Security Class Initialized
DEBUG - 2019-07-21 18:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 18:05:33 --> Input Class Initialized
INFO - 2019-07-21 18:05:33 --> Language Class Initialized
INFO - 2019-07-21 18:05:33 --> Loader Class Initialized
INFO - 2019-07-21 18:05:33 --> Database Driver Class Initialized
INFO - 2019-07-21 18:05:33 --> Controller Class Initialized
INFO - 2019-07-21 18:05:33 --> Model "Product" initialized
INFO - 2019-07-21 18:05:33 --> Final output sent to browser
DEBUG - 2019-07-21 18:05:33 --> Total execution time: 0.0176
INFO - 2019-07-21 18:05:46 --> Config Class Initialized
INFO - 2019-07-21 18:05:46 --> Hooks Class Initialized
DEBUG - 2019-07-21 18:05:46 --> UTF-8 Support Enabled
INFO - 2019-07-21 18:05:46 --> Utf8 Class Initialized
INFO - 2019-07-21 18:05:46 --> URI Class Initialized
INFO - 2019-07-21 18:05:46 --> Router Class Initialized
INFO - 2019-07-21 18:05:46 --> Config Class Initialized
INFO - 2019-07-21 18:05:46 --> Hooks Class Initialized
INFO - 2019-07-21 18:05:46 --> Output Class Initialized
INFO - 2019-07-21 18:05:46 --> Security Class Initialized
DEBUG - 2019-07-21 18:05:46 --> UTF-8 Support Enabled
INFO - 2019-07-21 18:05:46 --> Utf8 Class Initialized
INFO - 2019-07-21 18:05:46 --> URI Class Initialized
INFO - 2019-07-21 18:05:46 --> Router Class Initialized
INFO - 2019-07-21 18:05:46 --> Output Class Initialized
INFO - 2019-07-21 18:05:46 --> Security Class Initialized
DEBUG - 2019-07-21 18:05:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 18:05:46 --> Input Class Initialized
INFO - 2019-07-21 18:05:46 --> Language Class Initialized
INFO - 2019-07-21 18:05:46 --> Loader Class Initialized
DEBUG - 2019-07-21 18:05:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 18:05:46 --> Input Class Initialized
INFO - 2019-07-21 18:05:46 --> Language Class Initialized
INFO - 2019-07-21 18:05:46 --> Loader Class Initialized
INFO - 2019-07-21 18:05:46 --> Database Driver Class Initialized
INFO - 2019-07-21 18:05:46 --> Database Driver Class Initialized
INFO - 2019-07-21 18:05:46 --> Controller Class Initialized
INFO - 2019-07-21 18:05:46 --> Model "Product" initialized
INFO - 2019-07-21 18:05:46 --> Controller Class Initialized
INFO - 2019-07-21 18:05:46 --> Model "Product" initialized
INFO - 2019-07-21 18:05:46 --> Final output sent to browser
DEBUG - 2019-07-21 18:05:46 --> Total execution time: 0.0586
INFO - 2019-07-21 18:05:46 --> Final output sent to browser
DEBUG - 2019-07-21 18:05:46 --> Total execution time: 0.0562
INFO - 2019-07-21 18:05:53 --> Config Class Initialized
INFO - 2019-07-21 18:05:53 --> Hooks Class Initialized
DEBUG - 2019-07-21 18:05:53 --> UTF-8 Support Enabled
INFO - 2019-07-21 18:05:53 --> Utf8 Class Initialized
INFO - 2019-07-21 18:05:53 --> URI Class Initialized
INFO - 2019-07-21 18:05:53 --> Router Class Initialized
INFO - 2019-07-21 18:05:53 --> Output Class Initialized
INFO - 2019-07-21 18:05:53 --> Security Class Initialized
DEBUG - 2019-07-21 18:05:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 18:05:53 --> Input Class Initialized
INFO - 2019-07-21 18:05:53 --> Language Class Initialized
INFO - 2019-07-21 18:05:53 --> Loader Class Initialized
INFO - 2019-07-21 18:05:53 --> Database Driver Class Initialized
INFO - 2019-07-21 18:05:53 --> Config Class Initialized
INFO - 2019-07-21 18:05:53 --> Hooks Class Initialized
DEBUG - 2019-07-21 18:05:53 --> UTF-8 Support Enabled
INFO - 2019-07-21 18:05:53 --> Utf8 Class Initialized
INFO - 2019-07-21 18:05:53 --> URI Class Initialized
INFO - 2019-07-21 18:05:53 --> Router Class Initialized
INFO - 2019-07-21 18:05:53 --> Output Class Initialized
INFO - 2019-07-21 18:05:53 --> Controller Class Initialized
INFO - 2019-07-21 18:05:53 --> Model "Product" initialized
INFO - 2019-07-21 18:05:53 --> Security Class Initialized
INFO - 2019-07-21 18:05:53 --> Final output sent to browser
DEBUG - 2019-07-21 18:05:53 --> Total execution time: 0.0457
DEBUG - 2019-07-21 18:05:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 18:05:53 --> Input Class Initialized
INFO - 2019-07-21 18:05:53 --> Language Class Initialized
INFO - 2019-07-21 18:05:53 --> Loader Class Initialized
INFO - 2019-07-21 18:05:53 --> Database Driver Class Initialized
INFO - 2019-07-21 18:05:53 --> Controller Class Initialized
INFO - 2019-07-21 18:05:53 --> Model "Product" initialized
INFO - 2019-07-21 18:05:53 --> Final output sent to browser
DEBUG - 2019-07-21 18:05:53 --> Total execution time: 0.0312
INFO - 2019-07-21 18:07:03 --> Config Class Initialized
INFO - 2019-07-21 18:07:03 --> Hooks Class Initialized
DEBUG - 2019-07-21 18:07:03 --> UTF-8 Support Enabled
INFO - 2019-07-21 18:07:03 --> Utf8 Class Initialized
INFO - 2019-07-21 18:07:03 --> URI Class Initialized
INFO - 2019-07-21 18:07:03 --> Router Class Initialized
INFO - 2019-07-21 18:07:03 --> Output Class Initialized
INFO - 2019-07-21 18:07:03 --> Config Class Initialized
INFO - 2019-07-21 18:07:03 --> Hooks Class Initialized
INFO - 2019-07-21 18:07:03 --> Security Class Initialized
DEBUG - 2019-07-21 18:07:03 --> UTF-8 Support Enabled
INFO - 2019-07-21 18:07:03 --> Utf8 Class Initialized
DEBUG - 2019-07-21 18:07:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 18:07:03 --> Input Class Initialized
INFO - 2019-07-21 18:07:03 --> URI Class Initialized
INFO - 2019-07-21 18:07:03 --> Language Class Initialized
INFO - 2019-07-21 18:07:03 --> Loader Class Initialized
INFO - 2019-07-21 18:07:03 --> Router Class Initialized
INFO - 2019-07-21 18:07:03 --> Output Class Initialized
INFO - 2019-07-21 18:07:04 --> Security Class Initialized
DEBUG - 2019-07-21 18:07:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 18:07:04 --> Input Class Initialized
INFO - 2019-07-21 18:07:04 --> Language Class Initialized
INFO - 2019-07-21 18:07:04 --> Loader Class Initialized
INFO - 2019-07-21 18:07:04 --> Database Driver Class Initialized
INFO - 2019-07-21 18:07:04 --> Controller Class Initialized
INFO - 2019-07-21 18:07:04 --> Model "Product" initialized
INFO - 2019-07-21 18:07:04 --> Final output sent to browser
DEBUG - 2019-07-21 18:07:04 --> Total execution time: 0.0365
INFO - 2019-07-21 18:07:04 --> Database Driver Class Initialized
INFO - 2019-07-21 18:07:04 --> Controller Class Initialized
INFO - 2019-07-21 18:07:04 --> Model "Product" initialized
INFO - 2019-07-21 18:07:04 --> Final output sent to browser
DEBUG - 2019-07-21 18:07:04 --> Total execution time: 0.0326
INFO - 2019-07-21 18:07:09 --> Config Class Initialized
INFO - 2019-07-21 18:07:09 --> Hooks Class Initialized
DEBUG - 2019-07-21 18:07:09 --> UTF-8 Support Enabled
INFO - 2019-07-21 18:07:09 --> Utf8 Class Initialized
INFO - 2019-07-21 18:07:09 --> URI Class Initialized
INFO - 2019-07-21 18:07:09 --> Router Class Initialized
INFO - 2019-07-21 18:07:09 --> Output Class Initialized
INFO - 2019-07-21 18:07:09 --> Security Class Initialized
DEBUG - 2019-07-21 18:07:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 18:07:09 --> Input Class Initialized
INFO - 2019-07-21 18:07:09 --> Language Class Initialized
INFO - 2019-07-21 18:07:09 --> Loader Class Initialized
INFO - 2019-07-21 18:07:09 --> Database Driver Class Initialized
INFO - 2019-07-21 18:07:09 --> Controller Class Initialized
INFO - 2019-07-21 18:07:09 --> Model "Product" initialized
INFO - 2019-07-21 18:07:09 --> Final output sent to browser
DEBUG - 2019-07-21 18:07:09 --> Total execution time: 0.0191
INFO - 2019-07-21 18:07:12 --> Config Class Initialized
INFO - 2019-07-21 18:07:12 --> Hooks Class Initialized
DEBUG - 2019-07-21 18:07:12 --> UTF-8 Support Enabled
INFO - 2019-07-21 18:07:12 --> Utf8 Class Initialized
INFO - 2019-07-21 18:07:12 --> URI Class Initialized
INFO - 2019-07-21 18:07:12 --> Router Class Initialized
INFO - 2019-07-21 18:07:12 --> Output Class Initialized
INFO - 2019-07-21 18:07:12 --> Security Class Initialized
DEBUG - 2019-07-21 18:07:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 18:07:12 --> Input Class Initialized
INFO - 2019-07-21 18:07:12 --> Language Class Initialized
INFO - 2019-07-21 18:07:12 --> Loader Class Initialized
INFO - 2019-07-21 18:07:12 --> Database Driver Class Initialized
INFO - 2019-07-21 18:07:12 --> Controller Class Initialized
INFO - 2019-07-21 18:07:12 --> Model "Product" initialized
INFO - 2019-07-21 18:07:12 --> Final output sent to browser
DEBUG - 2019-07-21 18:07:12 --> Total execution time: 0.0215
INFO - 2019-07-21 18:07:36 --> Config Class Initialized
INFO - 2019-07-21 18:07:36 --> Hooks Class Initialized
DEBUG - 2019-07-21 18:07:36 --> UTF-8 Support Enabled
INFO - 2019-07-21 18:07:36 --> Utf8 Class Initialized
INFO - 2019-07-21 18:07:36 --> URI Class Initialized
INFO - 2019-07-21 18:07:36 --> Router Class Initialized
INFO - 2019-07-21 18:07:36 --> Output Class Initialized
INFO - 2019-07-21 18:07:36 --> Security Class Initialized
DEBUG - 2019-07-21 18:07:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 18:07:36 --> Input Class Initialized
INFO - 2019-07-21 18:07:36 --> Language Class Initialized
INFO - 2019-07-21 18:07:36 --> Config Class Initialized
INFO - 2019-07-21 18:07:36 --> Hooks Class Initialized
INFO - 2019-07-21 18:07:36 --> Loader Class Initialized
DEBUG - 2019-07-21 18:07:36 --> UTF-8 Support Enabled
INFO - 2019-07-21 18:07:36 --> Utf8 Class Initialized
INFO - 2019-07-21 18:07:36 --> URI Class Initialized
INFO - 2019-07-21 18:07:36 --> Router Class Initialized
INFO - 2019-07-21 18:07:36 --> Output Class Initialized
INFO - 2019-07-21 18:07:36 --> Database Driver Class Initialized
INFO - 2019-07-21 18:07:36 --> Controller Class Initialized
INFO - 2019-07-21 18:07:36 --> Model "Product" initialized
INFO - 2019-07-21 18:07:36 --> Security Class Initialized
DEBUG - 2019-07-21 18:07:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 18:07:36 --> Input Class Initialized
INFO - 2019-07-21 18:07:36 --> Language Class Initialized
INFO - 2019-07-21 18:07:36 --> Loader Class Initialized
INFO - 2019-07-21 18:07:36 --> Final output sent to browser
DEBUG - 2019-07-21 18:07:36 --> Total execution time: 0.0319
INFO - 2019-07-21 18:07:36 --> Database Driver Class Initialized
INFO - 2019-07-21 18:07:36 --> Controller Class Initialized
INFO - 2019-07-21 18:07:36 --> Model "Product" initialized
INFO - 2019-07-21 18:07:36 --> Final output sent to browser
DEBUG - 2019-07-21 18:07:36 --> Total execution time: 0.0325
INFO - 2019-07-21 18:08:57 --> Config Class Initialized
INFO - 2019-07-21 18:08:57 --> Hooks Class Initialized
DEBUG - 2019-07-21 18:08:57 --> UTF-8 Support Enabled
INFO - 2019-07-21 18:08:57 --> Utf8 Class Initialized
INFO - 2019-07-21 18:08:57 --> URI Class Initialized
INFO - 2019-07-21 18:08:57 --> Router Class Initialized
INFO - 2019-07-21 18:08:57 --> Output Class Initialized
INFO - 2019-07-21 18:08:57 --> Config Class Initialized
INFO - 2019-07-21 18:08:57 --> Hooks Class Initialized
INFO - 2019-07-21 18:08:57 --> Security Class Initialized
DEBUG - 2019-07-21 18:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 18:08:57 --> Input Class Initialized
DEBUG - 2019-07-21 18:08:57 --> UTF-8 Support Enabled
INFO - 2019-07-21 18:08:57 --> Utf8 Class Initialized
INFO - 2019-07-21 18:08:57 --> URI Class Initialized
INFO - 2019-07-21 18:08:57 --> Router Class Initialized
INFO - 2019-07-21 18:08:57 --> Output Class Initialized
INFO - 2019-07-21 18:08:57 --> Security Class Initialized
DEBUG - 2019-07-21 18:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 18:08:57 --> Input Class Initialized
INFO - 2019-07-21 18:08:57 --> Language Class Initialized
INFO - 2019-07-21 18:08:57 --> Loader Class Initialized
INFO - 2019-07-21 18:08:57 --> Language Class Initialized
INFO - 2019-07-21 18:08:57 --> Loader Class Initialized
INFO - 2019-07-21 18:08:57 --> Database Driver Class Initialized
INFO - 2019-07-21 18:08:57 --> Controller Class Initialized
INFO - 2019-07-21 18:08:57 --> Model "Product" initialized
INFO - 2019-07-21 18:08:57 --> Database Driver Class Initialized
INFO - 2019-07-21 18:08:57 --> Controller Class Initialized
INFO - 2019-07-21 18:08:57 --> Model "Product" initialized
INFO - 2019-07-21 18:08:57 --> Final output sent to browser
DEBUG - 2019-07-21 18:08:57 --> Total execution time: 0.0379
INFO - 2019-07-21 18:08:57 --> Final output sent to browser
DEBUG - 2019-07-21 18:08:57 --> Total execution time: 0.0505
INFO - 2019-07-21 18:09:05 --> Config Class Initialized
INFO - 2019-07-21 18:09:05 --> Hooks Class Initialized
DEBUG - 2019-07-21 18:09:05 --> UTF-8 Support Enabled
INFO - 2019-07-21 18:09:05 --> Utf8 Class Initialized
INFO - 2019-07-21 18:09:05 --> URI Class Initialized
INFO - 2019-07-21 18:09:05 --> Router Class Initialized
INFO - 2019-07-21 18:09:05 --> Output Class Initialized
INFO - 2019-07-21 18:09:05 --> Security Class Initialized
DEBUG - 2019-07-21 18:09:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 18:09:05 --> Input Class Initialized
INFO - 2019-07-21 18:09:05 --> Language Class Initialized
INFO - 2019-07-21 18:09:05 --> Loader Class Initialized
INFO - 2019-07-21 18:09:05 --> Database Driver Class Initialized
INFO - 2019-07-21 18:09:05 --> Controller Class Initialized
INFO - 2019-07-21 18:09:05 --> Model "Product" initialized
INFO - 2019-07-21 18:09:05 --> Final output sent to browser
DEBUG - 2019-07-21 18:09:05 --> Total execution time: 0.0201
INFO - 2019-07-21 18:09:07 --> Config Class Initialized
INFO - 2019-07-21 18:09:07 --> Hooks Class Initialized
DEBUG - 2019-07-21 18:09:07 --> UTF-8 Support Enabled
INFO - 2019-07-21 18:09:07 --> Utf8 Class Initialized
INFO - 2019-07-21 18:09:07 --> URI Class Initialized
INFO - 2019-07-21 18:09:07 --> Router Class Initialized
INFO - 2019-07-21 18:09:07 --> Output Class Initialized
INFO - 2019-07-21 18:09:07 --> Security Class Initialized
DEBUG - 2019-07-21 18:09:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 18:09:07 --> Input Class Initialized
INFO - 2019-07-21 18:09:07 --> Language Class Initialized
INFO - 2019-07-21 18:09:07 --> Loader Class Initialized
INFO - 2019-07-21 18:09:07 --> Database Driver Class Initialized
INFO - 2019-07-21 18:09:07 --> Controller Class Initialized
INFO - 2019-07-21 18:09:07 --> Model "Product" initialized
INFO - 2019-07-21 18:09:07 --> Final output sent to browser
DEBUG - 2019-07-21 18:09:07 --> Total execution time: 0.0160
INFO - 2019-07-21 18:19:59 --> Config Class Initialized
INFO - 2019-07-21 18:19:59 --> Hooks Class Initialized
DEBUG - 2019-07-21 18:19:59 --> UTF-8 Support Enabled
INFO - 2019-07-21 18:19:59 --> Utf8 Class Initialized
INFO - 2019-07-21 18:19:59 --> URI Class Initialized
INFO - 2019-07-21 18:19:59 --> Router Class Initialized
INFO - 2019-07-21 18:19:59 --> Output Class Initialized
INFO - 2019-07-21 18:19:59 --> Security Class Initialized
DEBUG - 2019-07-21 18:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 18:19:59 --> Input Class Initialized
INFO - 2019-07-21 18:19:59 --> Language Class Initialized
INFO - 2019-07-21 18:19:59 --> Loader Class Initialized
INFO - 2019-07-21 18:19:59 --> Config Class Initialized
INFO - 2019-07-21 18:19:59 --> Hooks Class Initialized
INFO - 2019-07-21 18:19:59 --> Database Driver Class Initialized
DEBUG - 2019-07-21 18:19:59 --> UTF-8 Support Enabled
INFO - 2019-07-21 18:19:59 --> Utf8 Class Initialized
INFO - 2019-07-21 18:19:59 --> Controller Class Initialized
INFO - 2019-07-21 18:19:59 --> Model "Product" initialized
INFO - 2019-07-21 18:19:59 --> Final output sent to browser
DEBUG - 2019-07-21 18:19:59 --> Total execution time: 0.0341
INFO - 2019-07-21 18:19:59 --> URI Class Initialized
INFO - 2019-07-21 18:19:59 --> Router Class Initialized
INFO - 2019-07-21 18:19:59 --> Output Class Initialized
INFO - 2019-07-21 18:19:59 --> Security Class Initialized
DEBUG - 2019-07-21 18:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 18:19:59 --> Input Class Initialized
INFO - 2019-07-21 18:19:59 --> Language Class Initialized
INFO - 2019-07-21 18:19:59 --> Loader Class Initialized
INFO - 2019-07-21 18:19:59 --> Database Driver Class Initialized
INFO - 2019-07-21 18:19:59 --> Controller Class Initialized
INFO - 2019-07-21 18:19:59 --> Model "Product" initialized
INFO - 2019-07-21 18:19:59 --> Final output sent to browser
DEBUG - 2019-07-21 18:19:59 --> Total execution time: 0.0329
INFO - 2019-07-21 18:20:09 --> Config Class Initialized
INFO - 2019-07-21 18:20:09 --> Hooks Class Initialized
DEBUG - 2019-07-21 18:20:09 --> UTF-8 Support Enabled
INFO - 2019-07-21 18:20:09 --> Utf8 Class Initialized
INFO - 2019-07-21 18:20:09 --> URI Class Initialized
INFO - 2019-07-21 18:20:09 --> Router Class Initialized
INFO - 2019-07-21 18:20:09 --> Output Class Initialized
INFO - 2019-07-21 18:20:09 --> Security Class Initialized
DEBUG - 2019-07-21 18:20:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 18:20:09 --> Input Class Initialized
INFO - 2019-07-21 18:20:09 --> Language Class Initialized
INFO - 2019-07-21 18:20:09 --> Config Class Initialized
INFO - 2019-07-21 18:20:09 --> Hooks Class Initialized
DEBUG - 2019-07-21 18:20:09 --> UTF-8 Support Enabled
INFO - 2019-07-21 18:20:09 --> Utf8 Class Initialized
INFO - 2019-07-21 18:20:09 --> URI Class Initialized
INFO - 2019-07-21 18:20:09 --> Router Class Initialized
INFO - 2019-07-21 18:20:09 --> Output Class Initialized
INFO - 2019-07-21 18:20:09 --> Security Class Initialized
DEBUG - 2019-07-21 18:20:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 18:20:09 --> Input Class Initialized
INFO - 2019-07-21 18:20:09 --> Language Class Initialized
INFO - 2019-07-21 18:20:09 --> Loader Class Initialized
INFO - 2019-07-21 18:20:09 --> Loader Class Initialized
INFO - 2019-07-21 18:20:09 --> Database Driver Class Initialized
INFO - 2019-07-21 18:20:09 --> Controller Class Initialized
INFO - 2019-07-21 18:20:09 --> Model "Product" initialized
INFO - 2019-07-21 18:20:09 --> Final output sent to browser
DEBUG - 2019-07-21 18:20:09 --> Total execution time: 0.0590
INFO - 2019-07-21 18:20:09 --> Database Driver Class Initialized
INFO - 2019-07-21 18:20:09 --> Controller Class Initialized
INFO - 2019-07-21 18:20:09 --> Model "Product" initialized
INFO - 2019-07-21 18:20:09 --> Final output sent to browser
DEBUG - 2019-07-21 18:20:09 --> Total execution time: 0.0450
INFO - 2019-07-21 18:20:18 --> Config Class Initialized
INFO - 2019-07-21 18:20:18 --> Hooks Class Initialized
DEBUG - 2019-07-21 18:20:18 --> UTF-8 Support Enabled
INFO - 2019-07-21 18:20:18 --> Utf8 Class Initialized
INFO - 2019-07-21 18:20:18 --> URI Class Initialized
INFO - 2019-07-21 18:20:18 --> Router Class Initialized
INFO - 2019-07-21 18:20:18 --> Output Class Initialized
INFO - 2019-07-21 18:20:18 --> Security Class Initialized
DEBUG - 2019-07-21 18:20:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 18:20:18 --> Input Class Initialized
INFO - 2019-07-21 18:20:18 --> Language Class Initialized
INFO - 2019-07-21 18:20:18 --> Loader Class Initialized
INFO - 2019-07-21 18:20:18 --> Database Driver Class Initialized
INFO - 2019-07-21 18:20:18 --> Controller Class Initialized
INFO - 2019-07-21 18:20:18 --> Model "Product" initialized
INFO - 2019-07-21 18:20:18 --> Final output sent to browser
DEBUG - 2019-07-21 18:20:18 --> Total execution time: 0.0214
INFO - 2019-07-21 18:20:21 --> Config Class Initialized
INFO - 2019-07-21 18:20:21 --> Hooks Class Initialized
DEBUG - 2019-07-21 18:20:21 --> UTF-8 Support Enabled
INFO - 2019-07-21 18:20:21 --> Utf8 Class Initialized
INFO - 2019-07-21 18:20:21 --> URI Class Initialized
INFO - 2019-07-21 18:20:21 --> Router Class Initialized
INFO - 2019-07-21 18:20:21 --> Output Class Initialized
INFO - 2019-07-21 18:20:21 --> Security Class Initialized
DEBUG - 2019-07-21 18:20:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 18:20:21 --> Input Class Initialized
INFO - 2019-07-21 18:20:21 --> Language Class Initialized
INFO - 2019-07-21 18:20:21 --> Loader Class Initialized
INFO - 2019-07-21 18:20:21 --> Database Driver Class Initialized
INFO - 2019-07-21 18:20:21 --> Controller Class Initialized
INFO - 2019-07-21 18:20:21 --> Model "Product" initialized
INFO - 2019-07-21 18:20:21 --> Final output sent to browser
DEBUG - 2019-07-21 18:20:21 --> Total execution time: 0.0240
INFO - 2019-07-21 18:20:22 --> Config Class Initialized
INFO - 2019-07-21 18:20:22 --> Hooks Class Initialized
DEBUG - 2019-07-21 18:20:22 --> UTF-8 Support Enabled
INFO - 2019-07-21 18:20:22 --> Utf8 Class Initialized
INFO - 2019-07-21 18:20:22 --> URI Class Initialized
INFO - 2019-07-21 18:20:22 --> Router Class Initialized
INFO - 2019-07-21 18:20:22 --> Output Class Initialized
INFO - 2019-07-21 18:20:22 --> Security Class Initialized
DEBUG - 2019-07-21 18:20:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 18:20:22 --> Input Class Initialized
INFO - 2019-07-21 18:20:22 --> Language Class Initialized
INFO - 2019-07-21 18:20:22 --> Loader Class Initialized
INFO - 2019-07-21 18:20:22 --> Database Driver Class Initialized
INFO - 2019-07-21 18:20:22 --> Controller Class Initialized
INFO - 2019-07-21 18:20:22 --> Model "Product" initialized
INFO - 2019-07-21 18:20:22 --> Final output sent to browser
DEBUG - 2019-07-21 18:20:22 --> Total execution time: 0.0175
INFO - 2019-07-21 18:21:36 --> Config Class Initialized
INFO - 2019-07-21 18:21:36 --> Hooks Class Initialized
DEBUG - 2019-07-21 18:21:36 --> UTF-8 Support Enabled
INFO - 2019-07-21 18:21:36 --> Utf8 Class Initialized
INFO - 2019-07-21 18:21:36 --> URI Class Initialized
INFO - 2019-07-21 18:21:36 --> Router Class Initialized
INFO - 2019-07-21 18:21:36 --> Config Class Initialized
INFO - 2019-07-21 18:21:36 --> Hooks Class Initialized
INFO - 2019-07-21 18:21:36 --> Output Class Initialized
DEBUG - 2019-07-21 18:21:36 --> UTF-8 Support Enabled
INFO - 2019-07-21 18:21:36 --> Utf8 Class Initialized
INFO - 2019-07-21 18:21:36 --> URI Class Initialized
INFO - 2019-07-21 18:21:36 --> Security Class Initialized
INFO - 2019-07-21 18:21:36 --> Router Class Initialized
DEBUG - 2019-07-21 18:21:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 18:21:36 --> Input Class Initialized
INFO - 2019-07-21 18:21:36 --> Language Class Initialized
INFO - 2019-07-21 18:21:36 --> Output Class Initialized
INFO - 2019-07-21 18:21:36 --> Security Class Initialized
INFO - 2019-07-21 18:21:36 --> Loader Class Initialized
DEBUG - 2019-07-21 18:21:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 18:21:36 --> Input Class Initialized
INFO - 2019-07-21 18:21:36 --> Language Class Initialized
INFO - 2019-07-21 18:21:36 --> Loader Class Initialized
INFO - 2019-07-21 18:21:36 --> Database Driver Class Initialized
INFO - 2019-07-21 18:21:36 --> Controller Class Initialized
INFO - 2019-07-21 18:21:36 --> Model "Product" initialized
INFO - 2019-07-21 18:21:36 --> Final output sent to browser
INFO - 2019-07-21 18:21:36 --> Database Driver Class Initialized
INFO - 2019-07-21 18:21:36 --> Controller Class Initialized
INFO - 2019-07-21 18:21:36 --> Model "Product" initialized
DEBUG - 2019-07-21 18:21:36 --> Total execution time: 0.0265
INFO - 2019-07-21 18:21:36 --> Final output sent to browser
DEBUG - 2019-07-21 18:21:36 --> Total execution time: 0.0256
INFO - 2019-07-21 18:21:42 --> Config Class Initialized
INFO - 2019-07-21 18:21:42 --> Hooks Class Initialized
DEBUG - 2019-07-21 18:21:42 --> UTF-8 Support Enabled
INFO - 2019-07-21 18:21:42 --> Utf8 Class Initialized
INFO - 2019-07-21 18:21:42 --> URI Class Initialized
INFO - 2019-07-21 18:21:42 --> Router Class Initialized
INFO - 2019-07-21 18:21:42 --> Output Class Initialized
INFO - 2019-07-21 18:21:42 --> Security Class Initialized
DEBUG - 2019-07-21 18:21:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 18:21:42 --> Input Class Initialized
INFO - 2019-07-21 18:21:42 --> Language Class Initialized
INFO - 2019-07-21 18:21:42 --> Loader Class Initialized
INFO - 2019-07-21 18:21:42 --> Database Driver Class Initialized
INFO - 2019-07-21 18:21:42 --> Controller Class Initialized
INFO - 2019-07-21 18:21:42 --> Model "Product" initialized
INFO - 2019-07-21 18:21:42 --> Final output sent to browser
DEBUG - 2019-07-21 18:21:42 --> Total execution time: 0.0715
INFO - 2019-07-21 18:21:44 --> Config Class Initialized
INFO - 2019-07-21 18:21:44 --> Hooks Class Initialized
DEBUG - 2019-07-21 18:21:44 --> UTF-8 Support Enabled
INFO - 2019-07-21 18:21:44 --> Utf8 Class Initialized
INFO - 2019-07-21 18:21:44 --> URI Class Initialized
INFO - 2019-07-21 18:21:44 --> Router Class Initialized
INFO - 2019-07-21 18:21:44 --> Output Class Initialized
INFO - 2019-07-21 18:21:44 --> Security Class Initialized
DEBUG - 2019-07-21 18:21:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 18:21:44 --> Input Class Initialized
INFO - 2019-07-21 18:21:44 --> Language Class Initialized
INFO - 2019-07-21 18:21:44 --> Loader Class Initialized
INFO - 2019-07-21 18:21:44 --> Database Driver Class Initialized
INFO - 2019-07-21 18:21:44 --> Controller Class Initialized
INFO - 2019-07-21 18:21:44 --> Model "Product" initialized
INFO - 2019-07-21 18:21:44 --> Final output sent to browser
DEBUG - 2019-07-21 18:21:44 --> Total execution time: 0.0237
INFO - 2019-07-21 18:21:45 --> Config Class Initialized
INFO - 2019-07-21 18:21:45 --> Hooks Class Initialized
DEBUG - 2019-07-21 18:21:45 --> UTF-8 Support Enabled
INFO - 2019-07-21 18:21:45 --> Utf8 Class Initialized
INFO - 2019-07-21 18:21:45 --> URI Class Initialized
INFO - 2019-07-21 18:21:45 --> Router Class Initialized
INFO - 2019-07-21 18:21:45 --> Output Class Initialized
INFO - 2019-07-21 18:21:45 --> Security Class Initialized
DEBUG - 2019-07-21 18:21:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 18:21:45 --> Input Class Initialized
INFO - 2019-07-21 18:21:45 --> Language Class Initialized
INFO - 2019-07-21 18:21:45 --> Loader Class Initialized
INFO - 2019-07-21 18:21:45 --> Database Driver Class Initialized
INFO - 2019-07-21 18:21:45 --> Controller Class Initialized
INFO - 2019-07-21 18:21:45 --> Model "Product" initialized
INFO - 2019-07-21 18:21:45 --> Final output sent to browser
DEBUG - 2019-07-21 18:21:45 --> Total execution time: 0.0184
INFO - 2019-07-21 18:21:47 --> Config Class Initialized
INFO - 2019-07-21 18:21:47 --> Hooks Class Initialized
DEBUG - 2019-07-21 18:21:47 --> UTF-8 Support Enabled
INFO - 2019-07-21 18:21:47 --> Utf8 Class Initialized
INFO - 2019-07-21 18:21:47 --> URI Class Initialized
INFO - 2019-07-21 18:21:47 --> Router Class Initialized
INFO - 2019-07-21 18:21:47 --> Output Class Initialized
INFO - 2019-07-21 18:21:47 --> Security Class Initialized
DEBUG - 2019-07-21 18:21:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 18:21:47 --> Input Class Initialized
INFO - 2019-07-21 18:21:47 --> Language Class Initialized
INFO - 2019-07-21 18:21:47 --> Loader Class Initialized
INFO - 2019-07-21 18:21:47 --> Database Driver Class Initialized
INFO - 2019-07-21 18:21:47 --> Controller Class Initialized
INFO - 2019-07-21 18:21:47 --> Model "Product" initialized
INFO - 2019-07-21 18:21:47 --> Final output sent to browser
DEBUG - 2019-07-21 18:21:47 --> Total execution time: 0.0199
INFO - 2019-07-21 18:22:16 --> Config Class Initialized
INFO - 2019-07-21 18:22:16 --> Hooks Class Initialized
DEBUG - 2019-07-21 18:22:16 --> UTF-8 Support Enabled
INFO - 2019-07-21 18:22:16 --> Utf8 Class Initialized
INFO - 2019-07-21 18:22:16 --> URI Class Initialized
INFO - 2019-07-21 18:22:16 --> Router Class Initialized
INFO - 2019-07-21 18:22:16 --> Output Class Initialized
INFO - 2019-07-21 18:22:16 --> Security Class Initialized
INFO - 2019-07-21 18:22:16 --> Config Class Initialized
INFO - 2019-07-21 18:22:16 --> Hooks Class Initialized
DEBUG - 2019-07-21 18:22:16 --> UTF-8 Support Enabled
INFO - 2019-07-21 18:22:16 --> Utf8 Class Initialized
INFO - 2019-07-21 18:22:16 --> URI Class Initialized
INFO - 2019-07-21 18:22:16 --> Router Class Initialized
INFO - 2019-07-21 18:22:16 --> Output Class Initialized
INFO - 2019-07-21 18:22:16 --> Security Class Initialized
DEBUG - 2019-07-21 18:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 18:22:16 --> Input Class Initialized
DEBUG - 2019-07-21 18:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 18:22:16 --> Input Class Initialized
INFO - 2019-07-21 18:22:16 --> Language Class Initialized
INFO - 2019-07-21 18:22:16 --> Loader Class Initialized
INFO - 2019-07-21 18:22:16 --> Language Class Initialized
INFO - 2019-07-21 18:22:16 --> Loader Class Initialized
INFO - 2019-07-21 18:22:16 --> Database Driver Class Initialized
INFO - 2019-07-21 18:22:16 --> Controller Class Initialized
INFO - 2019-07-21 18:22:16 --> Model "Product" initialized
INFO - 2019-07-21 18:22:16 --> Database Driver Class Initialized
INFO - 2019-07-21 18:22:16 --> Controller Class Initialized
INFO - 2019-07-21 18:22:16 --> Final output sent to browser
DEBUG - 2019-07-21 18:22:16 --> Total execution time: 0.0326
INFO - 2019-07-21 18:22:16 --> Model "Product" initialized
INFO - 2019-07-21 18:22:16 --> Final output sent to browser
DEBUG - 2019-07-21 18:22:16 --> Total execution time: 0.0512
INFO - 2019-07-21 18:22:43 --> Config Class Initialized
INFO - 2019-07-21 18:22:43 --> Hooks Class Initialized
DEBUG - 2019-07-21 18:22:43 --> UTF-8 Support Enabled
INFO - 2019-07-21 18:22:43 --> Utf8 Class Initialized
INFO - 2019-07-21 18:22:43 --> URI Class Initialized
INFO - 2019-07-21 18:22:43 --> Router Class Initialized
INFO - 2019-07-21 18:22:43 --> Output Class Initialized
INFO - 2019-07-21 18:22:43 --> Security Class Initialized
DEBUG - 2019-07-21 18:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 18:22:43 --> Input Class Initialized
INFO - 2019-07-21 18:22:43 --> Language Class Initialized
INFO - 2019-07-21 18:22:43 --> Config Class Initialized
INFO - 2019-07-21 18:22:43 --> Hooks Class Initialized
INFO - 2019-07-21 18:22:43 --> Loader Class Initialized
DEBUG - 2019-07-21 18:22:43 --> UTF-8 Support Enabled
INFO - 2019-07-21 18:22:43 --> Utf8 Class Initialized
INFO - 2019-07-21 18:22:43 --> URI Class Initialized
INFO - 2019-07-21 18:22:43 --> Router Class Initialized
INFO - 2019-07-21 18:22:43 --> Output Class Initialized
INFO - 2019-07-21 18:22:43 --> Security Class Initialized
INFO - 2019-07-21 18:22:43 --> Database Driver Class Initialized
DEBUG - 2019-07-21 18:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 18:22:43 --> Input Class Initialized
INFO - 2019-07-21 18:22:43 --> Language Class Initialized
INFO - 2019-07-21 18:22:43 --> Loader Class Initialized
INFO - 2019-07-21 18:22:43 --> Controller Class Initialized
INFO - 2019-07-21 18:22:43 --> Model "Product" initialized
INFO - 2019-07-21 18:22:43 --> Final output sent to browser
DEBUG - 2019-07-21 18:22:43 --> Total execution time: 0.0398
INFO - 2019-07-21 18:22:43 --> Database Driver Class Initialized
INFO - 2019-07-21 18:22:43 --> Controller Class Initialized
INFO - 2019-07-21 18:22:43 --> Model "Product" initialized
INFO - 2019-07-21 18:22:43 --> Final output sent to browser
DEBUG - 2019-07-21 18:22:43 --> Total execution time: 0.0370
INFO - 2019-07-21 18:22:49 --> Config Class Initialized
INFO - 2019-07-21 18:22:49 --> Hooks Class Initialized
DEBUG - 2019-07-21 18:22:49 --> UTF-8 Support Enabled
INFO - 2019-07-21 18:22:49 --> Utf8 Class Initialized
INFO - 2019-07-21 18:22:49 --> URI Class Initialized
INFO - 2019-07-21 18:22:49 --> Router Class Initialized
INFO - 2019-07-21 18:22:49 --> Output Class Initialized
INFO - 2019-07-21 18:22:49 --> Config Class Initialized
INFO - 2019-07-21 18:22:49 --> Hooks Class Initialized
INFO - 2019-07-21 18:22:49 --> Security Class Initialized
DEBUG - 2019-07-21 18:22:49 --> UTF-8 Support Enabled
INFO - 2019-07-21 18:22:49 --> Utf8 Class Initialized
DEBUG - 2019-07-21 18:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 18:22:49 --> Input Class Initialized
INFO - 2019-07-21 18:22:49 --> Language Class Initialized
INFO - 2019-07-21 18:22:49 --> URI Class Initialized
INFO - 2019-07-21 18:22:49 --> Router Class Initialized
INFO - 2019-07-21 18:22:49 --> Loader Class Initialized
INFO - 2019-07-21 18:22:49 --> Output Class Initialized
INFO - 2019-07-21 18:22:49 --> Security Class Initialized
INFO - 2019-07-21 18:22:49 --> Database Driver Class Initialized
INFO - 2019-07-21 18:22:49 --> Controller Class Initialized
INFO - 2019-07-21 18:22:49 --> Model "Product" initialized
DEBUG - 2019-07-21 18:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 18:22:49 --> Input Class Initialized
INFO - 2019-07-21 18:22:49 --> Language Class Initialized
INFO - 2019-07-21 18:22:49 --> Final output sent to browser
DEBUG - 2019-07-21 18:22:49 --> Total execution time: 0.0235
INFO - 2019-07-21 18:22:49 --> Loader Class Initialized
INFO - 2019-07-21 18:22:49 --> Database Driver Class Initialized
INFO - 2019-07-21 18:22:49 --> Controller Class Initialized
INFO - 2019-07-21 18:22:49 --> Model "Product" initialized
INFO - 2019-07-21 18:22:49 --> Final output sent to browser
DEBUG - 2019-07-21 18:22:49 --> Total execution time: 0.0342
INFO - 2019-07-21 18:22:58 --> Config Class Initialized
INFO - 2019-07-21 18:22:58 --> Hooks Class Initialized
DEBUG - 2019-07-21 18:22:58 --> UTF-8 Support Enabled
INFO - 2019-07-21 18:22:58 --> Utf8 Class Initialized
INFO - 2019-07-21 18:22:58 --> URI Class Initialized
INFO - 2019-07-21 18:22:58 --> Router Class Initialized
INFO - 2019-07-21 18:22:58 --> Output Class Initialized
INFO - 2019-07-21 18:22:58 --> Config Class Initialized
INFO - 2019-07-21 18:22:58 --> Hooks Class Initialized
INFO - 2019-07-21 18:22:58 --> Security Class Initialized
DEBUG - 2019-07-21 18:22:58 --> UTF-8 Support Enabled
INFO - 2019-07-21 18:22:58 --> Utf8 Class Initialized
DEBUG - 2019-07-21 18:22:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 18:22:58 --> URI Class Initialized
INFO - 2019-07-21 18:22:58 --> Input Class Initialized
INFO - 2019-07-21 18:22:58 --> Language Class Initialized
INFO - 2019-07-21 18:22:58 --> Router Class Initialized
INFO - 2019-07-21 18:22:58 --> Output Class Initialized
INFO - 2019-07-21 18:22:58 --> Loader Class Initialized
INFO - 2019-07-21 18:22:58 --> Security Class Initialized
DEBUG - 2019-07-21 18:22:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 18:22:58 --> Input Class Initialized
INFO - 2019-07-21 18:22:58 --> Language Class Initialized
INFO - 2019-07-21 18:22:58 --> Loader Class Initialized
INFO - 2019-07-21 18:22:58 --> Database Driver Class Initialized
INFO - 2019-07-21 18:22:58 --> Controller Class Initialized
INFO - 2019-07-21 18:22:58 --> Model "Product" initialized
INFO - 2019-07-21 18:22:58 --> Final output sent to browser
DEBUG - 2019-07-21 18:22:58 --> Total execution time: 0.0381
INFO - 2019-07-21 18:22:58 --> Database Driver Class Initialized
INFO - 2019-07-21 18:22:58 --> Controller Class Initialized
INFO - 2019-07-21 18:22:58 --> Model "Product" initialized
INFO - 2019-07-21 18:22:58 --> Final output sent to browser
DEBUG - 2019-07-21 18:22:58 --> Total execution time: 0.0348
INFO - 2019-07-21 18:23:12 --> Config Class Initialized
INFO - 2019-07-21 18:23:12 --> Hooks Class Initialized
DEBUG - 2019-07-21 18:23:12 --> UTF-8 Support Enabled
INFO - 2019-07-21 18:23:12 --> Utf8 Class Initialized
INFO - 2019-07-21 18:23:12 --> URI Class Initialized
INFO - 2019-07-21 18:23:12 --> Router Class Initialized
INFO - 2019-07-21 18:23:12 --> Output Class Initialized
INFO - 2019-07-21 18:23:12 --> Security Class Initialized
DEBUG - 2019-07-21 18:23:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 18:23:12 --> Input Class Initialized
INFO - 2019-07-21 18:23:12 --> Language Class Initialized
INFO - 2019-07-21 18:23:12 --> Loader Class Initialized
INFO - 2019-07-21 18:23:12 --> Database Driver Class Initialized
INFO - 2019-07-21 18:23:12 --> Controller Class Initialized
INFO - 2019-07-21 18:23:12 --> Model "Product" initialized
INFO - 2019-07-21 18:23:12 --> Final output sent to browser
DEBUG - 2019-07-21 18:23:12 --> Total execution time: 0.0278
INFO - 2019-07-21 18:23:12 --> Config Class Initialized
INFO - 2019-07-21 18:23:12 --> Hooks Class Initialized
DEBUG - 2019-07-21 18:23:12 --> UTF-8 Support Enabled
INFO - 2019-07-21 18:23:12 --> Utf8 Class Initialized
INFO - 2019-07-21 18:23:12 --> URI Class Initialized
INFO - 2019-07-21 18:23:12 --> Router Class Initialized
INFO - 2019-07-21 18:23:12 --> Output Class Initialized
INFO - 2019-07-21 18:23:12 --> Security Class Initialized
DEBUG - 2019-07-21 18:23:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 18:23:12 --> Input Class Initialized
INFO - 2019-07-21 18:23:12 --> Language Class Initialized
INFO - 2019-07-21 18:23:12 --> Loader Class Initialized
INFO - 2019-07-21 18:23:12 --> Database Driver Class Initialized
INFO - 2019-07-21 18:23:12 --> Controller Class Initialized
INFO - 2019-07-21 18:23:12 --> Model "Product" initialized
INFO - 2019-07-21 18:23:12 --> Final output sent to browser
DEBUG - 2019-07-21 18:23:12 --> Total execution time: 0.0299
INFO - 2019-07-21 18:23:26 --> Config Class Initialized
INFO - 2019-07-21 18:23:26 --> Hooks Class Initialized
DEBUG - 2019-07-21 18:23:26 --> UTF-8 Support Enabled
INFO - 2019-07-21 18:23:26 --> Utf8 Class Initialized
INFO - 2019-07-21 18:23:26 --> URI Class Initialized
INFO - 2019-07-21 18:23:26 --> Router Class Initialized
INFO - 2019-07-21 18:23:26 --> Output Class Initialized
INFO - 2019-07-21 18:23:26 --> Security Class Initialized
INFO - 2019-07-21 18:23:26 --> Config Class Initialized
INFO - 2019-07-21 18:23:26 --> Hooks Class Initialized
DEBUG - 2019-07-21 18:23:26 --> UTF-8 Support Enabled
INFO - 2019-07-21 18:23:26 --> Utf8 Class Initialized
DEBUG - 2019-07-21 18:23:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 18:23:26 --> Input Class Initialized
INFO - 2019-07-21 18:23:26 --> Language Class Initialized
INFO - 2019-07-21 18:23:26 --> Loader Class Initialized
INFO - 2019-07-21 18:23:26 --> URI Class Initialized
INFO - 2019-07-21 18:23:26 --> Router Class Initialized
INFO - 2019-07-21 18:23:26 --> Output Class Initialized
INFO - 2019-07-21 18:23:26 --> Security Class Initialized
DEBUG - 2019-07-21 18:23:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 18:23:26 --> Input Class Initialized
INFO - 2019-07-21 18:23:26 --> Language Class Initialized
INFO - 2019-07-21 18:23:26 --> Database Driver Class Initialized
INFO - 2019-07-21 18:23:26 --> Controller Class Initialized
INFO - 2019-07-21 18:23:26 --> Model "Product" initialized
INFO - 2019-07-21 18:23:26 --> Loader Class Initialized
INFO - 2019-07-21 18:23:26 --> Final output sent to browser
DEBUG - 2019-07-21 18:23:26 --> Total execution time: 0.0440
INFO - 2019-07-21 18:23:26 --> Database Driver Class Initialized
INFO - 2019-07-21 18:23:27 --> Controller Class Initialized
INFO - 2019-07-21 18:23:27 --> Model "Product" initialized
INFO - 2019-07-21 18:23:27 --> Final output sent to browser
DEBUG - 2019-07-21 18:23:27 --> Total execution time: 0.0393
INFO - 2019-07-21 18:23:34 --> Config Class Initialized
INFO - 2019-07-21 18:23:34 --> Hooks Class Initialized
DEBUG - 2019-07-21 18:23:34 --> UTF-8 Support Enabled
INFO - 2019-07-21 18:23:34 --> Utf8 Class Initialized
INFO - 2019-07-21 18:23:34 --> URI Class Initialized
INFO - 2019-07-21 18:23:34 --> Router Class Initialized
INFO - 2019-07-21 18:23:34 --> Output Class Initialized
INFO - 2019-07-21 18:23:34 --> Security Class Initialized
DEBUG - 2019-07-21 18:23:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 18:23:34 --> Input Class Initialized
INFO - 2019-07-21 18:23:34 --> Language Class Initialized
INFO - 2019-07-21 18:23:34 --> Loader Class Initialized
INFO - 2019-07-21 18:23:34 --> Database Driver Class Initialized
INFO - 2019-07-21 18:23:34 --> Controller Class Initialized
INFO - 2019-07-21 18:23:34 --> Model "Product" initialized
INFO - 2019-07-21 18:23:34 --> Final output sent to browser
DEBUG - 2019-07-21 18:23:34 --> Total execution time: 0.0192
INFO - 2019-07-21 18:23:36 --> Config Class Initialized
INFO - 2019-07-21 18:23:36 --> Hooks Class Initialized
DEBUG - 2019-07-21 18:23:36 --> UTF-8 Support Enabled
INFO - 2019-07-21 18:23:36 --> Utf8 Class Initialized
INFO - 2019-07-21 18:23:36 --> URI Class Initialized
INFO - 2019-07-21 18:23:36 --> Router Class Initialized
INFO - 2019-07-21 18:23:36 --> Output Class Initialized
INFO - 2019-07-21 18:23:36 --> Security Class Initialized
DEBUG - 2019-07-21 18:23:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 18:23:36 --> Input Class Initialized
INFO - 2019-07-21 18:23:36 --> Language Class Initialized
INFO - 2019-07-21 18:23:36 --> Loader Class Initialized
INFO - 2019-07-21 18:23:36 --> Database Driver Class Initialized
INFO - 2019-07-21 18:23:36 --> Controller Class Initialized
INFO - 2019-07-21 18:23:36 --> Model "Product" initialized
INFO - 2019-07-21 18:23:36 --> Final output sent to browser
DEBUG - 2019-07-21 18:23:36 --> Total execution time: 0.0188
INFO - 2019-07-21 18:23:38 --> Config Class Initialized
INFO - 2019-07-21 18:23:38 --> Hooks Class Initialized
DEBUG - 2019-07-21 18:23:38 --> UTF-8 Support Enabled
INFO - 2019-07-21 18:23:38 --> Utf8 Class Initialized
INFO - 2019-07-21 18:23:38 --> URI Class Initialized
INFO - 2019-07-21 18:23:38 --> Router Class Initialized
INFO - 2019-07-21 18:23:38 --> Output Class Initialized
INFO - 2019-07-21 18:23:38 --> Security Class Initialized
DEBUG - 2019-07-21 18:23:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 18:23:38 --> Input Class Initialized
INFO - 2019-07-21 18:23:38 --> Language Class Initialized
INFO - 2019-07-21 18:23:38 --> Loader Class Initialized
INFO - 2019-07-21 18:23:38 --> Database Driver Class Initialized
INFO - 2019-07-21 18:23:38 --> Controller Class Initialized
INFO - 2019-07-21 18:23:38 --> Model "Product" initialized
INFO - 2019-07-21 18:23:38 --> Final output sent to browser
DEBUG - 2019-07-21 18:23:38 --> Total execution time: 0.0223
INFO - 2019-07-21 18:23:45 --> Config Class Initialized
INFO - 2019-07-21 18:23:45 --> Hooks Class Initialized
DEBUG - 2019-07-21 18:23:45 --> UTF-8 Support Enabled
INFO - 2019-07-21 18:23:45 --> Utf8 Class Initialized
INFO - 2019-07-21 18:23:45 --> URI Class Initialized
INFO - 2019-07-21 18:23:45 --> Router Class Initialized
INFO - 2019-07-21 18:23:45 --> Output Class Initialized
INFO - 2019-07-21 18:23:45 --> Security Class Initialized
DEBUG - 2019-07-21 18:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 18:23:45 --> Input Class Initialized
INFO - 2019-07-21 18:23:45 --> Language Class Initialized
INFO - 2019-07-21 18:23:45 --> Loader Class Initialized
INFO - 2019-07-21 18:23:45 --> Database Driver Class Initialized
INFO - 2019-07-21 18:23:45 --> Controller Class Initialized
INFO - 2019-07-21 18:23:45 --> Model "Product" initialized
INFO - 2019-07-21 18:23:45 --> Final output sent to browser
DEBUG - 2019-07-21 18:23:45 --> Total execution time: 0.0160
INFO - 2019-07-21 18:23:49 --> Config Class Initialized
INFO - 2019-07-21 18:23:49 --> Hooks Class Initialized
DEBUG - 2019-07-21 18:23:49 --> UTF-8 Support Enabled
INFO - 2019-07-21 18:23:49 --> Utf8 Class Initialized
INFO - 2019-07-21 18:23:49 --> URI Class Initialized
INFO - 2019-07-21 18:23:49 --> Router Class Initialized
INFO - 2019-07-21 18:23:49 --> Output Class Initialized
INFO - 2019-07-21 18:23:49 --> Security Class Initialized
DEBUG - 2019-07-21 18:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 18:23:49 --> Input Class Initialized
INFO - 2019-07-21 18:23:49 --> Language Class Initialized
INFO - 2019-07-21 18:23:49 --> Loader Class Initialized
INFO - 2019-07-21 18:23:49 --> Database Driver Class Initialized
INFO - 2019-07-21 18:23:49 --> Controller Class Initialized
INFO - 2019-07-21 18:23:49 --> Model "Product" initialized
INFO - 2019-07-21 18:23:49 --> Final output sent to browser
DEBUG - 2019-07-21 18:23:49 --> Total execution time: 0.0197
INFO - 2019-07-21 18:24:34 --> Config Class Initialized
INFO - 2019-07-21 18:24:34 --> Hooks Class Initialized
DEBUG - 2019-07-21 18:24:34 --> UTF-8 Support Enabled
INFO - 2019-07-21 18:24:34 --> Utf8 Class Initialized
INFO - 2019-07-21 18:24:34 --> URI Class Initialized
INFO - 2019-07-21 18:24:34 --> Router Class Initialized
INFO - 2019-07-21 18:24:34 --> Output Class Initialized
INFO - 2019-07-21 18:24:34 --> Security Class Initialized
INFO - 2019-07-21 18:24:34 --> Config Class Initialized
INFO - 2019-07-21 18:24:34 --> Hooks Class Initialized
DEBUG - 2019-07-21 18:24:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 18:24:34 --> Input Class Initialized
INFO - 2019-07-21 18:24:34 --> Language Class Initialized
DEBUG - 2019-07-21 18:24:34 --> UTF-8 Support Enabled
INFO - 2019-07-21 18:24:34 --> Utf8 Class Initialized
INFO - 2019-07-21 18:24:34 --> URI Class Initialized
INFO - 2019-07-21 18:24:34 --> Router Class Initialized
INFO - 2019-07-21 18:24:34 --> Loader Class Initialized
INFO - 2019-07-21 18:24:34 --> Output Class Initialized
INFO - 2019-07-21 18:24:34 --> Security Class Initialized
INFO - 2019-07-21 18:24:34 --> Database Driver Class Initialized
DEBUG - 2019-07-21 18:24:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 18:24:34 --> Input Class Initialized
INFO - 2019-07-21 18:24:34 --> Controller Class Initialized
INFO - 2019-07-21 18:24:34 --> Language Class Initialized
INFO - 2019-07-21 18:24:34 --> Model "Product" initialized
INFO - 2019-07-21 18:24:34 --> Final output sent to browser
DEBUG - 2019-07-21 18:24:34 --> Total execution time: 0.0232
INFO - 2019-07-21 18:24:34 --> Loader Class Initialized
INFO - 2019-07-21 18:24:34 --> Database Driver Class Initialized
INFO - 2019-07-21 18:24:34 --> Controller Class Initialized
INFO - 2019-07-21 18:24:34 --> Model "Product" initialized
INFO - 2019-07-21 18:24:34 --> Final output sent to browser
DEBUG - 2019-07-21 18:24:34 --> Total execution time: 0.0375
INFO - 2019-07-21 18:24:39 --> Config Class Initialized
INFO - 2019-07-21 18:24:39 --> Hooks Class Initialized
DEBUG - 2019-07-21 18:24:39 --> UTF-8 Support Enabled
INFO - 2019-07-21 18:24:39 --> Utf8 Class Initialized
INFO - 2019-07-21 18:24:39 --> URI Class Initialized
INFO - 2019-07-21 18:24:39 --> Router Class Initialized
INFO - 2019-07-21 18:24:39 --> Output Class Initialized
INFO - 2019-07-21 18:24:39 --> Security Class Initialized
DEBUG - 2019-07-21 18:24:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 18:24:39 --> Input Class Initialized
INFO - 2019-07-21 18:24:39 --> Language Class Initialized
INFO - 2019-07-21 18:24:39 --> Loader Class Initialized
INFO - 2019-07-21 18:24:39 --> Database Driver Class Initialized
INFO - 2019-07-21 18:24:39 --> Controller Class Initialized
INFO - 2019-07-21 18:24:39 --> Model "Product" initialized
INFO - 2019-07-21 18:24:39 --> Final output sent to browser
DEBUG - 2019-07-21 18:24:39 --> Total execution time: 0.0199
INFO - 2019-07-21 18:24:40 --> Config Class Initialized
INFO - 2019-07-21 18:24:40 --> Hooks Class Initialized
DEBUG - 2019-07-21 18:24:40 --> UTF-8 Support Enabled
INFO - 2019-07-21 18:24:40 --> Utf8 Class Initialized
INFO - 2019-07-21 18:24:40 --> URI Class Initialized
INFO - 2019-07-21 18:24:40 --> Router Class Initialized
INFO - 2019-07-21 18:24:40 --> Output Class Initialized
INFO - 2019-07-21 18:24:40 --> Security Class Initialized
DEBUG - 2019-07-21 18:24:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 18:24:40 --> Input Class Initialized
INFO - 2019-07-21 18:24:40 --> Language Class Initialized
INFO - 2019-07-21 18:24:40 --> Loader Class Initialized
INFO - 2019-07-21 18:24:40 --> Database Driver Class Initialized
INFO - 2019-07-21 18:24:40 --> Controller Class Initialized
INFO - 2019-07-21 18:24:40 --> Model "Product" initialized
INFO - 2019-07-21 18:24:40 --> Final output sent to browser
DEBUG - 2019-07-21 18:24:40 --> Total execution time: 0.0272
INFO - 2019-07-21 18:24:54 --> Config Class Initialized
INFO - 2019-07-21 18:24:54 --> Hooks Class Initialized
DEBUG - 2019-07-21 18:24:54 --> UTF-8 Support Enabled
INFO - 2019-07-21 18:24:54 --> Utf8 Class Initialized
INFO - 2019-07-21 18:24:54 --> URI Class Initialized
INFO - 2019-07-21 18:24:54 --> Router Class Initialized
INFO - 2019-07-21 18:24:54 --> Output Class Initialized
INFO - 2019-07-21 18:24:54 --> Security Class Initialized
DEBUG - 2019-07-21 18:24:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 18:24:54 --> Input Class Initialized
INFO - 2019-07-21 18:24:54 --> Language Class Initialized
INFO - 2019-07-21 18:24:54 --> Loader Class Initialized
INFO - 2019-07-21 18:24:54 --> Database Driver Class Initialized
INFO - 2019-07-21 18:24:54 --> Controller Class Initialized
INFO - 2019-07-21 18:24:54 --> Model "Product" initialized
INFO - 2019-07-21 18:24:54 --> Final output sent to browser
DEBUG - 2019-07-21 18:24:54 --> Total execution time: 0.0294
INFO - 2019-07-21 18:24:54 --> Config Class Initialized
INFO - 2019-07-21 18:24:54 --> Hooks Class Initialized
DEBUG - 2019-07-21 18:24:54 --> UTF-8 Support Enabled
INFO - 2019-07-21 18:24:54 --> Utf8 Class Initialized
INFO - 2019-07-21 18:24:54 --> URI Class Initialized
INFO - 2019-07-21 18:24:54 --> Router Class Initialized
INFO - 2019-07-21 18:24:54 --> Output Class Initialized
INFO - 2019-07-21 18:24:54 --> Security Class Initialized
DEBUG - 2019-07-21 18:24:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 18:24:54 --> Input Class Initialized
INFO - 2019-07-21 18:24:54 --> Language Class Initialized
INFO - 2019-07-21 18:24:54 --> Loader Class Initialized
INFO - 2019-07-21 18:24:54 --> Database Driver Class Initialized
INFO - 2019-07-21 18:24:54 --> Controller Class Initialized
INFO - 2019-07-21 18:24:54 --> Model "Product" initialized
INFO - 2019-07-21 18:24:54 --> Final output sent to browser
DEBUG - 2019-07-21 18:24:54 --> Total execution time: 0.0325
INFO - 2019-07-21 18:26:55 --> Config Class Initialized
INFO - 2019-07-21 18:26:55 --> Hooks Class Initialized
DEBUG - 2019-07-21 18:26:55 --> UTF-8 Support Enabled
INFO - 2019-07-21 18:26:55 --> Utf8 Class Initialized
INFO - 2019-07-21 18:26:55 --> URI Class Initialized
INFO - 2019-07-21 18:26:55 --> Router Class Initialized
INFO - 2019-07-21 18:26:55 --> Output Class Initialized
INFO - 2019-07-21 18:26:55 --> Security Class Initialized
INFO - 2019-07-21 18:26:55 --> Config Class Initialized
INFO - 2019-07-21 18:26:55 --> Hooks Class Initialized
DEBUG - 2019-07-21 18:26:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 18:26:55 --> Input Class Initialized
INFO - 2019-07-21 18:26:55 --> Language Class Initialized
DEBUG - 2019-07-21 18:26:55 --> UTF-8 Support Enabled
INFO - 2019-07-21 18:26:55 --> Utf8 Class Initialized
INFO - 2019-07-21 18:26:55 --> URI Class Initialized
INFO - 2019-07-21 18:26:55 --> Router Class Initialized
INFO - 2019-07-21 18:26:55 --> Loader Class Initialized
INFO - 2019-07-21 18:26:55 --> Output Class Initialized
INFO - 2019-07-21 18:26:55 --> Security Class Initialized
DEBUG - 2019-07-21 18:26:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 18:26:55 --> Input Class Initialized
INFO - 2019-07-21 18:26:55 --> Language Class Initialized
INFO - 2019-07-21 18:26:55 --> Database Driver Class Initialized
INFO - 2019-07-21 18:26:55 --> Controller Class Initialized
INFO - 2019-07-21 18:26:55 --> Model "Product" initialized
INFO - 2019-07-21 18:26:55 --> Loader Class Initialized
INFO - 2019-07-21 18:26:55 --> Final output sent to browser
DEBUG - 2019-07-21 18:26:55 --> Total execution time: 0.0236
INFO - 2019-07-21 18:26:55 --> Database Driver Class Initialized
INFO - 2019-07-21 18:26:55 --> Controller Class Initialized
INFO - 2019-07-21 18:26:55 --> Model "Product" initialized
INFO - 2019-07-21 18:26:55 --> Final output sent to browser
DEBUG - 2019-07-21 18:26:55 --> Total execution time: 0.0276
INFO - 2019-07-21 18:28:12 --> Config Class Initialized
INFO - 2019-07-21 18:28:12 --> Hooks Class Initialized
DEBUG - 2019-07-21 18:28:12 --> UTF-8 Support Enabled
INFO - 2019-07-21 18:28:12 --> Utf8 Class Initialized
INFO - 2019-07-21 18:28:12 --> URI Class Initialized
INFO - 2019-07-21 18:28:12 --> Router Class Initialized
INFO - 2019-07-21 18:28:12 --> Output Class Initialized
INFO - 2019-07-21 18:28:12 --> Security Class Initialized
DEBUG - 2019-07-21 18:28:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 18:28:12 --> Input Class Initialized
INFO - 2019-07-21 18:28:12 --> Language Class Initialized
INFO - 2019-07-21 18:28:12 --> Loader Class Initialized
INFO - 2019-07-21 18:28:12 --> Database Driver Class Initialized
INFO - 2019-07-21 18:28:12 --> Controller Class Initialized
INFO - 2019-07-21 18:28:12 --> Model "Product" initialized
INFO - 2019-07-21 18:28:12 --> Final output sent to browser
DEBUG - 2019-07-21 18:28:12 --> Total execution time: 0.0451
INFO - 2019-07-21 18:28:12 --> Config Class Initialized
INFO - 2019-07-21 18:28:12 --> Hooks Class Initialized
DEBUG - 2019-07-21 18:28:12 --> UTF-8 Support Enabled
INFO - 2019-07-21 18:28:12 --> Utf8 Class Initialized
INFO - 2019-07-21 18:28:12 --> URI Class Initialized
INFO - 2019-07-21 18:28:12 --> Router Class Initialized
INFO - 2019-07-21 18:28:12 --> Output Class Initialized
INFO - 2019-07-21 18:28:12 --> Security Class Initialized
DEBUG - 2019-07-21 18:28:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 18:28:12 --> Input Class Initialized
INFO - 2019-07-21 18:28:12 --> Language Class Initialized
INFO - 2019-07-21 18:28:12 --> Loader Class Initialized
INFO - 2019-07-21 18:28:12 --> Database Driver Class Initialized
INFO - 2019-07-21 18:28:12 --> Controller Class Initialized
INFO - 2019-07-21 18:28:12 --> Model "Product" initialized
INFO - 2019-07-21 18:28:12 --> Final output sent to browser
DEBUG - 2019-07-21 18:28:12 --> Total execution time: 0.1083
INFO - 2019-07-21 18:28:14 --> Config Class Initialized
INFO - 2019-07-21 18:28:14 --> Hooks Class Initialized
DEBUG - 2019-07-21 18:28:14 --> UTF-8 Support Enabled
INFO - 2019-07-21 18:28:14 --> Utf8 Class Initialized
INFO - 2019-07-21 18:28:14 --> URI Class Initialized
INFO - 2019-07-21 18:28:14 --> Router Class Initialized
INFO - 2019-07-21 18:28:14 --> Output Class Initialized
INFO - 2019-07-21 18:28:14 --> Security Class Initialized
DEBUG - 2019-07-21 18:28:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 18:28:14 --> Input Class Initialized
INFO - 2019-07-21 18:28:14 --> Language Class Initialized
INFO - 2019-07-21 18:28:14 --> Loader Class Initialized
INFO - 2019-07-21 18:28:14 --> Database Driver Class Initialized
INFO - 2019-07-21 18:28:14 --> Controller Class Initialized
INFO - 2019-07-21 18:28:14 --> Model "Product" initialized
INFO - 2019-07-21 18:28:14 --> Final output sent to browser
DEBUG - 2019-07-21 18:28:14 --> Total execution time: 0.0184
INFO - 2019-07-21 18:28:24 --> Config Class Initialized
INFO - 2019-07-21 18:28:24 --> Hooks Class Initialized
DEBUG - 2019-07-21 18:28:24 --> UTF-8 Support Enabled
INFO - 2019-07-21 18:28:24 --> Utf8 Class Initialized
INFO - 2019-07-21 18:28:24 --> URI Class Initialized
INFO - 2019-07-21 18:28:24 --> Router Class Initialized
INFO - 2019-07-21 18:28:24 --> Output Class Initialized
INFO - 2019-07-21 18:28:24 --> Security Class Initialized
DEBUG - 2019-07-21 18:28:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 18:28:24 --> Input Class Initialized
INFO - 2019-07-21 18:28:24 --> Language Class Initialized
INFO - 2019-07-21 18:28:24 --> Loader Class Initialized
INFO - 2019-07-21 18:28:24 --> Database Driver Class Initialized
INFO - 2019-07-21 18:28:24 --> Controller Class Initialized
INFO - 2019-07-21 18:28:24 --> Model "Product" initialized
INFO - 2019-07-21 18:28:24 --> Final output sent to browser
DEBUG - 2019-07-21 18:28:24 --> Total execution time: 0.0231
INFO - 2019-07-21 18:28:27 --> Config Class Initialized
INFO - 2019-07-21 18:28:27 --> Hooks Class Initialized
DEBUG - 2019-07-21 18:28:27 --> UTF-8 Support Enabled
INFO - 2019-07-21 18:28:27 --> Utf8 Class Initialized
INFO - 2019-07-21 18:28:27 --> URI Class Initialized
INFO - 2019-07-21 18:28:27 --> Router Class Initialized
INFO - 2019-07-21 18:28:27 --> Output Class Initialized
INFO - 2019-07-21 18:28:27 --> Security Class Initialized
DEBUG - 2019-07-21 18:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 18:28:27 --> Input Class Initialized
INFO - 2019-07-21 18:28:27 --> Language Class Initialized
INFO - 2019-07-21 18:28:27 --> Loader Class Initialized
INFO - 2019-07-21 18:28:27 --> Database Driver Class Initialized
INFO - 2019-07-21 18:28:27 --> Controller Class Initialized
INFO - 2019-07-21 18:28:27 --> Model "Product" initialized
INFO - 2019-07-21 18:28:27 --> Final output sent to browser
DEBUG - 2019-07-21 18:28:27 --> Total execution time: 0.0193
INFO - 2019-07-21 18:28:27 --> Config Class Initialized
INFO - 2019-07-21 18:28:27 --> Hooks Class Initialized
DEBUG - 2019-07-21 18:28:27 --> UTF-8 Support Enabled
INFO - 2019-07-21 18:28:27 --> Utf8 Class Initialized
INFO - 2019-07-21 18:28:27 --> URI Class Initialized
INFO - 2019-07-21 18:28:27 --> Router Class Initialized
INFO - 2019-07-21 18:28:27 --> Output Class Initialized
INFO - 2019-07-21 18:28:27 --> Security Class Initialized
DEBUG - 2019-07-21 18:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 18:28:27 --> Input Class Initialized
INFO - 2019-07-21 18:28:27 --> Language Class Initialized
INFO - 2019-07-21 18:28:27 --> Loader Class Initialized
INFO - 2019-07-21 18:28:27 --> Database Driver Class Initialized
INFO - 2019-07-21 18:28:27 --> Controller Class Initialized
INFO - 2019-07-21 18:28:27 --> Model "Product" initialized
INFO - 2019-07-21 18:28:27 --> Final output sent to browser
DEBUG - 2019-07-21 18:28:27 --> Total execution time: 0.1001
INFO - 2019-07-21 18:28:29 --> Config Class Initialized
INFO - 2019-07-21 18:28:29 --> Hooks Class Initialized
DEBUG - 2019-07-21 18:28:29 --> UTF-8 Support Enabled
INFO - 2019-07-21 18:28:29 --> Utf8 Class Initialized
INFO - 2019-07-21 18:28:29 --> URI Class Initialized
INFO - 2019-07-21 18:28:29 --> Router Class Initialized
INFO - 2019-07-21 18:28:29 --> Output Class Initialized
INFO - 2019-07-21 18:28:29 --> Security Class Initialized
DEBUG - 2019-07-21 18:28:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 18:28:29 --> Input Class Initialized
INFO - 2019-07-21 18:28:29 --> Language Class Initialized
INFO - 2019-07-21 18:28:29 --> Loader Class Initialized
INFO - 2019-07-21 18:28:29 --> Database Driver Class Initialized
INFO - 2019-07-21 18:28:29 --> Controller Class Initialized
INFO - 2019-07-21 18:28:29 --> Model "Product" initialized
INFO - 2019-07-21 18:28:29 --> Final output sent to browser
DEBUG - 2019-07-21 18:28:29 --> Total execution time: 0.0215
INFO - 2019-07-21 18:29:11 --> Config Class Initialized
INFO - 2019-07-21 18:29:11 --> Hooks Class Initialized
DEBUG - 2019-07-21 18:29:11 --> UTF-8 Support Enabled
INFO - 2019-07-21 18:29:11 --> Utf8 Class Initialized
INFO - 2019-07-21 18:29:11 --> URI Class Initialized
INFO - 2019-07-21 18:29:11 --> Router Class Initialized
INFO - 2019-07-21 18:29:11 --> Output Class Initialized
INFO - 2019-07-21 18:29:11 --> Security Class Initialized
DEBUG - 2019-07-21 18:29:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 18:29:11 --> Input Class Initialized
INFO - 2019-07-21 18:29:11 --> Language Class Initialized
INFO - 2019-07-21 18:29:11 --> Loader Class Initialized
INFO - 2019-07-21 18:29:11 --> Database Driver Class Initialized
INFO - 2019-07-21 18:29:11 --> Controller Class Initialized
INFO - 2019-07-21 18:29:11 --> Model "Product" initialized
INFO - 2019-07-21 18:29:11 --> Final output sent to browser
DEBUG - 2019-07-21 18:29:11 --> Total execution time: 0.0194
INFO - 2019-07-21 18:29:12 --> Config Class Initialized
INFO - 2019-07-21 18:29:12 --> Hooks Class Initialized
DEBUG - 2019-07-21 18:29:12 --> UTF-8 Support Enabled
INFO - 2019-07-21 18:29:12 --> Utf8 Class Initialized
INFO - 2019-07-21 18:29:12 --> URI Class Initialized
INFO - 2019-07-21 18:29:12 --> Router Class Initialized
INFO - 2019-07-21 18:29:12 --> Output Class Initialized
INFO - 2019-07-21 18:29:12 --> Security Class Initialized
DEBUG - 2019-07-21 18:29:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-21 18:29:12 --> Input Class Initialized
INFO - 2019-07-21 18:29:12 --> Language Class Initialized
INFO - 2019-07-21 18:29:12 --> Loader Class Initialized
INFO - 2019-07-21 18:29:12 --> Database Driver Class Initialized
INFO - 2019-07-21 18:29:12 --> Controller Class Initialized
INFO - 2019-07-21 18:29:12 --> Model "Product" initialized
INFO - 2019-07-21 18:29:12 --> Final output sent to browser
DEBUG - 2019-07-21 18:29:12 --> Total execution time: 0.0207
