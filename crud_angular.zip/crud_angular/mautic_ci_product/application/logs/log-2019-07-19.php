<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2019-07-19 16:05:30 --> Config Class Initialized
INFO - 2019-07-19 16:05:30 --> Hooks Class Initialized
DEBUG - 2019-07-19 16:05:30 --> UTF-8 Support Enabled
INFO - 2019-07-19 16:05:30 --> Utf8 Class Initialized
INFO - 2019-07-19 16:05:30 --> URI Class Initialized
INFO - 2019-07-19 16:05:30 --> Router Class Initialized
INFO - 2019-07-19 16:05:30 --> Output Class Initialized
INFO - 2019-07-19 16:05:30 --> Security Class Initialized
DEBUG - 2019-07-19 16:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 16:05:30 --> Input Class Initialized
INFO - 2019-07-19 16:05:30 --> Language Class Initialized
INFO - 2019-07-19 16:05:30 --> Loader Class Initialized
INFO - 2019-07-19 16:05:30 --> Controller Class Initialized
INFO - 2019-07-19 16:05:30 --> Model "Product" initialized
ERROR - 2019-07-19 16:05:30 --> Severity: Notice --> Undefined property: Welcome::$db /var/www/html/mohan/dummy/mautic_ci_product/system/core/Model.php 73
ERROR - 2019-07-19 16:05:30 --> Severity: Error --> Call to a member function insert() on null /var/www/html/mohan/dummy/mautic_ci_product/application/models/Product.php 7
INFO - 2019-07-19 16:09:59 --> Config Class Initialized
INFO - 2019-07-19 16:09:59 --> Hooks Class Initialized
DEBUG - 2019-07-19 16:09:59 --> UTF-8 Support Enabled
INFO - 2019-07-19 16:09:59 --> Utf8 Class Initialized
INFO - 2019-07-19 16:09:59 --> URI Class Initialized
INFO - 2019-07-19 16:09:59 --> Router Class Initialized
INFO - 2019-07-19 16:09:59 --> Output Class Initialized
INFO - 2019-07-19 16:09:59 --> Security Class Initialized
DEBUG - 2019-07-19 16:09:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 16:09:59 --> Input Class Initialized
INFO - 2019-07-19 16:09:59 --> Language Class Initialized
INFO - 2019-07-19 16:09:59 --> Loader Class Initialized
INFO - 2019-07-19 16:09:59 --> Controller Class Initialized
INFO - 2019-07-19 16:09:59 --> Model "Product" initialized
INFO - 2019-07-19 16:09:59 --> Database Driver Class Initialized
INFO - 2019-07-19 16:09:59 --> Final output sent to browser
DEBUG - 2019-07-19 16:09:59 --> Total execution time: 0.2899
INFO - 2019-07-19 16:13:31 --> Config Class Initialized
INFO - 2019-07-19 16:13:31 --> Hooks Class Initialized
DEBUG - 2019-07-19 16:13:31 --> UTF-8 Support Enabled
INFO - 2019-07-19 16:13:31 --> Utf8 Class Initialized
INFO - 2019-07-19 16:13:31 --> URI Class Initialized
INFO - 2019-07-19 16:13:31 --> Router Class Initialized
INFO - 2019-07-19 16:13:31 --> Output Class Initialized
INFO - 2019-07-19 16:13:31 --> Security Class Initialized
DEBUG - 2019-07-19 16:13:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 16:13:31 --> Input Class Initialized
INFO - 2019-07-19 16:13:31 --> Language Class Initialized
INFO - 2019-07-19 16:13:31 --> Loader Class Initialized
INFO - 2019-07-19 16:13:31 --> Database Driver Class Initialized
INFO - 2019-07-19 16:13:31 --> Controller Class Initialized
INFO - 2019-07-19 16:13:31 --> Model "Product" initialized
INFO - 2019-07-19 16:13:31 --> Final output sent to browser
DEBUG - 2019-07-19 16:13:31 --> Total execution time: 0.0553
INFO - 2019-07-19 16:18:45 --> Config Class Initialized
INFO - 2019-07-19 16:18:45 --> Hooks Class Initialized
DEBUG - 2019-07-19 16:18:45 --> UTF-8 Support Enabled
INFO - 2019-07-19 16:18:45 --> Utf8 Class Initialized
INFO - 2019-07-19 16:18:45 --> URI Class Initialized
INFO - 2019-07-19 16:18:45 --> Router Class Initialized
INFO - 2019-07-19 16:18:45 --> Output Class Initialized
INFO - 2019-07-19 16:18:45 --> Security Class Initialized
DEBUG - 2019-07-19 16:18:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 16:18:45 --> Input Class Initialized
INFO - 2019-07-19 16:18:45 --> Language Class Initialized
INFO - 2019-07-19 16:18:45 --> Loader Class Initialized
INFO - 2019-07-19 16:18:45 --> Database Driver Class Initialized
INFO - 2019-07-19 16:18:45 --> Controller Class Initialized
INFO - 2019-07-19 16:18:45 --> Model "Product" initialized
INFO - 2019-07-19 16:18:46 --> Final output sent to browser
DEBUG - 2019-07-19 16:18:46 --> Total execution time: 0.0629
INFO - 2019-07-19 16:19:02 --> Config Class Initialized
INFO - 2019-07-19 16:19:02 --> Hooks Class Initialized
DEBUG - 2019-07-19 16:19:02 --> UTF-8 Support Enabled
INFO - 2019-07-19 16:19:02 --> Utf8 Class Initialized
INFO - 2019-07-19 16:19:02 --> URI Class Initialized
INFO - 2019-07-19 16:19:02 --> Router Class Initialized
INFO - 2019-07-19 16:19:02 --> Output Class Initialized
INFO - 2019-07-19 16:19:02 --> Security Class Initialized
DEBUG - 2019-07-19 16:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 16:19:02 --> Input Class Initialized
INFO - 2019-07-19 16:19:02 --> Language Class Initialized
INFO - 2019-07-19 16:19:02 --> Loader Class Initialized
INFO - 2019-07-19 16:19:02 --> Database Driver Class Initialized
INFO - 2019-07-19 16:19:02 --> Controller Class Initialized
INFO - 2019-07-19 16:19:02 --> Model "Product" initialized
ERROR - 2019-07-19 16:19:02 --> Severity: Notice --> Undefined index: name /var/www/html/mohan/dummy/mautic_ci_product/application/controllers/Welcome.php 39
ERROR - 2019-07-19 16:19:02 --> Severity: Notice --> Undefined index: email /var/www/html/mohan/dummy/mautic_ci_product/application/controllers/Welcome.php 40
ERROR - 2019-07-19 16:19:02 --> Query error: Column 'name' cannot be null - Invalid query: INSERT INTO `prod_signup` (`name`, `email`) VALUES (NULL, NULL)
INFO - 2019-07-19 16:19:02 --> Language file loaded: language/english/db_lang.php
INFO - 2019-07-19 17:40:28 --> Config Class Initialized
INFO - 2019-07-19 17:40:28 --> Hooks Class Initialized
DEBUG - 2019-07-19 17:40:28 --> UTF-8 Support Enabled
INFO - 2019-07-19 17:40:28 --> Utf8 Class Initialized
INFO - 2019-07-19 17:40:28 --> URI Class Initialized
INFO - 2019-07-19 17:40:28 --> Router Class Initialized
INFO - 2019-07-19 17:40:28 --> Output Class Initialized
INFO - 2019-07-19 17:40:28 --> Security Class Initialized
DEBUG - 2019-07-19 17:40:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 17:40:28 --> Input Class Initialized
INFO - 2019-07-19 17:40:28 --> Language Class Initialized
INFO - 2019-07-19 17:40:28 --> Loader Class Initialized
INFO - 2019-07-19 17:40:28 --> Database Driver Class Initialized
INFO - 2019-07-19 17:40:30 --> Config Class Initialized
INFO - 2019-07-19 17:40:30 --> Hooks Class Initialized
DEBUG - 2019-07-19 17:40:30 --> UTF-8 Support Enabled
INFO - 2019-07-19 17:40:30 --> Utf8 Class Initialized
INFO - 2019-07-19 17:40:30 --> URI Class Initialized
INFO - 2019-07-19 17:40:30 --> Router Class Initialized
INFO - 2019-07-19 17:40:30 --> Output Class Initialized
INFO - 2019-07-19 17:40:30 --> Security Class Initialized
DEBUG - 2019-07-19 17:40:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 17:40:30 --> Input Class Initialized
INFO - 2019-07-19 17:40:30 --> Language Class Initialized
INFO - 2019-07-19 17:40:30 --> Loader Class Initialized
INFO - 2019-07-19 17:40:30 --> Database Driver Class Initialized
INFO - 2019-07-19 17:40:36 --> Controller Class Initialized
INFO - 2019-07-19 17:40:36 --> Controller Class Initialized
INFO - 2019-07-19 17:40:36 --> Model "Product" initialized
INFO - 2019-07-19 17:40:36 --> Model "Product" initialized
ERROR - 2019-07-19 17:40:36 --> Severity: Notice --> Undefined index: name /var/www/html/mohan/dummy/mautic_ci_product/application/controllers/Welcome.php 39
ERROR - 2019-07-19 17:40:36 --> Severity: Notice --> Undefined index: name /var/www/html/mohan/dummy/mautic_ci_product/application/controllers/Welcome.php 39
ERROR - 2019-07-19 17:40:36 --> Severity: Notice --> Undefined index: email /var/www/html/mohan/dummy/mautic_ci_product/application/controllers/Welcome.php 40
ERROR - 2019-07-19 17:40:36 --> Severity: Notice --> Undefined index: email /var/www/html/mohan/dummy/mautic_ci_product/application/controllers/Welcome.php 40
ERROR - 2019-07-19 17:40:37 --> Query error: Column 'name' cannot be null - Invalid query: INSERT INTO `prod_signup` (`name`, `email`) VALUES (NULL, NULL)
INFO - 2019-07-19 17:40:37 --> Language file loaded: language/english/db_lang.php
ERROR - 2019-07-19 17:40:37 --> Query error: Column 'name' cannot be null - Invalid query: INSERT INTO `prod_signup` (`name`, `email`) VALUES (NULL, NULL)
INFO - 2019-07-19 17:40:37 --> Language file loaded: language/english/db_lang.php
INFO - 2019-07-19 17:40:38 --> Config Class Initialized
INFO - 2019-07-19 17:40:38 --> Hooks Class Initialized
DEBUG - 2019-07-19 17:40:38 --> UTF-8 Support Enabled
INFO - 2019-07-19 17:40:38 --> Utf8 Class Initialized
INFO - 2019-07-19 17:40:38 --> URI Class Initialized
INFO - 2019-07-19 17:40:38 --> Router Class Initialized
INFO - 2019-07-19 17:40:38 --> Output Class Initialized
INFO - 2019-07-19 17:40:38 --> Security Class Initialized
DEBUG - 2019-07-19 17:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 17:40:38 --> Input Class Initialized
INFO - 2019-07-19 17:40:38 --> Language Class Initialized
INFO - 2019-07-19 17:40:38 --> Loader Class Initialized
INFO - 2019-07-19 17:40:38 --> Database Driver Class Initialized
INFO - 2019-07-19 17:40:38 --> Controller Class Initialized
INFO - 2019-07-19 17:40:38 --> Model "Product" initialized
ERROR - 2019-07-19 17:40:38 --> Severity: Notice --> Undefined index: name /var/www/html/mohan/dummy/mautic_ci_product/application/controllers/Welcome.php 39
ERROR - 2019-07-19 17:40:38 --> Severity: Notice --> Undefined index: email /var/www/html/mohan/dummy/mautic_ci_product/application/controllers/Welcome.php 40
ERROR - 2019-07-19 17:40:38 --> Query error: Column 'name' cannot be null - Invalid query: INSERT INTO `prod_signup` (`name`, `email`) VALUES (NULL, NULL)
INFO - 2019-07-19 17:40:38 --> Language file loaded: language/english/db_lang.php
INFO - 2019-07-19 17:40:58 --> Config Class Initialized
INFO - 2019-07-19 17:40:58 --> Hooks Class Initialized
DEBUG - 2019-07-19 17:40:58 --> UTF-8 Support Enabled
INFO - 2019-07-19 17:40:58 --> Utf8 Class Initialized
INFO - 2019-07-19 17:40:58 --> URI Class Initialized
INFO - 2019-07-19 17:40:58 --> Router Class Initialized
INFO - 2019-07-19 17:40:58 --> Output Class Initialized
INFO - 2019-07-19 17:40:58 --> Security Class Initialized
DEBUG - 2019-07-19 17:40:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 17:40:58 --> Input Class Initialized
INFO - 2019-07-19 17:40:58 --> Language Class Initialized
INFO - 2019-07-19 17:40:58 --> Loader Class Initialized
INFO - 2019-07-19 17:40:58 --> Database Driver Class Initialized
INFO - 2019-07-19 17:41:02 --> Controller Class Initialized
INFO - 2019-07-19 17:41:02 --> Model "Product" initialized
ERROR - 2019-07-19 17:41:02 --> Severity: Notice --> Undefined index: name /var/www/html/mohan/dummy/mautic_ci_product/application/controllers/Welcome.php 39
ERROR - 2019-07-19 17:41:02 --> Severity: Notice --> Undefined index: email /var/www/html/mohan/dummy/mautic_ci_product/application/controllers/Welcome.php 40
ERROR - 2019-07-19 17:41:02 --> Query error: Column 'name' cannot be null - Invalid query: INSERT INTO `prod_signup` (`name`, `email`) VALUES (NULL, NULL)
INFO - 2019-07-19 17:41:02 --> Language file loaded: language/english/db_lang.php
INFO - 2019-07-19 17:42:42 --> Config Class Initialized
INFO - 2019-07-19 17:42:42 --> Hooks Class Initialized
DEBUG - 2019-07-19 17:42:42 --> UTF-8 Support Enabled
INFO - 2019-07-19 17:42:42 --> Utf8 Class Initialized
INFO - 2019-07-19 17:42:42 --> URI Class Initialized
INFO - 2019-07-19 17:42:42 --> Router Class Initialized
INFO - 2019-07-19 17:42:42 --> Output Class Initialized
INFO - 2019-07-19 17:42:42 --> Security Class Initialized
DEBUG - 2019-07-19 17:42:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 17:42:42 --> Input Class Initialized
INFO - 2019-07-19 17:42:42 --> Language Class Initialized
INFO - 2019-07-19 17:42:42 --> Loader Class Initialized
INFO - 2019-07-19 17:42:42 --> Database Driver Class Initialized
INFO - 2019-07-19 17:42:42 --> Controller Class Initialized
INFO - 2019-07-19 17:42:42 --> Model "Product" initialized
INFO - 2019-07-19 17:42:46 --> Final output sent to browser
DEBUG - 2019-07-19 17:42:46 --> Total execution time: 4.0886
INFO - 2019-07-19 17:45:48 --> Config Class Initialized
INFO - 2019-07-19 17:45:48 --> Hooks Class Initialized
DEBUG - 2019-07-19 17:45:48 --> UTF-8 Support Enabled
INFO - 2019-07-19 17:45:48 --> Utf8 Class Initialized
INFO - 2019-07-19 17:45:48 --> URI Class Initialized
INFO - 2019-07-19 17:45:48 --> Router Class Initialized
INFO - 2019-07-19 17:45:48 --> Output Class Initialized
INFO - 2019-07-19 17:45:48 --> Security Class Initialized
DEBUG - 2019-07-19 17:45:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 17:45:48 --> Input Class Initialized
INFO - 2019-07-19 17:45:48 --> Language Class Initialized
INFO - 2019-07-19 17:45:48 --> Loader Class Initialized
INFO - 2019-07-19 17:45:48 --> Database Driver Class Initialized
INFO - 2019-07-19 17:45:48 --> Controller Class Initialized
INFO - 2019-07-19 17:45:48 --> Model "Product" initialized
INFO - 2019-07-19 17:45:48 --> Final output sent to browser
DEBUG - 2019-07-19 17:45:48 --> Total execution time: 0.1234
INFO - 2019-07-19 17:46:20 --> Config Class Initialized
INFO - 2019-07-19 17:46:20 --> Hooks Class Initialized
DEBUG - 2019-07-19 17:46:20 --> UTF-8 Support Enabled
INFO - 2019-07-19 17:46:20 --> Utf8 Class Initialized
INFO - 2019-07-19 17:46:20 --> URI Class Initialized
INFO - 2019-07-19 17:46:20 --> Router Class Initialized
INFO - 2019-07-19 17:46:20 --> Output Class Initialized
INFO - 2019-07-19 17:46:20 --> Security Class Initialized
DEBUG - 2019-07-19 17:46:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 17:46:20 --> Input Class Initialized
INFO - 2019-07-19 17:46:20 --> Language Class Initialized
INFO - 2019-07-19 17:46:20 --> Loader Class Initialized
INFO - 2019-07-19 17:46:20 --> Database Driver Class Initialized
INFO - 2019-07-19 17:46:20 --> Controller Class Initialized
INFO - 2019-07-19 17:46:20 --> Model "Product" initialized
INFO - 2019-07-19 17:46:20 --> Final output sent to browser
DEBUG - 2019-07-19 17:46:20 --> Total execution time: 0.0829
INFO - 2019-07-19 17:53:08 --> Config Class Initialized
INFO - 2019-07-19 17:53:08 --> Hooks Class Initialized
DEBUG - 2019-07-19 17:53:08 --> UTF-8 Support Enabled
INFO - 2019-07-19 17:53:08 --> Utf8 Class Initialized
INFO - 2019-07-19 17:53:08 --> URI Class Initialized
INFO - 2019-07-19 17:53:08 --> Router Class Initialized
INFO - 2019-07-19 17:53:08 --> Output Class Initialized
INFO - 2019-07-19 17:53:08 --> Security Class Initialized
DEBUG - 2019-07-19 17:53:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 17:53:08 --> Input Class Initialized
INFO - 2019-07-19 17:53:08 --> Language Class Initialized
INFO - 2019-07-19 17:53:08 --> Loader Class Initialized
INFO - 2019-07-19 17:53:08 --> Database Driver Class Initialized
INFO - 2019-07-19 17:53:08 --> Controller Class Initialized
INFO - 2019-07-19 17:53:08 --> Model "Product" initialized
INFO - 2019-07-19 17:53:08 --> Final output sent to browser
DEBUG - 2019-07-19 17:53:08 --> Total execution time: 0.1158
INFO - 2019-07-19 17:53:08 --> Config Class Initialized
INFO - 2019-07-19 17:53:08 --> Hooks Class Initialized
DEBUG - 2019-07-19 17:53:08 --> UTF-8 Support Enabled
INFO - 2019-07-19 17:53:08 --> Utf8 Class Initialized
INFO - 2019-07-19 17:53:08 --> URI Class Initialized
INFO - 2019-07-19 17:53:08 --> Router Class Initialized
INFO - 2019-07-19 17:53:08 --> Output Class Initialized
INFO - 2019-07-19 17:53:08 --> Security Class Initialized
DEBUG - 2019-07-19 17:53:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 17:53:08 --> Input Class Initialized
INFO - 2019-07-19 17:53:08 --> Language Class Initialized
INFO - 2019-07-19 17:53:08 --> Loader Class Initialized
INFO - 2019-07-19 17:53:08 --> Database Driver Class Initialized
INFO - 2019-07-19 17:53:08 --> Controller Class Initialized
INFO - 2019-07-19 17:53:08 --> Model "Product" initialized
INFO - 2019-07-19 17:53:08 --> Final output sent to browser
DEBUG - 2019-07-19 17:53:08 --> Total execution time: 0.0957
INFO - 2019-07-19 17:53:55 --> Config Class Initialized
INFO - 2019-07-19 17:53:55 --> Hooks Class Initialized
DEBUG - 2019-07-19 17:53:55 --> UTF-8 Support Enabled
INFO - 2019-07-19 17:53:55 --> Utf8 Class Initialized
INFO - 2019-07-19 17:53:55 --> URI Class Initialized
INFO - 2019-07-19 17:53:55 --> Router Class Initialized
INFO - 2019-07-19 17:53:55 --> Output Class Initialized
INFO - 2019-07-19 17:53:55 --> Security Class Initialized
DEBUG - 2019-07-19 17:53:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 17:53:55 --> Input Class Initialized
INFO - 2019-07-19 17:53:55 --> Language Class Initialized
INFO - 2019-07-19 17:53:55 --> Loader Class Initialized
INFO - 2019-07-19 17:53:55 --> Database Driver Class Initialized
INFO - 2019-07-19 17:53:55 --> Controller Class Initialized
INFO - 2019-07-19 17:53:55 --> Model "Product" initialized
INFO - 2019-07-19 17:53:55 --> Final output sent to browser
DEBUG - 2019-07-19 17:53:55 --> Total execution time: 0.0987
INFO - 2019-07-19 17:53:55 --> Config Class Initialized
INFO - 2019-07-19 17:53:55 --> Hooks Class Initialized
DEBUG - 2019-07-19 17:53:55 --> UTF-8 Support Enabled
INFO - 2019-07-19 17:53:55 --> Utf8 Class Initialized
INFO - 2019-07-19 17:53:55 --> URI Class Initialized
INFO - 2019-07-19 17:53:55 --> Router Class Initialized
INFO - 2019-07-19 17:53:55 --> Output Class Initialized
INFO - 2019-07-19 17:53:55 --> Security Class Initialized
DEBUG - 2019-07-19 17:53:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 17:53:55 --> Input Class Initialized
INFO - 2019-07-19 17:53:55 --> Language Class Initialized
INFO - 2019-07-19 17:53:55 --> Loader Class Initialized
INFO - 2019-07-19 17:53:55 --> Database Driver Class Initialized
INFO - 2019-07-19 17:53:55 --> Controller Class Initialized
INFO - 2019-07-19 17:53:55 --> Model "Product" initialized
INFO - 2019-07-19 17:53:55 --> Final output sent to browser
DEBUG - 2019-07-19 17:53:55 --> Total execution time: 0.0860
INFO - 2019-07-19 17:55:21 --> Config Class Initialized
INFO - 2019-07-19 17:55:21 --> Hooks Class Initialized
DEBUG - 2019-07-19 17:55:21 --> UTF-8 Support Enabled
INFO - 2019-07-19 17:55:21 --> Utf8 Class Initialized
INFO - 2019-07-19 17:55:21 --> URI Class Initialized
INFO - 2019-07-19 17:55:21 --> Router Class Initialized
INFO - 2019-07-19 17:55:21 --> Output Class Initialized
INFO - 2019-07-19 17:55:21 --> Security Class Initialized
DEBUG - 2019-07-19 17:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 17:55:21 --> Input Class Initialized
INFO - 2019-07-19 17:55:21 --> Language Class Initialized
INFO - 2019-07-19 17:55:21 --> Loader Class Initialized
INFO - 2019-07-19 17:55:21 --> Database Driver Class Initialized
INFO - 2019-07-19 17:55:21 --> Controller Class Initialized
INFO - 2019-07-19 17:55:21 --> Model "Product" initialized
INFO - 2019-07-19 17:55:21 --> Final output sent to browser
DEBUG - 2019-07-19 17:55:21 --> Total execution time: 0.1157
INFO - 2019-07-19 17:55:21 --> Config Class Initialized
INFO - 2019-07-19 17:55:21 --> Hooks Class Initialized
DEBUG - 2019-07-19 17:55:21 --> UTF-8 Support Enabled
INFO - 2019-07-19 17:55:21 --> Utf8 Class Initialized
INFO - 2019-07-19 17:55:21 --> URI Class Initialized
INFO - 2019-07-19 17:55:21 --> Router Class Initialized
INFO - 2019-07-19 17:55:21 --> Output Class Initialized
INFO - 2019-07-19 17:55:21 --> Security Class Initialized
DEBUG - 2019-07-19 17:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 17:55:21 --> Input Class Initialized
INFO - 2019-07-19 17:55:21 --> Language Class Initialized
INFO - 2019-07-19 17:55:21 --> Loader Class Initialized
INFO - 2019-07-19 17:55:21 --> Database Driver Class Initialized
INFO - 2019-07-19 17:55:21 --> Controller Class Initialized
INFO - 2019-07-19 17:55:21 --> Model "Product" initialized
INFO - 2019-07-19 17:55:21 --> Final output sent to browser
DEBUG - 2019-07-19 17:55:21 --> Total execution time: 0.0387
INFO - 2019-07-19 17:55:53 --> Config Class Initialized
INFO - 2019-07-19 17:55:53 --> Hooks Class Initialized
DEBUG - 2019-07-19 17:55:53 --> UTF-8 Support Enabled
INFO - 2019-07-19 17:55:53 --> Utf8 Class Initialized
INFO - 2019-07-19 17:55:53 --> URI Class Initialized
INFO - 2019-07-19 17:55:53 --> Router Class Initialized
INFO - 2019-07-19 17:55:53 --> Output Class Initialized
INFO - 2019-07-19 17:55:53 --> Security Class Initialized
DEBUG - 2019-07-19 17:55:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 17:55:53 --> Input Class Initialized
INFO - 2019-07-19 17:55:53 --> Language Class Initialized
INFO - 2019-07-19 17:55:53 --> Loader Class Initialized
INFO - 2019-07-19 17:55:53 --> Database Driver Class Initialized
INFO - 2019-07-19 17:55:53 --> Controller Class Initialized
INFO - 2019-07-19 17:55:53 --> Model "Product" initialized
INFO - 2019-07-19 17:55:53 --> Final output sent to browser
DEBUG - 2019-07-19 17:55:53 --> Total execution time: 0.0849
INFO - 2019-07-19 17:55:53 --> Config Class Initialized
INFO - 2019-07-19 17:55:53 --> Hooks Class Initialized
DEBUG - 2019-07-19 17:55:53 --> UTF-8 Support Enabled
INFO - 2019-07-19 17:55:53 --> Utf8 Class Initialized
INFO - 2019-07-19 17:55:53 --> URI Class Initialized
INFO - 2019-07-19 17:55:53 --> Router Class Initialized
INFO - 2019-07-19 17:55:53 --> Output Class Initialized
INFO - 2019-07-19 17:55:53 --> Security Class Initialized
DEBUG - 2019-07-19 17:55:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 17:55:53 --> Input Class Initialized
INFO - 2019-07-19 17:55:53 --> Language Class Initialized
INFO - 2019-07-19 17:55:53 --> Loader Class Initialized
INFO - 2019-07-19 17:55:53 --> Database Driver Class Initialized
INFO - 2019-07-19 17:55:53 --> Controller Class Initialized
INFO - 2019-07-19 17:55:53 --> Model "Product" initialized
INFO - 2019-07-19 17:55:53 --> Final output sent to browser
DEBUG - 2019-07-19 17:55:53 --> Total execution time: 0.0508
INFO - 2019-07-19 17:56:22 --> Config Class Initialized
INFO - 2019-07-19 17:56:22 --> Hooks Class Initialized
DEBUG - 2019-07-19 17:56:22 --> UTF-8 Support Enabled
INFO - 2019-07-19 17:56:22 --> Utf8 Class Initialized
INFO - 2019-07-19 17:56:22 --> URI Class Initialized
INFO - 2019-07-19 17:56:22 --> Router Class Initialized
INFO - 2019-07-19 17:56:22 --> Output Class Initialized
INFO - 2019-07-19 17:56:22 --> Security Class Initialized
DEBUG - 2019-07-19 17:56:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 17:56:22 --> Input Class Initialized
INFO - 2019-07-19 17:56:22 --> Language Class Initialized
INFO - 2019-07-19 17:56:22 --> Loader Class Initialized
INFO - 2019-07-19 17:56:22 --> Database Driver Class Initialized
INFO - 2019-07-19 17:56:22 --> Controller Class Initialized
INFO - 2019-07-19 17:56:22 --> Model "Product" initialized
INFO - 2019-07-19 17:56:22 --> Config Class Initialized
INFO - 2019-07-19 17:56:22 --> Hooks Class Initialized
DEBUG - 2019-07-19 17:56:22 --> UTF-8 Support Enabled
INFO - 2019-07-19 17:56:22 --> Utf8 Class Initialized
INFO - 2019-07-19 17:56:22 --> URI Class Initialized
INFO - 2019-07-19 17:56:22 --> Router Class Initialized
INFO - 2019-07-19 17:56:22 --> Output Class Initialized
INFO - 2019-07-19 17:56:22 --> Security Class Initialized
DEBUG - 2019-07-19 17:56:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 17:56:22 --> Input Class Initialized
INFO - 2019-07-19 17:56:22 --> Language Class Initialized
INFO - 2019-07-19 17:56:22 --> Loader Class Initialized
INFO - 2019-07-19 17:56:22 --> Database Driver Class Initialized
INFO - 2019-07-19 17:56:22 --> Controller Class Initialized
INFO - 2019-07-19 17:56:22 --> Model "Product" initialized
INFO - 2019-07-19 17:57:11 --> Config Class Initialized
INFO - 2019-07-19 17:57:11 --> Hooks Class Initialized
DEBUG - 2019-07-19 17:57:11 --> UTF-8 Support Enabled
INFO - 2019-07-19 17:57:11 --> Utf8 Class Initialized
INFO - 2019-07-19 17:57:11 --> URI Class Initialized
INFO - 2019-07-19 17:57:11 --> Router Class Initialized
INFO - 2019-07-19 17:57:11 --> Output Class Initialized
INFO - 2019-07-19 17:57:11 --> Security Class Initialized
DEBUG - 2019-07-19 17:57:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 17:57:11 --> Input Class Initialized
INFO - 2019-07-19 17:57:11 --> Language Class Initialized
INFO - 2019-07-19 17:57:11 --> Loader Class Initialized
INFO - 2019-07-19 17:57:11 --> Database Driver Class Initialized
INFO - 2019-07-19 17:57:11 --> Controller Class Initialized
INFO - 2019-07-19 17:57:11 --> Model "Product" initialized
INFO - 2019-07-19 17:57:11 --> Config Class Initialized
INFO - 2019-07-19 17:57:11 --> Hooks Class Initialized
DEBUG - 2019-07-19 17:57:11 --> UTF-8 Support Enabled
INFO - 2019-07-19 17:57:11 --> Utf8 Class Initialized
INFO - 2019-07-19 17:57:11 --> URI Class Initialized
INFO - 2019-07-19 17:57:11 --> Router Class Initialized
INFO - 2019-07-19 17:57:11 --> Output Class Initialized
INFO - 2019-07-19 17:57:11 --> Security Class Initialized
DEBUG - 2019-07-19 17:57:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 17:57:11 --> Input Class Initialized
INFO - 2019-07-19 17:57:11 --> Language Class Initialized
INFO - 2019-07-19 17:57:11 --> Loader Class Initialized
INFO - 2019-07-19 17:57:11 --> Database Driver Class Initialized
INFO - 2019-07-19 17:57:11 --> Controller Class Initialized
INFO - 2019-07-19 17:57:11 --> Model "Product" initialized
INFO - 2019-07-19 17:58:06 --> Config Class Initialized
INFO - 2019-07-19 17:58:06 --> Hooks Class Initialized
DEBUG - 2019-07-19 17:58:06 --> UTF-8 Support Enabled
INFO - 2019-07-19 17:58:06 --> Utf8 Class Initialized
INFO - 2019-07-19 17:58:06 --> URI Class Initialized
INFO - 2019-07-19 17:58:06 --> Router Class Initialized
INFO - 2019-07-19 17:58:06 --> Output Class Initialized
INFO - 2019-07-19 17:58:06 --> Security Class Initialized
DEBUG - 2019-07-19 17:58:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 17:58:06 --> Input Class Initialized
INFO - 2019-07-19 17:58:06 --> Language Class Initialized
INFO - 2019-07-19 17:58:06 --> Loader Class Initialized
INFO - 2019-07-19 17:58:06 --> Database Driver Class Initialized
INFO - 2019-07-19 17:58:06 --> Controller Class Initialized
INFO - 2019-07-19 17:58:06 --> Model "Product" initialized
INFO - 2019-07-19 17:58:06 --> Config Class Initialized
INFO - 2019-07-19 17:58:06 --> Hooks Class Initialized
DEBUG - 2019-07-19 17:58:06 --> UTF-8 Support Enabled
INFO - 2019-07-19 17:58:06 --> Utf8 Class Initialized
INFO - 2019-07-19 17:58:06 --> URI Class Initialized
INFO - 2019-07-19 17:58:06 --> Router Class Initialized
INFO - 2019-07-19 17:58:06 --> Output Class Initialized
INFO - 2019-07-19 17:58:06 --> Security Class Initialized
DEBUG - 2019-07-19 17:58:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 17:58:06 --> Input Class Initialized
INFO - 2019-07-19 17:58:06 --> Language Class Initialized
INFO - 2019-07-19 17:58:06 --> Loader Class Initialized
INFO - 2019-07-19 17:58:06 --> Database Driver Class Initialized
INFO - 2019-07-19 17:58:06 --> Controller Class Initialized
INFO - 2019-07-19 17:58:06 --> Model "Product" initialized
INFO - 2019-07-19 18:10:39 --> Config Class Initialized
INFO - 2019-07-19 18:10:39 --> Hooks Class Initialized
DEBUG - 2019-07-19 18:10:39 --> UTF-8 Support Enabled
INFO - 2019-07-19 18:10:39 --> Utf8 Class Initialized
INFO - 2019-07-19 18:10:39 --> URI Class Initialized
INFO - 2019-07-19 18:10:39 --> Router Class Initialized
INFO - 2019-07-19 18:10:39 --> Output Class Initialized
INFO - 2019-07-19 18:10:39 --> Security Class Initialized
DEBUG - 2019-07-19 18:10:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 18:10:39 --> Input Class Initialized
INFO - 2019-07-19 18:10:39 --> Language Class Initialized
INFO - 2019-07-19 18:10:39 --> Loader Class Initialized
INFO - 2019-07-19 18:10:39 --> Database Driver Class Initialized
INFO - 2019-07-19 18:10:39 --> Controller Class Initialized
INFO - 2019-07-19 18:10:39 --> Model "Product" initialized
INFO - 2019-07-19 18:10:39 --> Final output sent to browser
DEBUG - 2019-07-19 18:10:39 --> Total execution time: 0.1316
INFO - 2019-07-19 18:10:39 --> Config Class Initialized
INFO - 2019-07-19 18:10:39 --> Hooks Class Initialized
DEBUG - 2019-07-19 18:10:39 --> UTF-8 Support Enabled
INFO - 2019-07-19 18:10:39 --> Utf8 Class Initialized
INFO - 2019-07-19 18:10:39 --> URI Class Initialized
INFO - 2019-07-19 18:10:39 --> Router Class Initialized
INFO - 2019-07-19 18:10:39 --> Output Class Initialized
INFO - 2019-07-19 18:10:39 --> Security Class Initialized
DEBUG - 2019-07-19 18:10:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 18:10:39 --> Input Class Initialized
INFO - 2019-07-19 18:10:39 --> Language Class Initialized
INFO - 2019-07-19 18:10:39 --> Loader Class Initialized
INFO - 2019-07-19 18:10:39 --> Database Driver Class Initialized
INFO - 2019-07-19 18:10:39 --> Controller Class Initialized
INFO - 2019-07-19 18:10:39 --> Model "Product" initialized
INFO - 2019-07-19 18:10:39 --> Final output sent to browser
DEBUG - 2019-07-19 18:10:39 --> Total execution time: 0.0602
INFO - 2019-07-19 18:12:14 --> Config Class Initialized
INFO - 2019-07-19 18:12:14 --> Hooks Class Initialized
DEBUG - 2019-07-19 18:12:14 --> UTF-8 Support Enabled
INFO - 2019-07-19 18:12:14 --> Utf8 Class Initialized
INFO - 2019-07-19 18:12:14 --> URI Class Initialized
INFO - 2019-07-19 18:12:14 --> Router Class Initialized
INFO - 2019-07-19 18:12:14 --> Output Class Initialized
INFO - 2019-07-19 18:12:14 --> Security Class Initialized
DEBUG - 2019-07-19 18:12:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 18:12:14 --> Input Class Initialized
INFO - 2019-07-19 18:12:14 --> Language Class Initialized
INFO - 2019-07-19 18:12:14 --> Loader Class Initialized
INFO - 2019-07-19 18:12:14 --> Database Driver Class Initialized
INFO - 2019-07-19 18:12:14 --> Controller Class Initialized
INFO - 2019-07-19 18:12:14 --> Model "Product" initialized
INFO - 2019-07-19 18:12:14 --> Final output sent to browser
DEBUG - 2019-07-19 18:12:14 --> Total execution time: 0.0700
INFO - 2019-07-19 18:12:14 --> Config Class Initialized
INFO - 2019-07-19 18:12:14 --> Hooks Class Initialized
DEBUG - 2019-07-19 18:12:14 --> UTF-8 Support Enabled
INFO - 2019-07-19 18:12:14 --> Utf8 Class Initialized
INFO - 2019-07-19 18:12:14 --> URI Class Initialized
INFO - 2019-07-19 18:12:14 --> Router Class Initialized
INFO - 2019-07-19 18:12:14 --> Output Class Initialized
INFO - 2019-07-19 18:12:14 --> Security Class Initialized
DEBUG - 2019-07-19 18:12:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 18:12:14 --> Input Class Initialized
INFO - 2019-07-19 18:12:14 --> Language Class Initialized
INFO - 2019-07-19 18:12:14 --> Loader Class Initialized
INFO - 2019-07-19 18:12:14 --> Database Driver Class Initialized
INFO - 2019-07-19 18:12:14 --> Controller Class Initialized
INFO - 2019-07-19 18:12:14 --> Model "Product" initialized
INFO - 2019-07-19 18:12:14 --> Final output sent to browser
DEBUG - 2019-07-19 18:12:14 --> Total execution time: 0.0035
INFO - 2019-07-19 18:12:25 --> Config Class Initialized
INFO - 2019-07-19 18:12:25 --> Hooks Class Initialized
DEBUG - 2019-07-19 18:12:25 --> UTF-8 Support Enabled
INFO - 2019-07-19 18:12:25 --> Utf8 Class Initialized
INFO - 2019-07-19 18:12:25 --> URI Class Initialized
INFO - 2019-07-19 18:12:25 --> Router Class Initialized
INFO - 2019-07-19 18:12:25 --> Output Class Initialized
INFO - 2019-07-19 18:12:25 --> Security Class Initialized
DEBUG - 2019-07-19 18:12:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 18:12:25 --> Input Class Initialized
INFO - 2019-07-19 18:12:25 --> Language Class Initialized
INFO - 2019-07-19 18:12:25 --> Loader Class Initialized
INFO - 2019-07-19 18:12:25 --> Database Driver Class Initialized
INFO - 2019-07-19 18:12:25 --> Controller Class Initialized
INFO - 2019-07-19 18:12:25 --> Model "Product" initialized
INFO - 2019-07-19 18:12:25 --> Final output sent to browser
DEBUG - 2019-07-19 18:12:25 --> Total execution time: 0.0066
INFO - 2019-07-19 18:12:25 --> Config Class Initialized
INFO - 2019-07-19 18:12:25 --> Hooks Class Initialized
DEBUG - 2019-07-19 18:12:25 --> UTF-8 Support Enabled
INFO - 2019-07-19 18:12:25 --> Utf8 Class Initialized
INFO - 2019-07-19 18:12:25 --> URI Class Initialized
INFO - 2019-07-19 18:12:25 --> Router Class Initialized
INFO - 2019-07-19 18:12:25 --> Output Class Initialized
INFO - 2019-07-19 18:12:25 --> Security Class Initialized
DEBUG - 2019-07-19 18:12:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 18:12:25 --> Input Class Initialized
INFO - 2019-07-19 18:12:25 --> Language Class Initialized
INFO - 2019-07-19 18:12:25 --> Loader Class Initialized
INFO - 2019-07-19 18:12:25 --> Database Driver Class Initialized
INFO - 2019-07-19 18:12:25 --> Controller Class Initialized
INFO - 2019-07-19 18:12:25 --> Model "Product" initialized
INFO - 2019-07-19 18:12:25 --> Final output sent to browser
DEBUG - 2019-07-19 18:12:25 --> Total execution time: 0.0041
INFO - 2019-07-19 18:12:32 --> Config Class Initialized
INFO - 2019-07-19 18:12:32 --> Hooks Class Initialized
DEBUG - 2019-07-19 18:12:32 --> UTF-8 Support Enabled
INFO - 2019-07-19 18:12:32 --> Utf8 Class Initialized
INFO - 2019-07-19 18:12:32 --> URI Class Initialized
INFO - 2019-07-19 18:12:32 --> Router Class Initialized
INFO - 2019-07-19 18:12:32 --> Output Class Initialized
INFO - 2019-07-19 18:12:32 --> Security Class Initialized
DEBUG - 2019-07-19 18:12:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 18:12:32 --> Input Class Initialized
INFO - 2019-07-19 18:12:32 --> Language Class Initialized
INFO - 2019-07-19 18:12:32 --> Loader Class Initialized
INFO - 2019-07-19 18:12:32 --> Database Driver Class Initialized
INFO - 2019-07-19 18:12:32 --> Controller Class Initialized
INFO - 2019-07-19 18:12:32 --> Model "Product" initialized
INFO - 2019-07-19 18:12:32 --> Final output sent to browser
DEBUG - 2019-07-19 18:12:32 --> Total execution time: 0.0046
INFO - 2019-07-19 18:12:32 --> Config Class Initialized
INFO - 2019-07-19 18:12:32 --> Hooks Class Initialized
DEBUG - 2019-07-19 18:12:32 --> UTF-8 Support Enabled
INFO - 2019-07-19 18:12:32 --> Utf8 Class Initialized
INFO - 2019-07-19 18:12:32 --> URI Class Initialized
INFO - 2019-07-19 18:12:32 --> Router Class Initialized
INFO - 2019-07-19 18:12:32 --> Output Class Initialized
INFO - 2019-07-19 18:12:32 --> Security Class Initialized
DEBUG - 2019-07-19 18:12:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 18:12:32 --> Input Class Initialized
INFO - 2019-07-19 18:12:32 --> Language Class Initialized
INFO - 2019-07-19 18:12:32 --> Loader Class Initialized
INFO - 2019-07-19 18:12:32 --> Database Driver Class Initialized
INFO - 2019-07-19 18:12:32 --> Controller Class Initialized
INFO - 2019-07-19 18:12:32 --> Model "Product" initialized
INFO - 2019-07-19 18:12:32 --> Final output sent to browser
DEBUG - 2019-07-19 18:12:32 --> Total execution time: 0.0053
INFO - 2019-07-19 18:14:22 --> Config Class Initialized
INFO - 2019-07-19 18:14:22 --> Hooks Class Initialized
DEBUG - 2019-07-19 18:14:22 --> UTF-8 Support Enabled
INFO - 2019-07-19 18:14:22 --> Utf8 Class Initialized
INFO - 2019-07-19 18:14:22 --> URI Class Initialized
INFO - 2019-07-19 18:14:22 --> Router Class Initialized
INFO - 2019-07-19 18:14:22 --> Output Class Initialized
INFO - 2019-07-19 18:14:22 --> Security Class Initialized
DEBUG - 2019-07-19 18:14:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 18:14:22 --> Input Class Initialized
INFO - 2019-07-19 18:14:22 --> Language Class Initialized
INFO - 2019-07-19 18:14:22 --> Loader Class Initialized
INFO - 2019-07-19 18:14:22 --> Database Driver Class Initialized
INFO - 2019-07-19 18:14:22 --> Controller Class Initialized
INFO - 2019-07-19 18:14:22 --> Model "Product" initialized
INFO - 2019-07-19 18:14:22 --> Final output sent to browser
DEBUG - 2019-07-19 18:14:22 --> Total execution time: 0.0042
INFO - 2019-07-19 18:14:22 --> Config Class Initialized
INFO - 2019-07-19 18:14:22 --> Hooks Class Initialized
DEBUG - 2019-07-19 18:14:22 --> UTF-8 Support Enabled
INFO - 2019-07-19 18:14:22 --> Utf8 Class Initialized
INFO - 2019-07-19 18:14:22 --> URI Class Initialized
INFO - 2019-07-19 18:14:22 --> Router Class Initialized
INFO - 2019-07-19 18:14:22 --> Output Class Initialized
INFO - 2019-07-19 18:14:22 --> Security Class Initialized
DEBUG - 2019-07-19 18:14:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 18:14:22 --> Input Class Initialized
INFO - 2019-07-19 18:14:22 --> Language Class Initialized
INFO - 2019-07-19 18:14:22 --> Loader Class Initialized
INFO - 2019-07-19 18:14:22 --> Database Driver Class Initialized
INFO - 2019-07-19 18:14:22 --> Controller Class Initialized
INFO - 2019-07-19 18:14:22 --> Model "Product" initialized
INFO - 2019-07-19 18:14:22 --> Final output sent to browser
DEBUG - 2019-07-19 18:14:22 --> Total execution time: 0.0044
INFO - 2019-07-19 18:17:19 --> Config Class Initialized
INFO - 2019-07-19 18:17:19 --> Hooks Class Initialized
DEBUG - 2019-07-19 18:17:19 --> UTF-8 Support Enabled
INFO - 2019-07-19 18:17:19 --> Utf8 Class Initialized
INFO - 2019-07-19 18:17:19 --> URI Class Initialized
INFO - 2019-07-19 18:17:19 --> Router Class Initialized
INFO - 2019-07-19 18:17:19 --> Output Class Initialized
INFO - 2019-07-19 18:17:19 --> Security Class Initialized
DEBUG - 2019-07-19 18:17:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 18:17:19 --> Input Class Initialized
INFO - 2019-07-19 18:17:19 --> Language Class Initialized
INFO - 2019-07-19 18:17:19 --> Loader Class Initialized
INFO - 2019-07-19 18:17:19 --> Database Driver Class Initialized
INFO - 2019-07-19 18:17:19 --> Controller Class Initialized
INFO - 2019-07-19 18:17:19 --> Model "Product" initialized
INFO - 2019-07-19 18:17:19 --> Final output sent to browser
DEBUG - 2019-07-19 18:17:19 --> Total execution time: 0.0564
INFO - 2019-07-19 18:17:19 --> Config Class Initialized
INFO - 2019-07-19 18:17:19 --> Hooks Class Initialized
DEBUG - 2019-07-19 18:17:19 --> UTF-8 Support Enabled
INFO - 2019-07-19 18:17:19 --> Utf8 Class Initialized
INFO - 2019-07-19 18:17:19 --> URI Class Initialized
INFO - 2019-07-19 18:17:19 --> Router Class Initialized
INFO - 2019-07-19 18:17:19 --> Output Class Initialized
INFO - 2019-07-19 18:17:19 --> Security Class Initialized
DEBUG - 2019-07-19 18:17:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 18:17:19 --> Input Class Initialized
INFO - 2019-07-19 18:17:19 --> Language Class Initialized
INFO - 2019-07-19 18:17:19 --> Loader Class Initialized
INFO - 2019-07-19 18:17:19 --> Database Driver Class Initialized
INFO - 2019-07-19 18:17:19 --> Controller Class Initialized
INFO - 2019-07-19 18:17:19 --> Model "Product" initialized
INFO - 2019-07-19 18:17:19 --> Final output sent to browser
DEBUG - 2019-07-19 18:17:19 --> Total execution time: 0.0045
INFO - 2019-07-19 18:22:20 --> Config Class Initialized
INFO - 2019-07-19 18:22:20 --> Hooks Class Initialized
DEBUG - 2019-07-19 18:22:20 --> UTF-8 Support Enabled
INFO - 2019-07-19 18:22:20 --> Utf8 Class Initialized
INFO - 2019-07-19 18:22:20 --> URI Class Initialized
INFO - 2019-07-19 18:22:20 --> Router Class Initialized
INFO - 2019-07-19 18:22:20 --> Output Class Initialized
INFO - 2019-07-19 18:22:20 --> Security Class Initialized
DEBUG - 2019-07-19 18:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 18:22:20 --> Input Class Initialized
INFO - 2019-07-19 18:22:20 --> Language Class Initialized
INFO - 2019-07-19 18:22:20 --> Loader Class Initialized
INFO - 2019-07-19 18:22:20 --> Database Driver Class Initialized
INFO - 2019-07-19 18:22:20 --> Controller Class Initialized
INFO - 2019-07-19 18:22:20 --> Model "Product" initialized
INFO - 2019-07-19 18:22:20 --> Final output sent to browser
DEBUG - 2019-07-19 18:22:20 --> Total execution time: 0.0557
INFO - 2019-07-19 18:22:20 --> Config Class Initialized
INFO - 2019-07-19 18:22:20 --> Hooks Class Initialized
DEBUG - 2019-07-19 18:22:20 --> UTF-8 Support Enabled
INFO - 2019-07-19 18:22:20 --> Utf8 Class Initialized
INFO - 2019-07-19 18:22:20 --> URI Class Initialized
INFO - 2019-07-19 18:22:20 --> Router Class Initialized
INFO - 2019-07-19 18:22:20 --> Output Class Initialized
INFO - 2019-07-19 18:22:20 --> Security Class Initialized
DEBUG - 2019-07-19 18:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 18:22:20 --> Input Class Initialized
INFO - 2019-07-19 18:22:20 --> Language Class Initialized
INFO - 2019-07-19 18:22:20 --> Loader Class Initialized
INFO - 2019-07-19 18:22:20 --> Database Driver Class Initialized
INFO - 2019-07-19 18:22:20 --> Controller Class Initialized
INFO - 2019-07-19 18:22:20 --> Model "Product" initialized
INFO - 2019-07-19 18:22:20 --> Final output sent to browser
DEBUG - 2019-07-19 18:22:20 --> Total execution time: 0.0033
INFO - 2019-07-19 18:24:58 --> Config Class Initialized
INFO - 2019-07-19 18:24:58 --> Hooks Class Initialized
DEBUG - 2019-07-19 18:24:58 --> UTF-8 Support Enabled
INFO - 2019-07-19 18:24:58 --> Utf8 Class Initialized
INFO - 2019-07-19 18:24:58 --> URI Class Initialized
INFO - 2019-07-19 18:24:58 --> Router Class Initialized
INFO - 2019-07-19 18:24:58 --> Output Class Initialized
INFO - 2019-07-19 18:24:58 --> Security Class Initialized
DEBUG - 2019-07-19 18:24:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 18:24:58 --> Input Class Initialized
INFO - 2019-07-19 18:24:58 --> Language Class Initialized
INFO - 2019-07-19 18:24:58 --> Loader Class Initialized
INFO - 2019-07-19 18:24:58 --> Database Driver Class Initialized
INFO - 2019-07-19 18:24:58 --> Controller Class Initialized
INFO - 2019-07-19 18:24:58 --> Model "Product" initialized
INFO - 2019-07-19 18:24:58 --> Final output sent to browser
DEBUG - 2019-07-19 18:24:58 --> Total execution time: 0.0070
INFO - 2019-07-19 18:24:58 --> Config Class Initialized
INFO - 2019-07-19 18:24:58 --> Hooks Class Initialized
DEBUG - 2019-07-19 18:24:58 --> UTF-8 Support Enabled
INFO - 2019-07-19 18:24:58 --> Utf8 Class Initialized
INFO - 2019-07-19 18:24:58 --> URI Class Initialized
INFO - 2019-07-19 18:24:58 --> Router Class Initialized
INFO - 2019-07-19 18:24:58 --> Output Class Initialized
INFO - 2019-07-19 18:24:58 --> Security Class Initialized
DEBUG - 2019-07-19 18:24:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 18:24:58 --> Input Class Initialized
INFO - 2019-07-19 18:24:58 --> Language Class Initialized
INFO - 2019-07-19 18:24:58 --> Loader Class Initialized
INFO - 2019-07-19 18:24:58 --> Database Driver Class Initialized
INFO - 2019-07-19 18:24:58 --> Controller Class Initialized
INFO - 2019-07-19 18:24:58 --> Model "Product" initialized
INFO - 2019-07-19 18:24:58 --> Final output sent to browser
DEBUG - 2019-07-19 18:24:58 --> Total execution time: 0.0064
INFO - 2019-07-19 18:25:31 --> Config Class Initialized
INFO - 2019-07-19 18:25:31 --> Hooks Class Initialized
DEBUG - 2019-07-19 18:25:31 --> UTF-8 Support Enabled
INFO - 2019-07-19 18:25:31 --> Utf8 Class Initialized
INFO - 2019-07-19 18:25:31 --> URI Class Initialized
INFO - 2019-07-19 18:25:31 --> Router Class Initialized
INFO - 2019-07-19 18:25:31 --> Output Class Initialized
INFO - 2019-07-19 18:25:31 --> Security Class Initialized
DEBUG - 2019-07-19 18:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 18:25:31 --> Input Class Initialized
INFO - 2019-07-19 18:25:31 --> Language Class Initialized
INFO - 2019-07-19 18:25:31 --> Loader Class Initialized
INFO - 2019-07-19 18:25:31 --> Database Driver Class Initialized
INFO - 2019-07-19 18:25:31 --> Controller Class Initialized
INFO - 2019-07-19 18:25:31 --> Model "Product" initialized
INFO - 2019-07-19 18:25:31 --> Final output sent to browser
DEBUG - 2019-07-19 18:25:31 --> Total execution time: 0.0061
INFO - 2019-07-19 18:25:31 --> Config Class Initialized
INFO - 2019-07-19 18:25:31 --> Hooks Class Initialized
DEBUG - 2019-07-19 18:25:31 --> UTF-8 Support Enabled
INFO - 2019-07-19 18:25:31 --> Utf8 Class Initialized
INFO - 2019-07-19 18:25:31 --> URI Class Initialized
INFO - 2019-07-19 18:25:31 --> Router Class Initialized
INFO - 2019-07-19 18:25:31 --> Output Class Initialized
INFO - 2019-07-19 18:25:31 --> Security Class Initialized
DEBUG - 2019-07-19 18:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 18:25:31 --> Input Class Initialized
INFO - 2019-07-19 18:25:31 --> Language Class Initialized
INFO - 2019-07-19 18:25:31 --> Loader Class Initialized
INFO - 2019-07-19 18:25:31 --> Database Driver Class Initialized
INFO - 2019-07-19 18:25:31 --> Controller Class Initialized
INFO - 2019-07-19 18:25:31 --> Model "Product" initialized
INFO - 2019-07-19 18:25:31 --> Final output sent to browser
DEBUG - 2019-07-19 18:25:31 --> Total execution time: 0.0238
INFO - 2019-07-19 18:31:43 --> Config Class Initialized
INFO - 2019-07-19 18:31:43 --> Hooks Class Initialized
DEBUG - 2019-07-19 18:31:43 --> UTF-8 Support Enabled
INFO - 2019-07-19 18:31:43 --> Utf8 Class Initialized
INFO - 2019-07-19 18:31:43 --> URI Class Initialized
INFO - 2019-07-19 18:31:43 --> Router Class Initialized
INFO - 2019-07-19 18:31:43 --> Output Class Initialized
INFO - 2019-07-19 18:31:43 --> Security Class Initialized
DEBUG - 2019-07-19 18:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 18:31:43 --> Input Class Initialized
INFO - 2019-07-19 18:31:43 --> Language Class Initialized
INFO - 2019-07-19 18:31:43 --> Loader Class Initialized
INFO - 2019-07-19 18:31:43 --> Database Driver Class Initialized
INFO - 2019-07-19 18:31:43 --> Controller Class Initialized
INFO - 2019-07-19 18:31:43 --> Model "Product" initialized
INFO - 2019-07-19 18:31:43 --> Final output sent to browser
DEBUG - 2019-07-19 18:31:43 --> Total execution time: 0.1228
INFO - 2019-07-19 18:31:43 --> Config Class Initialized
INFO - 2019-07-19 18:31:43 --> Hooks Class Initialized
DEBUG - 2019-07-19 18:31:43 --> UTF-8 Support Enabled
INFO - 2019-07-19 18:31:43 --> Utf8 Class Initialized
INFO - 2019-07-19 18:31:43 --> URI Class Initialized
INFO - 2019-07-19 18:31:43 --> Router Class Initialized
INFO - 2019-07-19 18:31:43 --> Output Class Initialized
INFO - 2019-07-19 18:31:43 --> Security Class Initialized
DEBUG - 2019-07-19 18:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 18:31:43 --> Input Class Initialized
INFO - 2019-07-19 18:31:43 --> Language Class Initialized
INFO - 2019-07-19 18:31:43 --> Loader Class Initialized
INFO - 2019-07-19 18:31:43 --> Database Driver Class Initialized
INFO - 2019-07-19 18:31:43 --> Controller Class Initialized
INFO - 2019-07-19 18:31:43 --> Model "Product" initialized
INFO - 2019-07-19 18:31:43 --> Final output sent to browser
DEBUG - 2019-07-19 18:31:43 --> Total execution time: 0.0512
INFO - 2019-07-19 18:32:46 --> Config Class Initialized
INFO - 2019-07-19 18:32:46 --> Hooks Class Initialized
DEBUG - 2019-07-19 18:32:46 --> UTF-8 Support Enabled
INFO - 2019-07-19 18:32:46 --> Utf8 Class Initialized
INFO - 2019-07-19 18:32:46 --> URI Class Initialized
INFO - 2019-07-19 18:32:46 --> Router Class Initialized
INFO - 2019-07-19 18:32:46 --> Output Class Initialized
INFO - 2019-07-19 18:32:46 --> Security Class Initialized
DEBUG - 2019-07-19 18:32:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 18:32:46 --> Input Class Initialized
INFO - 2019-07-19 18:32:46 --> Language Class Initialized
INFO - 2019-07-19 18:32:46 --> Loader Class Initialized
INFO - 2019-07-19 18:32:46 --> Database Driver Class Initialized
INFO - 2019-07-19 18:32:46 --> Controller Class Initialized
INFO - 2019-07-19 18:32:46 --> Model "Product" initialized
INFO - 2019-07-19 18:32:46 --> Final output sent to browser
DEBUG - 2019-07-19 18:32:46 --> Total execution time: 0.0728
INFO - 2019-07-19 18:32:46 --> Config Class Initialized
INFO - 2019-07-19 18:32:46 --> Hooks Class Initialized
DEBUG - 2019-07-19 18:32:46 --> UTF-8 Support Enabled
INFO - 2019-07-19 18:32:46 --> Utf8 Class Initialized
INFO - 2019-07-19 18:32:46 --> URI Class Initialized
INFO - 2019-07-19 18:32:46 --> Router Class Initialized
INFO - 2019-07-19 18:32:46 --> Output Class Initialized
INFO - 2019-07-19 18:32:46 --> Security Class Initialized
DEBUG - 2019-07-19 18:32:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 18:32:46 --> Input Class Initialized
INFO - 2019-07-19 18:32:46 --> Language Class Initialized
INFO - 2019-07-19 18:32:46 --> Loader Class Initialized
INFO - 2019-07-19 18:32:46 --> Database Driver Class Initialized
INFO - 2019-07-19 18:32:46 --> Controller Class Initialized
INFO - 2019-07-19 18:32:46 --> Model "Product" initialized
INFO - 2019-07-19 18:32:46 --> Final output sent to browser
DEBUG - 2019-07-19 18:32:46 --> Total execution time: 0.0689
INFO - 2019-07-19 18:33:41 --> Config Class Initialized
INFO - 2019-07-19 18:33:41 --> Hooks Class Initialized
DEBUG - 2019-07-19 18:33:41 --> UTF-8 Support Enabled
INFO - 2019-07-19 18:33:41 --> Utf8 Class Initialized
INFO - 2019-07-19 18:33:41 --> URI Class Initialized
INFO - 2019-07-19 18:33:41 --> Router Class Initialized
INFO - 2019-07-19 18:33:41 --> Output Class Initialized
INFO - 2019-07-19 18:33:41 --> Security Class Initialized
DEBUG - 2019-07-19 18:33:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 18:33:41 --> Input Class Initialized
INFO - 2019-07-19 18:33:41 --> Language Class Initialized
INFO - 2019-07-19 18:33:41 --> Loader Class Initialized
INFO - 2019-07-19 18:33:41 --> Database Driver Class Initialized
INFO - 2019-07-19 18:33:41 --> Controller Class Initialized
INFO - 2019-07-19 18:33:41 --> Model "Product" initialized
INFO - 2019-07-19 18:33:41 --> Final output sent to browser
DEBUG - 2019-07-19 18:33:41 --> Total execution time: 0.1638
INFO - 2019-07-19 18:33:41 --> Config Class Initialized
INFO - 2019-07-19 18:33:41 --> Hooks Class Initialized
DEBUG - 2019-07-19 18:33:41 --> UTF-8 Support Enabled
INFO - 2019-07-19 18:33:41 --> Utf8 Class Initialized
INFO - 2019-07-19 18:33:41 --> URI Class Initialized
INFO - 2019-07-19 18:33:41 --> Router Class Initialized
INFO - 2019-07-19 18:33:41 --> Output Class Initialized
INFO - 2019-07-19 18:33:41 --> Security Class Initialized
DEBUG - 2019-07-19 18:33:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 18:33:41 --> Input Class Initialized
INFO - 2019-07-19 18:33:41 --> Language Class Initialized
INFO - 2019-07-19 18:33:41 --> Loader Class Initialized
INFO - 2019-07-19 18:33:41 --> Database Driver Class Initialized
INFO - 2019-07-19 18:33:42 --> Controller Class Initialized
INFO - 2019-07-19 18:33:42 --> Model "Product" initialized
INFO - 2019-07-19 18:33:42 --> Final output sent to browser
DEBUG - 2019-07-19 18:33:42 --> Total execution time: 0.1488
INFO - 2019-07-19 18:34:17 --> Config Class Initialized
INFO - 2019-07-19 18:34:17 --> Hooks Class Initialized
DEBUG - 2019-07-19 18:34:17 --> UTF-8 Support Enabled
INFO - 2019-07-19 18:34:17 --> Utf8 Class Initialized
INFO - 2019-07-19 18:34:17 --> URI Class Initialized
INFO - 2019-07-19 18:34:17 --> Router Class Initialized
INFO - 2019-07-19 18:34:17 --> Output Class Initialized
INFO - 2019-07-19 18:34:17 --> Security Class Initialized
DEBUG - 2019-07-19 18:34:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 18:34:17 --> Input Class Initialized
INFO - 2019-07-19 18:34:17 --> Language Class Initialized
INFO - 2019-07-19 18:34:17 --> Loader Class Initialized
INFO - 2019-07-19 18:34:17 --> Database Driver Class Initialized
INFO - 2019-07-19 18:34:17 --> Controller Class Initialized
INFO - 2019-07-19 18:34:17 --> Model "Product" initialized
INFO - 2019-07-19 18:34:18 --> Final output sent to browser
DEBUG - 2019-07-19 18:34:18 --> Total execution time: 0.1035
INFO - 2019-07-19 18:34:18 --> Config Class Initialized
INFO - 2019-07-19 18:34:18 --> Hooks Class Initialized
DEBUG - 2019-07-19 18:34:18 --> UTF-8 Support Enabled
INFO - 2019-07-19 18:34:18 --> Utf8 Class Initialized
INFO - 2019-07-19 18:34:18 --> URI Class Initialized
INFO - 2019-07-19 18:34:18 --> Router Class Initialized
INFO - 2019-07-19 18:34:18 --> Output Class Initialized
INFO - 2019-07-19 18:34:18 --> Security Class Initialized
DEBUG - 2019-07-19 18:34:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 18:34:18 --> Input Class Initialized
INFO - 2019-07-19 18:34:18 --> Language Class Initialized
INFO - 2019-07-19 18:34:18 --> Loader Class Initialized
INFO - 2019-07-19 18:34:18 --> Database Driver Class Initialized
INFO - 2019-07-19 18:34:18 --> Controller Class Initialized
INFO - 2019-07-19 18:34:18 --> Model "Product" initialized
INFO - 2019-07-19 18:34:18 --> Final output sent to browser
DEBUG - 2019-07-19 18:34:18 --> Total execution time: 0.0401
INFO - 2019-07-19 18:35:18 --> Config Class Initialized
INFO - 2019-07-19 18:35:18 --> Hooks Class Initialized
DEBUG - 2019-07-19 18:35:18 --> UTF-8 Support Enabled
INFO - 2019-07-19 18:35:18 --> Utf8 Class Initialized
INFO - 2019-07-19 18:35:18 --> URI Class Initialized
INFO - 2019-07-19 18:35:18 --> Router Class Initialized
INFO - 2019-07-19 18:35:18 --> Output Class Initialized
INFO - 2019-07-19 18:35:18 --> Security Class Initialized
DEBUG - 2019-07-19 18:35:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 18:35:18 --> Input Class Initialized
INFO - 2019-07-19 18:35:18 --> Language Class Initialized
INFO - 2019-07-19 18:35:18 --> Loader Class Initialized
INFO - 2019-07-19 18:35:18 --> Database Driver Class Initialized
INFO - 2019-07-19 18:35:18 --> Controller Class Initialized
INFO - 2019-07-19 18:35:18 --> Model "Product" initialized
INFO - 2019-07-19 18:35:18 --> Final output sent to browser
DEBUG - 2019-07-19 18:35:18 --> Total execution time: 0.0039
INFO - 2019-07-19 18:35:18 --> Config Class Initialized
INFO - 2019-07-19 18:35:18 --> Hooks Class Initialized
DEBUG - 2019-07-19 18:35:18 --> UTF-8 Support Enabled
INFO - 2019-07-19 18:35:18 --> Utf8 Class Initialized
INFO - 2019-07-19 18:35:18 --> URI Class Initialized
INFO - 2019-07-19 18:35:18 --> Router Class Initialized
INFO - 2019-07-19 18:35:18 --> Output Class Initialized
INFO - 2019-07-19 18:35:18 --> Security Class Initialized
DEBUG - 2019-07-19 18:35:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 18:35:18 --> Input Class Initialized
INFO - 2019-07-19 18:35:18 --> Language Class Initialized
INFO - 2019-07-19 18:35:18 --> Loader Class Initialized
INFO - 2019-07-19 18:35:18 --> Database Driver Class Initialized
INFO - 2019-07-19 18:35:18 --> Controller Class Initialized
INFO - 2019-07-19 18:35:18 --> Model "Product" initialized
INFO - 2019-07-19 18:35:18 --> Final output sent to browser
DEBUG - 2019-07-19 18:35:18 --> Total execution time: 0.0859
INFO - 2019-07-19 18:41:41 --> Config Class Initialized
INFO - 2019-07-19 18:41:41 --> Hooks Class Initialized
DEBUG - 2019-07-19 18:41:41 --> UTF-8 Support Enabled
INFO - 2019-07-19 18:41:41 --> Utf8 Class Initialized
INFO - 2019-07-19 18:41:41 --> URI Class Initialized
INFO - 2019-07-19 18:41:41 --> Router Class Initialized
INFO - 2019-07-19 18:41:41 --> Output Class Initialized
INFO - 2019-07-19 18:41:41 --> Security Class Initialized
DEBUG - 2019-07-19 18:41:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 18:41:41 --> Input Class Initialized
INFO - 2019-07-19 18:41:41 --> Language Class Initialized
INFO - 2019-07-19 18:41:41 --> Loader Class Initialized
INFO - 2019-07-19 18:41:41 --> Database Driver Class Initialized
INFO - 2019-07-19 18:41:41 --> Controller Class Initialized
INFO - 2019-07-19 18:41:41 --> Model "Product" initialized
INFO - 2019-07-19 18:41:41 --> Final output sent to browser
DEBUG - 2019-07-19 18:41:41 --> Total execution time: 0.0492
INFO - 2019-07-19 18:41:41 --> Config Class Initialized
INFO - 2019-07-19 18:41:41 --> Hooks Class Initialized
DEBUG - 2019-07-19 18:41:41 --> UTF-8 Support Enabled
INFO - 2019-07-19 18:41:41 --> Utf8 Class Initialized
INFO - 2019-07-19 18:41:41 --> URI Class Initialized
INFO - 2019-07-19 18:41:41 --> Router Class Initialized
INFO - 2019-07-19 18:41:41 --> Output Class Initialized
INFO - 2019-07-19 18:41:41 --> Security Class Initialized
DEBUG - 2019-07-19 18:41:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 18:41:41 --> Input Class Initialized
INFO - 2019-07-19 18:41:41 --> Language Class Initialized
INFO - 2019-07-19 18:41:41 --> Loader Class Initialized
INFO - 2019-07-19 18:41:41 --> Database Driver Class Initialized
INFO - 2019-07-19 18:41:41 --> Controller Class Initialized
INFO - 2019-07-19 18:41:41 --> Model "Product" initialized
INFO - 2019-07-19 18:41:42 --> Final output sent to browser
DEBUG - 2019-07-19 18:41:42 --> Total execution time: 0.0583
INFO - 2019-07-19 18:42:26 --> Config Class Initialized
INFO - 2019-07-19 18:42:26 --> Hooks Class Initialized
DEBUG - 2019-07-19 18:42:26 --> UTF-8 Support Enabled
INFO - 2019-07-19 18:42:26 --> Utf8 Class Initialized
INFO - 2019-07-19 18:42:26 --> URI Class Initialized
INFO - 2019-07-19 18:42:26 --> Router Class Initialized
INFO - 2019-07-19 18:42:26 --> Output Class Initialized
INFO - 2019-07-19 18:42:26 --> Security Class Initialized
DEBUG - 2019-07-19 18:42:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 18:42:26 --> Input Class Initialized
INFO - 2019-07-19 18:42:26 --> Language Class Initialized
INFO - 2019-07-19 18:42:26 --> Loader Class Initialized
INFO - 2019-07-19 18:42:26 --> Database Driver Class Initialized
INFO - 2019-07-19 18:42:26 --> Controller Class Initialized
INFO - 2019-07-19 18:42:26 --> Model "Product" initialized
INFO - 2019-07-19 18:42:26 --> Final output sent to browser
DEBUG - 2019-07-19 18:42:26 --> Total execution time: 0.0499
INFO - 2019-07-19 18:42:26 --> Config Class Initialized
INFO - 2019-07-19 18:42:26 --> Hooks Class Initialized
DEBUG - 2019-07-19 18:42:26 --> UTF-8 Support Enabled
INFO - 2019-07-19 18:42:26 --> Utf8 Class Initialized
INFO - 2019-07-19 18:42:26 --> URI Class Initialized
INFO - 2019-07-19 18:42:26 --> Router Class Initialized
INFO - 2019-07-19 18:42:26 --> Output Class Initialized
INFO - 2019-07-19 18:42:26 --> Security Class Initialized
DEBUG - 2019-07-19 18:42:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 18:42:26 --> Input Class Initialized
INFO - 2019-07-19 18:42:26 --> Language Class Initialized
INFO - 2019-07-19 18:42:26 --> Loader Class Initialized
INFO - 2019-07-19 18:42:26 --> Database Driver Class Initialized
INFO - 2019-07-19 18:42:26 --> Controller Class Initialized
INFO - 2019-07-19 18:42:26 --> Model "Product" initialized
INFO - 2019-07-19 18:42:26 --> Final output sent to browser
DEBUG - 2019-07-19 18:42:26 --> Total execution time: 0.0666
INFO - 2019-07-19 18:42:56 --> Config Class Initialized
INFO - 2019-07-19 18:42:56 --> Hooks Class Initialized
DEBUG - 2019-07-19 18:42:56 --> UTF-8 Support Enabled
INFO - 2019-07-19 18:42:56 --> Utf8 Class Initialized
INFO - 2019-07-19 18:42:56 --> URI Class Initialized
INFO - 2019-07-19 18:42:56 --> Router Class Initialized
INFO - 2019-07-19 18:42:56 --> Output Class Initialized
INFO - 2019-07-19 18:42:56 --> Security Class Initialized
DEBUG - 2019-07-19 18:42:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 18:42:56 --> Input Class Initialized
INFO - 2019-07-19 18:42:56 --> Language Class Initialized
INFO - 2019-07-19 18:42:56 --> Loader Class Initialized
INFO - 2019-07-19 18:42:56 --> Database Driver Class Initialized
INFO - 2019-07-19 18:42:56 --> Controller Class Initialized
INFO - 2019-07-19 18:42:56 --> Model "Product" initialized
INFO - 2019-07-19 18:42:56 --> Final output sent to browser
DEBUG - 2019-07-19 18:42:56 --> Total execution time: 0.0062
INFO - 2019-07-19 18:42:56 --> Config Class Initialized
INFO - 2019-07-19 18:42:56 --> Hooks Class Initialized
DEBUG - 2019-07-19 18:42:56 --> UTF-8 Support Enabled
INFO - 2019-07-19 18:42:56 --> Utf8 Class Initialized
INFO - 2019-07-19 18:42:56 --> URI Class Initialized
INFO - 2019-07-19 18:42:56 --> Router Class Initialized
INFO - 2019-07-19 18:42:56 --> Output Class Initialized
INFO - 2019-07-19 18:42:56 --> Security Class Initialized
DEBUG - 2019-07-19 18:42:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 18:42:56 --> Input Class Initialized
INFO - 2019-07-19 18:42:56 --> Language Class Initialized
INFO - 2019-07-19 18:42:56 --> Loader Class Initialized
INFO - 2019-07-19 18:42:56 --> Database Driver Class Initialized
INFO - 2019-07-19 18:42:56 --> Controller Class Initialized
INFO - 2019-07-19 18:42:56 --> Model "Product" initialized
INFO - 2019-07-19 18:42:56 --> Final output sent to browser
DEBUG - 2019-07-19 18:42:56 --> Total execution time: 0.0409
INFO - 2019-07-19 19:23:26 --> Config Class Initialized
INFO - 2019-07-19 19:23:26 --> Hooks Class Initialized
DEBUG - 2019-07-19 19:23:26 --> UTF-8 Support Enabled
INFO - 2019-07-19 19:23:26 --> Utf8 Class Initialized
INFO - 2019-07-19 19:23:26 --> URI Class Initialized
INFO - 2019-07-19 19:23:26 --> Router Class Initialized
INFO - 2019-07-19 19:23:26 --> Output Class Initialized
INFO - 2019-07-19 19:23:26 --> Security Class Initialized
DEBUG - 2019-07-19 19:23:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 19:23:26 --> Input Class Initialized
INFO - 2019-07-19 19:23:26 --> Language Class Initialized
INFO - 2019-07-19 19:23:26 --> Loader Class Initialized
INFO - 2019-07-19 19:23:26 --> Database Driver Class Initialized
INFO - 2019-07-19 19:23:26 --> Controller Class Initialized
INFO - 2019-07-19 19:23:26 --> Model "Product" initialized
INFO - 2019-07-19 19:23:26 --> Final output sent to browser
DEBUG - 2019-07-19 19:23:26 --> Total execution time: 0.0310
INFO - 2019-07-19 19:23:26 --> Config Class Initialized
INFO - 2019-07-19 19:23:26 --> Hooks Class Initialized
DEBUG - 2019-07-19 19:23:26 --> UTF-8 Support Enabled
INFO - 2019-07-19 19:23:26 --> Utf8 Class Initialized
INFO - 2019-07-19 19:23:26 --> URI Class Initialized
INFO - 2019-07-19 19:23:26 --> Router Class Initialized
INFO - 2019-07-19 19:23:26 --> Output Class Initialized
INFO - 2019-07-19 19:23:26 --> Security Class Initialized
DEBUG - 2019-07-19 19:23:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 19:23:26 --> Input Class Initialized
INFO - 2019-07-19 19:23:26 --> Language Class Initialized
INFO - 2019-07-19 19:23:26 --> Loader Class Initialized
INFO - 2019-07-19 19:23:26 --> Database Driver Class Initialized
INFO - 2019-07-19 19:23:26 --> Controller Class Initialized
INFO - 2019-07-19 19:23:26 --> Model "Product" initialized
INFO - 2019-07-19 19:23:26 --> Final output sent to browser
DEBUG - 2019-07-19 19:23:26 --> Total execution time: 0.0679
INFO - 2019-07-19 19:24:25 --> Config Class Initialized
INFO - 2019-07-19 19:24:25 --> Hooks Class Initialized
DEBUG - 2019-07-19 19:24:25 --> UTF-8 Support Enabled
INFO - 2019-07-19 19:24:25 --> Utf8 Class Initialized
INFO - 2019-07-19 19:24:25 --> URI Class Initialized
INFO - 2019-07-19 19:24:25 --> Router Class Initialized
INFO - 2019-07-19 19:24:25 --> Output Class Initialized
INFO - 2019-07-19 19:24:25 --> Security Class Initialized
DEBUG - 2019-07-19 19:24:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 19:24:25 --> Input Class Initialized
INFO - 2019-07-19 19:24:25 --> Language Class Initialized
INFO - 2019-07-19 19:24:25 --> Loader Class Initialized
INFO - 2019-07-19 19:24:25 --> Database Driver Class Initialized
INFO - 2019-07-19 19:24:25 --> Controller Class Initialized
INFO - 2019-07-19 19:24:25 --> Model "Product" initialized
INFO - 2019-07-19 19:24:25 --> Final output sent to browser
DEBUG - 2019-07-19 19:24:25 --> Total execution time: 0.0062
INFO - 2019-07-19 19:24:25 --> Config Class Initialized
INFO - 2019-07-19 19:24:25 --> Hooks Class Initialized
DEBUG - 2019-07-19 19:24:25 --> UTF-8 Support Enabled
INFO - 2019-07-19 19:24:25 --> Utf8 Class Initialized
INFO - 2019-07-19 19:24:25 --> URI Class Initialized
INFO - 2019-07-19 19:24:25 --> Router Class Initialized
INFO - 2019-07-19 19:24:25 --> Output Class Initialized
INFO - 2019-07-19 19:24:25 --> Security Class Initialized
DEBUG - 2019-07-19 19:24:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 19:24:25 --> Input Class Initialized
INFO - 2019-07-19 19:24:25 --> Language Class Initialized
INFO - 2019-07-19 19:24:25 --> Loader Class Initialized
INFO - 2019-07-19 19:24:25 --> Database Driver Class Initialized
INFO - 2019-07-19 19:24:25 --> Controller Class Initialized
INFO - 2019-07-19 19:24:25 --> Model "Product" initialized
INFO - 2019-07-19 19:24:25 --> Final output sent to browser
DEBUG - 2019-07-19 19:24:25 --> Total execution time: 0.1356
INFO - 2019-07-19 19:25:31 --> Config Class Initialized
INFO - 2019-07-19 19:25:31 --> Hooks Class Initialized
DEBUG - 2019-07-19 19:25:31 --> UTF-8 Support Enabled
INFO - 2019-07-19 19:25:31 --> Utf8 Class Initialized
INFO - 2019-07-19 19:25:31 --> URI Class Initialized
INFO - 2019-07-19 19:25:31 --> Router Class Initialized
INFO - 2019-07-19 19:25:31 --> Output Class Initialized
INFO - 2019-07-19 19:25:31 --> Security Class Initialized
DEBUG - 2019-07-19 19:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 19:25:31 --> Input Class Initialized
INFO - 2019-07-19 19:25:31 --> Language Class Initialized
INFO - 2019-07-19 19:25:31 --> Loader Class Initialized
INFO - 2019-07-19 19:25:31 --> Database Driver Class Initialized
INFO - 2019-07-19 19:25:32 --> Controller Class Initialized
INFO - 2019-07-19 19:25:32 --> Model "Product" initialized
INFO - 2019-07-19 19:25:32 --> Final output sent to browser
DEBUG - 2019-07-19 19:25:32 --> Total execution time: 0.0545
INFO - 2019-07-19 19:25:32 --> Config Class Initialized
INFO - 2019-07-19 19:25:32 --> Hooks Class Initialized
DEBUG - 2019-07-19 19:25:32 --> UTF-8 Support Enabled
INFO - 2019-07-19 19:25:32 --> Utf8 Class Initialized
INFO - 2019-07-19 19:25:32 --> URI Class Initialized
INFO - 2019-07-19 19:25:32 --> Router Class Initialized
INFO - 2019-07-19 19:25:32 --> Output Class Initialized
INFO - 2019-07-19 19:25:32 --> Security Class Initialized
DEBUG - 2019-07-19 19:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 19:25:32 --> Input Class Initialized
INFO - 2019-07-19 19:25:32 --> Language Class Initialized
INFO - 2019-07-19 19:25:32 --> Loader Class Initialized
INFO - 2019-07-19 19:25:32 --> Database Driver Class Initialized
INFO - 2019-07-19 19:25:32 --> Controller Class Initialized
INFO - 2019-07-19 19:25:32 --> Model "Product" initialized
INFO - 2019-07-19 19:25:32 --> Final output sent to browser
DEBUG - 2019-07-19 19:25:32 --> Total execution time: 0.1066
INFO - 2019-07-19 19:26:22 --> Config Class Initialized
INFO - 2019-07-19 19:26:22 --> Hooks Class Initialized
DEBUG - 2019-07-19 19:26:22 --> UTF-8 Support Enabled
INFO - 2019-07-19 19:26:22 --> Utf8 Class Initialized
INFO - 2019-07-19 19:26:22 --> URI Class Initialized
INFO - 2019-07-19 19:26:22 --> Router Class Initialized
INFO - 2019-07-19 19:26:22 --> Output Class Initialized
INFO - 2019-07-19 19:26:22 --> Security Class Initialized
DEBUG - 2019-07-19 19:26:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 19:26:22 --> Input Class Initialized
INFO - 2019-07-19 19:26:22 --> Language Class Initialized
INFO - 2019-07-19 19:26:22 --> Loader Class Initialized
INFO - 2019-07-19 19:26:22 --> Database Driver Class Initialized
INFO - 2019-07-19 19:26:22 --> Controller Class Initialized
INFO - 2019-07-19 19:26:22 --> Model "Product" initialized
INFO - 2019-07-19 19:26:22 --> Final output sent to browser
DEBUG - 2019-07-19 19:26:22 --> Total execution time: 0.0519
INFO - 2019-07-19 19:26:22 --> Config Class Initialized
INFO - 2019-07-19 19:26:22 --> Hooks Class Initialized
DEBUG - 2019-07-19 19:26:22 --> UTF-8 Support Enabled
INFO - 2019-07-19 19:26:22 --> Utf8 Class Initialized
INFO - 2019-07-19 19:26:22 --> URI Class Initialized
INFO - 2019-07-19 19:26:22 --> Router Class Initialized
INFO - 2019-07-19 19:26:22 --> Output Class Initialized
INFO - 2019-07-19 19:26:22 --> Security Class Initialized
DEBUG - 2019-07-19 19:26:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 19:26:22 --> Input Class Initialized
INFO - 2019-07-19 19:26:22 --> Language Class Initialized
INFO - 2019-07-19 19:26:22 --> Loader Class Initialized
INFO - 2019-07-19 19:26:22 --> Database Driver Class Initialized
INFO - 2019-07-19 19:26:22 --> Controller Class Initialized
INFO - 2019-07-19 19:26:22 --> Model "Product" initialized
INFO - 2019-07-19 19:26:22 --> Final output sent to browser
DEBUG - 2019-07-19 19:26:22 --> Total execution time: 0.0848
INFO - 2019-07-19 19:29:06 --> Config Class Initialized
INFO - 2019-07-19 19:29:06 --> Hooks Class Initialized
DEBUG - 2019-07-19 19:29:06 --> UTF-8 Support Enabled
INFO - 2019-07-19 19:29:06 --> Utf8 Class Initialized
INFO - 2019-07-19 19:29:06 --> URI Class Initialized
INFO - 2019-07-19 19:29:06 --> Router Class Initialized
INFO - 2019-07-19 19:29:06 --> Output Class Initialized
INFO - 2019-07-19 19:29:06 --> Security Class Initialized
DEBUG - 2019-07-19 19:29:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 19:29:06 --> Input Class Initialized
INFO - 2019-07-19 19:29:06 --> Language Class Initialized
INFO - 2019-07-19 19:29:06 --> Loader Class Initialized
INFO - 2019-07-19 19:29:06 --> Database Driver Class Initialized
INFO - 2019-07-19 19:29:06 --> Controller Class Initialized
INFO - 2019-07-19 19:29:06 --> Model "Product" initialized
INFO - 2019-07-19 19:29:06 --> Final output sent to browser
DEBUG - 2019-07-19 19:29:06 --> Total execution time: 0.0606
INFO - 2019-07-19 19:29:06 --> Config Class Initialized
INFO - 2019-07-19 19:29:06 --> Hooks Class Initialized
DEBUG - 2019-07-19 19:29:06 --> UTF-8 Support Enabled
INFO - 2019-07-19 19:29:06 --> Utf8 Class Initialized
INFO - 2019-07-19 19:29:06 --> URI Class Initialized
INFO - 2019-07-19 19:29:06 --> Router Class Initialized
INFO - 2019-07-19 19:29:06 --> Output Class Initialized
INFO - 2019-07-19 19:29:06 --> Security Class Initialized
DEBUG - 2019-07-19 19:29:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 19:29:06 --> Input Class Initialized
INFO - 2019-07-19 19:29:06 --> Language Class Initialized
INFO - 2019-07-19 19:29:06 --> Loader Class Initialized
INFO - 2019-07-19 19:29:06 --> Database Driver Class Initialized
INFO - 2019-07-19 19:29:06 --> Controller Class Initialized
INFO - 2019-07-19 19:29:06 --> Model "Product" initialized
INFO - 2019-07-19 19:29:07 --> Final output sent to browser
DEBUG - 2019-07-19 19:29:07 --> Total execution time: 0.0992
INFO - 2019-07-19 19:30:29 --> Config Class Initialized
INFO - 2019-07-19 19:30:29 --> Hooks Class Initialized
DEBUG - 2019-07-19 19:30:29 --> UTF-8 Support Enabled
INFO - 2019-07-19 19:30:29 --> Utf8 Class Initialized
INFO - 2019-07-19 19:30:29 --> URI Class Initialized
INFO - 2019-07-19 19:30:29 --> Router Class Initialized
INFO - 2019-07-19 19:30:29 --> Output Class Initialized
INFO - 2019-07-19 19:30:29 --> Security Class Initialized
DEBUG - 2019-07-19 19:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 19:30:29 --> Input Class Initialized
INFO - 2019-07-19 19:30:29 --> Language Class Initialized
INFO - 2019-07-19 19:30:29 --> Loader Class Initialized
INFO - 2019-07-19 19:30:29 --> Database Driver Class Initialized
INFO - 2019-07-19 19:30:29 --> Controller Class Initialized
INFO - 2019-07-19 19:30:29 --> Model "Product" initialized
INFO - 2019-07-19 19:30:29 --> Final output sent to browser
DEBUG - 2019-07-19 19:30:29 --> Total execution time: 0.0462
INFO - 2019-07-19 19:30:29 --> Config Class Initialized
INFO - 2019-07-19 19:30:29 --> Hooks Class Initialized
DEBUG - 2019-07-19 19:30:29 --> UTF-8 Support Enabled
INFO - 2019-07-19 19:30:29 --> Utf8 Class Initialized
INFO - 2019-07-19 19:30:29 --> URI Class Initialized
INFO - 2019-07-19 19:30:29 --> Router Class Initialized
INFO - 2019-07-19 19:30:29 --> Output Class Initialized
INFO - 2019-07-19 19:30:29 --> Security Class Initialized
DEBUG - 2019-07-19 19:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 19:30:29 --> Input Class Initialized
INFO - 2019-07-19 19:30:29 --> Language Class Initialized
INFO - 2019-07-19 19:30:29 --> Loader Class Initialized
INFO - 2019-07-19 19:30:29 --> Database Driver Class Initialized
INFO - 2019-07-19 19:30:29 --> Controller Class Initialized
INFO - 2019-07-19 19:30:29 --> Model "Product" initialized
INFO - 2019-07-19 19:30:29 --> Final output sent to browser
DEBUG - 2019-07-19 19:30:29 --> Total execution time: 0.0586
INFO - 2019-07-19 19:30:50 --> Config Class Initialized
INFO - 2019-07-19 19:30:50 --> Hooks Class Initialized
DEBUG - 2019-07-19 19:30:50 --> UTF-8 Support Enabled
INFO - 2019-07-19 19:30:50 --> Utf8 Class Initialized
INFO - 2019-07-19 19:30:50 --> URI Class Initialized
INFO - 2019-07-19 19:30:50 --> Router Class Initialized
INFO - 2019-07-19 19:30:50 --> Output Class Initialized
INFO - 2019-07-19 19:30:50 --> Security Class Initialized
DEBUG - 2019-07-19 19:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 19:30:50 --> Input Class Initialized
INFO - 2019-07-19 19:30:50 --> Language Class Initialized
INFO - 2019-07-19 19:30:50 --> Loader Class Initialized
INFO - 2019-07-19 19:30:50 --> Database Driver Class Initialized
INFO - 2019-07-19 19:30:50 --> Controller Class Initialized
INFO - 2019-07-19 19:30:50 --> Model "Product" initialized
INFO - 2019-07-19 19:30:50 --> Final output sent to browser
DEBUG - 2019-07-19 19:30:50 --> Total execution time: 0.0399
INFO - 2019-07-19 19:30:50 --> Config Class Initialized
INFO - 2019-07-19 19:30:50 --> Hooks Class Initialized
DEBUG - 2019-07-19 19:30:50 --> UTF-8 Support Enabled
INFO - 2019-07-19 19:30:50 --> Utf8 Class Initialized
INFO - 2019-07-19 19:30:50 --> URI Class Initialized
INFO - 2019-07-19 19:30:50 --> Router Class Initialized
INFO - 2019-07-19 19:30:50 --> Output Class Initialized
INFO - 2019-07-19 19:30:50 --> Security Class Initialized
DEBUG - 2019-07-19 19:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 19:30:50 --> Input Class Initialized
INFO - 2019-07-19 19:30:50 --> Language Class Initialized
INFO - 2019-07-19 19:30:50 --> Loader Class Initialized
INFO - 2019-07-19 19:30:50 --> Database Driver Class Initialized
INFO - 2019-07-19 19:30:50 --> Controller Class Initialized
INFO - 2019-07-19 19:30:50 --> Model "Product" initialized
INFO - 2019-07-19 19:30:51 --> Final output sent to browser
DEBUG - 2019-07-19 19:30:51 --> Total execution time: 0.0664
INFO - 2019-07-19 19:32:06 --> Config Class Initialized
INFO - 2019-07-19 19:32:06 --> Hooks Class Initialized
DEBUG - 2019-07-19 19:32:06 --> UTF-8 Support Enabled
INFO - 2019-07-19 19:32:06 --> Utf8 Class Initialized
INFO - 2019-07-19 19:32:06 --> URI Class Initialized
INFO - 2019-07-19 19:32:06 --> Router Class Initialized
INFO - 2019-07-19 19:32:06 --> Output Class Initialized
INFO - 2019-07-19 19:32:06 --> Security Class Initialized
DEBUG - 2019-07-19 19:32:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 19:32:06 --> Input Class Initialized
INFO - 2019-07-19 19:32:06 --> Language Class Initialized
INFO - 2019-07-19 19:32:06 --> Loader Class Initialized
INFO - 2019-07-19 19:32:06 --> Database Driver Class Initialized
INFO - 2019-07-19 19:32:07 --> Controller Class Initialized
INFO - 2019-07-19 19:32:07 --> Model "Product" initialized
INFO - 2019-07-19 19:32:07 --> Final output sent to browser
DEBUG - 2019-07-19 19:32:07 --> Total execution time: 0.0469
INFO - 2019-07-19 19:32:07 --> Config Class Initialized
INFO - 2019-07-19 19:32:07 --> Hooks Class Initialized
DEBUG - 2019-07-19 19:32:07 --> UTF-8 Support Enabled
INFO - 2019-07-19 19:32:07 --> Utf8 Class Initialized
INFO - 2019-07-19 19:32:07 --> URI Class Initialized
INFO - 2019-07-19 19:32:07 --> Router Class Initialized
INFO - 2019-07-19 19:32:07 --> Output Class Initialized
INFO - 2019-07-19 19:32:07 --> Security Class Initialized
DEBUG - 2019-07-19 19:32:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 19:32:07 --> Input Class Initialized
INFO - 2019-07-19 19:32:07 --> Language Class Initialized
INFO - 2019-07-19 19:32:07 --> Loader Class Initialized
INFO - 2019-07-19 19:32:07 --> Database Driver Class Initialized
INFO - 2019-07-19 19:32:07 --> Controller Class Initialized
INFO - 2019-07-19 19:32:07 --> Model "Product" initialized
INFO - 2019-07-19 19:32:07 --> Final output sent to browser
DEBUG - 2019-07-19 19:32:07 --> Total execution time: 0.0748
INFO - 2019-07-19 19:32:54 --> Config Class Initialized
INFO - 2019-07-19 19:32:54 --> Hooks Class Initialized
DEBUG - 2019-07-19 19:32:54 --> UTF-8 Support Enabled
INFO - 2019-07-19 19:32:54 --> Utf8 Class Initialized
INFO - 2019-07-19 19:32:54 --> URI Class Initialized
INFO - 2019-07-19 19:32:54 --> Router Class Initialized
INFO - 2019-07-19 19:32:54 --> Output Class Initialized
INFO - 2019-07-19 19:32:54 --> Security Class Initialized
DEBUG - 2019-07-19 19:32:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 19:32:54 --> Input Class Initialized
INFO - 2019-07-19 19:32:54 --> Language Class Initialized
INFO - 2019-07-19 19:32:54 --> Loader Class Initialized
INFO - 2019-07-19 19:32:54 --> Database Driver Class Initialized
INFO - 2019-07-19 19:32:54 --> Controller Class Initialized
INFO - 2019-07-19 19:32:54 --> Model "Product" initialized
INFO - 2019-07-19 19:32:54 --> Final output sent to browser
DEBUG - 2019-07-19 19:32:54 --> Total execution time: 0.0464
INFO - 2019-07-19 19:32:54 --> Config Class Initialized
INFO - 2019-07-19 19:32:54 --> Hooks Class Initialized
DEBUG - 2019-07-19 19:32:54 --> UTF-8 Support Enabled
INFO - 2019-07-19 19:32:54 --> Utf8 Class Initialized
INFO - 2019-07-19 19:32:54 --> URI Class Initialized
INFO - 2019-07-19 19:32:54 --> Router Class Initialized
INFO - 2019-07-19 19:32:54 --> Output Class Initialized
INFO - 2019-07-19 19:32:54 --> Security Class Initialized
DEBUG - 2019-07-19 19:32:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 19:32:54 --> Input Class Initialized
INFO - 2019-07-19 19:32:54 --> Language Class Initialized
INFO - 2019-07-19 19:32:54 --> Loader Class Initialized
INFO - 2019-07-19 19:32:54 --> Database Driver Class Initialized
INFO - 2019-07-19 19:32:54 --> Controller Class Initialized
INFO - 2019-07-19 19:32:54 --> Model "Product" initialized
INFO - 2019-07-19 19:32:54 --> Final output sent to browser
DEBUG - 2019-07-19 19:32:54 --> Total execution time: 0.0733
INFO - 2019-07-19 19:33:45 --> Config Class Initialized
INFO - 2019-07-19 19:33:45 --> Hooks Class Initialized
DEBUG - 2019-07-19 19:33:45 --> UTF-8 Support Enabled
INFO - 2019-07-19 19:33:45 --> Utf8 Class Initialized
INFO - 2019-07-19 19:33:45 --> URI Class Initialized
INFO - 2019-07-19 19:33:45 --> Router Class Initialized
INFO - 2019-07-19 19:33:45 --> Output Class Initialized
INFO - 2019-07-19 19:33:45 --> Security Class Initialized
DEBUG - 2019-07-19 19:33:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 19:33:45 --> Input Class Initialized
INFO - 2019-07-19 19:33:45 --> Language Class Initialized
INFO - 2019-07-19 19:33:45 --> Loader Class Initialized
INFO - 2019-07-19 19:33:45 --> Database Driver Class Initialized
INFO - 2019-07-19 19:33:45 --> Controller Class Initialized
INFO - 2019-07-19 19:33:45 --> Model "Product" initialized
INFO - 2019-07-19 19:33:45 --> Final output sent to browser
DEBUG - 2019-07-19 19:33:45 --> Total execution time: 0.0600
INFO - 2019-07-19 19:33:45 --> Config Class Initialized
INFO - 2019-07-19 19:33:45 --> Hooks Class Initialized
DEBUG - 2019-07-19 19:33:45 --> UTF-8 Support Enabled
INFO - 2019-07-19 19:33:45 --> Utf8 Class Initialized
INFO - 2019-07-19 19:33:45 --> URI Class Initialized
INFO - 2019-07-19 19:33:45 --> Router Class Initialized
INFO - 2019-07-19 19:33:45 --> Output Class Initialized
INFO - 2019-07-19 19:33:45 --> Security Class Initialized
DEBUG - 2019-07-19 19:33:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 19:33:45 --> Input Class Initialized
INFO - 2019-07-19 19:33:45 --> Language Class Initialized
INFO - 2019-07-19 19:33:45 --> Loader Class Initialized
INFO - 2019-07-19 19:33:45 --> Database Driver Class Initialized
INFO - 2019-07-19 19:33:45 --> Controller Class Initialized
INFO - 2019-07-19 19:33:45 --> Model "Product" initialized
ERROR - 2019-07-19 19:33:45 --> Severity: Notice --> Undefined index: password /var/www/html/mohan/dummy/mautic_ci_product/application/models/Product.php 18
ERROR - 2019-07-19 19:33:45 --> Severity: Notice --> Undefined variable: signup /var/www/html/mohan/dummy/mautic_ci_product/application/controllers/Welcome.php 65
INFO - 2019-07-19 19:33:45 --> Final output sent to browser
DEBUG - 2019-07-19 19:33:45 --> Total execution time: 0.0274
INFO - 2019-07-19 19:33:48 --> Config Class Initialized
INFO - 2019-07-19 19:33:48 --> Hooks Class Initialized
DEBUG - 2019-07-19 19:33:48 --> UTF-8 Support Enabled
INFO - 2019-07-19 19:33:48 --> Utf8 Class Initialized
INFO - 2019-07-19 19:33:48 --> URI Class Initialized
INFO - 2019-07-19 19:33:48 --> Router Class Initialized
INFO - 2019-07-19 19:33:48 --> Output Class Initialized
INFO - 2019-07-19 19:33:48 --> Security Class Initialized
DEBUG - 2019-07-19 19:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 19:33:48 --> Input Class Initialized
INFO - 2019-07-19 19:33:48 --> Language Class Initialized
INFO - 2019-07-19 19:33:48 --> Loader Class Initialized
INFO - 2019-07-19 19:33:48 --> Database Driver Class Initialized
INFO - 2019-07-19 19:33:48 --> Controller Class Initialized
INFO - 2019-07-19 19:33:48 --> Model "Product" initialized
ERROR - 2019-07-19 19:33:48 --> Severity: Notice --> Undefined index: password /var/www/html/mohan/dummy/mautic_ci_product/application/models/Product.php 18
ERROR - 2019-07-19 19:33:48 --> Severity: Notice --> Undefined variable: signup /var/www/html/mohan/dummy/mautic_ci_product/application/controllers/Welcome.php 65
INFO - 2019-07-19 19:33:48 --> Final output sent to browser
DEBUG - 2019-07-19 19:33:48 --> Total execution time: 0.0074
INFO - 2019-07-19 19:33:59 --> Config Class Initialized
INFO - 2019-07-19 19:33:59 --> Hooks Class Initialized
DEBUG - 2019-07-19 19:33:59 --> UTF-8 Support Enabled
INFO - 2019-07-19 19:33:59 --> Utf8 Class Initialized
INFO - 2019-07-19 19:33:59 --> URI Class Initialized
INFO - 2019-07-19 19:33:59 --> Router Class Initialized
INFO - 2019-07-19 19:33:59 --> Output Class Initialized
INFO - 2019-07-19 19:33:59 --> Security Class Initialized
DEBUG - 2019-07-19 19:33:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 19:33:59 --> Input Class Initialized
INFO - 2019-07-19 19:33:59 --> Language Class Initialized
INFO - 2019-07-19 19:33:59 --> Loader Class Initialized
INFO - 2019-07-19 19:33:59 --> Database Driver Class Initialized
INFO - 2019-07-19 19:33:59 --> Controller Class Initialized
INFO - 2019-07-19 19:33:59 --> Model "Product" initialized
INFO - 2019-07-19 19:33:59 --> Final output sent to browser
DEBUG - 2019-07-19 19:33:59 --> Total execution time: 0.0058
INFO - 2019-07-19 19:33:59 --> Config Class Initialized
INFO - 2019-07-19 19:33:59 --> Hooks Class Initialized
DEBUG - 2019-07-19 19:33:59 --> UTF-8 Support Enabled
INFO - 2019-07-19 19:33:59 --> Utf8 Class Initialized
INFO - 2019-07-19 19:33:59 --> URI Class Initialized
INFO - 2019-07-19 19:33:59 --> Router Class Initialized
INFO - 2019-07-19 19:33:59 --> Output Class Initialized
INFO - 2019-07-19 19:33:59 --> Security Class Initialized
DEBUG - 2019-07-19 19:33:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 19:33:59 --> Input Class Initialized
INFO - 2019-07-19 19:33:59 --> Language Class Initialized
INFO - 2019-07-19 19:33:59 --> Loader Class Initialized
INFO - 2019-07-19 19:33:59 --> Database Driver Class Initialized
INFO - 2019-07-19 19:33:59 --> Controller Class Initialized
INFO - 2019-07-19 19:34:00 --> Model "Product" initialized
ERROR - 2019-07-19 19:34:00 --> Severity: Notice --> Undefined index: password /var/www/html/mohan/dummy/mautic_ci_product/application/models/Product.php 18
ERROR - 2019-07-19 19:34:00 --> Severity: Notice --> Undefined variable: signup /var/www/html/mohan/dummy/mautic_ci_product/application/controllers/Welcome.php 65
INFO - 2019-07-19 19:34:00 --> Final output sent to browser
DEBUG - 2019-07-19 19:34:00 --> Total execution time: 0.0093
INFO - 2019-07-19 19:34:24 --> Config Class Initialized
INFO - 2019-07-19 19:34:24 --> Hooks Class Initialized
DEBUG - 2019-07-19 19:34:24 --> UTF-8 Support Enabled
INFO - 2019-07-19 19:34:24 --> Utf8 Class Initialized
INFO - 2019-07-19 19:34:24 --> URI Class Initialized
INFO - 2019-07-19 19:34:24 --> Router Class Initialized
INFO - 2019-07-19 19:34:24 --> Output Class Initialized
INFO - 2019-07-19 19:34:24 --> Security Class Initialized
DEBUG - 2019-07-19 19:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 19:34:24 --> Input Class Initialized
INFO - 2019-07-19 19:34:24 --> Language Class Initialized
INFO - 2019-07-19 19:34:24 --> Loader Class Initialized
INFO - 2019-07-19 19:34:24 --> Database Driver Class Initialized
INFO - 2019-07-19 19:34:24 --> Controller Class Initialized
INFO - 2019-07-19 19:34:24 --> Model "Product" initialized
INFO - 2019-07-19 19:34:24 --> Final output sent to browser
DEBUG - 2019-07-19 19:34:24 --> Total execution time: 0.0039
INFO - 2019-07-19 19:34:24 --> Config Class Initialized
INFO - 2019-07-19 19:34:24 --> Hooks Class Initialized
DEBUG - 2019-07-19 19:34:24 --> UTF-8 Support Enabled
INFO - 2019-07-19 19:34:24 --> Utf8 Class Initialized
INFO - 2019-07-19 19:34:24 --> URI Class Initialized
INFO - 2019-07-19 19:34:24 --> Router Class Initialized
INFO - 2019-07-19 19:34:24 --> Output Class Initialized
INFO - 2019-07-19 19:34:24 --> Security Class Initialized
DEBUG - 2019-07-19 19:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 19:34:24 --> Input Class Initialized
INFO - 2019-07-19 19:34:24 --> Language Class Initialized
INFO - 2019-07-19 19:34:24 --> Loader Class Initialized
INFO - 2019-07-19 19:34:24 --> Database Driver Class Initialized
INFO - 2019-07-19 19:34:24 --> Controller Class Initialized
INFO - 2019-07-19 19:34:24 --> Model "Product" initialized
ERROR - 2019-07-19 19:34:24 --> Severity: Notice --> Undefined index: password /var/www/html/mohan/dummy/mautic_ci_product/application/models/Product.php 18
ERROR - 2019-07-19 19:34:24 --> Severity: Notice --> Undefined variable: signup /var/www/html/mohan/dummy/mautic_ci_product/application/controllers/Welcome.php 65
INFO - 2019-07-19 19:34:24 --> Final output sent to browser
DEBUG - 2019-07-19 19:34:24 --> Total execution time: 0.0065
INFO - 2019-07-19 19:35:10 --> Config Class Initialized
INFO - 2019-07-19 19:35:10 --> Hooks Class Initialized
DEBUG - 2019-07-19 19:35:10 --> UTF-8 Support Enabled
INFO - 2019-07-19 19:35:10 --> Utf8 Class Initialized
INFO - 2019-07-19 19:35:10 --> URI Class Initialized
INFO - 2019-07-19 19:35:10 --> Router Class Initialized
INFO - 2019-07-19 19:35:10 --> Output Class Initialized
INFO - 2019-07-19 19:35:10 --> Security Class Initialized
DEBUG - 2019-07-19 19:35:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 19:35:10 --> Input Class Initialized
INFO - 2019-07-19 19:35:10 --> Language Class Initialized
INFO - 2019-07-19 19:35:10 --> Loader Class Initialized
INFO - 2019-07-19 19:35:10 --> Database Driver Class Initialized
INFO - 2019-07-19 19:35:10 --> Controller Class Initialized
INFO - 2019-07-19 19:35:10 --> Model "Product" initialized
INFO - 2019-07-19 19:35:10 --> Config Class Initialized
INFO - 2019-07-19 19:35:10 --> Hooks Class Initialized
DEBUG - 2019-07-19 19:35:10 --> UTF-8 Support Enabled
INFO - 2019-07-19 19:35:10 --> Utf8 Class Initialized
INFO - 2019-07-19 19:35:10 --> URI Class Initialized
INFO - 2019-07-19 19:35:10 --> Router Class Initialized
INFO - 2019-07-19 19:35:10 --> Output Class Initialized
INFO - 2019-07-19 19:35:10 --> Security Class Initialized
DEBUG - 2019-07-19 19:35:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 19:35:10 --> Input Class Initialized
INFO - 2019-07-19 19:35:10 --> Language Class Initialized
INFO - 2019-07-19 19:35:10 --> Loader Class Initialized
INFO - 2019-07-19 19:35:10 --> Database Driver Class Initialized
INFO - 2019-07-19 19:35:10 --> Controller Class Initialized
INFO - 2019-07-19 19:35:10 --> Model "Product" initialized
INFO - 2019-07-19 19:37:25 --> Config Class Initialized
INFO - 2019-07-19 19:37:25 --> Hooks Class Initialized
DEBUG - 2019-07-19 19:37:25 --> UTF-8 Support Enabled
INFO - 2019-07-19 19:37:25 --> Utf8 Class Initialized
INFO - 2019-07-19 19:37:25 --> URI Class Initialized
INFO - 2019-07-19 19:37:25 --> Router Class Initialized
INFO - 2019-07-19 19:37:25 --> Output Class Initialized
INFO - 2019-07-19 19:37:25 --> Security Class Initialized
DEBUG - 2019-07-19 19:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 19:37:25 --> Input Class Initialized
INFO - 2019-07-19 19:37:25 --> Language Class Initialized
INFO - 2019-07-19 19:37:25 --> Loader Class Initialized
INFO - 2019-07-19 19:37:25 --> Database Driver Class Initialized
INFO - 2019-07-19 19:37:25 --> Controller Class Initialized
INFO - 2019-07-19 19:37:25 --> Model "Product" initialized
INFO - 2019-07-19 19:37:25 --> Config Class Initialized
INFO - 2019-07-19 19:37:25 --> Hooks Class Initialized
DEBUG - 2019-07-19 19:37:25 --> UTF-8 Support Enabled
INFO - 2019-07-19 19:37:25 --> Utf8 Class Initialized
INFO - 2019-07-19 19:37:25 --> URI Class Initialized
INFO - 2019-07-19 19:37:25 --> Router Class Initialized
INFO - 2019-07-19 19:37:25 --> Output Class Initialized
INFO - 2019-07-19 19:37:25 --> Security Class Initialized
DEBUG - 2019-07-19 19:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 19:37:25 --> Input Class Initialized
INFO - 2019-07-19 19:37:25 --> Language Class Initialized
INFO - 2019-07-19 19:37:25 --> Loader Class Initialized
INFO - 2019-07-19 19:37:25 --> Database Driver Class Initialized
INFO - 2019-07-19 19:37:25 --> Controller Class Initialized
INFO - 2019-07-19 19:37:25 --> Model "Product" initialized
INFO - 2019-07-19 19:37:59 --> Config Class Initialized
INFO - 2019-07-19 19:37:59 --> Hooks Class Initialized
DEBUG - 2019-07-19 19:37:59 --> UTF-8 Support Enabled
INFO - 2019-07-19 19:37:59 --> Utf8 Class Initialized
INFO - 2019-07-19 19:37:59 --> URI Class Initialized
INFO - 2019-07-19 19:37:59 --> Router Class Initialized
INFO - 2019-07-19 19:37:59 --> Output Class Initialized
INFO - 2019-07-19 19:37:59 --> Security Class Initialized
DEBUG - 2019-07-19 19:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 19:37:59 --> Input Class Initialized
INFO - 2019-07-19 19:37:59 --> Language Class Initialized
INFO - 2019-07-19 19:37:59 --> Loader Class Initialized
INFO - 2019-07-19 19:37:59 --> Database Driver Class Initialized
INFO - 2019-07-19 19:37:59 --> Controller Class Initialized
INFO - 2019-07-19 19:37:59 --> Model "Product" initialized
INFO - 2019-07-19 19:37:59 --> Config Class Initialized
INFO - 2019-07-19 19:37:59 --> Hooks Class Initialized
DEBUG - 2019-07-19 19:37:59 --> UTF-8 Support Enabled
INFO - 2019-07-19 19:37:59 --> Utf8 Class Initialized
INFO - 2019-07-19 19:37:59 --> URI Class Initialized
INFO - 2019-07-19 19:37:59 --> Router Class Initialized
INFO - 2019-07-19 19:37:59 --> Output Class Initialized
INFO - 2019-07-19 19:37:59 --> Security Class Initialized
DEBUG - 2019-07-19 19:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 19:37:59 --> Input Class Initialized
INFO - 2019-07-19 19:37:59 --> Language Class Initialized
INFO - 2019-07-19 19:37:59 --> Loader Class Initialized
INFO - 2019-07-19 19:37:59 --> Database Driver Class Initialized
INFO - 2019-07-19 19:37:59 --> Controller Class Initialized
INFO - 2019-07-19 19:37:59 --> Model "Product" initialized
INFO - 2019-07-19 19:39:00 --> Config Class Initialized
INFO - 2019-07-19 19:39:00 --> Hooks Class Initialized
DEBUG - 2019-07-19 19:39:00 --> UTF-8 Support Enabled
INFO - 2019-07-19 19:39:00 --> Utf8 Class Initialized
INFO - 2019-07-19 19:39:00 --> URI Class Initialized
INFO - 2019-07-19 19:39:00 --> Router Class Initialized
INFO - 2019-07-19 19:39:00 --> Output Class Initialized
INFO - 2019-07-19 19:39:00 --> Security Class Initialized
DEBUG - 2019-07-19 19:39:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 19:39:00 --> Input Class Initialized
INFO - 2019-07-19 19:39:00 --> Language Class Initialized
INFO - 2019-07-19 19:39:00 --> Loader Class Initialized
INFO - 2019-07-19 19:39:00 --> Database Driver Class Initialized
INFO - 2019-07-19 19:39:00 --> Controller Class Initialized
INFO - 2019-07-19 19:39:00 --> Model "Product" initialized
INFO - 2019-07-19 19:39:00 --> Config Class Initialized
INFO - 2019-07-19 19:39:00 --> Hooks Class Initialized
DEBUG - 2019-07-19 19:39:00 --> UTF-8 Support Enabled
INFO - 2019-07-19 19:39:00 --> Utf8 Class Initialized
INFO - 2019-07-19 19:39:00 --> URI Class Initialized
INFO - 2019-07-19 19:39:00 --> Router Class Initialized
INFO - 2019-07-19 19:39:00 --> Output Class Initialized
INFO - 2019-07-19 19:39:00 --> Security Class Initialized
DEBUG - 2019-07-19 19:39:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 19:39:00 --> Input Class Initialized
INFO - 2019-07-19 19:39:00 --> Language Class Initialized
INFO - 2019-07-19 19:39:00 --> Loader Class Initialized
INFO - 2019-07-19 19:39:00 --> Database Driver Class Initialized
INFO - 2019-07-19 19:39:00 --> Controller Class Initialized
INFO - 2019-07-19 19:39:00 --> Model "Product" initialized
INFO - 2019-07-19 19:39:32 --> Config Class Initialized
INFO - 2019-07-19 19:39:32 --> Hooks Class Initialized
DEBUG - 2019-07-19 19:39:32 --> UTF-8 Support Enabled
INFO - 2019-07-19 19:39:32 --> Utf8 Class Initialized
INFO - 2019-07-19 19:39:32 --> URI Class Initialized
INFO - 2019-07-19 19:39:32 --> Router Class Initialized
INFO - 2019-07-19 19:39:32 --> Output Class Initialized
INFO - 2019-07-19 19:39:32 --> Security Class Initialized
DEBUG - 2019-07-19 19:39:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 19:39:32 --> Input Class Initialized
INFO - 2019-07-19 19:39:32 --> Language Class Initialized
INFO - 2019-07-19 19:39:32 --> Loader Class Initialized
INFO - 2019-07-19 19:39:32 --> Database Driver Class Initialized
INFO - 2019-07-19 19:39:32 --> Controller Class Initialized
INFO - 2019-07-19 19:39:32 --> Model "Product" initialized
INFO - 2019-07-19 19:39:32 --> Final output sent to browser
DEBUG - 2019-07-19 19:39:32 --> Total execution time: 0.0045
INFO - 2019-07-19 19:39:32 --> Config Class Initialized
INFO - 2019-07-19 19:39:32 --> Hooks Class Initialized
DEBUG - 2019-07-19 19:39:32 --> UTF-8 Support Enabled
INFO - 2019-07-19 19:39:32 --> Utf8 Class Initialized
INFO - 2019-07-19 19:39:32 --> URI Class Initialized
INFO - 2019-07-19 19:39:32 --> Router Class Initialized
INFO - 2019-07-19 19:39:32 --> Output Class Initialized
INFO - 2019-07-19 19:39:32 --> Security Class Initialized
DEBUG - 2019-07-19 19:39:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 19:39:32 --> Input Class Initialized
INFO - 2019-07-19 19:39:32 --> Language Class Initialized
INFO - 2019-07-19 19:39:32 --> Loader Class Initialized
INFO - 2019-07-19 19:39:32 --> Database Driver Class Initialized
INFO - 2019-07-19 19:39:32 --> Controller Class Initialized
INFO - 2019-07-19 19:39:32 --> Model "Product" initialized
ERROR - 2019-07-19 19:39:32 --> Severity: Notice --> Undefined index: password /var/www/html/mohan/dummy/mautic_ci_product/application/models/Product.php 18
ERROR - 2019-07-19 19:39:32 --> Severity: Notice --> Undefined variable: signup /var/www/html/mohan/dummy/mautic_ci_product/application/controllers/Welcome.php 65
INFO - 2019-07-19 19:39:32 --> Final output sent to browser
DEBUG - 2019-07-19 19:39:32 --> Total execution time: 0.0055
INFO - 2019-07-19 19:40:27 --> Config Class Initialized
INFO - 2019-07-19 19:40:27 --> Hooks Class Initialized
DEBUG - 2019-07-19 19:40:27 --> UTF-8 Support Enabled
INFO - 2019-07-19 19:40:27 --> Utf8 Class Initialized
INFO - 2019-07-19 19:40:27 --> URI Class Initialized
INFO - 2019-07-19 19:40:27 --> Router Class Initialized
INFO - 2019-07-19 19:40:27 --> Output Class Initialized
INFO - 2019-07-19 19:40:27 --> Security Class Initialized
DEBUG - 2019-07-19 19:40:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 19:40:27 --> Input Class Initialized
INFO - 2019-07-19 19:40:27 --> Language Class Initialized
INFO - 2019-07-19 19:40:27 --> Loader Class Initialized
INFO - 2019-07-19 19:40:27 --> Database Driver Class Initialized
INFO - 2019-07-19 19:40:27 --> Controller Class Initialized
INFO - 2019-07-19 19:40:27 --> Model "Product" initialized
INFO - 2019-07-19 19:40:27 --> Final output sent to browser
DEBUG - 2019-07-19 19:40:27 --> Total execution time: 0.0052
INFO - 2019-07-19 19:40:27 --> Config Class Initialized
INFO - 2019-07-19 19:40:27 --> Hooks Class Initialized
DEBUG - 2019-07-19 19:40:27 --> UTF-8 Support Enabled
INFO - 2019-07-19 19:40:27 --> Utf8 Class Initialized
INFO - 2019-07-19 19:40:27 --> URI Class Initialized
INFO - 2019-07-19 19:40:27 --> Router Class Initialized
INFO - 2019-07-19 19:40:27 --> Output Class Initialized
INFO - 2019-07-19 19:40:27 --> Security Class Initialized
DEBUG - 2019-07-19 19:40:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 19:40:27 --> Input Class Initialized
INFO - 2019-07-19 19:40:27 --> Language Class Initialized
INFO - 2019-07-19 19:40:27 --> Loader Class Initialized
INFO - 2019-07-19 19:40:27 --> Database Driver Class Initialized
INFO - 2019-07-19 19:40:27 --> Controller Class Initialized
INFO - 2019-07-19 19:40:27 --> Model "Product" initialized
ERROR - 2019-07-19 19:40:27 --> Severity: Notice --> Undefined variable: signup /var/www/html/mohan/dummy/mautic_ci_product/application/controllers/Welcome.php 65
INFO - 2019-07-19 19:40:27 --> Final output sent to browser
DEBUG - 2019-07-19 19:40:27 --> Total execution time: 0.0057
INFO - 2019-07-19 19:41:03 --> Config Class Initialized
INFO - 2019-07-19 19:41:03 --> Hooks Class Initialized
DEBUG - 2019-07-19 19:41:03 --> UTF-8 Support Enabled
INFO - 2019-07-19 19:41:03 --> Utf8 Class Initialized
INFO - 2019-07-19 19:41:03 --> URI Class Initialized
INFO - 2019-07-19 19:41:03 --> Router Class Initialized
INFO - 2019-07-19 19:41:03 --> Output Class Initialized
INFO - 2019-07-19 19:41:03 --> Security Class Initialized
DEBUG - 2019-07-19 19:41:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 19:41:03 --> Input Class Initialized
INFO - 2019-07-19 19:41:03 --> Language Class Initialized
ERROR - 2019-07-19 19:41:03 --> Severity: Parsing Error --> syntax error, unexpected '$ode' (T_VARIABLE), expecting ',' or ';' /var/www/html/mohan/dummy/mautic_ci_product/application/controllers/Welcome.php 66
INFO - 2019-07-19 19:42:22 --> Config Class Initialized
INFO - 2019-07-19 19:42:22 --> Hooks Class Initialized
DEBUG - 2019-07-19 19:42:22 --> UTF-8 Support Enabled
INFO - 2019-07-19 19:42:22 --> Utf8 Class Initialized
INFO - 2019-07-19 19:42:22 --> URI Class Initialized
INFO - 2019-07-19 19:42:22 --> Router Class Initialized
INFO - 2019-07-19 19:42:22 --> Output Class Initialized
INFO - 2019-07-19 19:42:22 --> Security Class Initialized
DEBUG - 2019-07-19 19:42:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 19:42:22 --> Input Class Initialized
INFO - 2019-07-19 19:42:22 --> Language Class Initialized
INFO - 2019-07-19 19:42:22 --> Loader Class Initialized
INFO - 2019-07-19 19:42:22 --> Database Driver Class Initialized
INFO - 2019-07-19 19:42:22 --> Controller Class Initialized
INFO - 2019-07-19 19:42:22 --> Model "Product" initialized
INFO - 2019-07-19 19:42:22 --> Final output sent to browser
DEBUG - 2019-07-19 19:42:22 --> Total execution time: 0.0055
INFO - 2019-07-19 19:42:22 --> Config Class Initialized
INFO - 2019-07-19 19:42:22 --> Hooks Class Initialized
DEBUG - 2019-07-19 19:42:22 --> UTF-8 Support Enabled
INFO - 2019-07-19 19:42:22 --> Utf8 Class Initialized
INFO - 2019-07-19 19:42:22 --> URI Class Initialized
INFO - 2019-07-19 19:42:22 --> Router Class Initialized
INFO - 2019-07-19 19:42:22 --> Output Class Initialized
INFO - 2019-07-19 19:42:22 --> Security Class Initialized
DEBUG - 2019-07-19 19:42:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 19:42:22 --> Input Class Initialized
INFO - 2019-07-19 19:42:22 --> Language Class Initialized
INFO - 2019-07-19 19:42:22 --> Loader Class Initialized
INFO - 2019-07-19 19:42:22 --> Database Driver Class Initialized
INFO - 2019-07-19 19:42:22 --> Controller Class Initialized
INFO - 2019-07-19 19:42:22 --> Model "Product" initialized
INFO - 2019-07-19 19:42:36 --> Config Class Initialized
INFO - 2019-07-19 19:42:36 --> Hooks Class Initialized
DEBUG - 2019-07-19 19:42:36 --> UTF-8 Support Enabled
INFO - 2019-07-19 19:42:36 --> Utf8 Class Initialized
INFO - 2019-07-19 19:42:36 --> URI Class Initialized
INFO - 2019-07-19 19:42:36 --> Router Class Initialized
INFO - 2019-07-19 19:42:36 --> Output Class Initialized
INFO - 2019-07-19 19:42:36 --> Security Class Initialized
DEBUG - 2019-07-19 19:42:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 19:42:36 --> Input Class Initialized
INFO - 2019-07-19 19:42:36 --> Language Class Initialized
INFO - 2019-07-19 19:42:36 --> Loader Class Initialized
INFO - 2019-07-19 19:42:36 --> Database Driver Class Initialized
INFO - 2019-07-19 19:42:36 --> Controller Class Initialized
INFO - 2019-07-19 19:42:36 --> Model "Product" initialized
INFO - 2019-07-19 19:42:36 --> Final output sent to browser
DEBUG - 2019-07-19 19:42:36 --> Total execution time: 0.0045
INFO - 2019-07-19 19:42:36 --> Config Class Initialized
INFO - 2019-07-19 19:42:36 --> Hooks Class Initialized
DEBUG - 2019-07-19 19:42:36 --> UTF-8 Support Enabled
INFO - 2019-07-19 19:42:36 --> Utf8 Class Initialized
INFO - 2019-07-19 19:42:36 --> URI Class Initialized
INFO - 2019-07-19 19:42:36 --> Router Class Initialized
INFO - 2019-07-19 19:42:36 --> Output Class Initialized
INFO - 2019-07-19 19:42:36 --> Security Class Initialized
DEBUG - 2019-07-19 19:42:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 19:42:36 --> Input Class Initialized
INFO - 2019-07-19 19:42:36 --> Language Class Initialized
INFO - 2019-07-19 19:42:36 --> Loader Class Initialized
INFO - 2019-07-19 19:42:36 --> Database Driver Class Initialized
INFO - 2019-07-19 19:42:36 --> Controller Class Initialized
INFO - 2019-07-19 19:42:36 --> Model "Product" initialized
ERROR - 2019-07-19 19:42:36 --> Severity: Notice --> Undefined variable: signup /var/www/html/mohan/dummy/mautic_ci_product/application/controllers/Welcome.php 66
INFO - 2019-07-19 19:42:36 --> Final output sent to browser
DEBUG - 2019-07-19 19:42:36 --> Total execution time: 0.0053
INFO - 2019-07-19 19:43:11 --> Config Class Initialized
INFO - 2019-07-19 19:43:11 --> Hooks Class Initialized
DEBUG - 2019-07-19 19:43:11 --> UTF-8 Support Enabled
INFO - 2019-07-19 19:43:11 --> Utf8 Class Initialized
INFO - 2019-07-19 19:43:11 --> URI Class Initialized
INFO - 2019-07-19 19:43:11 --> Router Class Initialized
INFO - 2019-07-19 19:43:11 --> Output Class Initialized
INFO - 2019-07-19 19:43:11 --> Security Class Initialized
DEBUG - 2019-07-19 19:43:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 19:43:11 --> Input Class Initialized
INFO - 2019-07-19 19:43:11 --> Language Class Initialized
INFO - 2019-07-19 19:43:11 --> Loader Class Initialized
INFO - 2019-07-19 19:43:11 --> Database Driver Class Initialized
INFO - 2019-07-19 19:43:11 --> Controller Class Initialized
INFO - 2019-07-19 19:43:11 --> Model "Product" initialized
INFO - 2019-07-19 19:43:11 --> Final output sent to browser
DEBUG - 2019-07-19 19:43:11 --> Total execution time: 0.0080
INFO - 2019-07-19 19:43:11 --> Config Class Initialized
INFO - 2019-07-19 19:43:11 --> Hooks Class Initialized
DEBUG - 2019-07-19 19:43:11 --> UTF-8 Support Enabled
INFO - 2019-07-19 19:43:11 --> Utf8 Class Initialized
INFO - 2019-07-19 19:43:11 --> URI Class Initialized
INFO - 2019-07-19 19:43:11 --> Router Class Initialized
INFO - 2019-07-19 19:43:11 --> Output Class Initialized
INFO - 2019-07-19 19:43:11 --> Security Class Initialized
DEBUG - 2019-07-19 19:43:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 19:43:11 --> Input Class Initialized
INFO - 2019-07-19 19:43:11 --> Language Class Initialized
INFO - 2019-07-19 19:43:11 --> Loader Class Initialized
INFO - 2019-07-19 19:43:11 --> Database Driver Class Initialized
INFO - 2019-07-19 19:43:11 --> Controller Class Initialized
INFO - 2019-07-19 19:43:11 --> Model "Product" initialized
INFO - 2019-07-19 19:43:36 --> Config Class Initialized
INFO - 2019-07-19 19:43:36 --> Hooks Class Initialized
DEBUG - 2019-07-19 19:43:36 --> UTF-8 Support Enabled
INFO - 2019-07-19 19:43:36 --> Utf8 Class Initialized
INFO - 2019-07-19 19:43:36 --> URI Class Initialized
INFO - 2019-07-19 19:43:36 --> Router Class Initialized
INFO - 2019-07-19 19:43:36 --> Output Class Initialized
INFO - 2019-07-19 19:43:36 --> Security Class Initialized
DEBUG - 2019-07-19 19:43:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 19:43:36 --> Input Class Initialized
INFO - 2019-07-19 19:43:36 --> Language Class Initialized
INFO - 2019-07-19 19:43:36 --> Loader Class Initialized
INFO - 2019-07-19 19:43:36 --> Database Driver Class Initialized
INFO - 2019-07-19 19:43:36 --> Controller Class Initialized
INFO - 2019-07-19 19:43:36 --> Model "Product" initialized
INFO - 2019-07-19 19:43:36 --> Final output sent to browser
DEBUG - 2019-07-19 19:43:36 --> Total execution time: 0.0071
INFO - 2019-07-19 19:43:36 --> Config Class Initialized
INFO - 2019-07-19 19:43:36 --> Hooks Class Initialized
DEBUG - 2019-07-19 19:43:36 --> UTF-8 Support Enabled
INFO - 2019-07-19 19:43:36 --> Utf8 Class Initialized
INFO - 2019-07-19 19:43:36 --> URI Class Initialized
INFO - 2019-07-19 19:43:36 --> Router Class Initialized
INFO - 2019-07-19 19:43:36 --> Output Class Initialized
INFO - 2019-07-19 19:43:36 --> Security Class Initialized
DEBUG - 2019-07-19 19:43:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 19:43:36 --> Input Class Initialized
INFO - 2019-07-19 19:43:36 --> Language Class Initialized
INFO - 2019-07-19 19:43:36 --> Loader Class Initialized
INFO - 2019-07-19 19:43:36 --> Database Driver Class Initialized
INFO - 2019-07-19 19:43:36 --> Controller Class Initialized
INFO - 2019-07-19 19:43:36 --> Model "Product" initialized
ERROR - 2019-07-19 19:43:36 --> Severity: Notice --> Undefined index: password /var/www/html/mohan/dummy/mautic_ci_product/application/models/Product.php 19
ERROR - 2019-07-19 19:43:36 --> Severity: Notice --> Undefined property: Welcome::$sb /var/www/html/mohan/dummy/mautic_ci_product/system/core/Model.php 73
ERROR - 2019-07-19 19:43:36 --> Severity: Error --> Call to a member function last_query() on null /var/www/html/mohan/dummy/mautic_ci_product/application/models/Product.php 21
INFO - 2019-07-19 19:43:51 --> Config Class Initialized
INFO - 2019-07-19 19:43:51 --> Hooks Class Initialized
DEBUG - 2019-07-19 19:43:51 --> UTF-8 Support Enabled
INFO - 2019-07-19 19:43:51 --> Utf8 Class Initialized
INFO - 2019-07-19 19:43:51 --> URI Class Initialized
INFO - 2019-07-19 19:43:51 --> Router Class Initialized
INFO - 2019-07-19 19:43:51 --> Output Class Initialized
INFO - 2019-07-19 19:43:51 --> Security Class Initialized
DEBUG - 2019-07-19 19:43:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 19:43:51 --> Input Class Initialized
INFO - 2019-07-19 19:43:51 --> Language Class Initialized
INFO - 2019-07-19 19:43:51 --> Loader Class Initialized
INFO - 2019-07-19 19:43:51 --> Database Driver Class Initialized
INFO - 2019-07-19 19:43:51 --> Controller Class Initialized
INFO - 2019-07-19 19:43:51 --> Model "Product" initialized
INFO - 2019-07-19 19:43:51 --> Final output sent to browser
DEBUG - 2019-07-19 19:43:51 --> Total execution time: 0.0064
INFO - 2019-07-19 19:43:51 --> Config Class Initialized
INFO - 2019-07-19 19:43:51 --> Hooks Class Initialized
DEBUG - 2019-07-19 19:43:51 --> UTF-8 Support Enabled
INFO - 2019-07-19 19:43:51 --> Utf8 Class Initialized
INFO - 2019-07-19 19:43:51 --> URI Class Initialized
INFO - 2019-07-19 19:43:51 --> Router Class Initialized
INFO - 2019-07-19 19:43:51 --> Output Class Initialized
INFO - 2019-07-19 19:43:51 --> Security Class Initialized
DEBUG - 2019-07-19 19:43:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 19:43:51 --> Input Class Initialized
INFO - 2019-07-19 19:43:51 --> Language Class Initialized
INFO - 2019-07-19 19:43:51 --> Loader Class Initialized
INFO - 2019-07-19 19:43:51 --> Database Driver Class Initialized
INFO - 2019-07-19 19:43:51 --> Controller Class Initialized
INFO - 2019-07-19 19:43:51 --> Model "Product" initialized
ERROR - 2019-07-19 19:43:51 --> Severity: Notice --> Undefined index: password /var/www/html/mohan/dummy/mautic_ci_product/application/models/Product.php 19
INFO - 2019-07-19 19:44:36 --> Config Class Initialized
INFO - 2019-07-19 19:44:36 --> Hooks Class Initialized
DEBUG - 2019-07-19 19:44:36 --> UTF-8 Support Enabled
INFO - 2019-07-19 19:44:36 --> Utf8 Class Initialized
INFO - 2019-07-19 19:44:36 --> URI Class Initialized
INFO - 2019-07-19 19:44:36 --> Router Class Initialized
INFO - 2019-07-19 19:44:36 --> Output Class Initialized
INFO - 2019-07-19 19:44:36 --> Security Class Initialized
DEBUG - 2019-07-19 19:44:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 19:44:36 --> Input Class Initialized
INFO - 2019-07-19 19:44:36 --> Language Class Initialized
INFO - 2019-07-19 19:44:36 --> Loader Class Initialized
INFO - 2019-07-19 19:44:36 --> Database Driver Class Initialized
INFO - 2019-07-19 19:44:36 --> Controller Class Initialized
INFO - 2019-07-19 19:44:36 --> Model "Product" initialized
INFO - 2019-07-19 19:44:36 --> Final output sent to browser
DEBUG - 2019-07-19 19:44:36 --> Total execution time: 0.0059
INFO - 2019-07-19 19:44:36 --> Config Class Initialized
INFO - 2019-07-19 19:44:36 --> Hooks Class Initialized
DEBUG - 2019-07-19 19:44:36 --> UTF-8 Support Enabled
INFO - 2019-07-19 19:44:36 --> Utf8 Class Initialized
INFO - 2019-07-19 19:44:36 --> URI Class Initialized
INFO - 2019-07-19 19:44:36 --> Router Class Initialized
INFO - 2019-07-19 19:44:36 --> Output Class Initialized
INFO - 2019-07-19 19:44:36 --> Security Class Initialized
DEBUG - 2019-07-19 19:44:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 19:44:36 --> Input Class Initialized
INFO - 2019-07-19 19:44:36 --> Language Class Initialized
INFO - 2019-07-19 19:44:36 --> Loader Class Initialized
INFO - 2019-07-19 19:44:36 --> Database Driver Class Initialized
INFO - 2019-07-19 19:44:36 --> Controller Class Initialized
INFO - 2019-07-19 19:44:36 --> Model "Product" initialized
INFO - 2019-07-19 19:45:00 --> Config Class Initialized
INFO - 2019-07-19 19:45:00 --> Hooks Class Initialized
DEBUG - 2019-07-19 19:45:00 --> UTF-8 Support Enabled
INFO - 2019-07-19 19:45:00 --> Utf8 Class Initialized
INFO - 2019-07-19 19:45:00 --> URI Class Initialized
INFO - 2019-07-19 19:45:00 --> Router Class Initialized
INFO - 2019-07-19 19:45:00 --> Output Class Initialized
INFO - 2019-07-19 19:45:00 --> Security Class Initialized
DEBUG - 2019-07-19 19:45:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 19:45:00 --> Input Class Initialized
INFO - 2019-07-19 19:45:00 --> Language Class Initialized
INFO - 2019-07-19 19:45:00 --> Loader Class Initialized
INFO - 2019-07-19 19:45:00 --> Database Driver Class Initialized
INFO - 2019-07-19 19:45:00 --> Controller Class Initialized
INFO - 2019-07-19 19:45:00 --> Model "Product" initialized
INFO - 2019-07-19 19:45:00 --> Final output sent to browser
DEBUG - 2019-07-19 19:45:00 --> Total execution time: 0.0056
INFO - 2019-07-19 19:45:00 --> Config Class Initialized
INFO - 2019-07-19 19:45:00 --> Hooks Class Initialized
DEBUG - 2019-07-19 19:45:00 --> UTF-8 Support Enabled
INFO - 2019-07-19 19:45:00 --> Utf8 Class Initialized
INFO - 2019-07-19 19:45:00 --> URI Class Initialized
INFO - 2019-07-19 19:45:00 --> Router Class Initialized
INFO - 2019-07-19 19:45:00 --> Output Class Initialized
INFO - 2019-07-19 19:45:00 --> Security Class Initialized
DEBUG - 2019-07-19 19:45:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 19:45:00 --> Input Class Initialized
INFO - 2019-07-19 19:45:00 --> Language Class Initialized
INFO - 2019-07-19 19:45:00 --> Loader Class Initialized
INFO - 2019-07-19 19:45:00 --> Database Driver Class Initialized
INFO - 2019-07-19 19:45:00 --> Controller Class Initialized
INFO - 2019-07-19 19:45:00 --> Model "Product" initialized
ERROR - 2019-07-19 19:45:00 --> Severity: Notice --> Undefined variable: signup /var/www/html/mohan/dummy/mautic_ci_product/application/controllers/Welcome.php 65
INFO - 2019-07-19 19:45:00 --> Final output sent to browser
DEBUG - 2019-07-19 19:45:00 --> Total execution time: 0.0093
INFO - 2019-07-19 19:45:16 --> Config Class Initialized
INFO - 2019-07-19 19:45:16 --> Hooks Class Initialized
DEBUG - 2019-07-19 19:45:16 --> UTF-8 Support Enabled
INFO - 2019-07-19 19:45:16 --> Utf8 Class Initialized
INFO - 2019-07-19 19:45:16 --> URI Class Initialized
INFO - 2019-07-19 19:45:16 --> Router Class Initialized
INFO - 2019-07-19 19:45:16 --> Output Class Initialized
INFO - 2019-07-19 19:45:16 --> Security Class Initialized
DEBUG - 2019-07-19 19:45:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 19:45:16 --> Input Class Initialized
INFO - 2019-07-19 19:45:16 --> Language Class Initialized
INFO - 2019-07-19 19:45:16 --> Loader Class Initialized
INFO - 2019-07-19 19:45:16 --> Database Driver Class Initialized
INFO - 2019-07-19 19:45:16 --> Controller Class Initialized
INFO - 2019-07-19 19:45:16 --> Model "Product" initialized
INFO - 2019-07-19 19:45:16 --> Final output sent to browser
DEBUG - 2019-07-19 19:45:16 --> Total execution time: 0.0061
INFO - 2019-07-19 19:45:16 --> Config Class Initialized
INFO - 2019-07-19 19:45:16 --> Hooks Class Initialized
DEBUG - 2019-07-19 19:45:16 --> UTF-8 Support Enabled
INFO - 2019-07-19 19:45:16 --> Utf8 Class Initialized
INFO - 2019-07-19 19:45:16 --> URI Class Initialized
INFO - 2019-07-19 19:45:16 --> Router Class Initialized
INFO - 2019-07-19 19:45:16 --> Output Class Initialized
INFO - 2019-07-19 19:45:16 --> Security Class Initialized
DEBUG - 2019-07-19 19:45:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 19:45:16 --> Input Class Initialized
INFO - 2019-07-19 19:45:16 --> Language Class Initialized
INFO - 2019-07-19 19:45:16 --> Loader Class Initialized
INFO - 2019-07-19 19:45:16 --> Database Driver Class Initialized
INFO - 2019-07-19 19:45:16 --> Controller Class Initialized
INFO - 2019-07-19 19:45:16 --> Model "Product" initialized
INFO - 2019-07-19 19:45:16 --> Final output sent to browser
DEBUG - 2019-07-19 19:45:16 --> Total execution time: 0.0081
INFO - 2019-07-19 19:45:28 --> Config Class Initialized
INFO - 2019-07-19 19:45:28 --> Hooks Class Initialized
DEBUG - 2019-07-19 19:45:28 --> UTF-8 Support Enabled
INFO - 2019-07-19 19:45:28 --> Utf8 Class Initialized
INFO - 2019-07-19 19:45:28 --> URI Class Initialized
INFO - 2019-07-19 19:45:28 --> Router Class Initialized
INFO - 2019-07-19 19:45:28 --> Output Class Initialized
INFO - 2019-07-19 19:45:28 --> Security Class Initialized
DEBUG - 2019-07-19 19:45:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 19:45:28 --> Input Class Initialized
INFO - 2019-07-19 19:45:28 --> Language Class Initialized
INFO - 2019-07-19 19:45:28 --> Loader Class Initialized
INFO - 2019-07-19 19:45:28 --> Database Driver Class Initialized
INFO - 2019-07-19 19:45:28 --> Controller Class Initialized
INFO - 2019-07-19 19:45:28 --> Model "Product" initialized
INFO - 2019-07-19 19:45:28 --> Final output sent to browser
DEBUG - 2019-07-19 19:45:28 --> Total execution time: 0.0052
INFO - 2019-07-19 19:45:28 --> Config Class Initialized
INFO - 2019-07-19 19:45:28 --> Hooks Class Initialized
DEBUG - 2019-07-19 19:45:28 --> UTF-8 Support Enabled
INFO - 2019-07-19 19:45:28 --> Utf8 Class Initialized
INFO - 2019-07-19 19:45:28 --> URI Class Initialized
INFO - 2019-07-19 19:45:28 --> Router Class Initialized
INFO - 2019-07-19 19:45:28 --> Output Class Initialized
INFO - 2019-07-19 19:45:28 --> Security Class Initialized
DEBUG - 2019-07-19 19:45:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 19:45:28 --> Input Class Initialized
INFO - 2019-07-19 19:45:28 --> Language Class Initialized
INFO - 2019-07-19 19:45:28 --> Loader Class Initialized
INFO - 2019-07-19 19:45:28 --> Database Driver Class Initialized
INFO - 2019-07-19 19:45:28 --> Controller Class Initialized
INFO - 2019-07-19 19:45:28 --> Model "Product" initialized
INFO - 2019-07-19 19:45:28 --> Final output sent to browser
DEBUG - 2019-07-19 19:45:28 --> Total execution time: 0.0085
INFO - 2019-07-19 19:45:30 --> Config Class Initialized
INFO - 2019-07-19 19:45:30 --> Hooks Class Initialized
DEBUG - 2019-07-19 19:45:30 --> UTF-8 Support Enabled
INFO - 2019-07-19 19:45:30 --> Utf8 Class Initialized
INFO - 2019-07-19 19:45:30 --> URI Class Initialized
INFO - 2019-07-19 19:45:30 --> Router Class Initialized
INFO - 2019-07-19 19:45:30 --> Output Class Initialized
INFO - 2019-07-19 19:45:30 --> Security Class Initialized
DEBUG - 2019-07-19 19:45:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 19:45:30 --> Input Class Initialized
INFO - 2019-07-19 19:45:30 --> Language Class Initialized
INFO - 2019-07-19 19:45:30 --> Loader Class Initialized
INFO - 2019-07-19 19:45:30 --> Database Driver Class Initialized
INFO - 2019-07-19 19:45:30 --> Controller Class Initialized
INFO - 2019-07-19 19:45:30 --> Model "Product" initialized
INFO - 2019-07-19 19:45:30 --> Final output sent to browser
DEBUG - 2019-07-19 19:45:30 --> Total execution time: 0.0055
INFO - 2019-07-19 19:47:15 --> Config Class Initialized
INFO - 2019-07-19 19:47:15 --> Hooks Class Initialized
DEBUG - 2019-07-19 19:47:15 --> UTF-8 Support Enabled
INFO - 2019-07-19 19:47:15 --> Utf8 Class Initialized
INFO - 2019-07-19 19:47:15 --> URI Class Initialized
INFO - 2019-07-19 19:47:15 --> Router Class Initialized
INFO - 2019-07-19 19:47:15 --> Output Class Initialized
INFO - 2019-07-19 19:47:15 --> Security Class Initialized
DEBUG - 2019-07-19 19:47:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 19:47:15 --> Input Class Initialized
INFO - 2019-07-19 19:47:15 --> Language Class Initialized
INFO - 2019-07-19 19:47:15 --> Loader Class Initialized
INFO - 2019-07-19 19:47:15 --> Database Driver Class Initialized
INFO - 2019-07-19 19:47:15 --> Controller Class Initialized
INFO - 2019-07-19 19:47:15 --> Model "Product" initialized
INFO - 2019-07-19 19:47:15 --> Final output sent to browser
DEBUG - 2019-07-19 19:47:15 --> Total execution time: 0.0050
INFO - 2019-07-19 19:47:15 --> Config Class Initialized
INFO - 2019-07-19 19:47:15 --> Hooks Class Initialized
DEBUG - 2019-07-19 19:47:15 --> UTF-8 Support Enabled
INFO - 2019-07-19 19:47:15 --> Utf8 Class Initialized
INFO - 2019-07-19 19:47:15 --> URI Class Initialized
INFO - 2019-07-19 19:47:15 --> Router Class Initialized
INFO - 2019-07-19 19:47:15 --> Output Class Initialized
INFO - 2019-07-19 19:47:15 --> Security Class Initialized
DEBUG - 2019-07-19 19:47:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 19:47:15 --> Input Class Initialized
INFO - 2019-07-19 19:47:15 --> Language Class Initialized
INFO - 2019-07-19 19:47:15 --> Loader Class Initialized
INFO - 2019-07-19 19:47:15 --> Database Driver Class Initialized
INFO - 2019-07-19 19:47:15 --> Controller Class Initialized
INFO - 2019-07-19 19:47:15 --> Model "Product" initialized
INFO - 2019-07-19 19:47:15 --> Final output sent to browser
DEBUG - 2019-07-19 19:47:15 --> Total execution time: 0.0082
INFO - 2019-07-19 19:47:28 --> Config Class Initialized
INFO - 2019-07-19 19:47:28 --> Hooks Class Initialized
DEBUG - 2019-07-19 19:47:28 --> UTF-8 Support Enabled
INFO - 2019-07-19 19:47:28 --> Utf8 Class Initialized
INFO - 2019-07-19 19:47:28 --> URI Class Initialized
INFO - 2019-07-19 19:47:28 --> Router Class Initialized
INFO - 2019-07-19 19:47:28 --> Output Class Initialized
INFO - 2019-07-19 19:47:28 --> Security Class Initialized
DEBUG - 2019-07-19 19:47:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 19:47:28 --> Input Class Initialized
INFO - 2019-07-19 19:47:28 --> Language Class Initialized
INFO - 2019-07-19 19:47:28 --> Loader Class Initialized
INFO - 2019-07-19 19:47:28 --> Database Driver Class Initialized
INFO - 2019-07-19 19:47:28 --> Controller Class Initialized
INFO - 2019-07-19 19:47:28 --> Model "Product" initialized
INFO - 2019-07-19 19:47:28 --> Final output sent to browser
DEBUG - 2019-07-19 19:47:28 --> Total execution time: 0.0065
INFO - 2019-07-19 19:47:28 --> Config Class Initialized
INFO - 2019-07-19 19:47:28 --> Hooks Class Initialized
DEBUG - 2019-07-19 19:47:28 --> UTF-8 Support Enabled
INFO - 2019-07-19 19:47:28 --> Utf8 Class Initialized
INFO - 2019-07-19 19:47:28 --> URI Class Initialized
INFO - 2019-07-19 19:47:28 --> Router Class Initialized
INFO - 2019-07-19 19:47:28 --> Output Class Initialized
INFO - 2019-07-19 19:47:28 --> Security Class Initialized
DEBUG - 2019-07-19 19:47:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-19 19:47:28 --> Input Class Initialized
INFO - 2019-07-19 19:47:28 --> Language Class Initialized
INFO - 2019-07-19 19:47:28 --> Loader Class Initialized
INFO - 2019-07-19 19:47:28 --> Database Driver Class Initialized
INFO - 2019-07-19 19:47:28 --> Controller Class Initialized
INFO - 2019-07-19 19:47:28 --> Model "Product" initialized
INFO - 2019-07-19 19:47:28 --> Final output sent to browser
DEBUG - 2019-07-19 19:47:28 --> Total execution time: 0.0079
