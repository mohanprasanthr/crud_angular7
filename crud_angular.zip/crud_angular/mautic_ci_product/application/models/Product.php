<?php
class Product extends CI_Model {

	public function signup_insert($data)
	{
		$result = $this->db->insert('prod_signup', $data);
		if($result){
			return TRUE;
		}else{
			return FALSE;
		}
	}
	
	public function signin($data)
	{
		
		$this->db->select('*');
		$this->db->where('email',$data['email']);
		$this->db->where('password',$data['password']);
		$query = $this->db->get('prod_signup');	
		if($query->num_rows() > 0){
			return TRUE;
		}else{
			return FALSE;
		}
	}
	public function getusers()
	{
		$this->db->select('*');
		 
		$query = $this->db->get('prod_signup');	
		if($query->num_rows() > 0){
			return $query->result_array();
		}else{
			return array();
		}	
	}
	public function getsingleuser($id)
	{
		$this->db->select('*');
		$this->db->where('id',$id);
		$query = $this->db->get('prod_signup');	
		if($query->num_rows() > 0){
			return $query->result_array();
		}else{
			return array();
		}	
	}

	public function signup_update($id,$data)
	{
		$this->db->where('id',$id);		
		$result=$this->db->update('prod_signup', $data);		
		if($result){
			return TRUE;
		}else{
			return FALSE;
		}
	}
}
?>
