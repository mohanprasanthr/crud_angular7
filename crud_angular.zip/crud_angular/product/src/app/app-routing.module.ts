import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SignupComponent } from './signup/signup.component';
import { LoginComponent } from './login/login.component';
import { NotFoundComponent } from './not-found/not-found.component';
import { UserListComponent } from './user-list/user-list.component';
import { AuthGuardService } from './auth-guard.service';
import { EditUserComponent } from './edit-user/edit-user.component';

const routes: Routes = [
  
  {path:'',component:LoginComponent},
  { path :'signup' , component : SignupComponent},
  { path : 'login', component:LoginComponent},
  {path : 'users',component:UserListComponent, canActivate : [AuthGuardService],
  children :[
    {path:'edit/:id',component : EditUserComponent}
  ]},
  { path : "**", component:NotFoundComponent}


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
