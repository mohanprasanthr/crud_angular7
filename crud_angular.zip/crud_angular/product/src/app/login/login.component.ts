import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { AuthService } from '../auth.service';
import { AuthGuardService } from '../auth-guard.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  allowUser = false;
  constructor(private logauth : AuthService, private authguard :AuthGuardService) { }

  ngOnInit() {
  }

  loginData = {
    email :'',
    password:''
  }

  loginForm = new FormGroup(
    {
      email : new FormControl(null),
      password : new FormControl(null)
    }
  );



  onLogin(){
    this.loginData.email = this.loginForm.value.email;
    this.loginData.password = this.loginForm.value.password;
    this.logauth.login(this.loginData)
    .subscribe(
      (data)=>{
        this.logauth.isAuthenticated(data);
      }
    );
    this.loginForm.reset();
  }
  
}
