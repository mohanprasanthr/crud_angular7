import { Component, OnInit } from '@angular/core';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-user-list',
  templateUrl: './user-list.component.html',
  styleUrls: ['./user-list.component.css']
})
export class UserListComponent implements OnInit {
 uslist :any ='';
 result =[];
  constructor(private auth:AuthService) { }
 
  ngOnInit() {
    this.listUsers();
  }
  listUsers(){
    this.auth.loadUser().subscribe(
      (data : {}) =>{
        let dataKeys = Object.keys(data);
        for(let prop of dataKeys){
          this.result.push(data[prop]);
        }
      }
    );
  }

}
