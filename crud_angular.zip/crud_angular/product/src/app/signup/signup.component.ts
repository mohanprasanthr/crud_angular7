import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  constructor(private auth : AuthService) { }

  ngOnInit() {
  }

  signupData = {
    name :'',
    email :'',
    password:'',
    gender :'',
    country :'',
    maritialStatus:''
  }
  signupForm = new FormGroup(
    {
      name : new FormControl(null),
      email : new FormControl(null),
      password : new FormControl(null),
      gender : new FormControl(null),
      country : new FormControl(null),
      maritialStatus : new FormControl(null),
    }
  );

  onSignup(){
    
    this.signupData.name = this.signupForm.value.name;
    this.signupData.email = this.signupForm.value.email;
    this.signupData.password = this.signupForm.value.password;
    this.signupData.gender = this.signupForm.value.gender;
    this.signupData.country = this.signupForm.value.country;
    this.signupData.maritialStatus = this.signupForm.value.maritialStatus ? '1':'0';
    this.auth.singup(this.signupData)
    .subscribe(
      (data)=>{
        // console.log(data);
      }
    );
    this.signupForm.reset();
  }
}
